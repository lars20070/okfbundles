---
type: Chapter
title: "Google Developer Documentation Style Guide"
description: "Editorial guidelines for writing clear and consistent technical documentation for developers."
resource: https://developers.google.com/style
tags: [guide, google, style]
timestamp: 2026-08-01T06:28:39Z
---

<!-- markdownlint-disable MD033 -->

<!-- markdownlint-disable-next-line MD025 -->
# Google Developer Documentation Style Guide

*Snapshot of [https://developers.google.com/style](https://developers.google.com/style) generated 2026-08-01.*

## Introduction

<a id="style"></a>

### About this guide

*Source: <https://developers.google.com/style>*

This style guide provides editorial guidelines for writing clear and consistent technical
documentation for an audience of software developers and other technical practitioners.

If you're new to the guide and looking for introductory topics about our style, then start with
[Highlights](#highlights), [Voice and tone](/general-principles/voice-and-tone.md), and
[Text-formatting summary](/key-resources/text-formatting.md). Otherwise, use the guide as
a reference document for specific questions. For example, you can look up terms in the
[word list](/key-resources/word-list.md).

<a id="style--editorial-resources"></a>

#### Editorial resources

We recommend using the following editorial resources.

<a id="style--reference-hierarchy"></a>

##### Reference hierarchy

Use the following references, including this guide, in this order:

1. **Project-specific style**. Follow style guidance specific to your project or product, such
   as necessary exceptions to this guide or terms that are relevant only to your product.
2. **This style guide**. If project-specific style guidelines don't provide explicit
   guidance, then follow this guide.
3. **Third-party references**. If the preceding references don't provide explicit guidance,
   then see these third-party references, depending on the nature of your question:

   | Type of question | Third-party reference |
   | --- | --- |
   | Spelling | Follow [Merriam-Webster.com](https://www.merriam-webster.com/). See also [Spelling](https://developers.google.com/style/spelling). |
   | Nontechnical style | Follow [*The Chicago Manual of Style*, 17th edition](https://www.chicagomanualofstyle.org/home.html) (subscription required). |
   | Technical style | See the [Microsoft Writing Style Guide](https://docs.microsoft.com/style-guide/welcome/). But consider whether Microsoft's guidance applies; some of it might apply only to Microsoft products and interfaces. |

At multiple stages of this hierarchy, it can be helpful to look to established usage. For
example, search your organization's documentation, or check a broad language corpus such
as [Google Ngram Viewer](https://books.google.com/ngrams/).

<a id="style--other-editorial-resources"></a>

##### Other editorial resources

You can use additional resources to research and inform your thinking, but don't consider them
part of Google developer documentation style.

Here are some other style guides from the tech community:

- [Apple Style Guide](https://help.apple.com/applestyleguide/)
- [Red Hat supplementary style guide for product documentation](https://redhat-documentation.github.io/supplementary-style-guide/)

<a id="style--annotations"></a>

<a id="style--annotations-used-in-this-guide"></a>

#### Annotations used in this guide

For guidance that applies only to Android or Google Cloud documentation, look for the following
logos:

- precedes terms and guidelines specific to Android
  documentation.
- precedes terms and guidelines specific to Google Cloud
  documentation.

<a id="style--rules"></a>

<a id="style--break-the-rules"></a>

#### Break the rules

> *Break any of these rules sooner than say anything outright barbarous.*
>
> —George Orwell,
> "[Politics and the English Language](https://www.orwellfoundation.com/the-orwell-foundation/orwell/essays-and-other-works/politics-and-the-english-language/)"

This guide contains guidelines, not rules. Depart from it when doing so improves your
content.

For example, if we recommend spelling a term as one word, and you determine that the
hyphenated version of a term in your domain is more appropriate for your readers, then
it's fine to use that instead. We acknowledge that sometimes there are competing forms
of the same word in wide use, especially as new terms emerge, and you might have good
reasons for departing from our guidance.

When you depart from this guide, be consistent throughout your document.

---

## Highlights

*Source: <https://developers.google.com/style/highlights>*

The style guide covers a lot of material, so the following page provides an overview of its most
important points. For more information about topics on the page, follow the links.

<a id="highlights--tone"></a>

<a id="highlights--tone-and-content"></a>

#### Tone and content

- [Be conversational and friendly](/general-principles/voice-and-tone.md) without being
  frivolous.
- [Don't pre-announce anything](/general-principles/future-features.md) in
  documentation.
- Use descriptive link text.
- [Write accessibly](/general-principles/accessibility.md).
- [Write for a global audience](/general-principles/global-audience.md).

<a id="highlights--language"></a>

<a id="highlights--language-and-grammar"></a>

#### Language and grammar

- Use second person: "you" rather than
  "we."
- Use active voice: make clear who's performing
  the action.
- [Use standard American spelling](https://developers.google.com/style/spelling) and
  punctuation.
- Put conditions before instructions,
  not after.
- [For usage and spelling of specific words, see
  the word list](/key-resources/word-list.md).

<a id="highlights--formatting"></a>

<a id="highlights--formattingu002c-punctuationu002c-and-organization"></a>

#### Formatting, punctuation, and organization

- Use sentence case for document
  titles and section headings.
- Use numbered lists for sequences.
- Use bulleted lists for most other lists.

- Use description lists for pairs of related
  pieces of data.
- [Use serial commas](https://developers.google.com/style/commas-serial).
- Put code-related text in code font.
- Put UI elements in bold.
- Use unambiguous date formatting.

<a id="highlights--images"></a>

#### Images

- Provide alt
  text.
- Provide high-resolution or vector
  images when practical.

---

## What's new

*Source: <https://developers.google.com/style/whats-new>*

This page provides a summary of significant changes to the style guide.

<a id="whats-new--20260707"></a>

<a id="whats-new--july-7u002c-2026"></a>

#### July 7, 2026

| New guidance or change | Page |
| --- | --- |
| Softened a statement regarding the effect of inconsistent terminology on translation costs. | [Write for a global audience](/general-principles/global-audience.md) |
| Added cross-references between guidance about optional procedure steps and guidance about optional headings. | Headings and titles,  Procedures |
| Clarified that much of our guidance about writing inclusive documentation relates to the broader principle of avoiding figurative language, which can be ableist or unnecessarily graphic. Instead, we use literal, precise terms in their primary sense. | [Write inclusive documentation](/general-principles/inclusive-language.md),  [Voice and tone](/general-principles/voice-and-tone.md),  [Word list](/key-resources/word-list.md) |
| Updated guidance about creating custom heading targets, making anchor (`<a>`) elements equally as acceptable as section (`<section>`) elements. | Make headings into link targets |
| Added guidance about ensuring that you contextualize UI elements when you document them outside of a numbered procedure. | UI elements and interaction |
| Added word list entry: *managed instance group (MIG)* | [Word list](/key-resources/word-list.md) |

<a id="whats-new--20260407"></a>

<a id="whats-new--april-7u002c-2026"></a>

#### April 7, 2026

| New guidance or change | Page |
| --- | --- |
| Added guidance about avoiding inconsistent end punctuation in list items. | [Lists](#lists) |
| Added *do the following* as a recommended phrase for introducing lists in procedures. | Procedures |
| Clarified that ordered lists are appropriate for any list where sequence is significant. Added guidance about ensuring that it's clear whether the items in an unordered list are required or optional. | [Lists](#lists) |
| Added guidance that if you must refer to a step number, use the numeral. | Numbers |
| Added guidance to use italics sparingly, and consolidated italics guidance into a new page. | Use italics to discuss terms,  [Text-formatting summary](/key-resources/text-formatting.md) |
| Added guidance recommending the terms *selected* and *not selected* to refer to the state of a checkbox. | UI elements and interaction |
| Changed guidance to recommend using code font for IP addresses and port numbers. Added package names to the list of items to place in code font. | Code in text |
| Updated UI elements guidance with expanded definitions for *pane*, *panel*, and *section*. Added guidance about how to identify difficult-to-find UI elements without using directional language. | UI elements and interaction |
| Added `.wasm` (Wasm file) to the table of file extensions and corresponding file type names. | Filenames and file types |
| Reorganized and extended guidance about formatting abbreviation introductions. | Abbreviations,  [Text-formatting summary](/key-resources/text-formatting.md) |
| Consolidated pluralization guidance into a new page, including guidance about abbreviations, product names, and code elements. | Pluralization |
| Restructured guidance about writing for a global audience to make it easier to navigate. | [Write for a global audience](/general-principles/global-audience.md) |
| Expanded guidance about exclamation marks to clarify that we avoid them except in rare cases. | Periods and other end punctuation,  [Voice and tone](/general-principles/voice-and-tone.md) |
| Created a page about how to format common mathematical notation. | Mathematical notation,  Numbers,  [Text-formatting summary](/key-resources/text-formatting.md),  Units of measurement |
| Changed guidance for temperatures to recommend a nonbreaking space between a numeral and the degree symbol instead of between the degree symbol and the temperature scale. | Units of measurement |
| Added guidance about marking headings as optional. Restructured headings guidance to make it easier to navigate. | Headings and titles |
| Added an entry for *AI*, specifying that it rarely needs to be spelled out. | [Word list](/key-resources/word-list.md),  Abbreviations |
| Clarified that the word *can* can be used to convey both permission and ability. | [Word list](/key-resources/word-list.md) |
| Clarified that when we mark a term "Use with caution" in the word list, we recommend following our standard jargon guidance. | [Word list](/key-resources/word-list.md) |
| Clarified how we prefer to distinguish between a *page* (the whole web page) and a *document* (the text on a page that explains a product, feature, or service). | [Word list](/key-resources/word-list.md) |
| Revised the entry for *style sheet* to also allow for *stylesheet*, prioritizing consistency in a document. | [Word list](/key-resources/word-list.md) |
| Added explanations to several existing word list items regarding compound word usage: *clickthrough*, *hardcode*, *high availability*, *load balancing*, *plugin*, *third-party*, *time zone*, and *wake lock*. | [Word list](/key-resources/word-list.md) |
| Expanded the entry for *first class*, *first-class*, *first-class citizen*, providing new recommended alternatives with examples. | [Word list](/key-resources/word-list.md),  [Write inclusive documentation](/general-principles/inclusive-language.md) |
| Expanded or added entries for *like*, *such as*, *for example*, and *for instance*. Made corresponding updates to the page about writing examples. | [Word list](/key-resources/word-list.md),  Format examples |
| Added guidance to the *virtual machine (VM) instance* entry regarding Compute Engine instances. | [Word list](/key-resources/word-list.md) |

<a id="whats-new--20250508"></a>

<a id="whats-new--may-8u002c-2025"></a>

#### May 8, 2025

| New guidance or change | Page |
| --- | --- |
| Removed outdated language that indicated that a list of options is treated differently than other unordered lists. | [Lists](#lists) |
| Added a page about writing prescriptive documentation. | [Prescriptive documentation](/general-principles/prescriptive-documentation.md), Word list |
| Removed guidance that said to include empty parentheses after method names. | Code in text |
| Changed footnotes guidance to recommend using numbers instead of symbols. | Footnotes |
| Simplified contractions guidance, removing excess explanations and examples. | Contractions |
| Added examples to guidance about introducing sections of a document. | Headings and titles |
| Added an example service account ID. | [Example domains and names](#examples) |
| Simplified and clarified guidance about articles, including using articles before abbreviations and product names. | Abbreviations, Articles (a, an, the), [Product names](/key-resources/product-names.md), [Word list](/key-resources/word-list.md) |
| Included a general explanation of why we don't document future features. | [Document future features](/general-principles/future-features.md) |
| Revised guidance to recommend using an abbreviation in a title or heading only if the abbreviation is the more commonly known version of the word. | Headings and titles |
| Added a suggestion that when you use an imperative in running text, consider whether to write a procedure instead. | Second person and first person |
| Generalized existing guidance on what to do when jargon is part of a command or code sample. | [Jargon](/general-principles/jargon.md) |
| Consolidated guidance about cross-references and linking into one page. | Cross-references and linking |
| Added some specific reasons why we avoid directional language when orienting the reader to information on a page. | [Write accessible documentation](/general-principles/accessibility.md) |
| Clarified that spacing around icons is a judgment call based on readability. | UI elements and interaction |
| Removed an example phone number. | [Example domains and names](#examples) |
| Removed the word list entry for *property* because its usage heavily depends on the technical context. | [Word list](/key-resources/word-list.md) |
| New word list entries: *choose*, *confidential*, *sensitive*, *image*, *Fast Healthcare Interoperability Resources (FHIR)* | [Word list](/key-resources/word-list.md) |

<a id="whats-new--20250117"></a>

<a id="whats-new--january-17u002c-2025"></a>

#### January 17, 2025

| New guidance or change | Page |
| --- | --- |
| Consolidated spelling guidance into the introduction to the word list. Extended guidance about how to use the preferred dictionary to determine which spelling to use for a word with multiple spellings. | [Word list](/key-resources/word-list.md) |
| Generalized guidance about when to use spaces or tabs for indentation in code samples. | Code samples |
| Changed guidance for formatting telephone numbers to recommend using dashes instead of parentheses to set the area code off from the rest of the number. | Format phone numbers |
| Extended and clarified recommendation to avoid the abbreviations *i.e.*, *e.g.*, and *etc.* in most cases. | Abbreviations, Comma-separated lists |

<a id="whats-new--20241029"></a>

<a id="whats-new--october-29u002c-2024"></a>

#### October 29, 2024

| New guidance or change | Page |
| --- | --- |
| Consolidated and expanded guidance about hyphens and closed compounds. | Hyphens |
| Added *hotspot* to the word list. | Word list |

<a id="whats-new--20240815"></a>

<a id="whats-new--august-15u002c-2024"></a>

#### August 15, 2024

| New guidance or change | Page |
| --- | --- |
| Added guidance for distinguishing between binary and decimal units, such as gibibytes (GiB) and gigabytes (GB). Also corrected abbreviation of *kilobyte* to *kB*. | Decimal and binary units |
| Expanded guidance for referring to figures and other images in text. Clarified that figure numbers are not required. | Figure captions |
| Added word list entries: *curl*, *whitepaper*, *long-running operation* | [Word list](/key-resources/word-list.md) |
| Updated word list entries: *ingest*, *execute*, *content type*, *media type*, *MIME* | [Word list](/key-resources/word-list.md) |

<a id="whats-new--20240516"></a>

<a id="whats-new--may-16u002c-2024"></a>

#### May 16, 2024

| New guidance or change | Page |
| --- | --- |
| Added the term *generative AI*. | Word list |
| Added the term *rehost*. Redirected the definition for *lift and shift* to *rehost*. | Word list |
| Clarified that the style guide shows examples of how placeholders render but doesn't explain how to implement this visual styling. | Format placeholders |
| Added an example to the guidance showing how to use site-root-relative URLs to link to another page on the same server. | [Cross-references](https://developers.google.com/style/cross-references#same-server) |
| Clarified guidance about how to format anchor text. | Make headings into link targets |

<a id="whats-new--20240321"></a>

<a id="whats-new--march-21u002c-2024"></a>

#### March 21, 2024

| New guidance or change | Page |
| --- | --- |
| Expanded guidance about avoidance of the term *drop-down*. | Word list |
| Added examples to guidance about writing documentation that focuses on the present state of the software. | [Timeless documentation](/general-principles/timeless-documentation.md) |
| Added recommendation to use a more precise term than *workload* when possible, or to define what the term means in the specific context.  Added related guidance about avoiding ambiguous or overloaded words like *workload*, *solution*, and *support*, or defining them in each context. | Word list,  [Jargon](/general-principles/jargon.md) |
| Aligned guidance with XML and HTML specifications to recommend against the use of angle brackets as part of an element name, but instead to only use angle brackets as part of a tag. | Code in text |

<a id="whats-new--20240122"></a>

<a id="whats-new--january-22u002c-2024"></a>

#### January 22, 2024

| New guidance or change | Page |
| --- | --- |
| Cleaned up word list by removing entries that only provided hyphenation, [spelling](https://developers.google.com/style/spelling), or abbreviation guidance that followed directly from our general guidance. | [Word list](https://developers.google.com/style/style/word-list) |
| Consolidated and clarified guidance regarding alt text, figure captions, and figure descriptions. | [Diagrams, figures, and other images](#images)  [Write accessible documentation](/general-principles/accessibility.md) |
| Added recommendation to avoid linking to other document sets from navigation controls such as a table of contents. | [Links to other sites](https://developers.google.com/style/links-external) |
| Clarified guidance about avoiding words such as *above* and *below* in references to documentation and user interfaces for accessibility reasons, and provided example of appropriate non-directional usage. | Word list |
| Removed prohibition against hyphenation of the phrase *open source*, so this term now follows our general guidance for hyphenation, which allows for hyphenation of an adjectival phrase to add clarity and remove ambiguity. | [Word list](https://developers.google.com/style/word-list#open-source) |
| Changed guidance for indicating the omission of code from an instructional code snippet to recommend the use of an explanatory comment instead of a mere ellipsis. | Code samples |

<a id="whats-new--20231108"></a>

<a id="whats-new--november-8u002c-2023"></a>

#### November 8, 2023

| New guidance or change | Page |
| --- | --- |
| Changed guidance regarding run-in headings in description lists to recommend that the punctuation (such as a colon) is not formatted as bold. Making the punctuation bold caused the punctuation to seem to be part of the heading string, which caused confusion in cases such as UI labels. | Lists |
| Removed the recommendation to use a special *external* icon (indicated by `class="external"`) for links. Readers and writers have expressed confusion about the meaning and usage of this icon. We strengthened guidance about using other, explicit means to inform the reader about the destination and behavior of a link. | [Link text](https://developers.google.com/style/link-text#write-link-text) |

<a id="whats-new--20231024"></a>

<a id="whats-new--october-24u002c-2023"></a>

#### October 24, 2023

| New guidance or change | Page |
| --- | --- |
| Removed page about custom font styling, which only said to use styles defined in the style sheet for the website. Redirected link to page about HTML formatting and semantic tagging. | [HTML and semantic tagging](https://developers.google.com/style/fonts) |
| Added word-list entry for *then* and expanded entry for *if* to recommend the use of the optional helper word *then* in many cases in which it might be omitted in casual usage. | Word list |
| Simplified and unified guidance for *jank* and *janky* to recommend that these terms only be used for specific graphics issues. | Word list |
| Strengthened guidance against the use of *and/or* except in cases where space is limited. | Slashes |

<a id="whats-new--20230929"></a>

<a id="whats-new--september-29u002c-2023"></a>

#### September 29, 2023

| New guidance or change | Page |
| --- | --- |
| Added several examples of when and how to use quotation marks. | Quotation marks |
| Added explanation of guidance against anthropomorphism. | Anthropomorphism |
| Added guidance about using a hyphen with the prefix *non* before hyphenated compounds. | Hyphens |

<a id="whats-new--20230824"></a>

<a id="whats-new--august-24u002c-2023"></a>

#### August 24, 2023

| New guidance or change | Page |
| --- | --- |
| Added link buttons to each entry in the word list to make deep-linking to individual entries easier. | [Word list](/key-resources/word-list.md) |
| Extended guidance about example names to recommend using an initial to represent a person's surname. | Example person surnames |
| Clarified guidance about when to use present tense and when to use future tense. | Present tense |
| Extended link text guidance to include an example for `mailto` links. | [Link text](https://developers.google.com/style/link-text) |

<a id="whats-new--20230726"></a>

<a id="whats-new--july-26u002c-2023"></a>

#### July 26, 2023

| New guidance or change | Page |
| --- | --- |
| Added link to [Google API guidelines](https://google.aip.dev/192) for information about code comments. | API reference code comments |
| Revised guidance for the word *toggle* to recommend against use as a verb. | UI elements and interaction |
| Extended and clarified guidance for names for directories and files. | Filenames and file types |
| Added explanation for why to use code format for code items. | Code in text |

<a id="whats-new--20230615"></a>

<a id="whats-new--june-15u002c-2023"></a>

#### June 15, 2023

| New guidance or change | Page |
| --- | --- |
| Consolidated guidance about periods and end punctuation. Also removed standalone pages about exclamation points and about spacing after periods. | Periods and other end punctuation |
| Revised guidance about hyphens to suggest a lookup strategy, categorize uses, and note exceptions. | Hyphens |
| Created firmer guidance about punctuation in lists for run-in headings and at the end of list items. | [Lists](#lists) |
| Strengthened capitalization guidance: when *not* to use capitalization, and how to use capitalization with product names. | Capitalization, [Product names](/key-resources/product-names.md) |
| Added guidance about using end punctuation when documenting a command-line option or argument. | Document command-line syntax |
| Improved description and examples for using first-person pronouns (*we*, *our*). | Second person and first person |
| Updated word list entries: *etc.*, *OK*, *user*, *we*, *you* | [Word list](/key-resources/word-list.md) |

<a id="whats-new--20230509"></a>

<a id="whats-new--may-9u002c-2023"></a>

#### May 9, 2023

| New guidance or change | Page |
| --- | --- |
| Softened guidance regarding the choice between the pronouns *who* and *that*. | Pronouns |
| Added *web interface* as an alternative to *console* and *UI* in general references to a browser-based interface. | Word list |
| Clarified the purpose of the page about phone number formats. | Format phone numbers in text |

<a id="whats-new--20230331"></a>

<a id="whats-new--march-31u002c-2023"></a>

#### March 31, 2023

| New guidance or change | Page |
| --- | --- |
| Expanded and clarified guidance about using trademarks only as modifiers. This guidance emphasizes that you should never modify a trademark, such as by creating a possessive or plural form. | Use trademarks only as modifiers |
| Strengthened guidance against shortening product names to anything other than an approved alternative name. | [Google product names](/key-resources/product-names.md#shortening) |
| Expanded guidance about using ARIA labels in text that describes icons in graphical user interfaces. This improves accessibility and increases consistency in terminology used to refer to visual elements in text. | Buttons and icons, [Accessibility](/general-principles/accessibility.md) |
| New word list entry: *toolkit* | [Word list](/key-resources/word-list.md) |

<a id="whats-new--20230213"></a>

<a id="whats-new--february-13u002c-2023"></a>

#### February 13, 2023

| New guidance or change | Page |
| --- | --- |
| Added a page about paragraph structure, which provides guidance about recommended paragraph length and order of information. | Paragraph structure |
| Expanded accessibility guidance to say that a document should convey its information when you use it without images or animation. | [Write accessible documentation](/general-principles/accessibility.md) |
| Clarified that letter keys should be represented with uppercase letters. | Press and type keyboard keys |
| Added *existing* to list of examples of potentially problematic words in timeless documentation. | [Timeless documentation](/general-principles/timeless-documentation.md) |
| Recommended using an empty `alt` attribute for icons that include a text label. | Buttons and icons |
| Strengthened and clarified guidance about avoiding culturally specific references and about using simple and consistent language. | [Voice and tone](/general-principles/voice-and-tone.md) |
| Created section about items that are sometimes—but not always—formatted in code font, such as email addresses. | Items that are sometimes in code font |
| Added information about example internationalized domain names. | Example domain names |
| Expanded guidance about choosing example email addresses. | Example email addresses |
| Expanded guidance about using second-person *you* to refer to the reader of a document and, generally, using third-person *user* to refer to the intended user of the software that the reader is developing. | Second person |

<a id="whats-new--20221212"></a>

<a id="whats-new--december-12u002c-2022"></a>

#### December 12, 2022

| New guidance or change | Page |
| --- | --- |
| New word list entry: *anti-pattern* | [Word list](/key-resources/word-list.md) |

<a id="whats-new--20221107"></a>

<a id="whats-new--november-7u002c-2022"></a>

#### November 7, 2022

| New guidance or change | Page |
| --- | --- |
| To emphasize a negative, use `<em>not`</em>. | Contractions |

<a id="whats-new--20221031"></a>

<a id="whats-new--october-31u002c-2022"></a>

#### October 31, 2022

| New guidance or change | Page |
| --- | --- |
| New word list entry: *standalone* | [Word list](/key-resources/word-list.md) |

<a id="whats-new--20221003"></a>

<a id="whats-new--october-10u002c-2022"></a>

#### October 10, 2022

| New guidance or change | Page |
| --- | --- |
| Added guidance about how to document optional arguments for commands.  Special characters that indicate optional and mutually exclusive arguments in commands—such as brackets, braces, and pipes—break commands if the user doesn't edit them first. The new guidance offers several approaches for avoiding these problems. | Code in text, Code samples, Document command-line syntax |
| Clarified that contractions are recommended in general, but not required in all cases. | Contractions |

<a id="whats-new--20220926"></a>

<a id="whats-new--september-26u002c-2022"></a>

#### September 26, 2022

| New guidance or change | Page |
| --- | --- |
| In figure captions, always use end punctuation, and use complete sentences when possible. | [Figures and other images](/general-principles/accessibility.md#images) |
| Added separators between word list terms, to improve readability. | [Word list](/key-resources/word-list.md) |

<a id="whats-new--20220919"></a>

<a id="whats-new--september-19u002c-2022"></a>

#### September 19, 2022

| New guidance or change | Page |
| --- | --- |
| Added guidance to multiple pages about ways to make documentation more inclusive for readers who have a variety of cognitive patterns. | [Write accessible documentation](/general-principles/accessibility.md), Cross-references, Numbers, Procedures |

<a id="whats-new--20220912"></a>

<a id="whats-new--september-12u002c-2022"></a>

#### September 12, 2022

| New guidance or change | Page |
| --- | --- |
| Don't present new information in tables through images or symbols alone. | [Tables](/general-principles/accessibility.md#tables) |
| Clarified guidance about using footnotes in tables. | [Tables](/general-principles/accessibility.md#tables) |
| Added instructions for how to look up a UI element's `aria-label` attribute. | UI elements and interaction |

<a id="whats-new--20220905"></a>

<a id="whats-new--september-5u002c-2022"></a>

#### September 5, 2022

| New guidance or change | Page |
| --- | --- |
| Strengthened recommendation to avoid using semicolons where possible, and removed basic information about semicolons.  Our [accessibility guidance](/general-principles/accessibility.md) recommends against using semicolons where possible, because screen readers may not clearly indicate them. So we changed our semicolon guidance to be more in line with our accessibility guidance. | Semicolons |
| Expanded and clarified guidance about what to put in code font. | Code in text |

<a id="whats-new--20220829"></a>

<a id="whats-new--august-29u002c-2022"></a>

#### August 29, 2022

| New guidance or change | Page |
| --- | --- |
| Changed and clarified recommended phrasing for describing boolean parameters in reference docs. | API reference code comments |
| Expanded and clarified explanation of why we use straight quotation marks and apostrophes. | Quotation marks |
| Added suggested alternative terms for *cloud-native*. | [Word list](/key-resources/word-list.md) |
| New word list entries: *prebuilt*, *scroll* | [Word list](/key-resources/word-list.md) |

<a id="whats-new--20220822"></a>

<a id="whats-new--august-22u002c-2022"></a>

#### August 22, 2022

| New guidance or change | Page |
| --- | --- |
| Clarified that *and then* is generally better than just *then*. | [Write for a global audience](/general-principles/global-audience.md) |
| New word list entries: *canary*, *multi-service*, *precapture*, *pre-existing*, *presubmit*, *rebranding*, *roll out* | [Word list](/key-resources/word-list.md) |

<a id="whats-new--20220815"></a>

<a id="whats-new--august-15u002c-2022"></a>

#### August 15, 2022

| New guidance or change | Page |
| --- | --- |
| Expanded table-formatting guidance, to improve accessibility. | [Tables](/general-principles/accessibility.md#tables) |
| Improved guidance about figure captions, descriptions, and alt text. | [Figures and other images](/general-principles/accessibility.md#images) |

<a id="whats-new--20220808"></a>

<a id="whats-new--august-8u002c-2022"></a>

#### August 8, 2022

| New guidance or change | Page |
| --- | --- |
| Write *a SQL* rather than *an SQL*.  Both are in use, but *a SQL* is significantly more common. | Articles (a, an, the) |
| Added information about our distinction between *don't use* and *avoid*. | [Word list](/key-resources/word-list.md) |
| New word list entries: *nonce*, *SQL* | [Word list](/key-resources/word-list.md) |

<a id="whats-new--20220801"></a>

<a id="whats-new--august-1u002c-2022"></a>

#### August 1, 2022

| New guidance or change | Page |
| --- | --- |
| Expanded guidance about *mobile* and related terms. | [Word list](/key-resources/word-list.md) |
| It's OK to use *below* in set phrases such as *below (the) average*. | [Word list](/key-resources/word-list.md) |
| Expanded our information about serial commas. | Commas |
| To refer to a file with the `.tiff` extension, use the phrase *TIFF file*. | Filenames and file types |
| New word list entries: *admin*; *blue-green*; *cold*, *hot*, and *warm* (in the context of a failover, spare, or standby); *inline*; *mobile phone*; *online* | [Word list](/key-resources/word-list.md) |

<a id="whats-new--20220725"></a>

<a id="whats-new--july-25u002c-2022"></a>

#### July 25, 2022

| New guidance or change | Page |
| --- | --- |
| Updated guidance about the term *Cloud console*. | [Word list](/key-resources/word-list.md) |
| Clarified guidance about the term *see*. | [Word list](/key-resources/word-list.md) |

<a id="whats-new--20220718"></a>

<a id="whats-new--july-18u002c-2022"></a>

#### July 18, 2022

| New guidance or change | Page |
| --- | --- |
| Revised guidance about using the term *element* in HTML and XML contexts. | [Word list](/key-resources/word-list.md) |
| Revised and expanded guidance about how to form possessives. | Possessives |
| New word list entry: *tag* | [Word list](/key-resources/word-list.md) |

<a id="whats-new--20220620"></a>

<a id="whats-new--june-20u002c-2022"></a>

#### June 20, 2022

| New guidance or change | Page |
| --- | --- |
| New word list entry: *brown bag* | [Word list](/key-resources/word-list.md) |

<a id="whats-new--20220613"></a>

<a id="whats-new--june-13u002c-2022"></a>

#### June 13, 2022

| New guidance or change | Page |
| --- | --- |
| Clarified guidance about placement of *only*. | [Write for a global audience](/general-principles/global-audience.md) |
| New word list entry: *using* | [Word list](/key-resources/word-list.md) |

<a id="whats-new--20220606"></a>

<a id="whats-new--june-6u002c-2022"></a>

#### June 6, 2022

| New guidance or change | Page |
| --- | --- |
| Clarified guidance about *Interconnect connection*. | [Word list](/key-resources/word-list.md) |

<a id="whats-new--20220516"></a>

<a id="whats-new--may-16u002c-2022"></a>

#### May 16, 2022

| New guidance or change | Page |
| --- | --- |
| Offset footnote symbols using superscript. | Footnotes |
| New word list entries: *could*, *would* | [Word list](/key-resources/word-list.md) |

<a id="whats-new--20220509"></a>

<a id="whats-new--may-9u002c-2022"></a>

#### May 9, 2022

| New guidance or change | Page |
| --- | --- |
| Strengthened guidance recommending avoiding humor in documentation.  Most humor is difficult to translate, and much humor is culturally specific. | [Write for a global audience](/general-principles/global-audience.md) |
| Changed the link to a resource about identity-first language.  The site that we had previously linked to has disappeared. | [Write inclusive documentation](/general-principles/inclusive-language.md) |

<a id="whats-new--20220425"></a>

<a id="whats-new--april-25u002c-2022"></a>

#### April 25, 2022

| New guidance or change | Page |
| --- | --- |
| Added a new page about jargon. | [Jargon](/general-principles/jargon.md) |
| Expanded guidance about when to use the various notice types. | Notes, cautions, warnings, and other notices |
| Clarified and expanded guidance about when to remove locales from URLs. | [Link to other sites](https://developers.google.com/style/links-external) |
| New word list entries: *final solution*, `gsutil` | [Word list](/key-resources/word-list.md) |

<a id="whats-new--20220418"></a>

<a id="whats-new--april-18u002c-2022"></a>

#### April 18, 2022

| New guidance or change | Page |
| --- | --- |
| Introduce an interactive element (such as a button that expands and collapses) in the text preceding the element, to improve accessibility. | [Write accessible documentation](/general-principles/accessibility.md) |

<a id="whats-new--20220411"></a>

<a id="whats-new--april-11u002c-2022"></a>

#### April 11, 2022

| New guidance or change | Page |
| --- | --- |
| Changed guidance about taking screenshots. | [Figures and other images](/general-principles/accessibility.md#images) |
| In code samples, indicate omitted code using three dots and no spaces (`...`) | Code samples |
| New word list entries: *+* (appended to numbers in text) | [Word list](/key-resources/word-list.md) |

<a id="whats-new--20220404"></a>

<a id="whats-new--april-4u002c-2022"></a>

#### April 4, 2022

| New guidance or change | Page |
| --- | --- |
| Removed guidance about using lettered lists for mutually exclusive options.  The semantic distinction that we were making isn't in wide use, and lettered lists aren't supported in standard Markdown, so we no longer recommend using lettered lists. | [Lists](#lists) |
| Clarified recommendation about how to italicize in Markdown. | [Text-formatting summary](/key-resources/text-formatting.md) |
| Changed guidance about *dead-letter queue* and *hold the pointer over*. | [Word list](/key-resources/word-list.md) |
| New word list entry: *break-glass* | Word list |

<a id="whats-new--20220328"></a>

<a id="whats-new--march-28u002c-2022"></a>

#### March 28, 2022

| New guidance or change | Page |
| --- | --- |
| Clarified guidance about using an introductory phrase before the output of a command. | Document command-line syntax |
| New word list entry: *Unicode* | Word list |

<a id="whats-new--20220221"></a>

<a id="whats-new--february-21u002c-2022"></a>

#### February 21, 2022

| New guidance or change | Page |
| --- | --- |
| Use `gcloud` *CLI* instead of `gcloud` *command-line tool*. | [Word list](/key-resources/word-list.md) |
| New word list entry: *shift left* | [Word list](/key-resources/word-list.md) |

<a id="whats-new--20220207"></a>

<a id="whats-new--february-7u002c-2022"></a>

#### February 7, 2022

| New guidance or change | Page |
| --- | --- |
| In general, don't use a single *x* or a series of *x*'s as placeholders; instead, use a more informative placeholder. | Formatting placeholders |
| New word list entry: *GBps* | [Word list](/key-resources/word-list.md) |

<a id="whats-new--20220131"></a>

<a id="whats-new--january-31u002c-2022"></a>

#### January 31, 2022

| New guidance or change | Page |
| --- | --- |
| Avoid repeating the exact page title as a heading on the page. | Headings and titles |
| Expanded guidance about *runtime* and *run time*. | [Word list](/key-resources/word-list.md) |
| Added *.adoc* and *.md* to the list of examples of filename extensions. | Filenames and file types |

<a id="whats-new--20220124"></a>

<a id="whats-new--january-24u002c-2022"></a>

#### January 24, 2022

| New guidance or change | Page |
| --- | --- |
| Clarified guidance about video formats.  The main reason to avoid using animated GIF is that it's resource-inefficient. | [Figures and other images](/general-principles/accessibility.md#images) |
| Clarified guidance about changing an existing custom anchor for a heading. | Making headings into link targets |

<a id="whats-new--20220118"></a>

<a id="whats-new--january-18u002c-2022"></a>

#### January 18, 2022

| New guidance or change | Page |
| --- | --- |
| For animations and videos, use a compressed format (such as MP4), not animated GIF. | [Figures and other images](/general-principles/accessibility.md#images) |
| Don't use *email* as a verb. | [Word list](/key-resources/word-list.md) |
| New word list entry: *healthcare* | [Word list](/key-resources/word-list.md) |

---

## Philosophy of this guide

*Source: <https://developers.google.com/style/philosophy>*

This document discusses some of the principles and philosophy behind this
style guide.

<a id="philosophy--purpose"></a>

<a id="philosophy--intended-purpose"></a>

#### Intended purpose

This style guide codifies and records our style decisions and describes our
house style. The guide doesn't claim to be objectively correct.

This guide is *not* intended to do the following:

- Provide an industry documentation standard.
- Compete with other well-known style guides.
- Replace another style guide that you already follow.
- Provide a complete set of basic writing guidelines.
- Provide legal advice. For legal advice, consult a lawyer.

> [!NOTE]
> **Note**: Two disclaimers:
>
> - The guidance in this style guide doesn't limit the changes that Google can
>   make to its documentation.
> - If you don't read a given guideline, then you are still responsible for
>   behaving ethically and lawfully with regard to documentation.

<a id="philosophy--reasons-for-guidelines"></a>

<a id="philosophy--explanation-of-reasons-for-guidelines"></a>

#### Explanation of reasons for guidelines

We generally don't explain the reasoning behind most of our guidelines. We
have a couple of reasons for that:

- Many of our decisions are driven by accessibility, localization,
  globalization, and ease of understanding. Giving those reasons as explanations
  everywhere they apply would be repetitive.
- Often, a given guideline is one good option among several; in those cases, we
  sometimes just chose one option for consistency.
- Too much explanation can clutter up a page. Readers most often want a
  brief answer to a specific question, rather than a detailed explanation.

That said, we recognize that it's sometimes useful to know why we made a
given choice, so we've started to include occasional explanations in the [What's new](#whats-new) page.
