# General-principles

## Concepts

* [Accessibility](/general-principles/accessibility.md) - General guidelines and examples for writing accessible developer documentation.
* [Excessive claims](/general-principles/excessive-claims.md) - Guidance on avoiding unverifiable or subjective claims in documentation.
* [Future features](/general-principles/future-features.md) - Guidance against documenting future or unapproved features.
* [Global audience](/general-principles/global-audience.md) - Writing guidelines for translation, localization, and international audiences.
* [Inclusive language](/general-principles/inclusive-language.md) - Guidelines for writing inclusive, diverse, and respectful developer documentation.
* [Jargon](/general-principles/jargon.md) - Guidance on using and avoiding technical jargon in documentation.
* [Prescriptive documentation](/general-principles/prescriptive-documentation.md) - Guidance on writing prescriptive, opinionated documentation.
* [Third-party content](/general-principles/third-party-content.md) - Guidance on avoiding copying third-party content.
* [Timeless documentation](/general-principles/timeless-documentation.md) - Guidance on avoiding time-specific language in documentation.
* [Voice and tone](/general-principles/voice-and-tone.md) - Guidance on achieving a conversational, friendly, and respectful tone.
