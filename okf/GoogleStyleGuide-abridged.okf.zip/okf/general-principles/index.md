# General-principles

## Concepts

* [Accessibility](accessibility.md) - General guidelines and examples for writing accessible developer documentation.
* [Excessive claims](excessive-claims.md) - Guidance on avoiding unverifiable or subjective claims in documentation.
* [Future features](future-features.md) - Guidance against documenting future or unapproved features.
* [Global audience](global-audience.md) - Writing guidelines for translation, localization, and international audiences.
* [Inclusive language](inclusive-language.md) - Guidelines for writing inclusive, diverse, and respectful developer documentation.
* [Jargon](jargon.md) - Guidance on using and avoiding technical jargon in documentation.
* [Prescriptive documentation](prescriptive-documentation.md) - Guidance on writing prescriptive, opinionated documentation.
* [Third-party content](third-party-content.md) - Guidance on avoiding copying third-party content.
* [Timeless documentation](timeless-documentation.md) - Guidance on avoiding time-specific language in documentation.
* [Voice and tone](voice-and-tone.md) - Guidance on achieving a conversational, friendly, and respectful tone.
