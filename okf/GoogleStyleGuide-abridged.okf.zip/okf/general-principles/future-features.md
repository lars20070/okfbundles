---
type: Chapter
title: "Future features"
description: "Guidance against documenting future or unapproved features."
resource: https://developers.google.com/style/future
tags: [guide, google, style]
timestamp: 2026-08-01T06:28:39Z
---

## Future features

*Source: <https://developers.google.com/style/future>*

Avoid documenting future features or products, even in innocuous
ways. Don't pre-announce anything in documentation unless it has been approved by your legal counsel.

See also Present tense and
[Timeless documentation](/general-principles/timeless-documentation.md).
