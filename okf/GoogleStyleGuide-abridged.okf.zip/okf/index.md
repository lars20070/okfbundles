---
okf_version: "0.2"
---

# Knowledge Base

## Subdirectories

* [General-principles](/general-principles/)
* [Key-resources](/key-resources/)

## Concepts

* [Google Developer Documentation Style Guide](/google-developer-documentation-style-guide.md) - Editorial guidelines for writing clear and consistent technical documentation for developers.
