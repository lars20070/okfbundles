# Key-resources

## Concepts

* [Product names](product-names.md) - How to use Google product names in documentation.
* [Text-formatting summary](text-formatting.md) - Quick reference for general text-formatting conventions.
* [Word list](word-list.md) - Style and usage guidelines for specific terms in developer documentation.
