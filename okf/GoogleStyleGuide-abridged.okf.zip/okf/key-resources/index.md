# Key-resources

## Concepts

* [Product names](/key-resources/product-names.md) - How to use Google product names in documentation.
* [Text-formatting summary](/key-resources/text-formatting.md) - Quick reference for general text-formatting conventions.
* [Word list](/key-resources/word-list.md) - Style and usage guidelines for specific terms in developer documentation.
