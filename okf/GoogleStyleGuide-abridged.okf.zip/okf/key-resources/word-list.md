---
type: Chapter
title: "Word list"
description: "Style and usage guidelines for specific terms in developer documentation."
resource: https://developers.google.com/style/word-list
tags: [guide, google, style, word-list]
timestamp: 2026-08-01T06:28:39Z
---

## Word list

*Source: <https://developers.google.com/style/word-list>*

> [!NOTE]
> **Note**: This document includes references to potentially disrespectful
> or offensive terms. These terms are listed here to provide usage
> guidance and alternative terms.

This word list covers style and usage guidelines that are specific to developer documentation.

If the term that you're looking for isn't on this list, check our other
[editorial resources](/google-developer-documentation-style-guide.md#style--editorial-resources),
including our preferred dictionary,
[Merriam-Webster](https://www.merriam-webster.com/). If there are multiple spellings in
the Merriam-Webster word entry, use the first form listed, which is the most common spelling. For
example, in the
[entry for *cancel*](https://www.merriam-webster.com/dictionary/canceled),
the first form listed for the past tense is *canceled*, indicating that it's more common than
*cancelled*.

If you're looking for a technical definition, then it's often a good idea to check the
authoritative documentation on the topic.

Terminology decisions, including how and when to define or contextualize
terms, often require judgments based on factors like your product area,
your audience, and prevailing convention. Here are some other pages of this
guide that can help you make those types of judgments:

- [Jargon](/general-principles/jargon.md)
- [Inclusive language](/general-principles/inclusive-language.md)
- [Write for a global audience](/general-principles/global-audience.md)
- Hyphens
- Capitalization

As always, it's fine to deviate from our guidance if that serves your readers
better. For more information, see [Break the rules](/google-developer-documentation-style-guide.md#style--rules).
