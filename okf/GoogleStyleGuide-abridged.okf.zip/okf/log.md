# Update Log

## 2026-09-16
* **Creation**: Added [Google Developer Documentation Style Guide](/google-developer-documentation-style-guide.md) with introduction, highlights, changelog, and philosophy sections.
* **Creation**: Added [key-resources/](/key-resources/) directory with [Word list](/key-resources/word-list.md), [Product names](/key-resources/product-names.md), and [Text-formatting summary](/key-resources/text-formatting.md).
* **Creation**: Added [general-principles/](/general-principles/) directory with [Accessibility](/general-principles/accessibility.md), [Excessive claims](/general-principles/excessive-claims.md), [Future features](/general-principles/future-features.md), [Global audience](/general-principles/global-audience.md), [Inclusive language](/general-principles/inclusive-language.md), [Jargon](/general-principles/jargon.md), [Prescriptive documentation](/general-principles/prescriptive-documentation.md), [Third-party content](/general-principles/third-party-content.md), [Timeless documentation](/general-principles/timeless-documentation.md), and [Voice and tone](/general-principles/voice-and-tone.md).
* **Creation**: Updated [root index](/index.md) with full link list.
* **Update**: Added missing `timestamp` fields to all 14 content pages to pass lint.
* **Update**: Converted all relative links in index files to absolute (bundle-absolute) paths.
* **Update**: Verified and ensured every link across all three index files is bundle-absolute — no relative links remain in the wiki.
