---
type: Section
title: "The British Empire"
description: "Nelson, the East India Company, and imperial wars."
tags: [modern-britain]
timestamp: "2026-08-16T00:00:00Z"
---

# The British Empire

Nelson, the East India Company, and imperial wars.

30 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 68 | [The British Empire](https://pdst.fm/e/traffic.megaphone.fm/GLT6076978409.mp3?updated=1777395093) | 2021-07-01 |
| 75 | [The East India Company](https://pdst.fm/e/traffic.megaphone.fm/GLT7809915873.mp3?updated=1777395041) | 2021-07-15 |
| 76 | [Statues: Trafalgar Square](https://pdst.fm/e/traffic.megaphone.fm/GLT4670878913.mp3?updated=1777394917) | 2021-07-19 |
| 77 | [Statues: Whitehall](https://pdst.fm/e/traffic.megaphone.fm/GLT3402485088.mp3?updated=1777394864) | 2021-07-20 |
| 78 | [Statues: Parliament Square](https://pdst.fm/e/traffic.megaphone.fm/GLT3870229260.mp3?updated=1777394999) | 2021-07-22 |
| 100 | [Decolonising Africa](https://pdst.fm/e/traffic.megaphone.fm/GLT2427735251.mp3?updated=1777394971) | 2021-09-23 |
| 121 | [Australia Before Cook](https://pdst.fm/e/traffic.megaphone.fm/GLT2957294549.mp3?updated=1777394961) | 2021-11-18 |
| 141 | [General Gordon: The Ultimate Victorian Hero](https://pdst.fm/e/traffic.megaphone.fm/GLT2700696137.mp3?updated=1775852119) | 2022-01-24 |
| 142 | [General Gordon and the Siege of Khartoum](https://pdst.fm/e/traffic.megaphone.fm/GLT6227664313.mp3?updated=1775852109) | 2022-01-25 |
| 187 | [Australian Prime Ministers: Edmund Barton - Robert Menzies (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT3017584065.mp3?updated=1777394824) | 2022-05-23 |
| 188 | [Australian Prime Ministers: Harold Holt - Malcolm Fraser (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT4635125602.mp3?updated=1777394832) | 2022-05-24 |
| 189 | [Australian Prime Ministers: Bob Hawke - Scott Morrison (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT2222829202.mp3?updated=1777394946) | 2022-05-26 |
| 243 | [Trafalgar: A World at War (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT3542298238.mp3?updated=1729784394) | 2022-10-17 |
| 244 | [Trafalgar: Countdown to Annihilation (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT5489746159.mp3?updated=1729784420) | 2022-10-20 |
| 245 | [Trafalgar: Victory (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT4217731619.mp3?updated=1729784451) | 2022-10-21 |
| 257 | [Australia: The Mystery of the Somerton Man](https://pdst.fm/e/traffic.megaphone.fm/GLT2531949703.mp3?updated=1777394782) | 2022-11-19 |
| 380 | [Captain Cook: History’s Greatest Explorer (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT8106697435.mp3?updated=1729781697) | 2023-10-22 |
| 381 | [Captain Cook: To the Ends of the Earth (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT6950185057.mp3?updated=1729781723) | 2023-10-25 |
| 514 | [Nelson: Hero of the Seas (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT4893527428.mp3?updated=1731880805) | 2024-11-18 |
| 515 | [Nelson: Attack the French!  (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT9020085184.mp3?updated=1731889804) | 2024-11-21 |
| 516 | [Nelson: God of War (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT1686018300.mp3?updated=1732487389) | 2024-11-25 |
| 517 | [Nelson: The Hunt for Napoleon (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT5321926998.mp3?updated=1732010118) | 2024-11-28 |
| 518 | [Nelson: The Battle of the Nile (Part 5)](https://pdst.fm/e/traffic.megaphone.fm/GLT9518722562.mp3?updated=1733095800) | 2024-12-02 |
| 607 | [Nelson’s Lover: The Scandalous Lady Hamilton](https://pdst.fm/e/traffic.megaphone.fm/GLT1577197938.mp3?updated=1763642144) | 2025-10-08 |
| 608 | [Nelson: Slaughter in Naples (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT8594694484.mp3?updated=1763642104) | 2025-10-12 |
| 609 | [Nelson: The Gathering Storm (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT8067718474.mp3?updated=1763642285) | 2025-10-15 |
| 610 | [Nelson: The Battle of Copenhagen (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT9153225543.mp3?updated=1763642283) | 2025-10-19 |
| 611 | [Nelson: Bonaparte Prepares to Strike (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT9281187489.mp3?updated=1763642327) | 2025-10-22 |
| 612 | [Nelson: The Final Showdown (Part 5)](https://pdst.fm/e/traffic.megaphone.fm/GLT2077045869.mp3?updated=1763642169) | 2025-10-27 |
| 613 | [Nelson: Glory at Trafalgar (Part 6)](https://pdst.fm/e/traffic.megaphone.fm/GLT7193792251.mp3?updated=1763642241) | 2025-10-30 |
