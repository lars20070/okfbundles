---
type: Section
title: "London"
description: "The history of the capital."
tags: [modern-britain]
timestamp: "2026-08-16T00:00:00Z"
---

# London

The history of the capital.

8 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 209 | [Londinium (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT8659020002.mp3?updated=1777394849) | 2022-07-18 |
| 210 | [London: Places (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT8561271853.mp3?updated=1777394755) | 2022-07-19 |
| 211 | [London: People (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT1562041230.mp3?updated=1777394897) | 2022-07-20 |
| 212 | [Haunted London (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT8938796735.mp3?updated=1777394993) | 2022-07-21 |
| 213 | [London: Moments (Part 5)](https://pdst.fm/e/traffic.megaphone.fm/GLT4986306476.mp3?updated=1729785469) | 2022-07-22 |
| 364 | [Sixties Fashion: Swinging London (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT8438824218.mp3?updated=1729782150) | 2023-08-30 |
| 414 | [The Peasants’ Revolt: London’s Burning (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT6726049231.mp3?updated=1706795730) | 2024-02-01 |
| 653 | [London’s Golden Age: The Shadow of the Madhouse (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT2240052230.mp3?updated=1774256098) | 2026-03-19 |
