# Modern Britain

British history from the Empire through to the present day.

104 episodes.

## Subtopics
* [Twentieth-Century Britain](/modern-britain/britain-20th-century.md) — From the Edwardian era to Thatcher and beyond. (40 episodes)
* [London](/modern-britain/london.md) — The history of the capital. (8 episodes)
* [Ireland](/modern-britain/ireland.md) — The struggle for Irish independence. (22 episodes)
* [The British Empire](/modern-britain/british-empire.md) — Nelson, the East India Company, and imperial wars. (30 episodes)
* [The Falklands War](/modern-britain/falklands-war.md) — The 1982 conflict in the South Atlantic. (4 episodes)
