---
type: Section
title: "The Falklands War"
description: "The 1982 conflict in the South Atlantic."
tags: [modern-britain]
timestamp: "2026-08-16T00:00:00Z"
---

# The Falklands War

The 1982 conflict in the South Atlantic.

4 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 169 | [The Falklands War: Countdown to Invasion (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT6828599585.mp3?updated=1777394990) | 2022-03-28 |
| 170 | [The Falklands War: The Task Force Sails (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT1917394924.mp3?updated=1777394981) | 2022-03-29 |
| 171 | [The Falklands War: Battle for the Islands (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT4679725480.mp3?updated=1777394987) | 2022-03-31 |
| 172 | [The Falklands War: Afterlife (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT5779306068.mp3?updated=1777395025) | 2022-04-04 |
