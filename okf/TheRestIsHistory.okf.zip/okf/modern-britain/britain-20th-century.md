---
type: Section
title: "Twentieth-Century Britain"
description: "From the Edwardian era to Thatcher and beyond."
tags: [modern-britain]
timestamp: "2026-08-16T00:00:00Z"
---

# Twentieth-Century Britain

From the Edwardian era to Thatcher and beyond.

40 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 4 | [We're all so 17th Century](https://pdst.fm/e/traffic.megaphone.fm/GLT1251829896.mp3?updated=1777394932) | 2020-11-09 |
| 8 | [The Echo of a Coffee House](https://pdst.fm/e/traffic.megaphone.fm/GLT8695060101.mp3?updated=1777394957) | 2020-12-07 |
| 11 | [Brexit](https://pdst.fm/e/traffic.megaphone.fm/GLT9171248177.mp3?updated=1777395016) | 2020-12-28 |
| 18 | [The North South Divide](https://pdst.fm/e/traffic.megaphone.fm/GLT3709184192.mp3?updated=1777394862) | 2021-01-28 |
| 35 | [The Prime Ministers’ World Cup](https://pdst.fm/e/traffic.megaphone.fm/GLT6124252189.mp3?updated=1777394950) | 2021-03-22 |
| 36 | [Our Greatest Prime Minister](https://pdst.fm/e/traffic.megaphone.fm/GLT9826873277.mp3?updated=1777394980) | 2021-03-23 |
| 65 | [A Very British Scandal](https://pdst.fm/e/traffic.megaphone.fm/GLT1741780940.mp3?updated=1777395055) | 2021-06-21 |
| 67 | [Anglo-German Relations](https://pdst.fm/e/traffic.megaphone.fm/GLT1735608678.mp3?updated=1777395010) | 2021-06-28 |
| 73 | [England v Italy](https://pdst.fm/e/traffic.megaphone.fm/GLT3184835237.mp3?updated=1777395000) | 2021-07-09 |
| 96 | [The UK's Best Churches](https://pdst.fm/e/traffic.megaphone.fm/GLT7919970372.mp3?updated=1777395033) | 2021-09-13 |
| 180 | [England & Englishness](https://pdst.fm/e/traffic.megaphone.fm/GLT7388885434.mp3?updated=1777394987) | 2022-04-28 |
| 186 | [The New Elizabethan Age](https://pdst.fm/e/traffic.megaphone.fm/GLT7640926802.mp3?updated=1777395011) | 2022-05-19 |
| 190 | [Jubilees](https://pdst.fm/e/traffic.megaphone.fm/GLT4093596173.mp3?updated=1777394929) | 2022-05-30 |
| 193 | [How Prime Ministers Fall](https://pdst.fm/e/traffic.megaphone.fm/GLT7608869237.mp3?updated=1777395041) | 2022-06-07 |
| 205 | [The Last Days of Boris Johnson](https://pdst.fm/e/traffic.megaphone.fm/GLT2329301983.mp3?updated=1777394940) | 2022-07-08 |
| 222 | [Victorian Holidays](https://pdst.fm/e/traffic.megaphone.fm/GLT9970456316.mp3?updated=1694605858) | 2022-08-18 |
| 238 | [The Regency Revolution](https://pdst.fm/e/traffic.megaphone.fm/GLT7671750288.mp3?updated=1694603804) | 2022-09-29 |
| 246 | [The Fall of Liz Truss](https://pdst.fm/e/traffic.megaphone.fm/GLT3484252092.mp3?updated=1694602901) | 2022-10-22 |
| 249 | [Treason in Modern Britain (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT2159531504.mp3?updated=1729783868) | 2022-11-03 |
| 263 | [USA vs England: The 200-Year Rivalry](https://pdst.fm/e/traffic.megaphone.fm/GLT7546211559.mp3?updated=1777395014) | 2022-11-25 |
| 286 | [England: Beef and Liberty](https://pdst.fm/e/traffic.megaphone.fm/GLT5964129806.mp3?updated=1777394897) | 2022-12-18 |
| 400 | [Victorian Britain's Maddest Mystery](https://pdst.fm/e/traffic.megaphone.fm/GLT4466006716.mp3?updated=1703066755) | 2023-12-18 |
| 401 | [Windrush: The Story of Black Britain](https://pdst.fm/e/traffic.megaphone.fm/GLT4826407019.mp3?updated=1703118131) | 2023-12-21 |
| 417 | [Britain in 1974: State of Emergency (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT6761791949.mp3?updated=1707753485) | 2024-02-12 |
| 418 | [Britain in 1974: The Crisis Election (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT9690615062.mp3?updated=1707747695) | 2024-02-13 |
| 419 | [Britain in 1974: Countdown to a Coup (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT2033018212.mp3?updated=1707747735) | 2024-02-15 |
| 420 | [Britain in 1974: Thatcher Enters the Ring (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT2799978515.mp3?updated=1708044521) | 2024-02-16 |
| 463 | [Mad Elections (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT4220133865.mp3?updated=1718982280) | 2024-06-23 |
| 464 | [Modern British Elections (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT4046145085.mp3?updated=1719421973) | 2024-06-26 |
| 583 | [The Lion, the Priest and the Parlourmaids: A 1930s Sex Scandal](https://pdst.fm/e/traffic.megaphone.fm/GLT8788233490.mp3?updated=1753917783) | 2025-07-16 |
| 592 | [Mad Victorian Sport](https://pdst.fm/e/traffic.megaphone.fm/GLT6102181144.mp3?updated=1755510331) | 2025-08-17 |
| 600 | [Chatham High Street](https://pdst.fm/e/traffic.megaphone.fm/GLT2782191075.mp3?updated=1757879738) | 2025-09-14 |
| 606 | [Enoch Powell: Rivers of Blood](https://pdst.fm/e/traffic.megaphone.fm/GLT7520958596.mp3?updated=1763642349) | 2025-10-05 |
| 650 | [London’s Golden Age: The Mad Life of Dr Johnson (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT2687128958.mp3?updated=1773055447) | 2026-03-09 |
| 651 | [London’s Golden Age: Sex and Scandal in Georgian Britain (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT1542242808.mp3?updated=1773416272) | 2026-03-12 |
| 652 | [London’s Golden Age: The Ghosts of Culloden (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT2422514848.mp3?updated=1773416285) | 2026-03-16 |
| 662 | [Britain in the 70s: The Rise of Thatcher (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT1785737730.mp3?updated=1777544262) | 2026-04-19 |
| 663 | [Britain in the 70s: The Brexit That Never Was (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT2237203377.mp3?updated=1776869331) | 2026-04-22 |
| 664 | [Britain in the 70s: Scandal in Downing Street (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT9115516865.mp3?updated=1777029534) | 2026-04-26 |
| 665 | [Britain in the 70s: The Bailout from Hell (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT9598017819.mp3?updated=1777473193) | 2026-04-29 |
