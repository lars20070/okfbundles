---
type: Section
title: "Ireland"
description: "The struggle for Irish independence."
tags: [modern-britain]
timestamp: "2026-08-16T00:00:00Z"
---

# Ireland

The struggle for Irish independence.

22 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 12 | [Conspiracy Theories](https://pdst.fm/e/traffic.megaphone.fm/GLT7580472793.mp3?updated=1777394982) | 2021-01-04 |
| 259 | [Iran: England - 'The Little Satan'](https://pdst.fm/e/traffic.megaphone.fm/GLT8347276204.mp3?updated=1777395000) | 2022-11-21 |
| 312 | [Reagan, Iran-Contra and the Cold War (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT4042202229.mp3?updated=1777394895) | 2023-03-13 |
| 335 | [The Freemasons: History's Greatest Conspiracy Theory](https://pdst.fm/e/traffic.megaphone.fm/GLT4122245847.mp3?updated=1777394229) | 2023-05-25 |
| 337 | [Ireland: Union, Famine and Parnell (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT4375415331.mp3?updated=1777394923) | 2023-06-01 |
| 338 | [Ireland: Home Rule, Mutiny - and Civil War? (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT5217836668.mp3?updated=1777395064) | 2023-06-05 |
| 339 | [Ireland: The Easter Rising, 1916 (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT7095481415.mp3?updated=1777394202) | 2023-06-08 |
| 351 | [Amsterdam: Miracles, Money, and Mud (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT4666881212.mp3?updated=1729782312) | 2023-07-17 |
| 397 | [JFK: A Conspiracy Unmasked (Part 6)](https://pdst.fm/e/traffic.megaphone.fm/GLT4318220159.mp3?updated=1700749154) | 2023-12-07 |
| 466 | [The Murder of Franz Ferdinand: The Conspiracy (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT2060941792.mp3?updated=1720023414) | 2024-07-03 |
| 540 | [Horror in the Congo: A Conspiracy Unmasked (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT5172130471.mp3?updated=1739557159) | 2025-02-17 |
| 576 | [The Irish War of Independence: Rise of the IRA (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT9072105702.mp3?updated=1750631815) | 2025-06-22 |
| 577 | [The Irish War of Independence: The Violence Begins (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT3492584348.mp3?updated=1750870334) | 2025-06-25 |
| 578 | [The Irish War of Independence: Bloody Sunday (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT8552699883.mp3?updated=1751035728) | 2025-06-29 |
| 579 | [The Irish War of Independence: Showdown in London (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT9064307865.mp3?updated=1751464705) | 2025-07-02 |
| 580 | [The Irish Civil War: The Assassination of Sir Henry Wilson (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT8285525213.mp3?updated=1751982238) | 2025-07-06 |
| 581 | [The Irish Civil War: The Killing of Michael Collins (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT3233824863.mp3?updated=1752078918) | 2025-07-09 |
| 596 | [The First World War: The Miracle on the Marne (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT2229565266.mp3?updated=1756658924) | 2025-08-31 |
| 636 | [Revolution in Iran: Fall of the Shah  (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT5083873634.mp3?updated=1768557306) | 2026-01-19 |
| 637 | [Revolution in Iran: Rise of the Ayatollah (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT7243579163.mp3?updated=1769178690) | 2026-01-22 |
| 638 | [Revolution in Iran: The Hostage Crisis (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT6844236579.mp3?updated=1769165839) | 2026-01-26 |
| 639 | [Revolution in Iran: Death in the Desert (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT6288433592.mp3?updated=1769449341) | 2026-01-29 |
