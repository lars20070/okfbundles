---
type: Section
title: "Other WWII Topics"
description: "Churchill, resistance, and the wider war."
tags: [world-war-two]
timestamp: "2026-08-16T00:00:00Z"
---

# Other WWII Topics

Churchill, resistance, and the wider war.

11 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 102 | [Germany from Adenauer to Angela](https://pdst.fm/e/traffic.megaphone.fm/GLT6085378369.mp3?updated=1777394990) | 2021-09-28 |
| 234 | [Germans Behaving Badly](https://pdst.fm/e/traffic.megaphone.fm/GLT7143029609.mp3?updated=1694604507) | 2022-09-15 |
| 235 | [China and World War II (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT2114682484.mp3?updated=1729784689) | 2022-09-20 |
| 236 | [China and World War II (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT5290070743.mp3?updated=1729784729) | 2022-09-22 |
| 239 | [Young Churchill: Born to Lead (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT1969009161.mp3?updated=1729784554) | 2022-10-03 |
| 240 | [Young Churchill: Soldier of Empire (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT4710302249.mp3?updated=1729784566) | 2022-10-06 |
| 241 | [Young Churchill: Prisoner and Fugitive (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT9087091726.mp3?updated=1729784589) | 2022-10-10 |
| 247 | [Monty & Patton vs. the Nazis](https://pdst.fm/e/traffic.megaphone.fm/GLT2932235302.mp3?updated=1694602663) | 2022-10-27 |
| 256 | [Germany: The White Rose](https://pdst.fm/e/traffic.megaphone.fm/GLT6296738472.mp3?updated=1777395026) | 2022-11-18 |
| 493 | [Lee Miller: Exposing the Horrors of World War Two](https://pdst.fm/e/traffic.megaphone.fm/GLT1929673260.mp3?updated=1726077290) | 2024-09-11 |
| 533 | [Wojtek: The Bear Who Beat the Nazis](https://pdst.fm/e/traffic.megaphone.fm/GLT8956421015.mp3?updated=1738860496) | 2025-01-23 |
