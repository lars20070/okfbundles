---
type: Section
title: "Hitler"
description: "The dictator and his inner circle."
tags: [world-war-two]
timestamp: "2026-08-16T00:00:00Z"
---

# Hitler

The dictator and his inner circle.

5 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 63 | [Hitler, with Ian Kershaw - part 1](https://pdst.fm/e/traffic.megaphone.fm/GLT1996418919.mp3?updated=1777394961) | 2021-06-14 |
| 64 | [Hitler, with Ian Kershaw - part 2](https://pdst.fm/e/traffic.megaphone.fm/GLT5766781968.mp3?updated=1777394965) | 2021-06-17 |
| 375 | [Hitler and the Mitford Sisters](https://pdst.fm/e/traffic.megaphone.fm/GLT5493256820.mp3?updated=1696350753) | 2023-10-04 |
| 530 | [Hitler’s War on Poland: Countdown to Armageddon (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT8685711342.mp3?updated=1738860574) | 2025-01-13 |
| 679 | [Germany: The Song Hitler Stole (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT6217148052.mp3) | 2026-06-14 |
