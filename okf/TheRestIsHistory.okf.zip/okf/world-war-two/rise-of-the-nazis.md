---
type: Section
title: "The Rise of the Nazis"
description: "From the Beer Hall Putsch to total power."
tags: [world-war-two]
timestamp: "2026-08-16T00:00:00Z"
---

# The Rise of the Nazis

From the Beer Hall Putsch to total power.

23 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 17 | [Fascism](https://pdst.fm/e/traffic.megaphone.fm/GLT5738760220.mp3?updated=1777394968) | 2021-01-25 |
| 31 | [The Second Reich](https://pdst.fm/e/traffic.megaphone.fm/GLT1008050219.mp3?updated=1777394991) | 2021-03-11 |
| 194 | [The First Fascist](https://pdst.fm/e/traffic.megaphone.fm/GLT5479566212.mp3?updated=1777394985) | 2022-06-09 |
| 230 | [Portugal: Football, Fado, and Fascism? (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT9147423732.mp3?updated=1729784996) | 2022-09-08 |
| 295 | [The Rise of the Nazis (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT8045984312.mp3?updated=1777395031) | 2023-01-16 |
| 296 | [The Nazis: The Beer Hall Putsch (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT4099180386.mp3?updated=1777394248) | 2023-01-19 |
| 297 | [The Nazis: Hitler's Triumph (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT2055084600.mp3?updated=1777394205) | 2023-01-23 |
| 298 | [The Nazis: Total Power (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT6097237943.mp3?updated=1777395015) | 2023-01-26 |
| 372 | [The Birth of British Fascism](https://pdst.fm/e/traffic.megaphone.fm/GLT4747738645.mp3?updated=1695596282) | 2023-09-24 |
| 373 | [Oswald Mosley: Fascist Leader](https://pdst.fm/e/traffic.megaphone.fm/GLT7471576360.mp3?updated=1695823188) | 2023-09-27 |
| 374 | [The Battle of Cable Street: Fascism Defeated](https://pdst.fm/e/traffic.megaphone.fm/GLT3021730207.mp3?updated=1695832036) | 2023-10-01 |
| 404 | [The Nazis in Power: The Night of the Long Knives (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT3861584466.mp3?updated=1729781069) | 2024-01-01 |
| 405 | [The Nazis in Power: The Nuremberg Rallies (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT8681167377.mp3?updated=1729781109) | 2024-01-04 |
| 406 | [The Nazis in Power: Hitler’s Road to War (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT6776521114.mp3?updated=1729781136) | 2024-01-08 |
| 407 | [The Nazis in Power: The Conquest of Austria (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT5380362144.mp3?updated=1729781149) | 2024-01-11 |
| 408 | [The Nazis in Power: Hitler's Dream (Part 5)](https://pdst.fm/e/traffic.megaphone.fm/GLT6100029744.mp3?updated=1729781181) | 2024-01-15 |
| 409 | [The Nazis in Power: Hitler's War on the Jews (Part 6)](https://pdst.fm/e/traffic.megaphone.fm/GLT9460111455.mp3?updated=1729781195) | 2024-01-16 |
| 410 | [The Nazis in Power: The Night of Broken Glass (Part 7)](https://pdst.fm/e/traffic.megaphone.fm/GLT5771265943.mp3?updated=1729781221) | 2024-01-18 |
| 528 | [The Nazis' Road to War: Hitler Prepares to Strike (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT9235039478.mp3?updated=1784112629) | 2025-01-06 |
| 529 | [The Nazis' Road to War: Showdown in Munich (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT8359198113.mp3?updated=1738860594) | 2025-01-09 |
| 531 | [Hitler's War on Poland: The Pact with Stalin (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT5437884494.mp3?updated=1738860541) | 2025-01-16 |
| 532 | [Hitler's War on Poland: The Fall of Warsaw (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT6308788391.mp3?updated=1738860519) | 2025-01-20 |
| 620 | [The Nazis at War: Hitler Strikes West (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT4381972581.mp3?updated=1784111378) | 2025-11-24 |
