---
type: Section
title: "The War in Europe"
description: "The battles and campaigns of the European war."
tags: [world-war-two]
timestamp: "2026-08-16T00:00:00Z"
---

# The War in Europe

The battles and campaigns of the European war.

8 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 43 | [1940](https://pdst.fm/e/traffic.megaphone.fm/GLT2702093158.mp3?updated=1777394987) | 2021-04-15 |
| 182 | [Operation Barbarossa](https://pdst.fm/e/traffic.megaphone.fm/GLT3299389649.mp3?updated=1777395023) | 2022-05-05 |
| 214 | [The Battle of Stalingrad (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT4564292022.mp3?updated=1729785212) | 2022-07-25 |
| 215 | [Stalingrad and the Red Army (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT4269997308.mp3?updated=1777394881) | 2022-07-28 |
| 399 | [The Savage Storm: World War II and The Battle for Italy](https://pdst.fm/e/traffic.megaphone.fm/GLT8130436942.mp3?updated=1702491427) | 2023-12-14 |
| 621 | [The Nazis at War: Blitzkrieg (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT8711886512.mp3?updated=1784111303) | 2025-11-27 |
| 622 | [The Nazis at War: The Fall of France (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT6447940829.mp3?updated=1764261729) | 2025-12-01 |
| 623 | [The Nazis at War: Churchill’s Finest Hour (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT7746266438.mp3?updated=1764777567) | 2025-12-04 |
