# World War II

The rise of the Nazis, the war in Europe, and its legacy.

49 episodes.

## Subtopics
* [Hitler](/world-war-two/hitler.md) — The dictator and his inner circle. (5 episodes)
* [The War in Europe](/world-war-two/war-in-europe.md) — The battles and campaigns of the European war. (8 episodes)
* [The Rise of the Nazis](/world-war-two/rise-of-the-nazis.md) — From the Beer Hall Putsch to total power. (23 episodes)
* [Other WWII Topics](/world-war-two/ww2-other.md) — Churchill, resistance, and the wider war. (11 episodes)
* [Holocaust & Memory](/world-war-two/holocaust-memory.md) — The genocide and its aftermath. (2 episodes)
