---
type: Section
title: "Alexander the Great"
description: "The conqueror who reshaped the ancient world."
tags: [ancient-greece]
timestamp: "2026-08-16T00:00:00Z"
---

# Alexander the Great

The conqueror who reshaped the ancient world.

2 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 116 | [Alexander the Great Part 1](https://pdst.fm/e/traffic.megaphone.fm/GLT3321594885.mp3?updated=1777395016) | 2021-11-08 |
| 117 | [Alexander the Great part 2](https://pdst.fm/e/traffic.megaphone.fm/GLT9707946822.mp3?updated=1777394999) | 2021-11-09 |
