---
type: Section
title: "The Persian Wars, Sparta & Athens"
description: "The great conflicts of classical Greece."
tags: [ancient-greece]
timestamp: "2026-08-16T00:00:00Z"
---

# The Persian Wars, Sparta & Athens

The great conflicts of classical Greece.

7 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 82 | [Sparta](https://pdst.fm/e/traffic.megaphone.fm/GLT1755395266.mp3?updated=1777395019) | 2021-08-02 |
| 98 | [Thermopylae & Salamis Episode 1](https://pdst.fm/e/traffic.megaphone.fm/GLT3813381992.mp3?updated=1777394994) | 2021-09-20 |
| 99 | [Thermopylae & Salamis Episode 2](https://pdst.fm/e/traffic.megaphone.fm/GLT9857497334.mp3?updated=1777395009) | 2021-09-21 |
| 330 | [Herodotus: The Birth of History](https://pdst.fm/e/traffic.megaphone.fm/GLT7158094581.mp3?updated=1777394160) | 2023-05-08 |
| 334 | [Athens and the Birth of Democracy](https://pdst.fm/e/traffic.megaphone.fm/GLT2496707123.mp3?updated=1777394235) | 2023-05-22 |
| 668 | [Greece vs Persia: The Rise of the First Superpower (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT8965800182.mp3?updated=1779119313) | 2026-05-10 |
| 669 | [Greece vs. Persia: The Battle of Marathon (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT2696648260.mp3?updated=1778685155) | 2026-05-13 |
