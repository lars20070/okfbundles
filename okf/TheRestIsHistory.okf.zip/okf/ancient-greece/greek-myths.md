---
type: Section
title: "Greek Myths & Epic Poetry"
description: "The gods, heroes, and epic tales of ancient Greece."
tags: [ancient-greece]
timestamp: "2026-08-16T00:00:00Z"
---

# Greek Myths & Epic Poetry

The gods, heroes, and epic tales of ancient Greece.

10 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 6 | [Troy](https://pdst.fm/e/traffic.megaphone.fm/GLT4742295987.mp3?updated=1777395028) | 2020-11-23 |
| 13 | [Stephen Fry and Troy](https://pdst.fm/e/traffic.megaphone.fm/GLT5875934078.mp3?updated=1777395057) | 2021-01-07 |
| 457 | [Helen of Troy: Queen of the Greek Myths (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT7058693674.mp3?updated=1717377472) | 2024-06-02 |
| 458 | [Helen of Troy: A Family of Blood (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT7255356131.mp3?updated=1717361381) | 2024-06-05 |
| 602 | [Greek Myths: Zeus, King of the Gods (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT4871750364.mp3?updated=1758288034) | 2025-09-21 |
| 603 | [Greek Myths: The Riddle of the Sphinx (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT9108845593.mp3?updated=1758732761) | 2025-09-24 |
| 604 | [Greek Myths: Sex, Drugs & Tragedy (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT7123647684.mp3?updated=1759100706) | 2025-09-28 |
| 605 | [Greek Myths: Jason & The Quest for the Golden Fleece (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT3067620137.mp3?updated=1759342659) | 2025-10-01 |
| 687 | [The Odyssey: Hero of the Trojan Horse (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT2393125423.mp3) | 2026-07-12 |
| 688 | [The Odyssey: Return of the King (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT2882541084.mp3) | 2026-07-15 |
