# Ancient Greece

The Greek myths, the Greco-Persian Wars, Alexander, and classical civilisation.

19 episodes.

## Subtopics
* [Greek Myths & Epic Poetry](/ancient-greece/greek-myths.md) — The gods, heroes, and epic tales of ancient Greece. (10 episodes)
* [The Persian Wars, Sparta & Athens](/ancient-greece/persian-wars-sparta.md) — The great conflicts of classical Greece. (7 episodes)
* [Alexander the Great](/ancient-greece/alexander.md) — The conqueror who reshaped the ancient world. (2 episodes)
