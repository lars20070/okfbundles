---
okf_version: "0.1"
---

# The Rest Is History Podcast — episode guide

Episodes of [The Rest Is History](https://feeds.megaphone.fm/GLT4787413333) podcast, grouped by historical topic.

713 episodes covering ancient civilisations through to modern history.

## Topics
* [Tudor & Stuart Britain](/tudor-stuart-britain/) — From the Tudor dynasty through the Civil War to the Glorious Revolution. (28 episodes)
* [Specials & Extras](/specials/) — Live shows, interviews, 12 Days specials, World Cup brackets, and one-offs. (32 episodes)
* [Medieval Europe](/medieval-europe/) — From the fall of Rome to the Renaissance — Vikings, Crusades, kings, and cathedrals. (85 episodes)
* [Ancient Greece](/ancient-greece/) — The Greek myths, the Greco-Persian Wars, Alexander, and classical civilisation. (19 episodes)
* [American History](/american-history/) — From the Revolution through to the modern era. (75 episodes)
* [Africa](/africa/) — The history of the African continent. (7 episodes)
* [Latin America](/latin-america/) — Pre-Columbian civilisations and modern Latin American history. (30 episodes)
* [Cultural & Social History](/cultural-social/) — The history of ideas, art, sport, and everyday life. (127 episodes)
* [World War II](/world-war-two/) — The rise of the Nazis, the war in Europe, and its legacy. (49 episodes)
* [World War I](/world-war-one/) — The Great War — causes, battles, and aftermath. (23 episodes)
* [France](/france/) — French history from the Revolution to the present. (33 episodes)
* [Modern Britain](/modern-britain/) — British history from the Empire through to the present day. (104 episodes)
* [East Asia](/east-asia/) — China, Japan, and the Mongols. (13 episodes)
* [Ancient Rome](/ancient-rome/) — The Roman Republic, Empire, and their rivals — from the Punic Wars to the fall of Rome. (52 episodes)
* [Russia & the Soviet Union](/russia-soviet/) — From the birth of Russia to Putin's rule. (19 episodes)
* [Middle East & Islamic World](/middle-east-islamic/) — From ancient Mesopotamia to modern Iran. (17 episodes)
