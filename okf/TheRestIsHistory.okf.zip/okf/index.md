---
okf_version: "0.1"
---

# The Rest Is History

Hosted by historians Tom Holland and Dominic Sandbrook, The Rest is History dives deep into history's most dramatic moments and fascinating figures - exploring the stories of great empires, epic battles, and world-changing events. From the rise and fall of the Roman Empire to the French Revolution, the sinking of the Titanic, and the Norman Conquest of 1066, Tom and Dominic bring the past to life.

Source: [The Rest Is History RSS feed](https://feeds.megaphone.fm/GLT4787413333)

713 episodes total: 694 numbered episodes (1-695, with #52 missing) plus 19 bonus items and a trailer. All 694 numbered episodes are compiled below.

## Clusters

* [Ancient World](/history/ancient-world/) — Greek, Roman, and ancient Mediterranean history
* [Medieval Europe](/history/medieval-europe/) — From 1066 to the Reformation
* [Early Modern Europe](/history/early-modern-europe/) — Renaissance through the Napoleonic era
* [British & Irish History](/history/british-irish-history/) — Britain, Ireland, and the Commonwealth
* [Empire & Colonialism](/history/empire-colonialism/) — Exploration, conquest, and empire
* [American History](/history/american-history/) — From colonial era to modern United States
* [World Wars](/history/world-wars/) — WWI, WWII, and 20th century conflicts
* [Culture & Entertainment](/history/culture-entertainment/) — Music, film, sports, and popular culture
* [Asia-Pacific](/history/asia-pacific/) — Japanese and Asian history
* [Modern Geopolitics](/history/modern-geopolitics/) — Cold War and contemporary conflicts
