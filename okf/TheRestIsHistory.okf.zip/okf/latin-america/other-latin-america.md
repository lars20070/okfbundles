---
type: Section
title: "Other Latin American Topics"
description: "Mexico, Argentina, Chile, and more."
tags: [latin-america]
timestamp: "2026-08-16T00:00:00Z"
---

# Other Latin American Topics

Mexico, Argentina, Chile, and more.

11 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 163 | [The Last Emperor of Mexico](https://pdst.fm/e/traffic.megaphone.fm/GLT3817272823.mp3?updated=1777394971) | 2022-03-14 |
| 264 | [Mexico: Day of the Dead](https://pdst.fm/e/traffic.megaphone.fm/GLT9022174156.mp3?updated=1777394802) | 2022-11-26 |
| 275 | [Argentina: The Welsh Colony](https://pdst.fm/e/traffic.megaphone.fm/GLT3290664499.mp3?updated=1775851991) | 2022-12-07 |
| 317 | [African Amazons](https://pdst.fm/e/traffic.megaphone.fm/GLT5973082485.mp3?updated=1777394944) | 2023-03-30 |
| 371 | [The 1973 Chilean Coup: General Pinochet Seizes Power (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT3740766328.mp3?updated=1729782100) | 2023-09-21 |
| 494 | [Evita: Birth of a Legend (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT9994303396.mp3?updated=1726439455) | 2024-09-15 |
| 495 | [Evita: The Rise of General Perón (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT1831793233.mp3?updated=1726677273) | 2024-09-18 |
| 496 | [Evita: The World's Most Powerful Woman (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT3440260328.mp3?updated=1727033647) | 2024-09-22 |
| 497 | [Evita: Death of a Martyr (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT5046116399.mp3?updated=1727170014) | 2024-09-23 |
| 498 | [Evita: The Mystery of the Missing Body (Part 5)](https://pdst.fm/e/traffic.megaphone.fm/GLT5587823308.mp3?updated=1727284536) | 2024-09-25 |
| 543 | [Death in the Amazon: Aguirre, the Wrath of God](https://pdst.fm/e/traffic.megaphone.fm/GLT3694360248.mp3?updated=1740605631) | 2025-02-27 |
