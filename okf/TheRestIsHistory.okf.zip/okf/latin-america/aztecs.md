---
type: Section
title: "The Fall of the Aztecs"
description: "The conquest of the Aztec Empire."
tags: [latin-america]
timestamp: "2026-08-16T00:00:00Z"
---

# The Fall of the Aztecs

The conquest of the Aztec Empire.

9 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 51 | [Aztecs](https://pdst.fm/e/traffic.megaphone.fm/GLT9590586130.mp3?updated=1777395015) | 2021-05-13 |
| 384 | [The Fall of the Aztecs: The Adventure Begins (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT8046611029.mp3?updated=1699093514) | 2023-11-06 |
| 385 | [The Fall of the Aztecs: The Woman Who Changed The World (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT5124604457.mp3?updated=1699093536) | 2023-11-07 |
| 386 | [The Fall of the Aztecs: The City of Gold (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT2951201852.mp3?updated=1699093480) | 2023-11-09 |
| 387 | [The Fall of the Aztecs: Prisoners of Montezuma (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT8017930427.mp3?updated=1699093561) | 2023-11-13 |
| 388 | [The Fall of the Aztecs: The Festival of Blood (Part 5)](https://pdst.fm/e/traffic.megaphone.fm/GLT8784071073.mp3?updated=1699093591) | 2023-11-14 |
| 389 | [The Fall of the Aztecs: The Night of Tears (Part 6)](https://pdst.fm/e/traffic.megaphone.fm/GLT2744313815.mp3?updated=1699093626) | 2023-11-16 |
| 390 | [The Fall of the Aztecs: War to the Death (Part 7)](https://pdst.fm/e/traffic.megaphone.fm/GLT1796642529.mp3?updated=1699093669) | 2023-11-20 |
| 391 | [The Fall of the Aztecs: The Last Emperor (Part 8)](https://pdst.fm/e/traffic.megaphone.fm/GLT2984940365.mp3?updated=1699093693) | 2023-11-23 |
