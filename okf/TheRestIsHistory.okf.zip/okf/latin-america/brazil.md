---
type: Section
title: "Brazil"
description: "Empire, republic, and modern Brazil."
tags: [latin-america]
timestamp: "2026-08-16T00:00:00Z"
---

# Brazil

Empire, republic, and modern Brazil.

4 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 229 | [Portugal: Gold, Earthquakes, and Brazil (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT8317395817.mp3?updated=1777394992) | 2022-09-07 |
| 253 | [The World Cup: Post-war reconciliation, Brazilian dictatorship, and North Koreans in Middlesbrough (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT3874165711.mp3?updated=1777395066) | 2022-11-15 |
| 268 | [Brazil: The Last Emperor](https://pdst.fm/e/traffic.megaphone.fm/GLT5634696575.mp3?updated=1777394995) | 2022-11-30 |
| 681 | [Brazil: The Emperor’s Anthem (Part 5)](https://pdst.fm/e/traffic.megaphone.fm/GLT5596929385.mp3) | 2026-06-21 |
