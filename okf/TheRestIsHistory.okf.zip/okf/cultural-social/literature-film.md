---
type: Section
title: "Literature & Film"
description: "Books, authors, and storytelling."
tags: [cultural-social]
timestamp: "2026-08-16T00:00:00Z"
---

# Literature & Film

Books, authors, and storytelling.

20 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 14 | [Historical Fiction](https://pdst.fm/e/traffic.megaphone.fm/GLT2461510190.mp3?updated=1777395054) | 2021-01-11 |
| 85 | [Sherlock Holmes](https://pdst.fm/e/traffic.megaphone.fm/GLT8342867383.mp3?updated=1777394980) | 2021-08-12 |
| 101 | [James Bond](https://pdst.fm/e/traffic.megaphone.fm/GLT6304120514.mp3?updated=1777395057) | 2021-09-27 |
| 103 | [The Norse Sagas](https://pdst.fm/e/traffic.megaphone.fm/GLT8280648151.mp3?updated=1777394993) | 2021-09-30 |
| 104 | [Macbeth](https://pdst.fm/e/traffic.megaphone.fm/GLT3313769671.mp3?updated=1777395088) | 2021-10-04 |
| 105 | [Classics](https://pdst.fm/e/traffic.megaphone.fm/GLT1093096549.mp3?updated=1777394977) | 2021-10-07 |
| 130 | [Superheroes](https://pdst.fm/e/traffic.megaphone.fm/GLT5186846131.mp3?updated=1777395088) | 2021-12-13 |
| 185 | [Agatha Christie](https://pdst.fm/e/traffic.megaphone.fm/GLT9092045420.mp3?updated=1777394933) | 2022-05-16 |
| 208 | [George Orwell](https://pdst.fm/e/traffic.megaphone.fm/GLT5823999588.mp3?updated=1777395017) | 2022-07-14 |
| 225 | [J.R.R. Tolkien](https://pdst.fm/e/traffic.megaphone.fm/GLT9725776786.mp3?updated=1694605536) | 2022-08-29 |
| 226 | [The Lord of the Rings](https://pdst.fm/e/traffic.megaphone.fm/GLT1788342017.mp3?updated=1694605356) | 2022-09-01 |
| 341 | [The Trials of Oscar Wilde: Sex and Scandal (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT1940599692.mp3?updated=1777394822) | 2023-06-15 |
| 342 | [The Trials of Oscar Wilde: Downfall and Prison (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT5549466795.mp3?updated=1777394910) | 2023-06-19 |
| 367 | [The Real Harry Potter: Magic, Empire and Beastly Bullies](https://pdst.fm/e/traffic.megaphone.fm/GLT3711207657.mp3?updated=1694524289) | 2023-09-10 |
| 368 | [The History Behind Hogwarts: Ancient Schools and Revolting Students](https://pdst.fm/e/traffic.megaphone.fm/GLT6783238013.mp3?updated=1696245232) | 2023-09-13 |
| 440 | [Lord Byron: Mad, Bad and Dangerous to Know (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT4389862746.mp3?updated=1712939145) | 2024-04-14 |
| 441 | [Lord Byron: Scandal, Sex and Celebrity (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT1954408695.mp3?updated=1712939288) | 2024-04-17 |
| 442 | [Lord Byron: Dangerous Liaisons (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT1176702097.mp3?updated=1713098396) | 2024-04-21 |
| 443 | [Lord Byron: Death of a Vampire (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT3247503776.mp3?updated=1713543415) | 2024-04-24 |
| — | [RIHC: Disney's Legacy, with Bob Iger](https://pdst.fm/e/traffic.megaphone.fm/GLT6989183827.mp3?updated=1762813212) | 2025-11-07 |
