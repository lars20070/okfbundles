---
type: Section
title: "Festivals & Traditions"
description: "Christmas, Halloween, Valentine's Day, and other customs."
tags: [cultural-social]
timestamp: "2026-08-16T00:00:00Z"
---

# Festivals & Traditions

Christmas, Halloween, Valentine's Day, and other customs.

4 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 113 | [Hallowe'en and modern paganism](https://pdst.fm/e/traffic.megaphone.fm/GLT4064224583.mp3?updated=1777395048) | 2021-11-01 |
| 114 | [Stonehenge, ancient ritual and the origins of paganism](https://pdst.fm/e/traffic.megaphone.fm/GLT2588049137.mp3?updated=1777394823) | 2021-11-02 |
| 151 | [Valentine's Day](https://pdst.fm/e/traffic.megaphone.fm/GLT1795443565.mp3?updated=1777394901) | 2022-02-14 |
| 199 | [Stonehenge](https://pdst.fm/e/traffic.megaphone.fm/GLT3612348466.mp3?updated=1775852135) | 2022-06-23 |
