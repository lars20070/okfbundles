---
type: Section
title: "Ghosts, Mysteries & the Unexplained"
description: "The paranormal and the cryptozoological in history."
tags: [cultural-social]
timestamp: "2026-08-16T00:00:00Z"
---

# Ghosts, Mysteries & the Unexplained

The paranormal and the cryptozoological in history.

9 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 66 | [Ghosts](https://pdst.fm/e/traffic.megaphone.fm/GLT2309926019.mp3?updated=1777394789) | 2021-06-24 |
| 233 | [The Loch Ness Monster](https://pdst.fm/e/traffic.megaphone.fm/GLT3620889030.mp3?updated=1694604700) | 2022-09-12 |
| 300 | [The Real Downton Abbey](https://pdst.fm/e/traffic.megaphone.fm/GLT7393411506.mp3?updated=1777394146) | 2023-02-02 |
| 314 | [Atlantis: The Legend (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT4735672898.mp3?updated=1777394202) | 2023-03-20 |
| 315 | [Atlantis: Legacy of the Lost Empire (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT2807981945.mp3?updated=1777394247) | 2023-03-23 |
| 403 | [The Mystery of the Pregnant Pope](https://pdst.fm/e/traffic.megaphone.fm/GLT1981561492.mp3?updated=1703726604) | 2023-12-28 |
| 460 | [The Empress of the Apocalypse](https://pdst.fm/e/traffic.megaphone.fm/GLT9103397168.mp3?updated=1718239019) | 2024-06-12 |
| 461 | [Dragons](https://pdst.fm/e/traffic.megaphone.fm/GLT6416738853.mp3?updated=1718583039) | 2024-06-16 |
| 483 | [The Mysterious Case of the Ape Man](https://pdst.fm/e/traffic.megaphone.fm/GLT8701811415.mp3?updated=1722856732) | 2024-08-11 |
