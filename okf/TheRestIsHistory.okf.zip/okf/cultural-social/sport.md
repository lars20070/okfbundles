---
type: Section
title: "Sport"
description: "Football, cricket, the Olympics, and more."
tags: [cultural-social]
timestamp: "2026-08-16T00:00:00Z"
---

# Sport

Football, cricket, the Olympics, and more.

15 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 33 | [The Beautiful Game](https://pdst.fm/e/traffic.megaphone.fm/GLT5860295083.mp3?updated=1777395012) | 2021-03-18 |
| 55 | [The World Cup of Gods - Preview](https://pdst.fm/e/traffic.megaphone.fm/GLT7465078719.mp3?updated=1775851945) | 2021-05-22 |
| 58 | [The World Cup of Gods - Part 1](https://pdst.fm/e/traffic.megaphone.fm/GLT8884399326.mp3?updated=1777395005) | 2021-05-31 |
| 59 | [The World Cup of Gods - Part 2](https://pdst.fm/e/traffic.megaphone.fm/GLT6474253297.mp3?updated=1777394994) | 2021-06-01 |
| 79 | [Ancient Olympics](https://pdst.fm/e/traffic.megaphone.fm/GLT9627584488.mp3?updated=1777395054) | 2021-07-26 |
| 80 | [Modern Olympics - Part 1](https://pdst.fm/e/traffic.megaphone.fm/GLT3795252606.mp3?updated=1777395096) | 2021-07-29 |
| 81 | [Modern Olympics - Part 2](https://pdst.fm/e/traffic.megaphone.fm/GLT4846758176.mp3?updated=1777394963) | 2021-07-30 |
| 119 | [World Cup of Kings & Queens preview](https://pdst.fm/e/traffic.megaphone.fm/GLT7656399161.mp3?updated=1777394815) | 2021-11-12 |
| 123 | [World Cup of Kings and Queens part 1](https://pdst.fm/e/traffic.megaphone.fm/GLT3062961015.mp3?updated=1777394962) | 2021-11-22 |
| 124 | [World Cup of Kings and Queens part 2](https://pdst.fm/e/traffic.megaphone.fm/GLT4467647081.mp3?updated=1777395053) | 2021-11-23 |
| 129 | [Cricket](https://pdst.fm/e/traffic.megaphone.fm/GLT9095163579.mp3?updated=1777395042) | 2021-12-09 |
| 252 | [The World Cup: British Imperialism, South American rivalries, and Mussolini (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT2171290588.mp3?updated=1777394983) | 2022-11-14 |
| 254 | [The World Cup: The Falklands, despots, and corruption (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT5891154284.mp3?updated=1777394932) | 2022-11-16 |
| 593 | [The Fight of the Century](https://pdst.fm/e/traffic.megaphone.fm/GLT1334632459.mp3?updated=1775852216) | 2025-08-20 |
| — | [The Fascist World Cup: Mussolini's Football Dictatorship — History of the World Cup](https://pdst.fm/e/traffic.megaphone.fm/GLT5810592007.mp3) | 2026-06-16 |
