---
type: Section
title: "Social History"
description: "The lives of ordinary people through history."
tags: [cultural-social]
timestamp: "2026-08-16T00:00:00Z"
---

# Social History

The lives of ordinary people through history.

29 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 1 | [Greatness](https://pdst.fm/e/traffic.megaphone.fm/GLT2583338621.mp3?updated=1777062859) | 2020-11-02 |
| 5 | [1981](https://pdst.fm/e/traffic.megaphone.fm/GLT3026558838.mp3?updated=1777394965) | 2020-11-16 |
| 21 | [The History of the Future](https://pdst.fm/e/traffic.megaphone.fm/GLT7103118075.mp3?updated=1777394956) | 2021-02-08 |
| 23 | [The 90s](https://pdst.fm/e/traffic.megaphone.fm/GLT8035489270.mp3?updated=1777394993) | 2021-02-15 |
| 28 | [The Kings of Comedy](https://pdst.fm/e/traffic.megaphone.fm/GLT5677879972.mp3?updated=1777395093) | 2021-03-04 |
| 45 | [Top Ten Eunuchs](https://pdst.fm/e/traffic.megaphone.fm/GLT5221212176.mp3?updated=1777395081) | 2021-04-22 |
| 50 | [Teenagers](https://pdst.fm/e/traffic.megaphone.fm/GLT9697541566.mp3?updated=1777394935) | 2021-05-10 |
| 70 | [Children's History](https://pdst.fm/e/traffic.megaphone.fm/GLT3229015713.mp3?updated=1777394975) | 2021-07-05 |
| 84 | [Exams](https://pdst.fm/e/traffic.megaphone.fm/GLT6507641896.mp3?updated=1777394961) | 2021-08-09 |
| 97 | [Top Ten Mistresses](https://pdst.fm/e/traffic.megaphone.fm/GLT8855582591.mp3?updated=1777395011) | 2021-09-16 |
| 150 | [Smuggling](https://pdst.fm/e/traffic.megaphone.fm/GLT2228422151.mp3?updated=1777395067) | 2022-02-10 |
| 154 | [The Most Disastrous Party in History](https://pdst.fm/e/traffic.megaphone.fm/GLT6506112996.mp3?updated=1777394804) | 2022-02-21 |
| 158 | [Killer Fashion](https://pdst.fm/e/traffic.megaphone.fm/GLT5960489800.mp3?updated=1777394962) | 2022-03-03 |
| 191 | [Childbirth](https://pdst.fm/e/traffic.megaphone.fm/GLT5119375504.mp3?updated=1777394903) | 2022-06-02 |
| 206 | [Historical Love Island](https://pdst.fm/e/traffic.megaphone.fm/GLT8073929093.mp3?updated=1777394901) | 2022-07-11 |
| 207 | [Historical Love Island: THE WINNER](https://pdst.fm/e/traffic.megaphone.fm/GLT4172810067.mp3?updated=1775851769) | 2022-07-13 |
| 216 | [Pigeons](https://pdst.fm/e/traffic.megaphone.fm/GLT2770080110.mp3?updated=1694606770) | 2022-08-01 |
| 221 | [Holidays: Byron's Grand Tour](https://pdst.fm/e/traffic.megaphone.fm/GLT3921798295.mp3?updated=1694606007) | 2022-08-15 |
| 223 | [Sun, Sea, and Sex](https://pdst.fm/e/traffic.megaphone.fm/GLT5217352210.mp3?updated=1694605685) | 2022-08-22 |
| 323 | [History's Greatest Dogs](https://pdst.fm/e/traffic.megaphone.fm/GLT5170761413.mp3?updated=1777394160) | 2023-04-20 |
| 357 | [Historical Love Island: The Sequel](https://pdst.fm/e/traffic.megaphone.fm/GLT7719682575.mp3?updated=1692015923) | 2023-08-06 |
| 363 | [Sixties Fashion: The Teenage Revolution (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT5487814001.mp3?updated=1729782129) | 2023-08-27 |
| 426 | [History's Greatest Monkeys](https://pdst.fm/e/traffic.megaphone.fm/GLT5532014348.mp3?updated=1709802504) | 2024-03-07 |
| 459 | [The Suit, Savile Row, and Smartly Dressed Men](https://pdst.fm/e/traffic.megaphone.fm/GLT8912379704.mp3?updated=1717951459) | 2024-06-09 |
| 624 | [Jack The Ripper: History’s Darkest Mystery (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT7829555893.mp3?updated=1764858656) | 2025-12-08 |
| 625 | [Jack The Ripper: Horror in Whitechapel (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT2555108111.mp3?updated=1784107685) | 2025-12-11 |
| 626 | [Jack The Ripper: The Killer Strikes Again (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT7980605076.mp3?updated=1784107604) | 2025-12-15 |
| 627 | [Jack The Ripper: From Hell (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT6270048402.mp3?updated=1765988289) | 2025-12-18 |
| 628 | [Jack The Ripper: The Killer Unmasked (Part 5)](https://pdst.fm/e/traffic.megaphone.fm/GLT3796910737.mp3?updated=1766065370) | 2025-12-22 |
