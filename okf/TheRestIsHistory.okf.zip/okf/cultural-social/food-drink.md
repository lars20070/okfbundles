---
type: Section
title: "Food & Drink"
description: "The history of what we eat and drink."
tags: [cultural-social]
timestamp: "2026-08-16T00:00:00Z"
---

# Food & Drink

The history of what we eat and drink.

10 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 10 | [Christmas](https://pdst.fm/e/traffic.megaphone.fm/GLT9855064623.mp3?updated=1777394940) | 2020-12-21 |
| 49 | [Food Glorious Food](https://pdst.fm/e/traffic.megaphone.fm/GLT7001895639.mp3?updated=1777394947) | 2021-05-06 |
| 132 | [A Christmas Carol](https://pdst.fm/e/traffic.megaphone.fm/GLT9074696790.mp3?updated=1777394915) | 2021-12-20 |
| — | [12 Days: Port wine and Darwin sets sail](https://pdst.fm/e/traffic.megaphone.fm/GLT6423200478.mp3?updated=1777394826) | 2021-12-27 |
| 289 | [Drink](https://pdst.fm/e/traffic.megaphone.fm/GLT6408276244.mp3?updated=1777394179) | 2022-12-26 |
| 356 | [The Blood-Drinking Bride of Christ](https://pdst.fm/e/traffic.megaphone.fm/GLT8496536394.mp3?updated=1692016048) | 2023-08-02 |
| 402 | [Christmas: Pagan or Christian?](https://pdst.fm/e/traffic.megaphone.fm/GLT8329172184.mp3?updated=1703508615) | 2023-12-25 |
| 425 | [The History Of Chocolate](https://pdst.fm/e/traffic.megaphone.fm/GLT9203655246.mp3?updated=1709546956) | 2024-03-04 |
| 484 | [The Food that Changed the World](https://pdst.fm/e/traffic.megaphone.fm/GLT2872429496.mp3?updated=1723114973) | 2024-08-14 |
| 666 | [Wine and the Birth of Civilisation](https://pdst.fm/e/traffic.megaphone.fm/GLT1414718476.mp3?updated=1777979642) | 2026-05-03 |
