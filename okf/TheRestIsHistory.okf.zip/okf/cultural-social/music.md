---
type: Section
title: "Music"
description: "Composers, bands, and the history of sound."
tags: [cultural-social]
timestamp: "2026-08-16T00:00:00Z"
---

# Music

Composers, bands, and the history of sound.

11 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 91 | [The Beatles](https://pdst.fm/e/traffic.megaphone.fm/GLT5767145023.mp3?updated=1777395060) | 2021-08-30 |
| 526 | [Mozart: History's Greatest Prodigy LIVE at the Royal Albert Hall](https://pdst.fm/e/traffic.megaphone.fm/GLT4198925734.mp3?updated=1735520137) | 2024-12-30 |
| 527 | [Beethoven: Napoleon and the Music of War LIVE at the Royal Albert Hall](https://pdst.fm/e/traffic.megaphone.fm/GLT4140502571.mp3?updated=1735600324) | 2025-01-02 |
| 558 | [The Rolling Stones: Sex, Drugs and Rock ‘n’ Roll (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT1663902020.mp3?updated=1745166333) | 2025-04-20 |
| 559 | [The Rolling Stones: Satanic Majesties of Sixties Rebellion (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT1390188077.mp3?updated=1745417239) | 2025-04-23 |
| — | [The Beatles: The Band that Changed the World, with Conan O’Brien (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT5632094525.mp3?updated=1764730276) | 2025-12-03 |
| — | [The Beatles: The British Invasion, with Conan O’Brien (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT4240205398.mp3?updated=1765280297) | 2025-12-10 |
| 630 | [Tchaikovsky: LIVE at the Royal Albert Hall](https://pdst.fm/e/traffic.megaphone.fm/GLT2445190309.mp3?updated=1766537673) | 2025-12-29 |
| 631 | [Wagner: LIVE at the Royal Albert Hall](https://pdst.fm/e/traffic.megaphone.fm/GLT7214350401.mp3?updated=1766537584) | 2026-01-01 |
| 677 | [USA: The Star-Spangled Banner (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT7890467734.mp3) | 2026-06-07 |
| 678 | [Britain: God Save the King (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT2603959218.mp3) | 2026-06-10 |
