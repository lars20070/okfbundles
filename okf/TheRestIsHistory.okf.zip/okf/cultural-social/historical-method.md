---
type: Section
title: "Historical Method & Perspective"
description: "How history is written, taught, and understood."
tags: [cultural-social]
timestamp: "2026-08-16T00:00:00Z"
---

# Historical Method & Perspective

How history is written, taught, and understood.

29 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 7 | [The Lessons of History](https://pdst.fm/e/traffic.megaphone.fm/GLT2771707131.mp3?updated=1777395007) | 2020-11-30 |
| 15 | [Walls and Borders](https://pdst.fm/e/traffic.megaphone.fm/GLT1636005045.mp3?updated=1777395052) | 2021-01-18 |
| 22 | [Weird Wars](https://pdst.fm/e/traffic.megaphone.fm/GLT2360848948.mp3?updated=1777395020) | 2021-02-11 |
| 25 | [Empires](https://pdst.fm/e/traffic.megaphone.fm/GLT2896270746.mp3?updated=1777395048) | 2021-02-22 |
| 32 | [What if?](https://pdst.fm/e/traffic.megaphone.fm/GLT7767131043.mp3?updated=1777394951) | 2021-03-15 |
| 40 | [History as Entertainment](https://pdst.fm/e/traffic.megaphone.fm/GLT9519276470.mp3?updated=1777395013) | 2021-04-05 |
| 47 | [The Seven Years' War](https://pdst.fm/e/traffic.megaphone.fm/GLT8800494407.mp3?updated=1777394979) | 2021-04-29 |
| 86 | [The Enlightenment](https://pdst.fm/e/traffic.megaphone.fm/GLT8077157127.mp3?updated=1777394988) | 2021-08-16 |
| 89 | [Climate & Weather](https://pdst.fm/e/traffic.megaphone.fm/GLT6521438447.mp3?updated=1777395012) | 2021-08-23 |
| 108 | [The Industrial Revolution](https://pdst.fm/e/traffic.megaphone.fm/GLT2130563458.mp3?updated=1777395061) | 2021-10-14 |
| 110 | [History of India in 10 Buildings](https://pdst.fm/e/traffic.megaphone.fm/GLT7972990176.mp3?updated=1777395001) | 2021-10-21 |
| 111 | [Golden Ages](https://pdst.fm/e/traffic.megaphone.fm/GLT9885576415.mp3?updated=1777394997) | 2021-10-25 |
| — | [12 Days: Jean-Bédel Bokassa and the memory of pandemics](https://pdst.fm/e/traffic.megaphone.fm/GLT8335317305.mp3?updated=1777394844) | 2021-12-31 |
| 136 | [1922: The Birth of the Modern World Part 1](https://pdst.fm/e/traffic.megaphone.fm/GLT1607440485.mp3?updated=1777394940) | 2022-01-13 |
| 137 | [1922: The Birth of the Modern World Part 2](https://pdst.fm/e/traffic.megaphone.fm/GLT5281126494.mp3?updated=1777394956) | 2022-01-14 |
| 140 | [The Birth of the Railways](https://pdst.fm/e/traffic.megaphone.fm/GLT2177757841.mp3?updated=1777395082) | 2022-01-20 |
| 146 | [Disease vs. the rise of civilisation](https://pdst.fm/e/traffic.megaphone.fm/GLT4238916512.mp3?updated=1775852124) | 2022-02-03 |
| 147 | [Disease, the New World and modern pandemics](https://pdst.fm/e/traffic.megaphone.fm/GLT1023018457.mp3?updated=1777394863) | 2022-02-04 |
| 183 | [History's Biggest Questions with Dan Carlin (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT3395544177.mp3?updated=1694617962) | 2022-05-09 |
| 184 | [History's Biggest Questions with Dan Carlin (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT1976082798.mp3?updated=1777394996) | 2022-05-12 |
| 290 | [2022: A History](https://pdst.fm/e/traffic.megaphone.fm/GLT4625765030.mp3?updated=1777394182) | 2022-12-29 |
| 306 | [Columbus: The Adventure Begins (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT6089901915.mp3?updated=1777394222) | 2023-02-20 |
| 307 | [Columbus: A New World? (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT7219741357.mp3?updated=1777394820) | 2023-02-23 |
| 308 | [Columbus: Death in the Caribbean (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT3250512968.mp3?updated=1777394856) | 2023-02-27 |
| 309 | [Columbus: Villain or Hero? (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT6751575003.mp3?updated=1777394191) | 2023-03-02 |
| 313 | [Climate Apocalypse](https://pdst.fm/e/traffic.megaphone.fm/GLT8815959934.mp3?updated=1777394237) | 2023-03-16 |
| 316 | [The First Abolitionist](https://pdst.fm/e/traffic.megaphone.fm/GLT2136062721.mp3?updated=1777394987) | 2023-03-27 |
| 326 | [The Year of Revolutions: 1848](https://pdst.fm/e/traffic.megaphone.fm/GLT9746323554.mp3?updated=1777394808) | 2023-05-01 |
| 362 | [The Taj Mahal: Love and Death](https://pdst.fm/e/traffic.megaphone.fm/GLT2445608477.mp3?updated=1692810615) | 2023-08-23 |
