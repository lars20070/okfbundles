# World War I

The Great War — causes, battles, and aftermath.

23 episodes.

## Subtopics
* [The First World War (2025–26 series)](/world-war-one/first-world-war-series.md) — The major series covering the war's campaigns. (18 episodes)
* [WWI Specials](/world-war-one/ww1-specials.md) — Standalone episodes on the war. (5 episodes)
