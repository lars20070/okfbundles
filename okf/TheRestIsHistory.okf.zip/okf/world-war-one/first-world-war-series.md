---
type: Section
title: "The First World War (2025–26 series)"
description: "The major series covering the war's campaigns."
tags: [world-war-one]
timestamp: "2026-08-16T00:00:00Z"
---

# The First World War (2025–26 series)

The major series covering the war's campaigns.

18 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 9 | [Causes of the First World War](https://pdst.fm/e/traffic.megaphone.fm/GLT8234482474.mp3?updated=1777395079) | 2020-12-14 |
| 118 | [End of the First World War & Remembrance](https://pdst.fm/e/traffic.megaphone.fm/GLT2743125909.mp3?updated=1777395022) | 2021-11-11 |
| 469 | [The Road to The Great War: Countdown to Armageddon (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT3669608632.mp3?updated=1721008019) | 2024-07-14 |
| 470 | [The Road to The Great War: The Kaiser’s Blank Cheque (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT1054108569.mp3?updated=1721262147) | 2024-07-17 |
| 471 | [The Road to The Great War: The Austrian Ultimatum (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT1171003479.mp3?updated=1721346208) | 2024-07-18 |
| 472 | [The Road to The Great War: Britain's Fateful Choice (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT6983892157.mp3?updated=1721723355) | 2024-07-21 |
| 473 | [The Road to The Great War: The Tsar Chooses War (Part 5)](https://pdst.fm/e/traffic.megaphone.fm/GLT1322848845.mp3?updated=1721861492) | 2024-07-24 |
| 474 | [The Road to The Great War: The Lights Go Out (Part 6)](https://pdst.fm/e/traffic.megaphone.fm/GLT2293540702.mp3?updated=1721953753) | 2024-07-25 |
| 594 | [The First World War: The Invasion of Belgium (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT4855256129.mp3?updated=1755880436) | 2025-08-24 |
| 595 | [The First World War: The Battle of the Frontiers (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT5758313909.mp3?updated=1756312614) | 2025-08-27 |
| 597 | [The First World War: The Massacre of the Innocents (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT9434623550.mp3?updated=1757078000) | 2025-09-03 |
| 598 | [The First World War: The Eastern Front Explodes (Part 5)](https://pdst.fm/e/traffic.megaphone.fm/GLT2256735701.mp3?updated=1757428931) | 2025-09-05 |
| 671 | [The First World War: Blood in the Trenches (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT2309179565.mp3) | 2026-05-17 |
| 672 | [The First World War: Italy’s Doomed Campaign (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT3383347829.mp3) | 2026-05-20 |
| 673 | [The First World War: The Submarine Strikes (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT3632974949.mp3) | 2026-05-24 |
| 674 | [The First World War: The Spy Who Took on the Germans (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT1889262052.mp3) | 2026-05-27 |
| 675 | [The First World War: Slaughter at Gallipoli (Part 5)](https://pdst.fm/e/traffic.megaphone.fm/GLT4394132715.mp3) | 2026-05-31 |
| 676 | [The First World War: Churchill’s Calamity (Part 6)](https://pdst.fm/e/traffic.megaphone.fm/GLT1275431911.mp3) | 2026-06-03 |
