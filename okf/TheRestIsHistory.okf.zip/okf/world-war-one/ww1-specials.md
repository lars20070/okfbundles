---
type: Section
title: "WWI Specials"
description: "Standalone episodes on the war."
tags: [world-war-one]
timestamp: "2026-08-16T00:00:00Z"
---

# WWI Specials

Standalone episodes on the war.

5 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 90 | [The Western Front](https://pdst.fm/e/traffic.megaphone.fm/GLT9972346188.mp3?updated=1777395054) | 2021-08-26 |
| 465 | [The Murder of Franz Ferdinand: The Killer (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT8626991580.mp3?updated=1719791043) | 2024-06-30 |
| 467 | [The Murder of Franz Ferdinand: The Victim (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT9071060087.mp3?updated=1720382139) | 2024-07-07 |
| 468 | [The Murder of Franz Ferdinand: The Crime (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT1158335154.mp3?updated=1720521521) | 2024-07-10 |
| 629 | [WWI: The Christmas Truce](https://pdst.fm/e/traffic.megaphone.fm/GLT5393732684.mp3?updated=1766065378) | 2025-12-25 |
