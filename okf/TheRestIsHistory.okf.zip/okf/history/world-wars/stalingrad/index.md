# The Battle of Stalingrad (Part 1)

## Episodes

* [The Battle of Stalingrad (Part 1)](/history/world-wars/stalingrad/01-the-battle-of-stalingrad.md) — Episode 214: Stalingrad: the bloodiest battle of the Second World War.
* [Stalingrad and the Red Army (Part 2)](/history/world-wars/stalingrad/02-stalingrad-and-the-red-army.md) — Episode 215: Tom and Dominic are again joined by Iain MacGregor to discuss the climax of the Battle of Stalingrad.
