---
type: Section
title: "The Battle of Stalingrad (Part 1)"
description: "Episode 214: Stalingrad: the bloodiest battle of the Second World War."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "stalingrad", "world-war-ii"]
---

# The Battle of Stalingrad (Part 1)

2022-07-25 · 48:41 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4564292022.mp3?updated=1729785212)

Stalingrad: the bloodiest battle of the Second World War. Tom and Dominic are joined by Iain MacGregor to discuss the build up, context and outbreak of the Battle of Stalingrad. A second Stalingrad episode will be released on Thursday to your podcast feed. However, if you are part of The Rest Is History Club, you get the second episode right NOW! Join The Rest Is History Club for ad-free …