---
type: Section
title: "Stalingrad and the Red Army (Part 2)"
description: "Episode 215: Tom and Dominic are again joined by Iain MacGregor to discuss the climax of the Battle of Stalingrad."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "stalingrad", "world-war-ii"]
---

# Stalingrad and the Red Army (Part 2)

2022-07-28 · 48:17 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4269997308.mp3?updated=1777394881)

Tom and Dominic are again joined by Iain MacGregor to discuss the climax of the Battle of Stalingrad, Pavlov's House, and the Red Army's counter offensive that ultimately defeated the Axis forces. Join The Rest Is History Club for ad-free listening to the full archive, weekly bonus episodes, live streamed shows and access to an exclusive chatroom community.