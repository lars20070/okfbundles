---
type: Section
title: "The Man Who Escaped Auschwitz"
description: "Episode 291: Tom and Dominic are joined by Jonathan Freedland to discuss the incredible story of Rudolf Vrba and Alfréd Wetzler."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "auschwitz", "holocaust", "world-war-ii"]
---

# The Man Who Escaped Auschwitz

2023-01-02 · 53:20 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6191002964.mp3?updated=1777394191)

Tom and Dominic are joined by Jonathan Freedland to discuss the incredible story of Rudolf Vrba and Alfréd Wetzler, who escaped from Auschwitz in April 1944.