# The Man Who Escaped Auschwitz

## Episodes

* [The Man Who Escaped Auschwitz](/history/world-wars/auschwitz-escape/01-the-man-who-escaped-auschwitz.md) — Episode 291: Tom and Dominic are joined by Jonathan Freedland to discuss the incredible story of Rudolf Vrba and Alfréd Wetzler.
* [The Shadow of the Holocaust](/history/world-wars/auschwitz-escape/02-the-shadow-of-the-holocaust.md) — Episode 292: In our second episode exploring the story of Rudolf Vrba, Jonathan Freedland joins Tom and Dominic again.
