---
type: Section
title: "The Shadow of the Holocaust"
description: "Episode 292: In our second episode exploring the story of Rudolf Vrba, Jonathan Freedland joins Tom and Dominic again."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "auschwitz", "holocaust", "world-war-ii"]
---

# The Shadow of the Holocaust

2023-01-05 · 44:25 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7756076339.mp3?updated=1777394169)

In our second episode exploring the story of Rudolf Vrba, Jonathan Freedland joins Tom and Dominic again, to discuss the global reaction to the Vrba–Wetzler report: did anti-Semitism shape the Allied response?