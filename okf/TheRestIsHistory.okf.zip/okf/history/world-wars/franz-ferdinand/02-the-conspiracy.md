---
type: Section
title: "The Conspiracy (Part 2)"
description: "Episode 466: The Black Hand and the plot for a greater Yugoslavia."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "franz-ferdinand"]
---

# The Conspiracy (Part 2)

2024-07-03 · 55:01 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2060941792.mp3?updated=1720023414)

Gavrilo Princip, having been sent to school in Sarajevo, has become mixed up with the wrong crowd, and is now entangled in a secret Serbian nationalist organisation, the Black Hand. Hoping to be more involved in the struggle for a greater Yugoslavia, he's left for Belgrade, and after a few years, sets in motion a plot, supported by his underground network. The Austro-Hungarian emperor is on his …
