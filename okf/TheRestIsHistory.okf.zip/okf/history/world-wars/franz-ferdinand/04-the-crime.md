---
type: Section
title: "The Crime (Part 4)"
description: "Episode 468: The assassination in Sarajevo on June 28, 1914."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "franz-ferdinand"]
---

# The Crime (Part 4)

2024-07-10 · 1:00:34 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1158335154.mp3?updated=1720521521)

Archduke Franz Ferdinand has arrived in Sarajevo for a military inspection, alongside his wife, Sophie, on the 28th of June 1914. Unbeknownst to them, six assassins, including Gavrilo Princip, line the route of the motorcade, from Sarajevo train station to the town hall. Having completed the inspection, the Archduke faces a first assassination attempt on the way to the town hall, as a bomb …
