# The Killer (Part 1)

## Episodes

* [The Killer (Part 1)](/history/world-wars/franz-ferdinand/01-the-killer.md) — Episode 465: Gavrilo Princip and the assassin of Archduke Franz Ferdinand.
* [The Conspiracy (Part 2)](/history/world-wars/franz-ferdinand/02-the-conspiracy.md) — Episode 466: The Black Hand and the plot for a greater Yugoslavia.
* [The Victim (Part 3)](/history/world-wars/franz-ferdinand/03-the-victim.md) — Episode 467: Franz Ferdinand and his lonely marriage to Sophie.
* [The Crime (Part 4)](/history/world-wars/franz-ferdinand/04-the-crime.md) — Episode 468: The assassination in Sarajevo on June 28, 1914.
