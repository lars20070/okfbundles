---
type: Section
title: "The Killer (Part 1)"
description: "Episode 465: Gavrilo Princip and the assassin of Archduke Franz Ferdinand."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "franz-ferdinand", "world-war-i"]
---

# The Killer (Part 1)

2024-06-30 · 1:04:45 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8626991580.mp3?updated=1719791043)

The assassination of Archduke Franz Ferdinand, heir to one of the world's greatest empires, in June 1914, set in motion a series of events that would culminate in the First World War, where more than 15 million people would lose their lives. Franz Ferdinand's assassin, Gavrilo Princip, did not share the same illustrious lineage. A Bosnian serb of humble origins who dreamed of a greater …
