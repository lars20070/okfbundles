---
type: Section
title: "The Victim (Part 3)"
description: "Episode 467: Franz Ferdinand and his lonely marriage to Sophie."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "franz-ferdinand"]
---

# The Victim (Part 3)

2024-07-07 · 58:02 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9071060087.mp3?updated=1720382139)

Archduke Franz Ferdinand, as heir to the Austro-Hungarian Empire, was one of the most important men in the world. But he was a lonely man, not helped by the fact that, in spite of custom and tradition, he had chosen for wife Sophie, an aristocrat who nonetheless was not noble enough to marry a Habsburg Archduke. Public humiliation, enforced by the Emperor himself, would plague them for the rest …
