---
type: Section
title: "Countdown to Armageddon (Part 1)"
description: "Episode 469: From the assassination of Archduke Franz Ferdinand to the July crisis."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "world-war-i", "franz-ferdinand"]
---

# Countdown to Armageddon (Part 1)

2024-07-14 · 48:40 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3669608632.mp3?updated=1721008019)

By the end of July 1914, the world hovered on the edge of a cataclysmic world war; Austria was at war with Serbia, Russia with Germany, and an ultimatum had been handed to Belgium. The July crisis had resolved itself in the most calamitous way possible. But how did this state of affairs erupt from the assassination of Archduke Franz Ferdinand and his wife, Sophie, in Sarajevo a month earlier? …
