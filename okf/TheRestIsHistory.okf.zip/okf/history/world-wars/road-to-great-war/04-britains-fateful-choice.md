---
type: Section
title: "Britain's Fateful Choice (Part 4)"
description: "Episode 472: Focus turns to Britain as Germany stands by Austria."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "world-war-i", "britain"]
---

# Britain's Fateful Choice (Part 4)

2024-07-21 · 53:45 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6983892157.mp3?updated=1721723355)

On the 24th of July 1914, in London, the Liberal British Cabinet met to hear the Foreign Secretary, Sir Edward Grey, read them the Ultimatum handed to Serbia by the Austro-Hungarian Empire the day before. The world held its breath, awaiting Serbia's response. With Germany determined to stand by Austria, and the French against them, focus now turned turned to Britain. Historically a German ally …
