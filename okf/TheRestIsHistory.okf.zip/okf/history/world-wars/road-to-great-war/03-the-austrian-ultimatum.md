---
type: Section
title: "The Austrian Ultimatum (Part 3)"
description: "Episode 471: France and Russia meeting as Austria writes the ultimatum to Serbia."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "world-war-i"]
---

# The Austrian Ultimatum (Part 3)

2024-07-18 · 52:40 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1171003479.mp3?updated=1721346208)

On the 20th of July 1914 the heads of state of two great European powers - France and Russia - met in St Petersburg. Little did they know, though they may have suspected, that the Austrians were simultaneously writing up an Ultimatum, and waiting for the departure of the French to hand it to Serbia. Russia, at that time a vast continental empire under the leadership of the conservative, nervous …
