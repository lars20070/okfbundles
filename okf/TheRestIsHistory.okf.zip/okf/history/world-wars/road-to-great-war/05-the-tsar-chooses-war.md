---
type: Section
title: "The Tsar Chooses War (Part 5)"
description: "Episode 473: The Kaiser and the Tsar friends and cousins find themselves in a precarious situation."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "world-war-i"]
---

# The Tsar Chooses War (Part 5)

2024-07-24 · 55:29 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1322848845.mp3?updated=1721861492)

"We have been forced to draw the sword". Following the expiry of Austria's Ultimatum on Saturday 25th July 1914, the Kaiser and the Tsar - friends and cousins, long desirous of peace between their two nations - found themselves in a new and highly precarious situation. Even so, there was still a widespread sense across Europe that war could be avoided, with Sir Edward Grey determined to mediate …
