---
type: Section
title: "The Kaiser's Blank Cheque (Part 2)"
description: "Episode 470: Austria's opportunity for decisive action after the assassination."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "world-war-i", "franz-ferdinand"]
---

# The Kaiser's Blank Cheque (Part 2)

2024-07-17 · 45:08 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1054108569.mp3?updated=1721262147)

In the wake of the cataclysmic assassination of Franz Ferdinand on the 28th of June 1914, in Austria, the long percolating question of what to do about Serbia, reached a climax. At last, they had been handed an opportunity to take decisive action. On Sunday 5th of July an emissary of the the old and embattled emperor Franz Joseph I of Austria, arrived in a deserted Berlin with letters for Kaiser …
