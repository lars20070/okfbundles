---
type: Section
title: "The Lights Go Out (Part 6)"
description: "Episode 474: Britain held its breath as the Kaiser believed he could count on George V."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "world-war-i"]
---

# The Lights Go Out (Part 6)

2024-07-25 · 1:07:52 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2293540702.mp3?updated=1721953753)

"The lamps are going out all over Europe, we shall not see them lit again in our lifetime" In the early days of August 1914, the British press has become increasingly vocal about the prospect of war breaking out amongst the great European powers. But the Kaiser still believes he can count on his ambassador in London, and his dear cousin, George V, to make sure Britain stays out of the war, giving …
