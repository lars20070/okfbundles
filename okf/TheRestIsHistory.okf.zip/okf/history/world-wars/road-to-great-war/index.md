# Countdown to Armageddon (Part 1)

## Episodes

* [Countdown to Armageddon (Part 1)](/history/world-wars/road-to-great-war/01-countdown-to-armageddon.md) — Episode 469: From the assassination of Archduke Franz Ferdinand to the July crisis.
* [The Kaiser's Blank Cheque (Part 2)](/history/world-wars/road-to-great-war/02-the-kaisers-blank-cheque.md) — Episode 470: Austria's opportunity for decisive action after the assassination.
* [The Austrian Ultimatum (Part 3)](/history/world-wars/road-to-great-war/03-the-austrian-ultimatum.md) — Episode 471: France and Russia meeting as Austria writes the ultimatum to Serbia.
* [Britain's Fateful Choice (Part 4)](/history/world-wars/road-to-great-war/04-britains-fateful-choice.md) — Episode 472: Focus turns to Britain as Germany stands by Austria.
* [The Tsar Chooses War (Part 5)](/history/world-wars/road-to-great-war/05-the-tsar-chooses-war.md) — Episode 473: The Kaiser and the Tsar friends and cousins find themselves in a precarious situation.
* [The Lights Go Out (Part 6)](/history/world-wars/road-to-great-war/06-the-lights-go-out.md) — Episode 474: Britain held its breath as the Kaiser believed he could count on George V.
