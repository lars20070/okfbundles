---
type: Section
title: "Hitler's Dream (Part 5)"
description: "Episode 408: The compulsory sterilisation law and the Aryan race."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "nazis", "hitler"]
---

# Hitler's Dream (Part 5)

2024-01-15 · 53:08 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6100029744.mp3?updated=1729781181)

"We must have a healthy people to dominate in the world". In July 1933, Hitler's Nazi party passed a new law for the compulsory sterilisation of anyone with a physical disability, or "congenital feeble-mindedness". They claimed this was scientifically sound, and for the moral and biological good of the Aryan race. The measure darkly foreshadowed the tragedies to come, as Nazi Germany ratcheted up …