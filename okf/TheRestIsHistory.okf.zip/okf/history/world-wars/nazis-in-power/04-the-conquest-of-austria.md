---
type: Section
title: "The Conquest of Austria (Part 4)"
description: "Episode 407: The annexation of Austria and Kurt Schuschnigg's referendum."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "nazis", "hitler"]
---

# The Conquest of Austria (Part 4)

2024-01-11 · 55:25 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5380362144.mp3?updated=1729781149)

By 1937, Hitler's ever-growing ambitions were driving Europe to the brink of war. Ever restless, he knew that Germany must conquer the world, or be destroyed. His first target was Austria, his homeland, whose annexation to Germany would unite German blood under one indomitable Reich. However, in an effort to avoid Nazi rule, the Austrian Chancellor, Kurt Schuschnigg, called a referendum on …