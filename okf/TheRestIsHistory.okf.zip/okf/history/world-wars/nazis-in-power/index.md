# The Night of the Long Knives (Part 1)

## Episodes

* [The Night of the Long Knives (Part 1)](/history/world-wars/nazis-in-power/01-the-night-of-the-long-knives.md) — Episode 404: The bloody faction fight within the Party on 30 June 1934.
* [The Nuremberg Rallies (Part 2)](/history/world-wars/nazis-in-power/02-the-nuremberg-rallies.md) — Episode 405: The sixth annual party conference in September 1934.
* [Hitler's Road to War (Part 3)](/history/world-wars/nazis-in-power/03-hitlers-road-to-war.md) — Episode 406: Hitler planning for war since 1928 and overcoming internal enemies.
* [The Conquest of Austria (Part 4)](/history/world-wars/nazis-in-power/04-the-conquest-of-austria.md) — Episode 407: The annexation of Austria and Kurt Schuschnigg's referendum.
* [Hitler's Dream (Part 5)](/history/world-wars/nazis-in-power/05-hitlers-dream.md) — Episode 408: The compulsory sterilisation law and the Aryan race.
* [Hitler's War on the Jews (Part 6)](/history/world-wars/nazis-in-power/06-hitlers-war-on-the-jews.md) — Episode 409: Totalitarian oppression against Jewish people.
* [The Night of Broken Glass (Part 7)](/history/world-wars/nazis-in-power/07-the-night-of-broken-glass.md) — Episode 410: Synagogues destroyed and plans for mass action against Jewish people.
