---
type: Section
title: "Hitler's War on the Jews (Part 6)"
description: "Episode 409: Totalitarian oppression against Jewish people."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "nazis", "hitler"]
---

# Hitler's War on the Jews (Part 6)

2024-01-16 · 51:48 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9460111455.mp3?updated=1729781195)

As Hitler ramps up the German war machine, he remains obsessed with one idea: uprooting Jews from the Reich. The Nazis embark on a campaign of totalitarian oppression against them, persecuting Jewish people in every aspect of life. They are excluded from most professions, forbidden from intermarrying, Jewish children are bullied and excluded from schools, all Jews have a "J" stamped in their …