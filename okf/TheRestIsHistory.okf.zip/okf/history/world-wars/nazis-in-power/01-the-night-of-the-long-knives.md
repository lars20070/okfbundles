---
type: Section
title: "The Night of the Long Knives (Part 1)"
description: "Episode 404: The bloody faction fight within the Party on 30 June 1934."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "nazis", "hitler"]
---

# The Night of the Long Knives (Part 1)

2024-01-01 · 55:08 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3861584466.mp3?updated=1729781069)

"Hitler had entered Röhm's bedroom alone with a whip in his hand. Behind him had stood two detectives holding pistols, with the safety catch removed, at the ready…" The 30th of June 1934 saw a seismic moment unfold in the early years of the Third Reich. With the Führer and his party firmly in power, a bloody faction fight takes place within the Party. The Nazis have gained control of both the …