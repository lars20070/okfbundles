---
type: Section
title: "The Night of Broken Glass (Part 7)"
description: "Episode 410: Synagogues destroyed and plans for mass action against Jewish people."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "nazis", "hitler"]
---

# The Night of Broken Glass (Part 7)

2024-01-18 · 44:44 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5771265943.mp3?updated=1729781221)

By November 1938 the scene in Germany was at its darkest yet, as the full scale of Hitler's intentions for the Jewish population of the German Reich was becoming evermore apparent. As the threat of another world war increased, so the Nazi anti-semitism machine went up a gear. Synagogues were destroyed, Jewish businessmen, bureaucrats, lawyers and doctors disbarred, plans were made for a mass …