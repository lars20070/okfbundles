---
type: Section
title: "Hitler's Road to War (Part 3)"
description: "Episode 406: Hitler planning for war since 1928 and overcoming internal enemies."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "nazis", "hitler"]
---

# Hitler's Road to War (Part 3)

2024-01-08 · 59:15 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6776521114.mp3?updated=1729781136)

"No one can doubt that this world will one day be the scene of dreadful struggles for existence on the part of mankind. In the end, the instinct of self-preservation alone will triumph." Hitler has been planning for war since 1928. However, the Treaty of Versailles has placed immense limitations on his ability to rearm Germany, and he must first overcome internal enemies, whether the SA or the …