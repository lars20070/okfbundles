---
type: Section
title: "The Nuremberg Rallies (Part 2)"
description: "Episode 405: The sixth annual party conference in September 1934."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "nazis", "hitler"]
---

# The Nuremberg Rallies (Part 2)

2024-01-04 · 53:05 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8681167377.mp3?updated=1729781109)

"We did not lose the war because our artillery gave out, but because the weapons of our mind didn't fire" In September 1934, the Nazis held their sixth annual party conference in the Bavarian city of Nuremberg. The location held a symbolic resonance for the party, being not only the embodiment of an uncorrupted medieval Germany, and the centre of the First Reich, but also a bedrock of …