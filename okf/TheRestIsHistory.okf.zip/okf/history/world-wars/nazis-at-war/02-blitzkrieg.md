---
type: Section
title: "Blitzkrieg (Part 2)"
description: "Episode 621: Hitler's conquest of Norway, Denmark, and France."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, world-war-ii, nazis]
---

# Blitzkrieg (Part 2)

2025-11-27 · 1:06:55 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8711886512.mp3?updated=1784111303)

When Hitler's eye fell on Norway and Denmark, how did he and the Nazis enact their terrible plan of conquest? How did the Allies respond to this western campaign? And, how did the French fare against the furious German attack…? Join Dominic and Tom as they discuss the next bombastic phase of the Nazis at war.
