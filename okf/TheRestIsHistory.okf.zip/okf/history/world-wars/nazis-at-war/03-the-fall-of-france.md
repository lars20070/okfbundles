---
type: Section
title: "The Fall of France (Part 3)"
description: "Episode 622: The Battle of Dunkirk and a key turning point."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, world-war-ii, nazis]
---

# The Fall of France (Part 3)

2025-12-01 · 1:07:54 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6447940829.mp3?updated=1764261729)

How did the Battle of Dunkirk unfold in 1940? Why was it one of the key turning points of the Second World War for Hitler and his Nazi regime? And, how did the Allies manage to evade the jaws of annihilation at this crucial stage of the Second World War…? Join Dominic and Tom as they march further into the Nazis at war, with Hitler's forces closing in on the Allies at Dunkirk, before wreaking …
