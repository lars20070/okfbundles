---
type: Section
title: "Hitler Strikes West (Part 1)"
description: "Episode 620: The Second World War begins with Hitler's westward expansion."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, world-war-ii, nazis]
---

# Hitler Strikes West (Part 1)

2025-11-24 · 1:12:01 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4381972581.mp3?updated=1784111378)

What was Adolf Hitler's next move, after occupying Czechoslovakia in March 1939, and brutally invading Poland that September? Why did the Allies fail to act, despite the Nazis shocking offensive? And, would an assassination plot from within Germany itself prove to be Hitler's undoing? Join Dominic and Tom as they launch into the Second World War, as Hitler and the Nazis escalate their war on …
