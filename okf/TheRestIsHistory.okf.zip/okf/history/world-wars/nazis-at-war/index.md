# Hitler Strikes West (Part 1)

## Episodes

* [Hitler Strikes West (Part 1)](/history/world-wars/nazis-at-war/01-hitler-strikes-west.md) — Episode 620: The Second World War begins with Hitler's westward expansion.
* [Blitzkrieg (Part 2)](/history/world-wars/nazis-at-war/02-blitzkrieg.md) — Episode 621: Hitler's conquest of Norway, Denmark, and France.
* [The Fall of France (Part 3)](/history/world-wars/nazis-at-war/03-the-fall-of-france.md) — Episode 622: The Battle of Dunkirk and a key turning point.
* [Churchill's Finest Hour (Part 4)](/history/world-wars/nazis-at-war/04-churchills-finest-hour.md) — Episode 623: The Battle of Britain and Churchill's response.
