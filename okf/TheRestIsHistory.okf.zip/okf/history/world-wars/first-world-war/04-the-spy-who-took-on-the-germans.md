---
type: Section
title: "The Spy Who Took on the Germans (Part 4)"
description: "Episode 674: Edith Cavell, the Belgian Resistance, and her tragic fate."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, world-war-i, edith-cavell]
---

# The Spy Who Took on the Germans (Part 4)

2026-05-27 · 1:07:41 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1889262052.mp3)

Why did the British nurse, Edith Cavell, become a key player in the Belgian Resistance to German occupation? How did she carry out her mission? And, why was she ultimately executed, so controversially? Join Dominic and Tom as they unfold the life of the remarkable Edith Cavell, her time as a nurse, her espionage, and ultimately her tragic fate, amidst the death and destruction of the First World …
