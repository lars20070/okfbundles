---
type: Section
title: "Churchill's Calamity (Part 6)"
description: "Episode 676: The end of the disastrous Gallipoli campaign and the Anzac identity."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, world-war-i, gallipoli, churchill]
---

# Churchill's Calamity (Part 6)

2026-06-03 · 1:17:03 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1275431911.mp3)

After Gallipoli has descended into a bloodbath, why do the British pour in more troops? Does Churchill finally understand his fateful error? How do the allies escape the total mess they find themselves in? And, why has this failed campaign become the foundational moment of Anzac identity? Join Dominic and Tom as they bring an end to this disastrous Gallipoli campaign and the bloody year of 1915.
