---
type: Section
title: "Slaughter at Gallipoli (Part 5)"
description: "Episode 675: The worst military catastrophe of the First World War."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, world-war-i, gallipoli]
---

# Slaughter at Gallipoli (Part 5)

2026-05-31 · 1:16:42 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4394132715.mp3)

Why was the Battle of Gallipoli, starting in February 1915, in Turkey, so disastrous for the Allies, and in particular, Winston Churchill? How has it become such a foundational moment in the national identity of New Zealand and Australia? And, how did it transform the destiny of Turkey? Join Dominic and Tom as they launch into one of the worst military catastrophes of the First World War.
