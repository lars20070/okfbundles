# Blood in the Trenches (Part 1)

## Episodes

* [Blood in the Trenches (Part 1)](/history/world-wars/first-world-war/01-blood-in-the-trenches.md) — Episode 671: Life in the trenches on the Western Front in 1915.
* [Italy's Doomed Campaign (Part 2)](/history/world-wars/first-world-war/02-italys-doomed-campaign.md) — Episode 672: Italy's disastrous entry into the First World War.
* [The Submarine Strikes (Part 3)](/history/world-wars/first-world-war/03-the-submarine-strikes.md) — Episode 673: The Lusitania and the U-boat fleet's cataclysmic tragedy.
* [The Spy Who Took on the Germans (Part 4)](/history/world-wars/first-world-war/04-the-spy-who-took-on-the-germans.md) — Episode 674: Edith Cavell, the Belgian Resistance, and her tragic fate.
* [Slaughter at Gallipoli (Part 5)](/history/world-wars/first-world-war/05-slaughter-at-gallipoli.md) — Episode 675: The worst military catastrophe of the First World War.
* [Churchill's Calamity (Part 6)](/history/world-wars/first-world-war/06-churchills-calamity.md) — Episode 676: The end of the disastrous Gallipoli campaign and the Anzac identity.
* [The Massacre of the Innocents (Part 4)](/history/world-wars/first-world-war/07-the-massacre-of-the-innocents.md) — Episode 597: The Battle of Ypres and the Kindermord.
* [The Miracle on the Marne (Part 3)](/history/world-wars/first-world-war/08-the-miracle-on-the-marne.md) — Episode 596: The French counter-offensive at the Marne.
* [The Battle of the Frontiers (Part 2)](/history/world-wars/first-world-war/09-the-battle-of-the-frontiers.md) — Episode 595: The Battle of the Ardennes and Britain's first move.
* [The Invasion of Belgium (Part 1)](/history/world-wars/first-world-war/10-the-invasion-of-belgium.md) — Episode 594: The outbreak of the First World War and the earliest military engagements.
