---
type: Section
title: "Blood in the Trenches (Part 1)"
description: "Episode 671: Life in the trenches on the Western Front in 1915."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, world-war-i, trenches]
---

# Blood in the Trenches (Part 1)

2026-05-17 · 1:24:23 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2309179565.mp3)

During the First World War, what was it like to live in the trenches on the Western Front in 1915? How did the Germans attempt to knock the Allies out of the war right from the outset? And, what secret weapon did the Germans unleash? Join Dominic and Tom as they plunge back into the First World War, and carry us through life in the trenches, the horrors of shelling, and the escalation of this …
