---
type: Section
title: "The Submarine Strikes (Part 3)"
description: "Episode 673: The Lusitania and the U-boat fleet's cataclysmic tragedy."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, world-war-i, lusitania]
---

# The Submarine Strikes (Part 3)

2026-05-24 · 1:16:40 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3632974949.mp3)

Was the Lusitania merely an ocean liner like Titanic, or a formidable battle ship? How and why did a German U-boat fleet manage to bring down this titan of the sea? And, how did the tragedy ignite the United States' decision to finally join the War in 1917? Join Dominic and Tom as they launch into one of the most cataclysmic events of the First World War, and a major turning point for America's …
