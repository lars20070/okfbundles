---
type: Section
title: "The Massacre of the Innocents (Part 4)"
description: "Episode 597: The Battle of Ypres and the Kindermord."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, world-war-i, ypres]
---

# The Massacre of the Innocents (Part 4)

2025-09-03 · 55:15 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9434623550.mp3?updated=1757078000)

What happened at the crucial, bloody, Battle of Ypres in October 1914? How did the battle come about? Why did the Germans and the British fight each other so brutally and for so long to take Ypres? What made the fighting so particularly violent? How were the British able to repel the relentless German onslaught time after time? What was the famous "Kindermord" - "the Massacre of the Innocents" …
