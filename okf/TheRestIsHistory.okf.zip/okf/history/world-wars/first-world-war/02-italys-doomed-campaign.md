---
type: Section
title: "Italy's Doomed Campaign (Part 2)"
description: "Episode 672: Italy's disastrous entry into the First World War."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, world-war-i, italy]
---

# Italy's Doomed Campaign (Part 2)

2026-05-20 · 1:11:02 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3383347829.mp3)

How did Italy enter the First World War alongside the Allies in 1915? What were they hoping to gain? And, why was their attempt to invade the Austro-Hungarian Empire one of the bloodiest campaigns of the entire war? Join Dominic and Tom as they discuss Italy's entrance into the War, their disastrous efforts to carve out a corner of the Austro-Hungarian Empire, and the terrible aftermath of this …
