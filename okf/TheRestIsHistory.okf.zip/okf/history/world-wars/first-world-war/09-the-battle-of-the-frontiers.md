---
type: Section
title: "The Battle of the Frontiers (Part 2)"
description: "Episode 595: The Battle of the Ardennes and Britain's first move."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, world-war-i]
---

# The Battle of the Frontiers (Part 2)

2025-08-27 · 1:00:37 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5758313909.mp3?updated=1756312614)

What was Britain's first military move following the outbreak of the First World War? Where did the French launch their initial attack on the Germans? Whose army was the biggest and best of all the participants in the war? And, what unfolded at the pivotal Battle of the Ardennes in August 1914, on the frontiers of France, between the Germans and the French, and what would be the consequences of …
