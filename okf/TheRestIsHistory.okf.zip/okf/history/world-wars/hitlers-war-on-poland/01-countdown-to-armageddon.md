---
type: Section
title: "Countdown to Armageddon (Part 1)"
description: "Episode 530: Hitler's determination to make Germany the greatest power in Europe."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "world-war-ii", "poland"]
---

# Countdown to Armageddon (Part 1)

2025-01-13 · 59:03 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8685711342.mp3?updated=1738860574)

Following the Munich agreement of September 1938, Nazi troops marched into Czechoslovakia and ruthlessly claimed it as a German protectorate. Still, even following his annexation of Czechoslovakia, Hitler's determination to make Germany the greatest power in Europe was far from sated. Thus, hungry for war and keenly conscious of Germany's fast imploding economic situation, his mind had turned by …
