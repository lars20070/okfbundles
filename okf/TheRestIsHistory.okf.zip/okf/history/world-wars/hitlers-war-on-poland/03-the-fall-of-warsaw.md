---
type: Section
title: "The Fall of Warsaw (Part 3)"
description: "Episode 532: The Nazi invasion of Poland and the first capital to face annihilation."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "world-war-ii", "poland"]
---

# The Fall of Warsaw (Part 3)

2025-01-20 · 1:00:36 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6308788391.mp3?updated=1738860519)

The Nazi invasion of Poland is one of the most harrowing episodes of the Second World War, which saw terrible scenes of abuse take place. Though long threatened, Poland was in no way prepared to face Hitler's war machine when it finally attacked. Replete with tanks and planes, his would be a new kind of warfare. So, on the 10th of September 1939, Warsaw became the first capital in Europe to face …
