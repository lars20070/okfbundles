---
type: Section
title: "The Pact with Stalin (Part 2)"
description: "Episode 531: Hitler drawing up a plan of attack for Poland."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "world-war-ii", "poland"]
---

# The Pact with Stalin (Part 2)

2025-01-16 · 1:02:44 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5437884494.mp3?updated=1738860541)

By the 11th of April 1939, Adolf Hitler and his Nazis were in the process of drawing up a plan of attack for Poland, the Poles having resisted Germany's attempts to make them hand over Danzig and turn themselves into a satellite state. Now, with a new military alliance between France, Britain and Poland established, the time has come for Hitler to throw the dice and cast Europe into the long …
