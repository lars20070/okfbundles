# Countdown to Armageddon (Part 1)

## Episodes

* [Countdown to Armageddon (Part 1)](/history/world-wars/hitlers-war-on-poland/01-countdown-to-armageddon.md) — Episode 530: Hitler's determination to make Germany the greatest power in Europe.
* [The Pact with Stalin (Part 2)](/history/world-wars/hitlers-war-on-poland/02-the-pact-with-stalin.md) — Episode 531: Hitler drawing up a plan of attack for Poland.
* [The Fall of Warsaw (Part 3)](/history/world-wars/hitlers-war-on-poland/03-the-fall-of-warsaw.md) — Episode 532: The Nazi invasion of Poland and the first capital to face annihilation.
