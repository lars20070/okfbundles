---
type: Section
title: "The Witch Hunt (Part 2)"
description: "Episode 344: Following the use of the atomic bomb in Japan, Oppenheimer pushes for an international approach to nuclear power."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "oppenheimer", "nuclear-age", "mccarthyism"]
---

# The Witch Hunt (Part 2)

2023-06-23 · 53:09 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1594914557.mp3?updated=1777394723)

Following the use of the atomic bomb in Japan and the end of the Second World War, Oppenheimer pushes for an international approach to nuclear power. This attitude towards nuclear secrets, alongside his history of close relationships with known communists, results in all his security clearances being revoked in 1954 after a public hearing. Join Tom and Dominic as they explore McCarthyism …