# The Father of the Atom Bomb (Part 1)

## Episodes

* [The Father of the Atom Bomb (Part 1)](/history/world-wars/oppenheimer/01-the-father-of-the-atom-bomb.md) — Episode 343: 'Now I am become Death, the destroyer of worlds.' J. Robert Oppenheimer's reaction to the first atomic bomb test in July 1945.
* [The Witch Hunt (Part 2)](/history/world-wars/oppenheimer/02-the-witch-hunt.md) — Episode 344: Following the use of the atomic bomb in Japan, Oppenheimer pushes for an international approach to nuclear power.
