---
type: Section
title: "The Father of the Atom Bomb (Part 1)"
description: "Episode 343: 'Now I am become Death, the destroyer of worlds.' J. Robert Oppenheimer's reaction to the first atomic bomb test in July 1945."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "oppenheimer", "nuclear-age", "world-war-ii"]
---

# The Father of the Atom Bomb (Part 1)

2023-06-22 · 55:08 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9202576882.mp3?updated=1777394186)

"Now I am become Death, the destroyer of worlds." This was J. Robert Oppenheimer's reaction to the first atomic bomb test in July 1945, marking the beginning of the nuclear age. Oppenheimer, an American theoretical physicist of Jewish-German descent, was in charge of the American nuclear project, leading the Los Alamos laboratory and tasked with developing "the bomb" in 1943, following his …