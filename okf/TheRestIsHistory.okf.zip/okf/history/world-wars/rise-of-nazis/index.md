# The Rise of the Nazis (Part 1)

## Episodes

* [The Rise of the Nazis (Part 1)](/history/world-wars/rise-of-nazis/01-the-rise-of-the-nazis.md) — Episode 295: Where do the origins of Nazism lie? The Second Reich? Hitler's time in Vienna? The First World War?
* [The Beer Hall Putsch (Part 2)](/history/world-wars/rise-of-nazis/02-the-beer-hall-putsch.md) — Episode 296: German hyperinflation, the Beer Hall Putsch, Hitler's trial.
* [Hitler's Triumph (Part 3)](/history/world-wars/rise-of-nazis/03-hitlers-triumph.md) — Episode 297: Wall Street crashes, the German economy capitulates and governments start to fall.
* [Total Power (Part 4)](/history/world-wars/rise-of-nazis/04-total-power.md) — Episode 298: Hitler is chancellor, but he is not yet all-powerful.
