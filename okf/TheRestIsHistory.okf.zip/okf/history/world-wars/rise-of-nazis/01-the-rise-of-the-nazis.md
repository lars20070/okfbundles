---
type: Section
title: "The Rise of the Nazis (Part 1)"
description: "Episode 295: Where do the origins of Nazism lie? The Second Reich? Hitler's time in Vienna? The First World War?"
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "nazis", "hitler", "germany"]
---

# The Rise of the Nazis (Part 1)

2023-01-16 · 1:03:21 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8045984312.mp3?updated=1777395031)

Where do the origins of Nazism lie? The Second Reich? Hitler's time in Vienna? The First World War? Join Tom and Dominic in the first of their four-part series on the Rise of the Nazis as they discuss its origins.