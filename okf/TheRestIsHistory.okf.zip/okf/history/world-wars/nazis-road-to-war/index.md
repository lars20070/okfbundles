# Hitler Prepares to Strike (Part 1)

## Episodes

* [Hitler Prepares to Strike (Part 1)](/history/world-wars/nazis-road-to-war/01-hitler-prepares-to-strike.md) — Episode 528: Hitler's vile ambitions turn to Czechoslovakia in the 1930s.
* [Showdown in Munich (Part 2)](/history/world-wars/nazis-road-to-war/02-showdown-in-munich.md) — Episode 529: Chamberlain's meeting with Hitler in September 1938.
