---
type: Section
title: "Showdown in Munich (Part 2)"
description: "Episode 529: Chamberlain's meeting with Hitler in September 1938."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "world-war-ii", "nazis"]
---

# Showdown in Munich (Part 2)

2025-01-09 · 57:19 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8359198113.mp3?updated=1738860594)

On 17th September 1938, in Munich, one of the most extraordinary meetings in history took place. Neville Chamberlain launched an extraordinary and unprecedented diplomatic coup. Boarding a plane, he set off to meet Adolf Hitler in a desperate attempt to prevent war over Czechoslovakia, following the Nazis' territorial incursions into Czechoslovakia. Little did he know that Hitler was already …