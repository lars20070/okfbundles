---
type: Section
title: "Hitler Prepares to Strike (Part 1)"
description: "Episode 528: Hitler's vile ambitions turn to Czechoslovakia in the 1930s."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "world-war-ii", "nazis"]
---

# Hitler Prepares to Strike (Part 1)

2025-01-06 · 1:01:15 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9235039478.mp3?updated=1784112629)

Throughout the course of the 1930s, Adolf Hitler's Nazi party has overwhelmingly, terrifyingly seized power in Germany. Now, Hitler's vile ambitions have turned to Czechoslovakia. On the 12th of September 1938 at the Nazi Party Congress in Nuremberg, he rabidly defended the supposed interests of the German speaking minority in Czechoslovakia, claiming that they had been ravaged and tortured by …