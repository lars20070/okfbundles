---
type: Section
title: "Apocalypse Now (Part 2)"
description: "Episode 325: 'It is 105 degrees in Saigon, and rising.' This announcement, made through U.S. Armed Forces radio on a spring morning in 1975."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "vietnam-war", "saigon"]
---

# Apocalypse Now (Part 2)

2023-04-27 · 52:05 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1698435670.mp3?updated=1777394192)

"It is 105 degrees in Saigon, and rising." This announcement, made through U.S. Armed Forces radio on a spring morning in 1975, is the cue for all Americans remaining in Saigon to head to the US embassy, in order to be evacuated. With up to a million South Vietnamese also expecting to be flown to safety, the city erupts into panic and unrest. The last U.S. troops barricade themselves on the roof …