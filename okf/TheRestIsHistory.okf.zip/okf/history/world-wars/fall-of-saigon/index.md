# The Nightmare Begins (Part 1)

## Episodes

* [The Nightmare Begins (Part 1)](/history/world-wars/fall-of-saigon/01-the-nightmare-begins.md) — Episode 324: It's 1975, and in the final act of the Vietnam War, the U.S. have ordered all remaining civilian and military personnel to be withdrawn from South Vietnam.
* [Apocalypse Now (Part 2)](/history/world-wars/fall-of-saigon/02-apocalypse-now.md) — Episode 325: 'It is 105 degrees in Saigon, and rising.' This announcement, made through U.S. Armed Forces radio on a spring morning in 1975.
