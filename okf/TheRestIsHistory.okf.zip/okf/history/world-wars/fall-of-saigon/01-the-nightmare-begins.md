---
type: Section
title: "The Nightmare Begins (Part 1)"
description: "Episode 324: It's 1975, and in the final act of the Vietnam War, the U.S. have ordered all remaining civilian and military personnel to be withdrawn from South Vietnam."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "vietnam-war", "saigon"]
---

# The Nightmare Begins (Part 1)

2023-04-24 · 49:14 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6047251362.mp3?updated=1777394160)

It's 1975, and in the final act of the Vietnam War, the U.S. have ordered all remaining civilian and military personnel to be withdrawn from South Vietnam. The communist Viet Cong are closing in on the city of Saigon, the hub of America's presence, as choppers evacuate the 6000 Americans left in the city. Thousands of Vietnamese storm the U.S. embassy, as Saigon descends into chaos. Join Tom and …