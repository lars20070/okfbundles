# The Beer Hall Putsch (Part 2)

## Episodes

* [The Beer Hall Putsch (Part 2)](/history/world-wars/nazis-total-power/02-the-beer-hall-putsch.md) — Episode 296: German hyperinflation, the Beer Hall Putsch, Hitler's trial.
* [Hitler's Triumph (Part 3)](/history/world-wars/nazis-total-power/03-hitlers-triumph.md) — Episode 297: Wall Street crashes, the German economy capitulates and governments start to fall.
* [Total Power (Part 4)](/history/world-wars/nazis-total-power/04-total-power.md) — Episode 298: Hitler is chancellor, but he is not yet all-powerful.
