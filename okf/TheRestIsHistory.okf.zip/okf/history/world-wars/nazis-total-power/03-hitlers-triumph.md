---
type: Section
title: "Hitler's Triumph (Part 3)"
description: "Episode 297: Wall Street crashes, the German economy capitulates and governments start to fall."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "nazis", "hitler", "germany"]
---

# Hitler's Triumph (Part 3)

2023-01-23 · 59:29 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2055084600.mp3?updated=1777394205)

Wall Street crashes. The German economy capitulates and governments start to fall. Backroom deals and political scheming come to the fore. Join Tom and Dominic as they tell the story of the shadowy deals that allowed Hitler to gain power.