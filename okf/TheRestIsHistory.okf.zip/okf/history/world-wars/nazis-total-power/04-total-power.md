---
type: Section
title: "Total Power (Part 4)"
description: "Episode 298: Hitler is chancellor, but he is not yet all-powerful."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "nazis", "hitler", "germany"]
---

# Total Power (Part 4)

2023-01-26 · 57:07 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6097237943.mp3?updated=1777395015)

Hitler is chancellor, but he is not yet all-powerful. How does he go from becoming the leader of the Reichstag, to an unshackled dictator with nothing to check his power?