---
type: Section
title: "The Beer Hall Putsch (Part 2)"
description: "Episode 296: German hyperinflation, the Beer Hall Putsch, Hitler's trial."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "nazis", "hitler", "germany"]
---

# The Beer Hall Putsch (Part 2)

2023-01-19 · 59:11 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4099180386.mp3?updated=1777394248)

German hyperinflation. The Beer Hall Putsch. Hitler's trial. Join Tom and Dominic as they discuss the Nazis in the early 1920s as the Weimar Republic is in crisis and Hitler tries to grow the party beyond Bavaria.