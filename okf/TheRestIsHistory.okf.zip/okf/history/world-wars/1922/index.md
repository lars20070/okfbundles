# The Birth of the Modern World Part 1

## Episodes

* [The Birth of the Modern World Part 1](/history/world-wars/1922/01-the-birth-of-the-modern-world-part-1.md) — Episode 136: 2022 marks 100 years since one of the most important years in modern history.
* [The Birth of the Modern World Part 2](/history/world-wars/1922/02-the-birth-of-the-modern-world-part-2.md) — Episode 137: In part 2 of this centennial episode, Tom and Dominic cover the triggering of the Irish Civil War.
