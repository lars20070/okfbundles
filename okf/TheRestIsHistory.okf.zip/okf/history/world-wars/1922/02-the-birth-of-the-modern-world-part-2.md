---
type: Section
title: "The Birth of the Modern World Part 2"
description: "Episode 137: In part 2 of this centennial episode, Tom and Dominic cover the triggering of the Irish Civil War."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "1922", "modern-world"]
---

# The Birth of the Modern World Part 2

2022-01-14 · 1:03:42 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5281126494.mp3?updated=1777394956)

In part 2 of this centennial episode, Tom and Dominic cover the triggering of the Irish Civil War, the birth of the BBC, and Howard Carter's 'Tutmania'. Plus, have you ever wondered how many stars Dominic's 1995 Edinburgh Fringe performance of Becket REALLY received from The Scotsman? Featuring appearances from Winston Churchill, Michael Collins and Just William, this podcast is not to be missed!