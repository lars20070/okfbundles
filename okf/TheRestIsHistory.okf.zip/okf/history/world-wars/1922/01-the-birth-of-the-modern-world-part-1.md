---
type: Section
title: "The Birth of the Modern World Part 1"
description: "Episode 136: 2022 marks 100 years since one of the most important years in modern history."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "1922", "modern-world"]
---

# The Birth of the Modern World Part 1

2022-01-13 · 55:06 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1607440485.mp3?updated=1777394940)

2022 marks 100 years since one of the most important years in modern history. In part 1 Tom and Dominic discuss all things 1922: Bolshevism, fascism, and the significance of The Waste Land and Ulysses.