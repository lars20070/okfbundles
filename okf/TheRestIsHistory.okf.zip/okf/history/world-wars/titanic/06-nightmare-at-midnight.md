---
type: Section
title: "Nightmare at Midnight (Part 5)"
description: "Episode 431: Titanic hurtling towards a formidable iceberg."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "titanic", "shipwreck"]
---

# Nightmare at Midnight (Part 5)

2024-03-19 · 1:03:23 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2941711597.mp3?updated=1710797587)

"A story of horror unparalleled in the annals of the Sea." On the 14th of April 1912, Titanic, a floating palace sailing through the North Atlantic, found itself hurtling towards a formidable iceberg. Contrary to the panicked reactions of her crew who, fatefully, pulled the hulking vessel to starboard, the ship's passengers slept, laughed and played on, unaware of the danger ahead. Then came a …