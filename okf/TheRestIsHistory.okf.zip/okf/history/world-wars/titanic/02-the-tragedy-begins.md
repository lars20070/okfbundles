---
type: Section
title: "The Tragedy Begins (Part 1)"
description: "Episode 427: How the state-of-the-art ocean liner came to sink."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "titanic", "shipwreck"]
---

# The Tragedy Begins (Part 1)

2024-03-11 · 46:40 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3124111041.mp3?updated=1710109452)

"There is no danger that Titanic will sink. The boat is unsinkable and nothing but inconvenience will be suffered by the passengers." The sinking of the Titanic, on a freezing Sunday night in April 1912, claimed more than 1500 lives. But how this state-of-the-art ocean liner came to be is also a story full of drama, encapsulating the turn of the century's spirit of competition and drive for …