---
type: Section
title: "Countdown to Disaster (Part 3)"
description: "Episode 429: The drama and tragedy of the Titanic's sinking."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "titanic", "shipwreck"]
---

# Countdown to Disaster (Part 3)

2024-03-14 · 46:36 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1273657377.mp3?updated=1710410949)

The drama and tragedy of the Titanic's sinking has spawned all manner of myths about those who left Southampton on the 10th of April 1912, and for four days luxuriated in the ship's modern facilities, extravagant interiors, and plush cabins. Among them were many magnates and tycoons, such as J.J. Astor, the richest man onboard, and the American businessman Ben Guggenheim. Conspicuously absent …