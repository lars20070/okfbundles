---
type: Section
title: "The Iceberg Strikes (Part 4)"
description: "Episode 430: Passengers enjoying a journey incomparable in its modernity."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "titanic", "shipwreck"]
---

# The Iceberg Strikes (Part 4)

2024-03-18 · 43:38 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2129072034.mp3?updated=1710526023)

It is Sunday the 14th of April 1912, and the passengers of the Titanic, from the tycoons in first class to the migrants in third class, have been enjoying a journey incomparable in its modernity. The weather, up until that point exceptionally clement, suddenly grew colder, stiller, calmer, and the ice warnings that had been coming through the ship's sophisticated communications machine since …