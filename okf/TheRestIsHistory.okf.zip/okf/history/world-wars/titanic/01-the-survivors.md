---
type: Section
title: "The Survivors (Part 6)"
description: "Episode 432: The aftermath of the Titanic's sinking and the reactions across the Atlantic."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "titanic", "shipwreck"]
---

# The Survivors (Part 6)

2024-03-21 · 54:33 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4613169046.mp3?updated=1710797624)

"Then it is I drown again, with all those dim lost faces I never understood… Include me in your lamentations." The aftermath of the Titanic's sinking saw different reactions erupt across the Atlantic, and the responses of both mourners and onlookers were visceral. Guilt-ridden survivors were both ostracised and lauded. Heroes became legends - the unsinkable Molly Brown and the band that played on …