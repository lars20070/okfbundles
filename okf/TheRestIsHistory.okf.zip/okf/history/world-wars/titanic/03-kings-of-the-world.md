---
type: Section
title: "Kings of the World (Part 2)"
description: "Episode 428: The Titanic as a product of the late Gilded Age."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "titanic", "shipwreck"]
---

# Kings of the World (Part 2)

2024-03-12 · 50:24 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7773063166.mp3?updated=1710109933)

The Titanic was a product of the furious competition of the late Gilded Age, and no expenses were spared to make her the most extraordinary and luxurious ship ever built. The height of an eleven-story building, fully electric, and with first class suites designed for the world's wealthiest, the Titanic embodied the Edwardian obsessions with grandeur and greatness. But the ship was also designed …