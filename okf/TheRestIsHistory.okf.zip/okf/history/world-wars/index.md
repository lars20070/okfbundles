# World Wars

## Series

* [The Birth of the Modern World Part 1](/history/world-wars/1922/) — Series about The Birth of the Modern World Part 1
* [The Man Who Escaped Auschwitz](/history/world-wars/auschwitz-escape/) — Series about The Man Who Escaped Auschwitz
* [China and World War II (Part 1)](/history/world-wars/china-wwii/) — Series about China and World War II (Part 1)
* [The Nightmare Begins (Part 1)](/history/world-wars/fall-of-saigon/) — Series about The Nightmare Begins (Part 1)
* [Blood in the Trenches (Part 1)](/history/world-wars/first-world-war/) — Series about Blood in the Trenches (Part 1)
* [The Killer (Part 1)](/history/world-wars/franz-ferdinand/) — Series about The Killer (Part 1)
* [Countdown to Armageddon (Part 1)](/history/world-wars/hitlers-war-on-poland/) — Series about Countdown to Armageddon (Part 1)
* [Hitler Strikes West (Part 1)](/history/world-wars/nazis-at-war/) — Series about Hitler Strikes West (Part 1)
* [The Night of the Long Knives (Part 1)](/history/world-wars/nazis-in-power/) — Series about The Night of the Long Knives (Part 1)
* [Hitler Prepares to Strike (Part 1)](/history/world-wars/nazis-road-to-war/) — Series about Hitler Prepares to Strike (Part 1)
* [The Beer Hall Putsch (Part 2)](/history/world-wars/nazis-total-power/) — Series about The Beer Hall Putsch (Part 2)
* [The Father of the Atom Bomb (Part 1)](/history/world-wars/oppenheimer/) — Series about The Father of the Atom Bomb (Part 1)
* [The Rise of the Nazis (Part 1)](/history/world-wars/rise-of-nazis/) — Series about The Rise of the Nazis (Part 1)
* [Countdown to Armageddon (Part 1)](/history/world-wars/road-to-great-war/) — Series about Countdown to Armageddon (Part 1)
* [The Battle of Stalingrad (Part 1)](/history/world-wars/stalingrad/) — Series about The Battle of Stalingrad (Part 1)
* [The Survivors (Part 6)](/history/world-wars/titanic/) — Series about The Survivors (Part 6)
