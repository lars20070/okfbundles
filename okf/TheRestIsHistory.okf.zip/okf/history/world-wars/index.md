# World Wars

## Series

* [1922: The Birth of the Modern World](/history/world-wars/1922/) — 2 episodes
* [Auschwitz Escape](/history/world-wars/auschwitz-escape/) — 2 episodes
* [China in World War II](/history/world-wars/china-wwii/) — 2 episodes
* [Fall of Saigon](/history/world-wars/fall-of-saigon/) — 2 episodes
* [The First World War](/history/world-wars/first-world-war/) — 10 episodes
* [The Murder of Franz Ferdinand](/history/world-wars/franz-ferdinand/) — 4 episodes
* [Hitler's War on Poland](/history/world-wars/hitlers-war-on-poland/) — 3 episodes
* [The Nazis at War](/history/world-wars/nazis-at-war/) — 4 episodes
* [The Nazis in Power](/history/world-wars/nazis-in-power/) — 7 episodes
* [The Nazis' Road to War](/history/world-wars/nazis-road-to-war/) — 2 episodes
* [The Nazis' Total Power](/history/world-wars/nazis-total-power/) — 3 episodes
* [Oppenheimer](/history/world-wars/oppenheimer/) — 2 episodes
* [The Rise of the Nazis](/history/world-wars/rise-of-nazis/) — 4 episodes
* [The Road to the Great War](/history/world-wars/road-to-great-war/) — 6 episodes
* [Stalingrad](/history/world-wars/stalingrad/) — 2 episodes
* [Titanic](/history/world-wars/titanic/) — 6 episodes
