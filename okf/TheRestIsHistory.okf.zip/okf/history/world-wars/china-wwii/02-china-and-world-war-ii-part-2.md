---
type: Section
title: "China and World War II (Part 2)"
description: "Episode 236: Tom and Dominic welcome back special guest Rana Mitter."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "china", "world-war-ii"]
---

# China and World War II (Part 2)

2022-09-22 · 1:05:14 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5290070743.mp3?updated=1729784729)

Tom and Dominic welcome back special guest Rana Mitter to discuss China's position during World War Two. This episode covers the Rape of Nanjing by Japanese forces, the military tactic of flooding the Yellow River, the deal between Chinese Nationalist Wang Jin Wei and Japan, and the unlikely pairing of 'Vinegar Joe' Stilwell and Chiang Kai-shek.
