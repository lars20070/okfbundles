---
type: Section
title: "China and World War II (Part 1)"
description: "Episode 235: Friend of the show Rana Mitter joins Tom and Dominic this week."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "china", "world-war-ii"]
---

# China and World War II (Part 1)

2022-09-20 · 59:33 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2114682484.mp3?updated=1729784689)

Friend of the show Rana Mitter joins Tom and Dominic this week to discuss the role of China in the Second World War. In the first of two episodes, Rana, Tom and Dominic cover the fall of the last Emperor and the establishment of a Chinese Republic in 1912, the Opium Wars, warlords, and the Kuomintang uniting China.
