---
type: Section
title: "Portugal: Football, Fado, and Fascism? (Part 4)"
description: "Episode 230: In the final chapter of this series on the history of Portugal."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "portugal", "modern-history"]
---

# Portugal: Football, Fado, and Fascism? (Part 4)

2022-09-08 · 1:00:04 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9147423732.mp3?updated=1729784996)

In the final chapter of this series on the history of Portugal, Tom and Dominic explore Portugal in the 20th century, the two World Wars, the Miracle of Fatima and dictator Antonio Salazar.
