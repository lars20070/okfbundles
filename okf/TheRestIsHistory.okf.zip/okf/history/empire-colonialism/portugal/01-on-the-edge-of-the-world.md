---
type: Section
title: "Portugal: On the Edge of the World (Part 1)"
description: "Episode 227: Welcome to The Rest Is History's Portugal mini-series!"
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "portugal", "exploration"]
---

# Portugal: On the Edge of the World (Part 1)

2022-09-05 · 48:49 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1834337589.mp3?updated=1729784908)

Welcome to The Rest Is History's Portugal mini-series! In the first of four episodes on Portugal, Tom and Dominic chart the nation's early history: Romans, Visigoths, the Reconquista, alliances with England, and much, much more...
