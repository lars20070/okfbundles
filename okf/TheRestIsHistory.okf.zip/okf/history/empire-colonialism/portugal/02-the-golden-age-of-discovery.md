---
type: Section
title: "Portugal: The Golden Age of Discovery (Part 2)"
description: "Episode 228: In the second episode of this Portugal mini-series, Tom and Dominic discuss the Portuguese setting sail for far flung reaches of the world."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "portugal", "exploration"]
---

# Portugal: The Golden Age of Discovery (Part 2)

2022-09-06 · 53:38 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7949934800.mp3?updated=1729784931)

In the second episode of this Portugal mini-series, Tom and Dominic discuss the Portuguese setting sail for far flung reaches of the world, their relationship with Philip II of Spain, and the impact of Vasco da Gama.
