---
type: Section
title: "Portugal: Gold, Earthquakes, and Brazil (Part 3)"
description: "Episode 229: Earthquakes, gold rush, and Brazil."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "portugal", "exploration"]
---

# Portugal: Gold, Earthquakes, and Brazil (Part 3)

2022-09-07 · 55:24 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8317395817.mp3?updated=1777394992)

Earthquakes, gold rush, and Brazil. Join Tom and Dominic for the third episode in this history of Portugal series.
