# Portugal: On the Edge of the World (Part 1)

## Episodes

* [Portugal: On the Edge of the World (Part 1)](/history/empire-colonialism/portugal/01-on-the-edge-of-the-world.md) — Episode 227: Welcome to The Rest Is History's Portugal mini-series!
* [Portugal: The Golden Age of Discovery (Part 2)](/history/empire-colonialism/portugal/02-the-golden-age-of-discovery.md) — Episode 228: In the second episode of this Portugal mini-series, Tom and Dominic discuss the Portuguese setting sail for far flung reaches of the world.
* [Portugal: Gold, Earthquakes, and Brazil (Part 3)](/history/empire-colonialism/portugal/03-gold-earthquakes-and-brazil.md) — Episode 229: Earthquakes, gold rush, and Brazil.
* [Portugal: Football, Fado, and Fascism? (Part 4)](/history/empire-colonialism/portugal/04-portugal-football-fado-and-fascism-part-4.md) — Episode 230: In the final chapter of this series on the history of Portugal.
