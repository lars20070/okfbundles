---
type: Section
title: "History's Greatest Explorer (Part 1)"
description: "Episode 380: The greatest sea explorer of all time, James Cook was born to a humble Yorkshire family."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "captain-cook", "exploration"]
---

# History's Greatest Explorer (Part 1)

2023-10-22 · 50:11 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8106697435.mp3?updated=1729781697)

The greatest sea explorer of all time, James Cook was born to a humble Yorkshire family, and first stood out for his talents as a cartographer for the Royal Navy in Newfoundland. He would go on to lead three epic voyages to the Pacific during the 18th century, as part of history's first ever scientific research team, accompanied by Joseph Banks, two cats, a dog and a goat. First sent to track the …