---
type: Section
title: "To the Ends of the Earth (Part 2)"
description: "Episode 381: Cook has been sent by the Royal Navy to the Pacific to track the transit of Venus from Tahiti."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "captain-cook", "exploration"]
---

# To the Ends of the Earth (Part 2)

2023-10-25 · 53:45 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6950185057.mp3?updated=1729781723)

Cook has been sent by the Royal Navy to the Pacific to track the transit of Venus from Tahiti, but also with a second, secret mission: once he's reached Tahiti, he will go on to search for the great southern continent, Terra Australis. Encountering Tahitians, Maori and Aboriginal Australians, Cook and his crew develop relations with them which will often turn sour. Join Tom and Dominic in the …