# History's Greatest Explorer (Part 1)

## Episodes

* [History's Greatest Explorer (Part 1)](/history/empire-colonialism/captain-cook/01-historys-greatest-explorer.md) — Episode 380: The greatest sea explorer of all time, James Cook was born to a humble Yorkshire family.
* [To the Ends of the Earth (Part 2)](/history/empire-colonialism/captain-cook/02-to-the-ends-of-the-earth.md) — Episode 381: Cook has been sent by the Royal Navy to the Pacific to track the transit of Venus from Tahiti.
