---
type: Section
title: "Birth of a Legend (Part 1)"
description: "Episode 494: Eva's humble beginnings and shunning by her rural community."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "evita", "peron", "argentina"]
---

# Birth of a Legend (Part 1)

2024-09-15 · 41:14 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9994303396.mp3?updated=1726439455)

"Don't cry for me Argentina, the truth is I never left you." Few political figures have been both hailed as a saint and immortalised through an Andrew Lloyd Webber musical. The mythology of Evita Perón continues to permeate through Argentinian society, but what's the real history of her life? Eva and her siblings were born out of wedlock and subsequently shunned by the community in her rural …
