---
type: Section
title: "The Mystery of the Missing Body (Part 5)"
description: "Episode 498: Eva's ghost haunts the nation after her death."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "evita", "peron", "argentina"]
---

# The Mystery of the Missing Body (Part 5)

2024-09-25 · 55:22 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5587823308.mp3?updated=1727284536)

After lying in state in an open casket, Evita's corpse is taken down to a secret laboratory in the basement. And as the Argentinian Victor Frankenstein, Dr Ara, busily embalms her body, her ghost continues to haunt the nation. Sightings of her face are reported in obscure places all over the country. With Evita gone, Colonel Perón embarks upon an affair with a much younger girl and has a creepily …
