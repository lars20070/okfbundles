---
type: Section
title: "Death of a Martyr (Part 4)"
description: "Episode 497: Eva's health deteriorates and her supporters call for her to run as Vice President."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "evita", "peron", "argentina"]
---

# Death of a Martyr (Part 4)

2024-09-23 · 45:56 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5046116399.mp3?updated=1727170014)

The workaholic mother of a nation, Evita's health deteriorates and she faints at a public event. A self-proclaimed martyr, she seems to be willing to die for Perón and Perónism, and her supporters see her passion. As she continues her public work, her supporters call for her to run as Vice President in the upcoming election - a position of power no woman on Earth has yet held. Evita's supporters …
