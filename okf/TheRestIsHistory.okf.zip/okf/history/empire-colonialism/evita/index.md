# Birth of a Legend (Part 1)

## Episodes

* [Birth of a Legend (Part 1)](/history/empire-colonialism/evita/01-birth-of-a-legend.md) — Episode 494: Eva's humble beginnings and shunning by her rural community.
* [The Rise of General Perón (Part 2)](/history/empire-colonialism/evita/02-the-rise-of-general-peron.md) — Episode 495: Eva meets Colonel Perón at a fundraising event.
* [The World's Most Powerful Woman (Part 3)](/history/empire-colonialism/evita/03-the-worlds-most-powerful-woman.md) — Episode 496: Eva embodies the working-class migrant to Buenos Aires.
* [Death of a Martyr (Part 4)](/history/empire-colonialism/evita/04-death-of-a-martyr.md) — Episode 497: Eva's health deteriorates and her supporters call for her to run as Vice President.
* [The Mystery of the Missing Body (Part 5)](/history/empire-colonialism/evita/05-the-mystery-of-the-missing-body.md) — Episode 498: Eva's ghost haunts the nation after her death.
