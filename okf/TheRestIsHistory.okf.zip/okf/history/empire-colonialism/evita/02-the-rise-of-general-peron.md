---
type: Section
title: "The Rise of General Perón (Part 2)"
description: "Episode 495: Eva meets Colonel Perón at a fundraising event."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "evita", "peron", "argentina"]
---

# The Rise of General Perón (Part 2)

2024-09-18 · 52:30 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1831793233.mp3?updated=1726677273)

An admirer of Hitler and Mussolini, Colonel Perón rose through the ranks during the 1943 military coup in Argentina. Following a disastrous earthquake in 1944, Perón crossed paths with Eva at a fundraising event. Now a successful radio actress, Eva was 20 years his junior but became completely infatuated with him and swiftly removed her romantic rivals. And despite the relationship being …
