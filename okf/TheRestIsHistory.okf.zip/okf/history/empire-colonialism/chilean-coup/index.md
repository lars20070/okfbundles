# Allende, Nixon and the CIA (Part 1)

## Episodes

* [Allende, Nixon and the CIA (Part 1)](/history/empire-colonialism/chilean-coup/01-allende-nixon-and-the-cia.md) — Episode 370: A story imbued in American Imperialism during the Cold War.
* [General Pinochet Seizes Power (Part 2)](/history/empire-colonialism/chilean-coup/02-general-pinochet-seizes-power.md) — Episode 371: General Pinochet would overthrow Allende and become a bloodthirsty tyrant.
