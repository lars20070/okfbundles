---
type: Section
title: "General Pinochet Seizes Power (Part 2)"
description: "Episode 371: General Pinochet would overthrow Allende and become a bloodthirsty tyrant."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "chile", "coup", "cold-war"]
---

# General Pinochet Seizes Power (Part 2)

2023-09-21 · 50:34 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3740766328.mp3?updated=1729782100)

The U.S. have given up on ousting the socialist President Allende through democratic means, and shift to a more militaristic approach, in the form of General Pinochet. Once known as the 'dull dog', a man who had a reputation for procuring Jeeps for his fellow troops, the son of a customs official, he would overthrow Allende and become a bloodthirsty tyrant, killing thousands and torturing far …