---
type: Section
title: "Allende, Nixon and the CIA (Part 1)"
description: "Episode 370: A story imbued in American Imperialism during the Cold War."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "chile", "coup", "cold-war"]
---

# Allende, Nixon and the CIA (Part 1)

2023-09-20 · 44:29 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6405070034.mp3?updated=1729782085)

In the midst of the Cold War, the 1973 coup against the socialist Chilean president Salvador Allende, led by General Pinochet with the support of Richard Nixon, remains a seismic episode in Latin American history. A story imbued in American Imperialism, Allende sees off waves of attempts by the U.S. to oust and undermine him, until they exhaust all legal and parliamentary means, and seek new ways …