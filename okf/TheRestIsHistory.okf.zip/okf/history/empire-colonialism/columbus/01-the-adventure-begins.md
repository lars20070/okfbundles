---
type: Section
title: "The Adventure Begins (Part 1)"
description: "Episode 306: Columbus' early life in Genoa, his journey to becoming an accomplished sailor."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "columbus", "exploration"]
---

# The Adventure Begins (Part 1)

2023-02-20 · 56:09 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6089901915.mp3?updated=1777394222)

A controversial figure both now and in his time, Tom and Dominic discuss Columbus and his drive for discovery, power and status. They look at Columbus' early life in Genoa, his journey to becoming an accomplished sailor, his obsession with crossing the Atlantic to reach what he thought was Asia, and how he convinced the Catholic Monarchs of Spain to fund his voyage.