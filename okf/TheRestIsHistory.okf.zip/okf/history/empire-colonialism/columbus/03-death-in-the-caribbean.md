---
type: Section
title: "Death in the Caribbean (Part 3)"
description: "Episode 308: Columbus returns to the remnants of his first voyage to the 'Indies'."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "columbus", "exploration"]
---

# Death in the Caribbean (Part 3)

2023-02-27 · 47:43 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3250512968.mp3?updated=1777394856)

Columbus returns to the remnants of his first voyage to the "Indies", having convinced Isabella and Ferdinand to fund a larger second trip. Desperate to make his mission financially fruitful, his search for wealth and capital unleashes horror on the land that he has "discovered". Columbus makes enemies, causes destruction and starts to lose his grip on reality, whilst he attempts to cling to his …