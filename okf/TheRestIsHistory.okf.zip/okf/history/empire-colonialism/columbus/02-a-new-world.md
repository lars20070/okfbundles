---
type: Section
title: "A New World? (Part 2)"
description: "Episode 307: Having convinced the Catholic Monarchs to fund his journey across the Atlantic."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "columbus", "exploration"]
---

# A New World? (Part 2)

2023-02-23 · 49:46 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7219741357.mp3?updated=1777394820)

Having convinced the Catholic Monarchs to fund his journey across the Atlantic, Columbus sets sail with three ships, a crew with dubious loyalties, and a mission to find China or Japan by heading west. A voyage spanning the Canary Islands, Cuba and Hispaniola, he will encounter and enslave indigenous peoples, mislead and fall out with his crew, then eventually be arrested in Portugal on his …