---
type: Section
title: "Columbus: Villain or Hero? (Part 4)"
description: "Episode 309: Christopher Columbus caused debate in his own time, and remains a controversial figure today."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "columbus", "exploration", "caribbean"]
---

# Columbus: Villain or Hero? (Part 4)

2023-03-02 · 56:00 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6751575003.mp3?updated=1777394191)

Christopher Columbus caused debate in his own time, and remains a controversial figure today: some argue he initiated both the Atlantic slave trade and the genocide of the Native Americans, others laud him as one of the great men of History. Join Tom and Dominic as they explore these issues, their roots, and the truth behind the man Columbus really was...