# The Adventure Begins (Part 1)

## Episodes

* [The Adventure Begins (Part 1)](/history/empire-colonialism/columbus/01-the-adventure-begins.md) — Episode 306: Columbus' early life in Genoa, his journey to becoming an accomplished sailor.
* [A New World? (Part 2)](/history/empire-colonialism/columbus/02-a-new-world.md) — Episode 307: Having convinced the Catholic Monarchs to fund his journey across the Atlantic.
* [Death in the Caribbean (Part 3)](/history/empire-colonialism/columbus/03-death-in-the-caribbean.md) — Episode 308: Columbus returns to the remnants of his first voyage to the 'Indies'.
* [Columbus: Villain or Hero? (Part 4)](/history/empire-colonialism/columbus/04-columbus-villain-or-hero.md) — Episode 309: Christopher Columbus caused debate in his own time, and remains a controversial figure today.
