---
type: Section
title: "Prisoners of Montezuma (Part 4)"
description: "Episode 387: Hernán Cortés and his Spanish comrades have arrived in Tenochtitlan."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "aztecs", "conquistadors"]
---

# Prisoners of Montezuma (Part 4)

2023-11-13 · 44:24 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8017930427.mp3?updated=1699093561)

The year is 1519. Hernán Cortés and his Spanish comrades have arrived in Tenochtitlan, the capital city of the Aztecs, and have been welcomed by their Emperor Montezuma. But what is Montezuma planning? Are the Spaniards his guests - or his prisoners? Has he really acknowledged them as his overlords? Or are they destined for a rather darker fate, as the latest inmates in his mysterious zoo? In …