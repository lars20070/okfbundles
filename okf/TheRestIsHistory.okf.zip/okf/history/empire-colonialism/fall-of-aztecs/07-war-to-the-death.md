---
type: Section
title: "War to the Death (Part 7)"
description: "Episode 390: The fate of Mexico hangs by a thread as Cortés cuts off Tenochtitlan."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "aztecs", "conquistadors"]
---

# War to the Death (Part 7)

2023-11-20 · 38:04 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1796642529.mp3?updated=1699093669)

"Conquer or die indeed, Cortes thought… The hour of decision was at hand…" It is the spring of 1521 and the fate of Mexico hangs by a thread. Smallpox has ripped through the local population, while the ruthless Spanish commander, Hernán Cortés, has cut off the Aztec capital, Tenochtitlan, from its surrounding provinces. So begins one of the bloodiest and most dramatic struggles in all history …