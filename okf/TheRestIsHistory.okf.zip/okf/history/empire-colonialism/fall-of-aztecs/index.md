# The Adventure Begins (Part 1)

## Episodes

* [The Adventure Begins (Part 1)](/history/empire-colonialism/fall-of-aztecs/01-the-adventure-begins.md) — Episode 384: Hernán Cortés setting sail from Cuba to find gold on the coast of Mexico.
* [The Woman Who Changed The World (Part 2)](/history/empire-colonialism/fall-of-aztecs/02-the-woman-who-changed-the-world.md) — Episode 385: A woman whose very name has become a byword for treachery.
* [The City of Gold (Part 3)](/history/empire-colonialism/fall-of-aztecs/03-the-city-of-gold.md) — Episode 386: Hernán Cortés chooses to disobey orders and head inland for the gold-rich empire.
* [Prisoners of Montezuma (Part 4)](/history/empire-colonialism/fall-of-aztecs/04-prisoners-of-montezuma.md) — Episode 387: Hernán Cortés and his Spanish comrades have arrived in Tenochtitlan.
* [The Festival of Blood (Part 5)](/history/empire-colonialism/fall-of-aztecs/05-the-festival-of-blood.md) — Episode 388: Cortés decides to leave the city with his mistress Malinche to pursue Narváez.
* [The Night of Tears (Part 6)](/history/empire-colonialism/fall-of-aztecs/06-the-night-of-tears.md) — Episode 389: Cortés and his band of Spaniards trapped in the heart of Tenochtitlan.
* [War to the Death (Part 7)](/history/empire-colonialism/fall-of-aztecs/07-war-to-the-death.md) — Episode 390: The fate of Mexico hangs by a thread as Cortés cuts off Tenochtitlan.
* [The Last Emperor (Part 8)](/history/empire-colonialism/fall-of-aztecs/08-the-last-emperor.md) — Episode 391: The final episode of this astonishing journey.
