---
type: Section
title: "The Night of Tears (Part 6)"
description: "Episode 389: Cortés and his band of Spaniards trapped in the heart of Tenochtitlan."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "aztecs", "conquistadors"]
---

# The Night of Tears (Part 6)

2023-11-16 · 44:40 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2744313815.mp3?updated=1699093626)

Things have never looked bleaker for Hernán Cortés and his band of Spaniards. They are trapped, starving and terrified in the heart of the Aztec city of Tenochtitlan, surrounded by an enraged people bent on revenge. And with their imperial hostage Montezuma dead, they only have one option left - a desperate escape in the dead of night. Can they make it across the lake with their gold? Or will the …