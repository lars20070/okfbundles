---
type: Section
title: "The Festival of Blood (Part 5)"
description: "Episode 388: Cortés decides to leave the city with his mistress Malinche to pursue Narváez."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "aztecs", "conquistadors"]
---

# The Festival of Blood (Part 5)

2023-11-14 · 49:38 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8784071073.mp3?updated=1699093591)

"The blood flowed like water…" It is 1520 and word has reached Hernán Cortés in Tenochtitlan that another group of Spaniards led by the ferocious Pánfilo de Narváez, have landed on the coast to hunt him down. Taking drastic action, he decides to leave the city with his wily mistress Malinche to pursue the newcomers, but not before taking the Emperor of the Aztecs, Montezuma, as his hostage. But …