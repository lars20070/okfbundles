---
type: Section
title: "The Adventure Begins (Part 1)"
description: "Episode 384: Hernán Cortés setting sail from Cuba to find gold on the coast of Mexico."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "aztecs", "conquistadors"]
---

# The Adventure Begins (Part 1)

2023-11-06 · 51:34 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8046611029.mp3?updated=1699093514)

Hernán Cortés has set sail from Cuba, eager to find the truth behind the rumours of gold on the coast of Mexico. Ahead lies a world he can barely imagine - a land of pyramid temples, terrifying gods and unknown peoples - the empire of the Aztecs. But Cortés has a secret weapon: a woman whose very name has become a byword for treachery … In today's episode, Dominic and Tom explore the …