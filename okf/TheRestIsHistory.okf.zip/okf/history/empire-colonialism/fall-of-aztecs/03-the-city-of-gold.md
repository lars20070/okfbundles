---
type: Section
title: "The City of Gold (Part 3)"
description: "Episode 386: Hernán Cortés chooses to disobey orders and head inland for the gold-rich empire."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "aztecs", "conquistadors"]
---

# The City of Gold (Part 3)

2023-11-09 · 48:50 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2951201852.mp3?updated=1699093480)

"Conquer or die! Conquer or die! Conquer or die!" Making a decision that will change the course of history, Hernán Cortés chooses to disobey his orders and head inland in search of the gold-rich empire of the mysterious Montezuma. Ahead lie the mountain passes that will lead him down into the Valley of Mexico, a vast lake shimmering at its heart. In the middle of the lake lies the island city of …