---
type: Section
title: "The Last Emperor (Part 8)"
description: "Episode 391: The final episode of this astonishing journey."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "aztecs", "conquistadors"]
---

# The Last Emperor (Part 8)

2023-11-23 · 56:35 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2984940365.mp3?updated=1699093693)

Tenochtitlan, once the glittering jewel at the heart of the mighty Aztec Empire, has fallen. Hernán Cortés stands triumphant, the master of this New Spain. Or so it seems. For the last Aztec emperor, Cuauhtemoc, is still alive and well. And in the jungles of Mexico and Honduras, a dark and bloody story is only just beginning … In the final episode of this astonishing journey, Dominic and Tom …