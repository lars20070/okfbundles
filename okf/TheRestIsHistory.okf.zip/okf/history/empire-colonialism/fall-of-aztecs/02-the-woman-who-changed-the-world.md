---
type: Section
title: "The Woman Who Changed The World (Part 2)"
description: "Episode 385: A woman whose very name has become a byword for treachery."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "aztecs", "conquistadors"]
---

# The Woman Who Changed The World (Part 2)

2023-11-07 · 52:52 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5124604457.mp3?updated=1699093536)

Hernán Cortés has set sail from Cuba, eager to find the truth behind the rumours of gold on the coast of Mexico. Ahead lies a world he can barely imagine - a land of pyramid temples, terrifying gods and unknown peoples - the empire of the Aztecs. But Cortés has a secret weapon: a woman whose very name has become a byword for treachery … In today's episode, Dominic and Tom explore the …