# Empire Colonialism

## Series

* [Baghdad](/history/empire-colonialism/baghdad/) — 4 episodes
* [Captain Cook](/history/empire-colonialism/captain-cook/) — 2 episodes
* [The Chilean Coup](/history/empire-colonialism/chilean-coup/) — 2 episodes
* [Columbus](/history/empire-colonialism/columbus/) — 4 episodes
* [Evita](/history/empire-colonialism/evita/) — 5 episodes
* [The Fall of the Aztecs](/history/empire-colonialism/fall-of-aztecs/) — 8 episodes
* [The Incas](/history/empire-colonialism/incas/) — 6 episodes
* [Portugal](/history/empire-colonialism/portugal/) — 4 episodes
