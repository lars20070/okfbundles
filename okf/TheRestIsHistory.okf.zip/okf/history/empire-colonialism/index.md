# Empire Colonialism

## Series

* [The Forging of Islam (Part 1)](/history/empire-colonialism/baghdad/) — Series about The Forging of Islam (Part 1)
* [History's Greatest Explorer (Part 1)](/history/empire-colonialism/captain-cook/) — Series about History's Greatest Explorer (Part 1)
* [Allende, Nixon and the CIA (Part 1)](/history/empire-colonialism/chilean-coup/) — Series about Allende, Nixon and the CIA (Part 1)
* [The Adventure Begins (Part 1)](/history/empire-colonialism/columbus/) — Series about The Adventure Begins (Part 1)
* [Birth of a Legend (Part 1)](/history/empire-colonialism/evita/) — Series about Birth of a Legend (Part 1)
* [The Adventure Begins (Part 1)](/history/empire-colonialism/fall-of-aztecs/) — Series about The Adventure Begins (Part 1)
* [Empire of Gold (Part 1)](/history/empire-colonialism/incas/) — Series about Empire of Gold (Part 1)
* [Portugal: On the Edge of the World (Part 1)](/history/empire-colonialism/portugal/) — Series about Portugal: On the Edge of the World (Part 1)
