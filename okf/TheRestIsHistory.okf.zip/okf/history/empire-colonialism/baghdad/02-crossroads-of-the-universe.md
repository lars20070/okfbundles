---
type: Section
title: "Crossroads of the Universe (Part 2)"
description: "Episode 377: Baghdad was chosen by the Abbasid Caliph Al-Mansur as the site for the new capital."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "baghdad", "islamic-golden-age"]
---

# Crossroads of the Universe (Part 2)

2023-10-11 · 45:04 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9127243683.mp3?updated=1729781768)

"No city in the world will ever rival it for prosperity..." Baghdad, originally a Christian village in Iraq, was chosen by the Abbasid Caliph Al-Mansur as the site for the new capital of his empire, and it would become a cosmopolis to rival Rome or Babylon. Its foundations were built in a perfect circle, with walls 90 feet tall, and at its heart, the monumental Palace of the Golden Gate …