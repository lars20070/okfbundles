---
type: Section
title: "The Arabian Nights (Part 4)"
description: "Episode 379: The setting for so many of the Arabian Nights tales."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "baghdad", "islamic-golden-age"]
---

# The Arabian Nights (Part 4)

2023-10-18 · 49:06 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8529456010.mp3?updated=1729781852)

The setting for so many of the Arabian Nights, like the stories of Sinbad the Sailor, Ali Baba and the Forty Thieves, or Aladdin, Baghdad during the Islamic Golden Age had a shimmering image, a dimension of mystery and wonder… Join Tom and Dominic in the final part of our series on the history of Baghdad, as they explore the tales of One Thousand and One Nights, and the city of Caliphs, Hadiths …