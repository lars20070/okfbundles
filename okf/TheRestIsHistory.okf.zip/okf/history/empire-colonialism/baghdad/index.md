# The Forging of Islam (Part 1)

## Episodes

* [The Forging of Islam (Part 1)](/history/empire-colonialism/baghdad/01-the-forging-of-islam.md) — Episode 376: The foundation of Baghdad is a fundamental episode in the development of Islam.
* [Crossroads of the Universe (Part 2)](/history/empire-colonialism/baghdad/02-crossroads-of-the-universe.md) — Episode 377: Baghdad was chosen by the Abbasid Caliph Al-Mansur as the site for the new capital.
* [The Golden Age (Part 3)](/history/empire-colonialism/baghdad/03-the-golden-age.md) — Episode 378: During the Islamic Golden Age, Baghdad was the most global city the world had ever seen.
* [The Arabian Nights (Part 4)](/history/empire-colonialism/baghdad/04-the-arabian-nights.md) — Episode 379: The setting for so many of the Arabian Nights tales.
