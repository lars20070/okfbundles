---
type: Section
title: "The Forging of Islam (Part 1)"
description: "Episode 376: The foundation of Baghdad is a fundamental episode in the development of Islam."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "baghdad", "islamic-golden-age"]
---

# The Forging of Islam (Part 1)

2023-10-08 · 51:03 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9529602805.mp3?updated=1729781750)

A story of great myth and of huge historical significance, the foundation of Baghdad is a fundamental episode in the development of Islam. The Umayyad Caliphate, the first great Islamic empire, stretched from the Atlantic Ocean to the borders of China; no dynasty had ever presided over a greater array of conquests. But amongst growing sectarian and internal divisions, discontent on the fringes of …