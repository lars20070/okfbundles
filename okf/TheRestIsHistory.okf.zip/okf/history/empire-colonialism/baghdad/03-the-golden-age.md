---
type: Section
title: "The Golden Age (Part 3)"
description: "Episode 378: During the Islamic Golden Age, Baghdad was the most global city the world had ever seen."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "baghdad", "islamic-golden-age"]
---

# The Golden Age (Part 3)

2023-10-15 · 51:13 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9689814482.mp3?updated=1729781786)

Baghdad was a place of fabulous sophistication and teeming multitudes, where terrible things could happen, but great wonders could also be found… During the Islamic Golden Age, it was the most global city the world had ever seen, a truly diverse cosmopolis, with silks and porcelains from China, spices from India, slaves from the frozen shores of the distant "North", and ships coming and going …