---
type: Section
title: "The King in the North (Part 4)"
description: "Episode 647: The Spanish takeover of the Incan civil war."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, incas, spain, conquest]
---

# The King in the North (Part 4)

2026-02-26 · 1:10:59 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4740382633.mp3?updated=1772124782)

How did the Spanish conquistadors under Francisco Pizarro take advantage of the Incan civil War? Were they able to discover the glorious city of Cusco, with all of its riches? And, what terrible brutalities did they commit along the way…? Join Dominic and Tom, as they discuss the next dramatic phase of the Spaniards conquest of the Incas, as the violence escalates and the city of gold prepares to …
