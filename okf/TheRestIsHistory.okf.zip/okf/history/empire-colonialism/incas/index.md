# Empire of Gold (Part 1)

## Episodes

* [Empire of Gold (Part 1)](/history/empire-colonialism/incas/01-empire-of-gold.md) — Episode 644: Francisco Pizarro and the glittering Incan Empire.
* [Massacre in the Andes (Part 2)](/history/empire-colonialism/incas/02-massacre-in-the-andes.md) — Episode 645: Pizarro's face-to-face meeting with Emperor Atahualpa.
* [Death to the Emperor (Part 3)](/history/empire-colonialism/incas/03-death-to-the-emperor.md) — Episode 646: The bloodiest moment of the conquest of the Incas.
* [The King in the North (Part 4)](/history/empire-colonialism/incas/04-the-king-in-the-north.md) — Episode 647: The Spanish takeover of the Incan civil war.
* [Battle for the Sacred City (Part 5)](/history/empire-colonialism/incas/05-battle-for-the-sacred-city.md) — Episode 648: The Spaniards' response to the Incan uprising led by Manco.
* [The Last Emperor (Part 6)](/history/empire-colonialism/incas/06-the-last-emperor.md) — Episode 649: The epic conclusion of the hunt for gold and glory.
