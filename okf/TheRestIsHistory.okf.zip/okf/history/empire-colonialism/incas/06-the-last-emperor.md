---
type: Section
title: "The Last Emperor (Part 6)"
description: "Episode 649: The epic conclusion of the hunt for gold and glory."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, incas, spain, conquest]
---

# The Last Emperor (Part 6)

2026-03-05 · 1:12:25 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4505534064.mp3?updated=1772550842)

With the Incan emperor on the run, and the Spanish divided, what atrocities would unfold in the final phase of this brutal conquest? Who would triumph, Francisco Pizarro or his brutal former partner Diego de Almagro? And how would the once mighty Incas, finally fall…? Join Dominic and Tom for the epic conclusion of one of the most epic stories in all of world history: a hunt for gold and glory …
