---
type: Section
title: "Massacre in the Andes (Part 2)"
description: "Episode 645: Pizarro's face-to-face meeting with Emperor Atahualpa."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, incas, spain, conquest]
---

# Massacre in the Andes (Part 2)

2026-02-19 · 1:09:00 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2938007438.mp3?updated=1771863725)

What happened when the Spanish conquistadors lead by Francisco Pizarro came face to face with the ruthless emperor of the Incan Empire, Atahualpa? How did the Incas treat their strange, pale, alien visitors with their horses? And, why did a brutal, bloody fight to the death break out between the two sides after the meeting? Join Dominic and Tom, as they discuss one of the most totemic meetings of …
