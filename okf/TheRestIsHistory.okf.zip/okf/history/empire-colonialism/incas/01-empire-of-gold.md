---
type: Section
title: "Empire of Gold (Part 1)"
description: "Episode 644: Francisco Pizarro and the glittering Incan Empire."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, incas, spain, conquest]
---

# Empire of Gold (Part 1)

2026-02-16 · 1:16:20 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4676536558.mp3?updated=1771269723)

Why was the Spanish conquest of the Incas one of the most pivotal moments in world history? Who was Francisco Pizarro, the buccaneer behind this bloody event? And, what was the glittering Incan Empire like? Join Dominic and Tom, as they launch into a tale of horror, adventure, and terrible violence, which would see a mighty civilisation brought to its knees by alien invaders. As Pizarro and his …
