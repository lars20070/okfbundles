---
type: Section
title: "Battle for the Sacred City (Part 5)"
description: "Episode 648: The Spaniards' response to the Incan uprising led by Manco."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, incas, spain, conquest]
---

# Battle for the Sacred City (Part 5)

2026-03-02 · 1:07:43 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6392035011.mp3?updated=1772185903)

Three years into the conquest of the Incas, how did the Spaniards respond to the Incan uprising, lead by their puppet emperor Manco? How did the despicable behaviour of Pizarro and his men spark the rebellion? And, how would the terrifying assault of Manco and his Incan warriors, on a stranded contingent of Spaniards, play out…? Join Dominic and Tom, as they reach the thrilling climax of this …
