---
type: Section
title: "Death to the Emperor (Part 3)"
description: "Episode 646: The bloodiest moment of the conquest of the Incas."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, incas, spain, conquest]
---

# Death to the Emperor (Part 3)

2026-02-23 · 1:05:36 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8131543734.mp3?updated=1771955001)

What happened to the emperor of the Incas after he was taken prisoner by the Spanish conquistadors? Did the formidable buccaneer, Francisco Pizarro, and his men succeed in discovering the treasure troves of the Incas? And, could the Incan empire stand united against this terrifying, alien invasion…? Join Dominic and Tom, as they charge into the bloodiest moment of the whole conquest of the Incas …
