---
type: Section
title: "Death in the Desert (Part 4)"
description: "Episode 639: The climactic conclusion to the Iranian Revolution."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, iran, revolution, hostage-crisis]
---

# Death in the Desert (Part 4)

2026-01-29 · 1:12:15 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6288433592.mp3?updated=1769449341)

How did America respond after the American Embassy in Tehran was seized, and American citizens taken hostage? Would the hostages survive? And, what became of the Iranian Revolution, and Ayatollah Khomeini? Join Dominic and Tom, as they unfold the climactic conclusion to the Iranian Revolution, and America's attempts to bring its hostages home.
