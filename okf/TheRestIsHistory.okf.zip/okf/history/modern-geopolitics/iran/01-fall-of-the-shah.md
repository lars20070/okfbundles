---
type: Section
title: "Fall of the Shah (Part 1)"
description: "Episode 636: The Iranian Revolution of 1979, Carter, the Shah, and Ayatollah Khomeini."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, iran, revolution, hostage-crisis]
---

# Fall of the Shah (Part 1)

2026-01-19 · 1:17:34 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5083873634.mp3?updated=1768557306)

Why did the Iranian Revolution erupt in 1979? What was the nature of the relationship between President Carter and the ostentatious Shah Mohammad Reza Pahlavi? And, who was the Ayatollah Ruhollah Khomeini, a man whose militant vision for Iran would see it drastically remade? Join Dominic and Tom, as they launch into one of the most dramatic stories of all time, with such far reaching …
