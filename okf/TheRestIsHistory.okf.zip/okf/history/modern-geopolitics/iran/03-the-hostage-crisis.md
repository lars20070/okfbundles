---
type: Section
title: "The Hostage Crisis (Part 3)"
description: "Episode 638: The storming of the American Embassy in 1979."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, iran, revolution, hostage-crisis]
---

# The Hostage Crisis (Part 3)

2026-01-26 · 1:15:18 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6844236579.mp3?updated=1769165839)

Why and how was the American Embassy stormed in 1979, at the height of the Iranian Revolution? Did America respond when large numbers of American civil servants were taken hostage? And, would a science fiction film called Argo save the only 6 Americans able to escape…? Join Dominic and Tom, as they discuss the defining event of the Iranian Revolution: the invasion of the American Embassy on the …
