---
type: Section
title: "Rise of the Ayatollah (Part 2)"
description: "Episode 637: The final uprisings of the Iranian Revolution and Ayatollah Khomeini."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, iran, revolution, hostage-crisis]
---

# Rise of the Ayatollah (Part 2)

2026-01-22 · 1:09:47 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7243579163.mp3?updated=1769178690)

What set off the final uprisings of the Iranian Revolution, against the last Shah of Iran, Mohammed Reza Pahlavi? Would President Jimmy Carter and America back the Shah's forbidding opponent, the firebrand, Ayatollah Khomeini? And, why would the Revolution prove to be one of the most pivotal events in recent history? Join Dominic and Tom, as they discuss the final fall of Iran's last Shah …
