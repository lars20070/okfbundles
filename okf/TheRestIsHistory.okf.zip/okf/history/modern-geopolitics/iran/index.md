# Fall of the Shah (Part 1)

## Episodes

* [Fall of the Shah (Part 1)](/history/modern-geopolitics/iran/01-fall-of-the-shah.md) — Episode 636: The Iranian Revolution of 1979, Carter, the Shah, and Ayatollah Khomeini.
* [Rise of the Ayatollah (Part 2)](/history/modern-geopolitics/iran/02-rise-of-the-ayatollah.md) — Episode 637: The final uprisings of the Iranian Revolution and Ayatollah Khomeini.
* [The Hostage Crisis (Part 3)](/history/modern-geopolitics/iran/03-the-hostage-crisis.md) — Episode 638: The storming of the American Embassy in 1979.
* [Death in the Desert (Part 4)](/history/modern-geopolitics/iran/04-death-in-the-desert.md) — Episode 639: The climactic conclusion to the Iranian Revolution.
