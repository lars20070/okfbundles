---
type: Section
title: "God and the American Empire"
description: "Episode 153: On today's episode Tom and Dominic are joined by Professor Andrew Preston to talk about the relationship between the US and religion."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "american-crusades", "usa"]
---

# God and the American Empire

2022-02-18 · 29:43 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8752091834.mp3?updated=1777394623)

On today's episode Tom and Dominic are joined by Friend of the Show, Professor Andrew Preston, to talk about the relationship between the US and religion, both at home and abroad in the 20th and 21st centuries. Why have there been such low levels of anti-clericalism in the US compared to the rest of the world? What's behind the sustained and growing numbers of religious believers in the United …