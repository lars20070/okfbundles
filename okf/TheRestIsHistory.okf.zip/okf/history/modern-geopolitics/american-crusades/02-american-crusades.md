---
type: Section
title: "American Crusades"
description: "Episode 152: On today's episode Tom and Dominic are joined by Andrew Preston, a Cambridge University professor."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "american-crusades", "usa"]
---

# American Crusades

2022-02-17 · 45:49 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4400059090.mp3?updated=1777394894)

On today's episode Tom and Dominic are joined by Andrew Preston, a Cambridge University professor whose new book focuses on religion in American war and diplomacy. What is the role of religion in the American outlook? How has it shaped foreign policy? What is the relationship between pacifistic religious ideals and a crusading mentality? Join us tomorrow for another episode, which focuses on more …