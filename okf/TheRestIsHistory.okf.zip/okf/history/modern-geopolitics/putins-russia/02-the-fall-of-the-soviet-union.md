---
type: Section
title: "The Fall of the Soviet Union (Part 2)"
description: "Episode 160: This episode marks the second instalment in our four part series on the Soviet Union."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "putin", "russia", "soviet-union"]
---

# The Fall of the Soviet Union (Part 2)

2022-03-08 · 32:05 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9472343994.mp3?updated=1777394738)

[Episode 2 of 4] This episode of The Rest Is History marks the second instalment in our four part series on the Soviet Union, Russia and the rise of Vladimir Putin. From the 70th anniversary of the Russian Revolution in 1987 to the fall of the Soviet Union on Christmas Day 1991, this episode is jam-packed full of late Soviet drama. Tune in now to hear about the abuse Yeltsin received after his …