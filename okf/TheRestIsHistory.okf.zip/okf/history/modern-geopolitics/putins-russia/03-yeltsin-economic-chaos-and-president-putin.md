---
type: Section
title: "Yeltsin, Economic Chaos and President Putin (Part 3)"
description: "Episode 161: In part three of our Soviet Union, Russia and Putin series, Tom and Dominic drill down into the details of the chaos in 90s Russia."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "putin", "russia", "soviet-union"]
---

# Yeltsin, Economic Chaos and President Putin (Part 3)

2022-03-09 · 37:33 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3048619920.mp3?updated=1777394773)

[Episode 3 of 4] 'You certainly won't understand what ordinary Russians see in Vladimir Putin if you don't understand what happened in the 1990s. A time of utter, utter collapse.' In part three of our Soviet Union, Russia and Putin series, Tom and Dominic drill down into the details of the chaos in 90s Russia, the laughing stock Yeltsin became on the global stage, and Putin's brutal rise to power …