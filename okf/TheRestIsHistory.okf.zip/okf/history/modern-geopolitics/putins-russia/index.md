# Young Putin, the KGB and the Soviet Union (Part 1)

## Episodes

* [Young Putin, the KGB and the Soviet Union (Part 1)](/history/modern-geopolitics/putins-russia/01-young-putin-the-kgb-and-the-soviet-union.md) — Episode 159: Welcome to our new four part series on the latter years of the Soviet Union.
* [The Fall of the Soviet Union (Part 2)](/history/modern-geopolitics/putins-russia/02-the-fall-of-the-soviet-union.md) — Episode 160: This episode marks the second instalment in our four part series on the Soviet Union.
* [Yeltsin, Economic Chaos and President Putin (Part 3)](/history/modern-geopolitics/putins-russia/03-yeltsin-economic-chaos-and-president-putin.md) — Episode 161: In part three of our Soviet Union, Russia and Putin series, Tom and Dominic drill down into the details of the chaos in 90s Russia.
* [Putin's Russia (Part 4)](/history/modern-geopolitics/putins-russia/04-putins-russia.md) — Episode 162: In the final instalment of our Russia mini-series, Tom and Dominic reach the climax of Putin's rise to power.
