---
type: Section
title: "Young Putin, the KGB and the Soviet Union (Part 1)"
description: "Episode 159: Welcome to our new four part series on the latter years of the Soviet Union."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "putin", "russia", "soviet-union"]
---

# Young Putin, the KGB and the Soviet Union (Part 1)

2022-03-07 · 35:28 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7336670203.mp3?updated=1777394844)

[Episode 1 of 4] Welcome to our new four part series on the latter years of the Soviet Union, its fall, Putin's early life and his subsequent rise to power. Today's episode focuses on Brezhnev, Putin's formative years, his early KGB career and Gorbachev's descent into chaos. Was Putin a nationalist or a communist? What changed from Brezhnev to Gorbachev? What was Putin doing in East Germany …