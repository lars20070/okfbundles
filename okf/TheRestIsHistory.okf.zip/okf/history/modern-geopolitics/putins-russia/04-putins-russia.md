---
type: Section
title: "Putin's Russia (Part 4)"
description: "Episode 162: In the final instalment of our Russia mini-series, Tom and Dominic reach the climax of Putin's rise to power."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "putin", "russia", "soviet-union"]
---

# Putin's Russia (Part 4)

2022-03-10 · 35:03 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4575290976.mp3?updated=1777394824)

[Episode 4 of 4] 'In the noughties, Russian democracy becomes a form of show business' In the final instalment of our Russia mini-series, Tom and Dominic reach the climax of Putin's rise to power, charting how a former KGB agent managed to climb from relative obscurity to become the uncrowned Tsar of Russia. The episode also touches on his relationship with oligarchs such as Roman Abramovich, the …