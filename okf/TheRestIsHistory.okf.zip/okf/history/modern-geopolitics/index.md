# Modern Geopolitics

## Series

* [God and the American Empire](/history/modern-geopolitics/american-crusades/) — Series about God and the American Empire
* [Fall of the Shah (Part 1)](/history/modern-geopolitics/iran/) — Series about Fall of the Shah (Part 1)
* [Young Putin, the KGB and the Soviet Union (Part 1)](/history/modern-geopolitics/putins-russia/) — Series about Young Putin, the KGB and the Soviet Union (Part 1)
