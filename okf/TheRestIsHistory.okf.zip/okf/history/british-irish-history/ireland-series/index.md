# Celts, Conquest and Cromwell (Part 1)

## Episodes

* [Celts, Conquest and Cromwell (Part 1)](/history/british-irish-history/ireland-series/01-celts-conquest-and-cromwell.md) — Episode 336: 'In every generation the Irish people have asserted their right to national freedom and sovereignty.'
* [Union, Famine and Parnell (Part 2)](/history/british-irish-history/ireland-series/02-union-famine-and-parnell.md) — Episode 337: At the start of the 19th century, the kingdoms of Britain and Ireland were officially 'united' with the Acts of Union.
* [Home Rule, Mutiny - and Civil War? (Part 3)](/history/british-irish-history/ireland-series/03-home-rule-mutiny-and-civil-war.md) — Episode 338: The year is 1912. The bitter arguments about Home Rule for Ireland are reaching boiling point.
* [The Easter Rising, 1916 (Part 4)](/history/british-irish-history/ireland-series/04-the-easter-rising-1916.md) — Episode 339: The Easter Rising began in Dublin's General Post Office on Easter Monday, 24th April 1916.
