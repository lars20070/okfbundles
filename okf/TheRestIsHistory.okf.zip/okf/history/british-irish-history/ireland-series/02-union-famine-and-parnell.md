---
type: Section
title: "Union, Famine and Parnell (Part 2)"
description: "Episode 337: At the start of the 19th century, the kingdoms of Britain and Ireland were officially 'united' with the Acts of Union."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "ireland", "easter-rising"]
---

# Union, Famine and Parnell (Part 2)

2023-06-01 · 51:23 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4375415331.mp3?updated=1777394923)

At the start of the 19th century, the kingdoms of Britain and Ireland were officially 'united' with the Acts of Union. Historian Paul Rouse continues our sweep through the Anglo-Irish relationship, including the Great Famine and the political battles both for and against Home Rule. Tom, Dominic and Paul recorded this episode in the iconic General Post Office on O'Connell Street in Dublin.