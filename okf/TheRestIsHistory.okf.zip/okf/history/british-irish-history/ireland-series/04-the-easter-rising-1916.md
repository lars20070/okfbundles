---
type: Section
title: "The Easter Rising, 1916 (Part 4)"
description: "Episode 339: The Easter Rising began in Dublin's General Post Office on Easter Monday, 24th April 1916."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "ireland", "easter-rising"]
---

# The Easter Rising, 1916 (Part 4)

2023-06-08 · 1:01:21 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7095481415.mp3?updated=1777394202)

The Easter Rising began in Dublin's General Post Office on Easter Monday, 24th April 1916, with Patrick Pearse's dramatic proclamation of the Irish Republic. Led by republicans opposed to British rule in Ireland, this was the most significant uprising in more than a century - and changed the entire course of Irish and British history, with effects that still reverberate today. In today's episode …