---
type: Section
title: "Home Rule, Mutiny - and Civil War? (Part 3)"
description: "Episode 338: The year is 1912. The bitter arguments about Home Rule for Ireland are reaching boiling point."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "ireland", "easter-rising"]
---

# Home Rule, Mutiny - and Civil War? (Part 3)

2023-06-05 · 1:02:26 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5217836668.mp3?updated=1777395064)

The year is 1912. The bitter arguments about Home Rule for Ireland are reaching boiling point. But with Ulster in uproar, the Tories encouraging mutiny and thousands of rifles pouring into Ireland, is the United Kingdom really heading for a bloody civil war? And was Sarajevo really the turning point that saved Britain from a sectarian inferno? In today's episode, Tom and Dominic are joined by …