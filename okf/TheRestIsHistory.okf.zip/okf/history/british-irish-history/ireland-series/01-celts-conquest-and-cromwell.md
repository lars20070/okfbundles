---
type: Section
title: "Celts, Conquest and Cromwell (Part 1)"
description: "Episode 336: 'In every generation the Irish people have asserted their right to national freedom and sovereignty.'"
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "ireland", "easter-rising"]
---

# Celts, Conquest and Cromwell (Part 1)

2023-05-29 · 55:45 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6280042699.mp3?updated=1777394205)

"In every generation the Irish people have asserted their right to national freedom and sovereignty; six times during the past three hundred years they have asserted it in arms." The proclamation of the Irish Republic, delivered by Patrick Pearse in Dublin, marked the beginning of the Easter Rising in 1916. Looking at the Anglo-Irish relationship leading up to the Easter Rising, Tom and Dominic …