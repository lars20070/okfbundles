---
type: Section
title: "Young Churchill: Soldier of Empire (Part 2)"
description: "Episode 240: Join Tom and Dominic in the second episode of our mini-series on Young Churchill."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "churchill", "young-churchill"]
---

# Young Churchill: Soldier of Empire (Part 2)

2022-10-06 · 54:39 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4710302249.mp3?updated=1729784566)

Join Tom and Dominic in the second episode of our mini-series on Young Churchill as they dive into his imperial exploits. From Cuba to Sudan, they explore his obsession with adventure, the ambiguities that existed within his own moral universe, and his swashbuckling prose.
