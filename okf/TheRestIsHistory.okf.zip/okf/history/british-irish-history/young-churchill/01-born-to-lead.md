---
type: Section
title: "Young Churchill: Born to Lead (Part 1)"
description: "Episode 239: 'The child is the father of the man.'"
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "churchill", "young-churchill"]
---

# Young Churchill: Born to Lead (Part 1)

2022-10-03 · 52:57 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1969009161.mp3?updated=1729784554)

'The child is the father of the man.' In the first episode of this mini-series on Young Churchill, Tom and Dominic explore the early life of Winston Churchill. They discuss the cruelty of his parents, his deeply imbued sense of destiny, and the razor sharp wit of the future Prime Minister.
