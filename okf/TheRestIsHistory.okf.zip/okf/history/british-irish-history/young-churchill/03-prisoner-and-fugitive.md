---
type: Section
title: "Young Churchill: Prisoner and Fugitive (Part 3)"
description: "Episode 241: In the final instalment of our series on Young Churchill."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "churchill", "young-churchill"]
---

# Young Churchill: Prisoner and Fugitive (Part 3)

2022-10-10 · 51:49 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9087091726.mp3?updated=1729784589)

In the final instalment of our series on Young Churchill, learn how Churchill escaped a prisoner of war camp in the Boer War, becoming an imperialist hero. Discover how Churchill sought shelter in rat infested hideaways, escaped in the tight consignment of a train, plus how the simple activity of a hair appointment almost blew his cover...
