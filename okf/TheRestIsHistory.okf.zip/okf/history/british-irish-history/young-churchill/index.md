# Young Churchill: Born to Lead (Part 1)

## Episodes

* [Young Churchill: Born to Lead (Part 1)](/history/british-irish-history/young-churchill/01-born-to-lead.md) — Episode 239: 'The child is the father of the man.'
* [Young Churchill: Soldier of Empire (Part 2)](/history/british-irish-history/young-churchill/02-soldier-of-empire.md) — Episode 240: Join Tom and Dominic in the second episode of our mini-series on Young Churchill.
* [Young Churchill: Prisoner and Fugitive (Part 3)](/history/british-irish-history/young-churchill/03-prisoner-and-fugitive.md) — Episode 241: In the final instalment of our series on Young Churchill.
