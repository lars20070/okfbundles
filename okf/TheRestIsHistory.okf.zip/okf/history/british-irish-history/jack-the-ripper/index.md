# History's Darkest Mystery (Part 1)

## Episodes

* [History's Darkest Mystery (Part 1)](/history/british-irish-history/jack-the-ripper/01-historys-darkest-mystery.md) — Episode 624: Jack the Ripper's terrible reign of terror begins in Victorian London.
* [Horror in Whitechapel (Part 2)](/history/british-irish-history/jack-the-ripper/02-horror-in-whitechapel.md) — Episode 625: The second victim and the police investigation.
* [The Killer Strikes Again (Part 3)](/history/british-irish-history/jack-the-ripper/03-the-killer-strikes-again.md) — Episode 626: Two murders in one night and chilling clues.
* [From Hell (Part 4)](/history/british-irish-history/jack-the-ripper/04-from-hell.md) — Episode 627: Mary-Jane Kelly and the nightmarish crescendo.
* [The Killer Unmasked (Part 5)](/history/british-irish-history/jack-the-ripper/05-the-killer-unmasked.md) — Episode 628: The prime suspects and the true identity of Jack the Ripper.
