---
type: Section
title: "The Killer Strikes Again (Part 3)"
description: "Episode 626: Two murders in one night and chilling clues."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, jack-the-ripper, victorian-london]
---

# The Killer Strikes Again (Part 3)

2025-12-15 · 59:09 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7980605076.mp3?updated=1784107604)

How did Jack the Ripper manage to strike twice in the same night without getting caught? Did he have an accomplice? And, what chilling clues did the police discover in the wake of the murder…? Join Dominic and Tom as they decode the next horrific phase of Jack the Ripper's shocking killing spree, as they seek to reveal his identity once and for all.
