---
type: Section
title: "From Hell (Part 4)"
description: "Episode 627: Mary-Jane Kelly and the nightmarish crescendo."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, jack-the-ripper, victorian-london]
---

# From Hell (Part 4)

2025-12-18 · 1:10:08 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6270048402.mp3?updated=1765988289)

Why was Jack the Ripper's final murder the most appalling of all? Who was the mysterious Mary-Jane Kelly, his unfortunate victim? And, what enduring impact would his crimes have upon the cultural climate of England, and the treatment of women? Join Tom and Dominic as they reach the nightmarish crescendo of Victorian London's darkest days, as Jack the Ripper's killing spree culminates with his …
