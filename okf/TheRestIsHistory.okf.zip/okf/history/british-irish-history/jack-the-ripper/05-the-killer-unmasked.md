---
type: Section
title: "The Killer Unmasked (Part 5)"
description: "Episode 628: The prime suspects and the true identity of Jack the Ripper."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, jack-the-ripper, victorian-london]
---

# The Killer Unmasked (Part 5)

2025-12-22 · 1:35:53 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3796910737.mp3?updated=1766065370)

Who are the prime suspects for the identity of Jack the Ripper? Why did he suddenly halt his hellish killing spree, and never strike again? And, once and for all, who really was Jack the Ripper…? Join Dominic and Tom as they reveal, with shocking melodrama, the true identity of one of the world's most mysterious serial killers: Jack the Ripper…
