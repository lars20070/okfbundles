---
type: Section
title: "History's Darkest Mystery (Part 1)"
description: "Episode 624: Jack the Ripper's terrible reign of terror begins in Victorian London."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, jack-the-ripper, victorian-london]
---

# History's Darkest Mystery (Part 1)

2025-12-08 · 1:04:08 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7829555893.mp3?updated=1764858656)

Was Jack the Ripper the first serial killer of all time? Who was his first victim, and why was the murder so shocking? And, what did the Ripper phenomenon reveal about the anxieties of Victorian London? Join Tom and Dominic as they delve into the darkest days of London's long history, as Jack the Ripper's terrible, grisly reign of terror begins...
