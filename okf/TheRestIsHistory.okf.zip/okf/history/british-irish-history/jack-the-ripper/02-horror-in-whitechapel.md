---
type: Section
title: "Horror in Whitechapel (Part 2)"
description: "Episode 625: The second victim and the police investigation."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, jack-the-ripper, victorian-london]
---

# Horror in Whitechapel (Part 2)

2025-12-11 · 1:06:32 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2555108111.mp3?updated=1784107685)

Who was Jack the Ripper's second victim, and why was their murder considered the true starting point of his terrifying killing spree? How did the police investigation unfold? And, when and how did the Ripper strike again…? Join Dominic and Tom as they travel further into the dark streets of Victorian London and follow Jack the Ripper's depraved trail, as they unravel the truth behind the world's …
