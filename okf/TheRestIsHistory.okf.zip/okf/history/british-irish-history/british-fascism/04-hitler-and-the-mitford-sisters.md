---
type: Section
title: "Hitler and the Mitford Sisters"
description: "Episode 375: Diana Mitford married Oswald Mosley, while her sister Unity had a relationship with Hitler."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "fascism", "mitford-sisters", "hitler"]
---

# Hitler and the Mitford Sisters

2023-10-04 · 53:22 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5493256820.mp3?updated=1696350753)

The Mitfords were the most glamorous aristocrats on the London scene in the 1920s, with at their head Diana, the most beautiful woman in London, who would eventually marry Oswald Mosley. However, her younger sister Unity would strike up a relationship with her own fascist leader: Adolf Hitler. Having first moved to Berlin in 1934, Unity would eventually become part of the Führer's inner-circle …