---
type: Section
title: "Oswald Mosley: Fascist Leader"
description: "Episode 373: The fascists in Britain have found a leader: the sinister yet complex Oswald Mosley."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "fascism", "britain", "oswald-mosley"]
---

# Oswald Mosley: Fascist Leader

2023-09-27 · 54:31 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7471576360.mp3?updated=1695823188)

The fascists in Britain have found a leader known across the country: the sinister yet complex Oswald Mosley. Following stints as an MP for both the Tories and Labour, Mosley, a veteran of the First World War, forms the British Union of Fascists in 1932, making a big effort to appeal to women and the working class. Although his rhetoric is surprisingly anti-militarist, the violence that occurs at …