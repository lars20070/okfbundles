---
type: Section
title: "The Birth of British Fascism"
description: "Episode 372: The cultural roots of fascism swirled around Britain at the turn of the 20th century."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "fascism", "britain"]
---

# The Birth of British Fascism

2023-09-24 · 54:20 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4747738645.mp3?updated=1695596282)

The cultural roots of fascism swirled around Britain at the turn of the 20th century, as medieval nostalgia, an obsession with hygiene, anti-semitism, and concern for the environment grew in the wake of modern development. In the 1920s, Britain faced similarly tough conditions to the European countries where fascism did take hold; major economic difficulties, unpopular governments, and intense …