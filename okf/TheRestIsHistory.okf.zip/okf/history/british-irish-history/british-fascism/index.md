# The Birth of British Fascism

## Episodes

* [The Birth of British Fascism](/history/british-irish-history/british-fascism/01-the-birth-of-british-fascism.md) — Episode 372: The cultural roots of fascism swirled around Britain at the turn of the 20th century.
* [Oswald Mosley: Fascist Leader](/history/british-irish-history/british-fascism/02-oswald-mosley-fascist-leader.md) — Episode 373: The fascists in Britain have found a leader: the sinister yet complex Oswald Mosley.
* [The Battle of Cable Street: Fascism Defeated](/history/british-irish-history/british-fascism/03-the-battle-of-cable-street.md) — Episode 374: The British fascist movement is in decline after the violent scenes at Kensington Olympia.
* [Hitler and the Mitford Sisters](/history/british-irish-history/british-fascism/04-hitler-and-the-mitford-sisters.md) — Episode 375: Diana Mitford married Oswald Mosley, while her sister Unity had a relationship with Hitler.
