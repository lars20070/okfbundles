---
type: Section
title: "The Battle of Cable Street: Fascism Defeated"
description: "Episode 374: The British fascist movement is in decline after the violent scenes at Kensington Olympia."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "fascism", "britain", "battle-of-cable-street"]
---

# The Battle of Cable Street: Fascism Defeated

2023-10-01 · 45:03 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3021730207.mp3?updated=1695832036)

"You will never catch Sir Oswald admitting to anti-semitism - all he does is embody it!" Following the violent scenes at Kensington Olympia, the British fascist movement is in decline. Britain is swirling with unemployment, having just come out of a decade of general strikes, and as the country suffers, changes and becomes more urbanised, the fascists seek a scapegoat to pin Britain's downfall …