# State of Emergency (Part 1)

## Episodes

* [State of Emergency (Part 1)](/history/british-irish-history/britain-1974/01-state-of-emergency.md) — Episode 417: Britain in the early 1970s as a state in crisis.
* [The Crisis Election (Part 2)](/history/british-irish-history/britain-1974/02-the-crisis-election.md) — Episode 418: Edward Heath calls an election three days after the IRA attacks.
* [Countdown to a Coup (Part 3)](/history/british-irish-history/britain-1974/03-countdown-to-a-coup.md) — Episode 419: Harold Wilson re-elected but inheriting a nation in crisis.
* [Thatcher Enters the Ring (Part 4)](/history/british-irish-history/britain-1974/04-thatcher-enters-the-ring.md) — Episode 420: The Guildford Pub Bombings and the election campaign of 1974.
