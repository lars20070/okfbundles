---
type: Section
title: "State of Emergency (Part 1)"
description: "Episode 417: Britain in the early 1970s as a state in crisis."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "britain", "1970s", "harold-wilson"]
---

# State of Emergency (Part 1)

2024-02-12 · 57:47 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6761791949.mp3?updated=1707753485)

"Who governs Britain?" Britain in the early 1970's was a state in crisis, and by 1974, things had never seemed bleaker. Held hostage by the Trade Unions, British industry was flailing. England's sporting record was atrocious, the economy was tanking and the prospect of a miners' strike loomed large. Violence was surging in Northern Ireland, as the IRA escalated its bombing campaigns, and the …