---
type: Section
title: "The Crisis Election (Part 2)"
description: "Episode 418: Edward Heath calls an election three days after the IRA attacks."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "britain", "1970s", "harold-wilson"]
---

# The Crisis Election (Part 2)

2024-02-13 · 48:57 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9690615062.mp3?updated=1707747695)

Three days after one of the most devastating IRA attacks launched upon British soil, the Conservative Prime Minister Edward Heath called an election, in circumstances that had never been more dire. Running against him was the veteran Labour leader, Harold Wilson, now as tired and beleaguered as his rival, and whose party was increasingly divided by internal conflict. Jeremy Thorpe, the charming …