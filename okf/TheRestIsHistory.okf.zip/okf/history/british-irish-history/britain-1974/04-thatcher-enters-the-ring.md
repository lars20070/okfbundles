---
type: Section
title: "Thatcher Enters the Ring (Part 4)"
description: "Episode 420: The Guildford Pub Bombings and the election campaign of 1974."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "britain", "1970s", "harold-wilson"]
---

# Thatcher Enters the Ring (Part 4)

2024-02-16 · 49:11 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2799978515.mp3?updated=1708044521)

The horrific Guildford Pub Bombings of Saturday 5th October 1974 sent shockwaves through Britain, worsening the sense of crisis sweeping through the nation. It cast a dark shadow over the election campaign due to take place five days later. The future had rarely seemed grimmer, with a general sense of moral and economic panic, weariness and depression. For the fourth time, Labour's Harold Wilson …