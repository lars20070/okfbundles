---
type: Section
title: "Countdown to a Coup (Part 3)"
description: "Episode 419: Harold Wilson re-elected but inheriting a nation in crisis."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "britain", "1970s", "harold-wilson"]
---

# Countdown to a Coup (Part 3)

2024-02-15 · 1:03:15 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2033018212.mp3?updated=1707747735)

Following a tumultuous election in February 1974, Labour's Harold Wilson has been re-elected Prime Minister of the United Kingdom. Wilson, an unpretentious, kind man, has inherited a nation in crisis: train strikes in Norfolk, students fighting in Oxford, inflation, an ongoing oil crisis, a terrible cost of living crisis, striking miners, and weekly IRA terrorist attacks. He's further hindered by …