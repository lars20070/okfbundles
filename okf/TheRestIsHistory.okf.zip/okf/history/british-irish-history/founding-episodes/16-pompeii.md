---
type: Section
title: "Episode 16: Pompeii"
description: "Why does Pompeii continue to hold such a fascination for so many people?"
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "pompeii", "rome"]
---

# Pompeii

2021-01-21 · 51:29 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3349011345.mp3?updated=1777395023)

Pompeii Why does Pompeii continue to hold such a fascination for so many people? And which secrets are still to be uncovered from beneath the ashes? Dr Sophie Hay, a leading expert on the ruined Italian city, joins Tom Holland and Dominic Sandbrook to answer lots of listener questions.