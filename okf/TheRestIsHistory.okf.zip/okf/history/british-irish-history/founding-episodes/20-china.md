---
type: Section
title: "Episode 20: China"
description: "Broadcaster and historian Michael Wood joins Tom Holland and Dominic Sandbrook to discuss the world's oldest civilisation."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "china"]
---

# China

2021-02-04 · 58:52 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4329327216.mp3?updated=1777395005)

Broadcaster and historian Michael Wood joins Tom Holland and Dominic Sandbrook to discuss the world's oldest civilisation. What were the great moments in Chinese history and why do the Opium Wars still feature so prominently in the modern Chinese school syllabus? The birth of the Chinese Communist Party and the complicated legacy of Chairman Mao all feature.