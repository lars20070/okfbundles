---
type: Section
title: "Episode 3: Is Trump Caesar or Nixon?"
description: "Recorded hours after Joe Biden was named President of the United States."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "trump", "nixon", "caesar"]
---

# Is Trump Caesar or Nixon?

2020-11-09 · 38:49 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4982990068.mp3?updated=1777394973)

Recorded hours after Joe Biden was named President of the United States, we ask if Donald Trump is a modern day Caesar, willing to do anything to stay in power? Or is Trump the natural successor to the disgraced Richard Nixon? Tom Holland and Dominic Sandbrook draw parallels between the modern White House, the 1970s and ancient Rome.