---
type: Section
title: "Episode 17: Fascism"
description: "What is fascism and where did it come from?"
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "fascism"]
---

# Fascism

2021-01-25 · 49:28 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5738760220.mp3?updated=1777394968)

What is fascism and where did it come from? No one admits to being a fascist yet it continues to be a term of abuse hurled on a regular basis. Tom Holland and Dominic Sandbrook discuss the history of this most unacceptable of political models.