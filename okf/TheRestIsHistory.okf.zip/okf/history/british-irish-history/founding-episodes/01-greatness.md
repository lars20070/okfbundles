---
type: Section
title: "Episode 1: Greatness"
description: "How did certain people come to be called 'the Great'?"
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "greatness"]
---

# Greatness

2020-11-02 · 32:55 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2583338621.mp3?updated=1777062859)

How did certain people come to be called 'the Great'? Is the notion of great men and women outmoded? Can anyone today be reckoned 'great'? Historians Tom Holland and Dominic Sandbrook take a wide ranging stroll through the annals of time, from Nero to Nixon, with a bit of Trump thrown in for good measure.