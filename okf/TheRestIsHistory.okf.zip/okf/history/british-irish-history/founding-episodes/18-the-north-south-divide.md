---
type: Section
title: "Episode 18: The North South Divide"
description: "England has long been divided by an invisible line somewhere north of Watford and south of the Mersey."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "north-south-divide", "england"]
---

# The North South Divide

2021-01-28 · 55:07 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3709184192.mp3?updated=1777394862)

England has long been divided by an invisible line somewhere north of Watford and south of the Mersey. But do northerners really have more in common with Scots and Welsh people than their fellow Englishmen in London? Dan Jackson, author of The Northumbrians and a former advisor to Cheryl Cole, joins southerner Tom Holland and midlander Dominic Sandbrook to try and decide if we should eat lunch …