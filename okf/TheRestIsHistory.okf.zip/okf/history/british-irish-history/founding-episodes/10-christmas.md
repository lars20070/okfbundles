---
type: Section
title: "Episode 10: Christmas"
description: "Is Christmas an ancient ritual or was it invented by Dickens?"
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "christmas"]
---

# Christmas

2020-12-21 · 39:31 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9855064623.mp3?updated=1777394940)

Is Christmas an ancient ritual or was it invented by Dickens? Dominic Sandbrook and Tom Holland discuss the transformation of Christmas from public to private event and decide when it became a commercial rather than spiritual celebration.