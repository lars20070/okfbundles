---
type: Section
title: "Episode 8: The Echo of a Coffee House"
description: "Social media has colonised the world but is it really a new phenomenon?"
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "social-media", "coffee-houses"]
---

# The Echo of a Coffee House

2020-12-07 · 44:24 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8695060101.mp3?updated=1777394957)

Social media has colonised the world but is it really a new phenomenon? Tom Holland and Dominic Sandbrook debate the effects of technical innovations from the printing press to Twitter. Do they really make a difference? Or was Swift right when he said: "It is the folly of too many, to mistake the echo of a London coffee-house for the voice of the kingdom."