---
type: Section
title: "Episode 12: Conspiracy Theories"
description: "History is littered with conspiracy theories, from Popish plots to JFK's assassination."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "conspiracy-theories"]
---

# Conspiracy Theories

2021-01-04 · 47:49 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7580472793.mp3?updated=1777394982)

History is littered with conspiracy theories, from Popish plots to JFK's assassination. But what makes people believe in them and how do they gain currency? As strange stories continue to swirl around the coronavirus vaccine, Tom Holland and Dominic Sandbrook examine conspiracy theories through the ages. Oh and Dominic finally solves the question of who did kill JFK.