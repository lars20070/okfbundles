---
type: Section
title: "Episode 15: Walls and Borders"
description: "From the Great Wall of China to the Berlin Wall, history is littered with the building of barriers."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "walls", "borders"]
---

# Walls and Borders

2021-01-18 · 46:00 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1636005045.mp3?updated=1777395052)

From the Great Wall of China to the Berlin Wall, history is littered with the building of barriers aimed at keeping people out, and sometimes in. Do they work? Are they ever a good thing? Tom Holland and Dominic Sandbrook climb walls and explore borders as they investigate the history of separation.