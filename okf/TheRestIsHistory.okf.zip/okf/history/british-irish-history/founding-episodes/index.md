# Greatness

## Episodes

* [Greatness](/history/british-irish-history/founding-episodes/01-greatness.md) — How did certain people come to be called 'the Great'?
* [Civil War](/history/british-irish-history/founding-episodes/02-civil-war.md) — What are the conditions needed for a civil war to start?
* [Is Trump Caesar or Nixon?](/history/british-irish-history/founding-episodes/03-is-trump-caesar-or-nixon.md) — Recorded hours after Joe Biden was named President of the United States.
* [We're all so 17th Century](/history/british-irish-history/founding-episodes/04-were-all-so-17th-century.md) — Has 2020 turned out to be the 17th Century in disguise?
* [1981](/history/british-irish-history/founding-episodes/05-1981.md) — As a new series of The Crown arrives on Netflix, returning viewers to the 1980s.
* [Troy](/history/british-irish-history/founding-episodes/06-troy.md) — It's been described as the most legendary story ever told. But did the Trojan War actually happen?
* [The Lessons of History](/history/british-irish-history/founding-episodes/07-the-lessons-of-history.md) — Can we truly learn from history? And if we can - do we?
* [The Echo of a Coffee House](/history/british-irish-history/founding-episodes/08-the-echo-of-a-coffee-house.md) — Social media has colonised the world but is it really a new phenomenon?
* [Causes of the First World War](/history/british-irish-history/founding-episodes/09-causes-of-the-first-world-war.md) — Whose fault was it? Does the question even make sense?
* [Christmas](/history/british-irish-history/founding-episodes/10-christmas.md) — Is Christmas an ancient ritual or was it invented by Dickens?
* [Brexit](/history/british-irish-history/founding-episodes/11-brexit.md) — As Britain leaves the EU, Tom Holland and Dominic Sandbrook look at the best & worst comparisons from history.
* [Conspiracy Theories](/history/british-irish-history/founding-episodes/12-conspiracy-theories.md) — History is littered with conspiracy theories, from Popish plots to JFK's assassination.
* [Stephen Fry and Troy](/history/british-irish-history/founding-episodes/13-stephen-fry-and-troy.md) — Stephen Fry is our guest on The Rest is History.
* [Historical Fiction](/history/british-irish-history/founding-episodes/14-historical-fiction.md) — Is the author's responsibility to the quality of the novel or the truth of history?
* [Walls and Borders](/history/british-irish-history/founding-episodes/15-walls-and-borders.md) — From the Great Wall of China to the Berlin Wall, history is littered with the building of barriers.
* [Pompeii](/history/british-irish-history/founding-episodes/16-pompeii.md) — Why does Pompeii continue to hold such a fascination for so many people?
* [Fascism](/history/british-irish-history/founding-episodes/17-fascism.md) — What is fascism and where did it come from?
* [The North South Divide](/history/british-irish-history/founding-episodes/18-the-north-south-divide.md) — England has long been divided by an invisible line somewhere north of Watford and south of the Mersey.
* [King Arthur](/history/british-irish-history/founding-episodes/19-king-arthur.md) — It remains the most romantic historical story of all time, but is the legend of King Arthur a myth?
* [China](/history/british-irish-history/founding-episodes/20-china.md) — Broadcaster and historian Michael Wood joins Tom Holland and Dominic Sandbrook to discuss the world's oldest civilisation.
