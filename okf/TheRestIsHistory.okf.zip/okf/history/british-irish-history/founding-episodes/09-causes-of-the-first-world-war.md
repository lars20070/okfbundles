---
type: Section
title: "Episode 9: Causes of the First World War"
description: "Whose fault was it? Does the question even make sense?"
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "first-world-war", "causes"]
---

# Causes of the First World War

2020-12-14 · 46:07 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8234482474.mp3?updated=1777395079)

Whose fault was it? Does the question even make sense? Are wars always somebody's "fault"? Was it really the first global war? And should Britain have fought, or stayed out?