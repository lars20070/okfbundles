---
type: Section
title: "Episode 19: King Arthur"
description: "It remains the most romantic historical story of all time, but is the legend of King Arthur a myth?"
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "king-arthur", "medieval"]
---

# King Arthur

2021-02-01 · 51:31 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1076701162.mp3?updated=1777394962)

It remains the most romantic historical story of all time, but is the legend of King Arthur a myth? Was he even English? And will he rise again when the country needs him most? Tom Holland and Dominic Sandbrook take their places at the round table.