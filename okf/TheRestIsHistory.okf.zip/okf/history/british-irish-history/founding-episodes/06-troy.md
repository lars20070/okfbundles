---
type: Section
title: "Episode 6: Troy"
description: "It's been described as the most legendary story ever told. But did the Trojan War actually happen?"
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "troy", "greek-myths"]
---

# Troy

2020-11-23 · 38:42 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4742295987.mp3?updated=1777395028)

It's been described as the most legendary story ever told. But did the Trojan War actually happen? And was it really fought over a beautiful woman? Tom Holland and Dominic Sandbrook discuss an enduring tale that still resonates to this day.