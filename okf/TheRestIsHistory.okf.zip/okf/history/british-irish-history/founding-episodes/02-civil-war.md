---
type: Section
title: "Episode 2: Civil War"
description: "What are the conditions needed for a civil war to start?"
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "civil-war"]
---

# Civil War

2020-11-02 · 39:21 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5809911007.mp3?updated=1777394993)

What are the conditions needed for a civil war to start? Could we see a modern industrial nation turn upon itself again? Historians Tom Holland and Dominic Sandbrook explore examples from ancient history though to Spain in the 1930s and Yugoslavia in the 1990s to work out what it takes for neighbour to murder neighbour.