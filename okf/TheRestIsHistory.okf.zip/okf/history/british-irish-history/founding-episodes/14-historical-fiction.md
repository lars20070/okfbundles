---
type: Section
title: "Episode 14: Historical Fiction"
description: "Is the author's responsibility to the quality of the novel or the truth of history?"
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "historical-fiction"]
---

# Historical Fiction

2021-01-11 · 59:29 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2461510190.mp3?updated=1777395054)

Is the author's responsibility to the quality of the novel or the truth of history? What makes a great historical novel and which authors have contributed to our understanding of history. Tom Holland and Dominic Sandbrook range across literature in search of the best of historical fiction.