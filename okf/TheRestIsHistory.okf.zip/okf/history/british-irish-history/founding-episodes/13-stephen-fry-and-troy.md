---
type: Section
title: "Episode 13: Stephen Fry and Troy"
description: "Stephen Fry is our guest on The Rest is History."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "stephen-fry", "troy", "greek-myths"]
---

# Stephen Fry and Troy

2021-01-07 · 1:03:15 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5875934078.mp3?updated=1777395057)

Stephen Fry is our guest on The Rest is History as he tells Tom Holland and Dominic Sandbrook about his enduring fascination with the Greek myths.