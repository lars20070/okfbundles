---
type: Section
title: "Episode 7: The Lessons of History"
description: "Can we truly learn from history? And if we can - do we?"
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "lessons"]
---

# The Lessons of History

2020-11-30 · 48:13 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2771707131.mp3?updated=1777395007)

Can we truly learn from history? And if we can - do we? It's one of the big questions this week as Tom Holland and Dominic Sandbrook roam through the centuries in search of certainty. Never get involved in a land war in Asia. That's our starter for ten.