---
type: Section
title: "Episode 4: We're all so 17th Century"
description: "Has 2020 turned out to be the 17th Century in disguise?"
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "17th-century"]
---

# We're all so 17th Century

2020-11-09 · 36:58 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1251829896.mp3?updated=1777394932)

Plague, pestilence and statue smashing are back in business. Has 2020 turned out to be the 17th Century in disguise? And if so, has Boris Johnson become the new Oliver Cromwell, determined to crack down on the excesses of Christmas? Dominic Sandbrook and Tom Holland suggest things now are not as bad as we thought.