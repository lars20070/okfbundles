---
type: Section
title: "Episode 11: Brexit"
description: "As Britain leaves the EU, Tom Holland and Dominic Sandbrook look at the best & worst comparisons from history."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "brexit", "european-union"]
---

# Brexit

2020-12-28 · 44:58 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9171248177.mp3?updated=1777395016)

As Britain leaves the EU, Tom Holland and Dominic Sandbrook look at the best & worst comparisons from history that have been made to Brexit.