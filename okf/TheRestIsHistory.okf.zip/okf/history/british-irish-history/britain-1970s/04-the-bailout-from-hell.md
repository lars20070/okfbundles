---
type: Section
title: "The Bailout from Hell (Part 4)"
description: "Episode 665: Jim Callaghan's plan to keep Britain from bankruptcy."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, britain, 1970s]
---

# The Bailout from Hell (Part 4)

2026-04-29 · 1:15:11 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9598017819.mp3?updated=1777473193)

How did the new British Prime Minister, Jim Callaghan, intend to keep Britain from bankruptcy in 1976? What extreme new step might have seen riots in the streets? And, would labour survive the greatest financial scandal in British history? Join Tom and Dominic as they reach the epic conclusion of their dramatic series on the most uproarious years of the 1970s in Britain, including the high point …
