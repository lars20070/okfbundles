---
type: Section
title: "The Brexit That Never Was (Part 2)"
description: "Episode 663: Harold Wilson embattled and Britain's fracturing relationship with Europe."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, britain, 1970s]
---

# The Brexit That Never Was (Part 2)

2026-04-22 · 1:17:18 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2237203377.mp3?updated=1776869331)

In the Spring of 1975, why was the Prime Minister, Harold Wilson, so embattled? Why was the left so divided during this period? And, was Britain's relationship with Europe already fracturing…? Join Tom and Dominic, as they discuss the trials of Harold Wilson, as the melee of 1970s Britain rolled on.
