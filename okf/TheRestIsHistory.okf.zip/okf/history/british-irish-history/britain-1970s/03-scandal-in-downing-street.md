---
type: Section
title: "Scandal in Downing Street (Part 3)"
description: "Episode 664: Financial meltdown, bombs, and unprecedented inflation in 1975."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, britain, 1970s]
---

# Scandal in Downing Street (Part 3)

2026-04-26 · 1:14:08 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9115516865.mp3?updated=1777029534)

With Britain heading towards financial meltdown and paranoia in the air, could its exhausted Prime Minister, Harold Wilson survive? Why were bombs going off in London every few days in the winter of 1975? And, with inflation reaching unprecedented heights, would the government finally act? Join Tom and Dominic as they discuss one of the greatest crisis points in modern British history.
