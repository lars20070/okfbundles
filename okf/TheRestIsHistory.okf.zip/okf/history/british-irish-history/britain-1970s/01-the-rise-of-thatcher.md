---
type: Section
title: "The Rise of Thatcher (Part 1)"
description: "Episode 662: Margaret Thatcher's rise to power in 1970s Britain."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, britain, 1970s, Thatcher]
---

# The Rise of Thatcher (Part 1)

2026-04-19 · 1:15:36 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1785737730.mp3?updated=1777544262)

How did Margaret Thatcher rise to become leader of the Conservative Party in Britain? Why were British politics so tumultuous in the 1970s? And, who was Thatcher up against? Join Dominic and Tom as they launch into the dramas, calamities, and triumphs of Thatcher's rise to power, in 1970s Britain.
