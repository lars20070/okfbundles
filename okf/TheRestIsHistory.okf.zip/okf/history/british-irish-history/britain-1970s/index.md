# The Rise of Thatcher (Part 1)

## Episodes

* [The Rise of Thatcher (Part 1)](/history/british-irish-history/britain-1970s/01-the-rise-of-thatcher.md) — Episode 662: Margaret Thatcher's rise to power in 1970s Britain.
* [The Brexit That Never Was (Part 2)](/history/british-irish-history/britain-1970s/02-the-brexit-that-never-was.md) — Episode 663: Harold Wilson embattled and Britain's fracturing relationship with Europe.
* [Scandal in Downing Street (Part 3)](/history/british-irish-history/britain-1970s/03-scandal-in-downing-street.md) — Episode 664: Financial meltdown, bombs, and unprecedented inflation in 1975.
* [The Bailout from Hell (Part 4)](/history/british-irish-history/britain-1970s/04-the-bailout-from-hell.md) — Episode 665: Jim Callaghan's plan to keep Britain from bankruptcy.
