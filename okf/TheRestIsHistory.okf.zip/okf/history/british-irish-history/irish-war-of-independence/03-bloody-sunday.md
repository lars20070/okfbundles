---
type: Section
title: "Bloody Sunday (Part 3)"
description: "Episode 578: The bloodiest and most brutal moments in Irish history."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, ireland, irish-war-of-independence]
---

# Bloody Sunday (Part 3)

2025-06-29 · 57:46 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8552699883.mp3?updated=1751035728)

What occurred on Bloody Sunday on 21 November 1920 - a turning point in the Irish War of Independence and one of the bloodiest and most brutal moments in Irish history? How many British Army Officers were assassinated on the instructions of firebrand political leader, Michael Collins, that morning? Then, how many civilians did the British army gun down during a Gaelic football match at Croke Park …
