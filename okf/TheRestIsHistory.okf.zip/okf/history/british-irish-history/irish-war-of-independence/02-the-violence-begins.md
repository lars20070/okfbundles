---
type: Section
title: "The Violence Begins (Part 2)"
description: "Episode 577: Sinn Féin's first move and the IRA's methods."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, ireland, irish-war-of-independence]
---

# The Violence Begins (Part 2)

2025-06-25 · 1:03:37 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3492584348.mp3?updated=1750870334)

What was Sinn Féin's totemic first move after winning a majority seat in 1917? Were the IRA's methods during this early stages of the war as violent as they are commonly believed to have been? How sectarian was the IRA? What crucial strategy did the Irish adopt in order to overwhelm English efforts to re-establish control in Ireland? As a victor of the First World War, was Ireland's struggle for …
