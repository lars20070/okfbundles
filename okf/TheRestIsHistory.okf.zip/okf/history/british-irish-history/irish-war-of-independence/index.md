# Rise of the IRA (Part 1)

## Episodes

* [Rise of the IRA (Part 1)](/history/british-irish-history/irish-war-of-independence/01-rise-of-the-ira.md) — Episode 576: The Easter Rising of 1916 and Éamon de Valera.
* [The Violence Begins (Part 2)](/history/british-irish-history/irish-war-of-independence/02-the-violence-begins.md) — Episode 577: Sinn Féin's first move and the IRA's methods.
* [Bloody Sunday (Part 3)](/history/british-irish-history/irish-war-of-independence/03-bloody-sunday.md) — Episode 578: The bloodiest and most brutal moments in Irish history.
* [Showdown in London (Part 4)](/history/british-irish-history/irish-war-of-independence/04-showdown-in-london.md) — Episode 579: The Anglo-Irish Treaty and the seeds of civil war.
* [The Killing of Michael Collins (Part 2)](/history/british-irish-history/irish-war-of-independence/05-the-killing-of-michael-collins.md) — Episode 581: The Battle of the Four Courts and Michael Collins' assassination.
* [The Assassination of Sir Henry Wilson (Part 1)](/history/british-irish-history/irish-war-of-independence/06-the-assassination-of-sir-henry-wilson.md) — Episode 580: The shocking murder of Sir Henry Wilson in 1922.
