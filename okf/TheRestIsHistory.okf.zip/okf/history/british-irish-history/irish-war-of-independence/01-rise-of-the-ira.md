---
type: Section
title: "Rise of the IRA (Part 1)"
description: "Episode 576: The Easter Rising of 1916 and Éamon de Valera."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, ireland, irish-war-of-independence]
---

# Rise of the IRA (Part 1)

2025-06-22 · 1:09:58 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9072105702.mp3?updated=1750631815)

What are the origins of the Irish War of Independence? What impact did the First World War have on Irish efforts for Home Rule? What was the mood in Ireland following the bloody Easter Rising of 1916? And, who was Éamon de Valera, the man who dominated the story of not only Irish politics in the 20th century, but also the entire story of Irish independence? As they launch back into the epic and …
