---
type: Section
title: "Showdown in London (Part 4)"
description: "Episode 579: The Anglo-Irish Treaty and the seeds of civil war."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, ireland, irish-war-of-independence]
---

# Showdown in London (Part 4)

2025-07-02 · 1:06:07 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9064307865.mp3?updated=1751464705)

What were the terms of the Anglo-Irish Treaty, signed in December 1921, following negotiations between the UK and Sinn Féin? How was it received by the Irish people? What was the process by which it was agreed between Lloyd George, Winston Churchill, Michael Collins, and Arthur Griffith? Why did Éamon de Valera object to the treaty, and how did this sow the seeds of civil war? Had the Irish …
