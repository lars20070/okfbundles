---
type: Section
title: "The Assassination of Sir Henry Wilson (Part 1)"
description: "Episode 580: The shocking murder of Sir Henry Wilson in 1922."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, ireland, irish-war-of-independence]
---

# The Assassination of Sir Henry Wilson (Part 1)

2025-07-06 · 47:32 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8285525213.mp3?updated=1751982238)

Who was Sir Henry Wilson, and how was he shockingly murdered in 1922? Who ordered it? What was his attitude to the question of Irish Home Rule? Why has death been compared to the assassination of Archduke Franz Ferdinand, whose death triggered the First World War? How did he garner the undying enmity of British Prime Minister, Herbert Henry Asquith? What was Wilson's reputation in Ireland then …
