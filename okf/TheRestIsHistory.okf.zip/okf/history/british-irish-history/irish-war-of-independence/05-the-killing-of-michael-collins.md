---
type: Section
title: "The Killing of Michael Collins (Part 2)"
description: "Episode 581: The Battle of the Four Courts and Michael Collins' assassination."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, ireland, civil-war]
---

# The Killing of Michael Collins (Part 2)

2025-07-09 · 45:22 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3233824863.mp3?updated=1752078918)

After the assassination of Sir Henry Wilson and the signing of the polarising Anglo-Irish Treaty, how did the bombastic Battle of the Four Courts break out in Dublin? With British guns opening fire on the building, how long did the men of the IRA hold out? What was the outcome of the battle? With the IRA split, were more people for or against the Anglo-Irish treaty? Was Michael Collins trying to …
