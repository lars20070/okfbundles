---
type: Section
title: "Harold Holt - Malcolm Fraser (Part 2)"
description: "Episode 188: In the second part of our Australian PMs trilogy, Tom and Dominic explore Chinese Communist conspiracy theories."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "australia", "prime-ministers"]
---

# Harold Holt - Malcolm Fraser (Part 2)

2022-05-24 · 45:40 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4635125602.mp3?updated=1777394832)

In the second part of our Australian PMs trilogy, Tom and Dominic explore Chinese Communist conspiracy theories and talk about the most entertaining of all the Aussie leaders. The final instalment of this mini-series will be in your podcast feed on Thursday. To get the last episode right now, join The Rest Is History Club, where you'll also get ad-free listening to the full archive, weekly bonus …