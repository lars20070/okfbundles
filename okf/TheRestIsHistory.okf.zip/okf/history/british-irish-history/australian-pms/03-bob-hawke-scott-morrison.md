---
type: Section
title: "Bob Hawke - Scott Morrison (Part 3)"
description: "Episode 189: Join Tom and Dominic for the final episode of their Australian epic."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "australia", "prime-ministers"]
---

# Bob Hawke - Scott Morrison (Part 3)

2022-05-26 · 46:23 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2222829202.mp3?updated=1777394946)

Join Tom and Dominic for the final episode of their Australian epic. Tune in to hear about the exploits of the most recent stretch of prime ministers, spanning from Bob Hawke to Scott Morrison. Join The Rest Is History Club for ad-free listening to the full archive, weekly bonus episodes, live streamed shows and access to an exclusive chatroom community.