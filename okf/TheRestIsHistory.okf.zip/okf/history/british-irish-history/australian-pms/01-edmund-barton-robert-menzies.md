---
type: Section
title: "Edmund Barton - Robert Menzies (Part 1)"
description: "Episode 187: In the wake of Anthony Albanese's victory in this weekend's Australian election."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "australia", "prime-ministers"]
---

# Edmund Barton - Robert Menzies (Part 1)

2022-05-23 · 53:42 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3017584065.mp3?updated=1777394824)

In the wake of Anthony Albanese's victory in this weekend's Australian election, Tom and Dominic have recorded a three part Antipodean special on the history of Australian prime ministers. The first episode begins in 1901 with Edmund Barton, covers both World Wars, and drills down into the premierships of Robert Menzies. The second part will be in your podcast feeds tomorrow, with the final …