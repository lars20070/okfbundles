# Edmund Barton - Robert Menzies (Part 1)

## Episodes

* [Edmund Barton - Robert Menzies (Part 1)](/history/british-irish-history/australian-pms/01-edmund-barton-robert-menzies.md) — Episode 187: In the wake of Anthony Albanese's victory in this weekend's Australian election.
* [Harold Holt - Malcolm Fraser (Part 2)](/history/british-irish-history/australian-pms/02-harold-holt-malcolm-fraser.md) — Episode 188: In the second part of our Australian PMs trilogy, Tom and Dominic explore Chinese Communist conspiracy theories.
* [Bob Hawke - Scott Morrison (Part 3)](/history/british-irish-history/australian-pms/03-bob-hawke-scott-morrison.md) — Episode 189: Join Tom and Dominic for the final episode of their Australian epic.
