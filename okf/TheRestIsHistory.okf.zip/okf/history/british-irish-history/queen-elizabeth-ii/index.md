# Queen Elizabeth II (Part 1)

## Episodes

* [Queen Elizabeth II (Part 1)](/history/british-irish-history/queen-elizabeth-ii/01-queen-elizabeth-ii-part-1.md) — Episode 231: The death of the Queen at the age of 96 brings to an end seven decades of her reign.
* [Queen Elizabeth II (Part 2)](/history/british-irish-history/queen-elizabeth-ii/02-queen-elizabeth-ii-part-2.md) — Episode 232: In February 1952, on the death of her father King George VI, the 25-year-old Elizabeth became Queen.
