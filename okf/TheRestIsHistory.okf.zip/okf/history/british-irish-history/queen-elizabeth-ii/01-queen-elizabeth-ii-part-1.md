---
type: Section
title: "Queen Elizabeth II (Part 1)"
description: "Episode 231: The death of the Queen at the age of 96 brings to an end seven decades of her reign."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "queen-elizabeth-ii"]
---

# Queen Elizabeth II (Part 1)

2022-09-09 · 47:29 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2826379729.mp3?updated=1775851953)

The death of the Queen at the age of 96 brings to an end seven decades of her reign over Britain and the Commonwealth. In the first of a two-part series, Dominic Sandbrook and Tom Holland look back at the early years of Elizabeth's life, leading up to her coronation.
