---
type: Section
title: "Queen Elizabeth II (Part 2)"
description: "Episode 232: In February 1952, on the death of her father King George VI, the 25-year-old Elizabeth became Queen."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "queen-elizabeth-ii"]
---

# Queen Elizabeth II (Part 2)

2022-09-09 · 47:53 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5667149245.mp3?updated=1775852029)

In February 1952, on the death of her father King George VI, the 25-year-old Elizabeth became Queen. During her long reign she was served by 15 Prime Ministers and met an extraordinary array of people. Dominic Sandbrook and Tom Holland here examine her 70 years as Queen of the United Kingdom & 14 other countries, and head of the Commonwealth.
