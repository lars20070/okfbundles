# The Ultimate Victorian Hero

## Episodes

* [The Ultimate Victorian Hero](/history/british-irish-history/general-gordon/01-the-ultimate-victorian-hero.md) — Episode 141: Who was General Gordon? Tune in to hear about the life and times of the 'emblematic martyr of the Victorian age'.
* [General Gordon and the Siege of Khartoum](/history/british-irish-history/general-gordon/02-general-gordon-and-the-siege-of-khartoum.md) — Episode 142: What happened to Gordon at Khartoum? Described by Dominic as the 'greatest media event of the Victorian era'.
