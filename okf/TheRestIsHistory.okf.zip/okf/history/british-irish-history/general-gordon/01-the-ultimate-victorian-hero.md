---
type: Section
title: "The Ultimate Victorian Hero"
description: "Episode 141: Who was General Gordon? Tune in to hear about the life and times of the 'emblematic martyr of the Victorian age'."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "general-gordon", "victorian"]
---

# The Ultimate Victorian Hero

2022-01-24 · 41:47 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2700696137.mp3?updated=1775852119)

Who was General Gordon? Tune in to hear about the life and times of the 'emblematic martyr of the Victorian age'.