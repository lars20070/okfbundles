---
type: Section
title: "General Gordon and the Siege of Khartoum"
description: "Episode 142: What happened to Gordon at Khartoum? Described by Dominic as the 'greatest media event of the Victorian era'."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "general-gordon", "victorian"]
---

# General Gordon and the Siege of Khartoum

2022-01-25 · 58:21 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6227664313.mp3?updated=1775852109)

What happened to Gordon at Khartoum? Described by Dominic as the 'greatest media event of the Victorian era', this second parter is not to be missed.