# British Irish History

## Series

* [Australian Prime Ministers](/history/british-irish-history/australian-pms/) — 3 episodes
* [Britain in the 1970s](/history/british-irish-history/britain-1970s/) — 4 episodes
* [Britain in 1974](/history/british-irish-history/britain-1974/) — 4 episodes
* [British Fascism](/history/british-irish-history/british-fascism/) — 4 episodes
* [Founding Episodes](/history/british-irish-history/founding-episodes/) — 20 episodes
* [General Gordon](/history/british-irish-history/general-gordon/) — 2 episodes
* [Ireland Series](/history/british-irish-history/ireland-series/) — 4 episodes
* [Irish War of Independence](/history/british-irish-history/irish-war-of-independence/) — 6 episodes
* [Jack the Ripper](/history/british-irish-history/jack-the-ripper/) — 5 episodes
* [Queen Elizabeth II](/history/british-irish-history/queen-elizabeth-ii/) — 2 episodes
* [Young Churchill](/history/british-irish-history/young-churchill/) — 3 episodes
