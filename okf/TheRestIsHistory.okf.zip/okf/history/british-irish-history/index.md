# British Irish History

## Series

* [Edmund Barton - Robert Menzies (Part 1)](/history/british-irish-history/australian-pms/) — Series about Edmund Barton - Robert Menzies (Part 1)
* [The Rise of Thatcher (Part 1)](/history/british-irish-history/britain-1970s/) — Series about The Rise of Thatcher (Part 1)
* [State of Emergency (Part 1)](/history/british-irish-history/britain-1974/) — Series about State of Emergency (Part 1)
* [The Birth of British Fascism](/history/british-irish-history/british-fascism/) — Series about The Birth of British Fascism
* [Greatness](/history/british-irish-history/founding-episodes/) — Series about Greatness
* [The Ultimate Victorian Hero](/history/british-irish-history/general-gordon/) — Series about The Ultimate Victorian Hero
* [Celts, Conquest and Cromwell (Part 1)](/history/british-irish-history/ireland-series/) — Series about Celts, Conquest and Cromwell (Part 1)
* [Rise of the IRA (Part 1)](/history/british-irish-history/irish-war-of-independence/) — Series about Rise of the IRA (Part 1)
* [History's Darkest Mystery (Part 1)](/history/british-irish-history/jack-the-ripper/) — Series about History's Darkest Mystery (Part 1)
* [Queen Elizabeth II (Part 1)](/history/british-irish-history/queen-elizabeth-ii/) — Series about Queen Elizabeth II (Part 1)
* [Young Churchill: Born to Lead (Part 1)](/history/british-irish-history/young-churchill/) — Series about Young Churchill: Born to Lead (Part 1)
