---
type: Section
title: "Trafalgar: Victory (Part 3)"
description: "Episode 245: In this final episode Tom and Dominic discuss the legendary Battle of Trafalgar."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "trafalgar", "naval-warfare"]
---

# Trafalgar: Victory (Part 3)

2022-10-21 · 58:11 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4217731619.mp3?updated=1729784451)

In this final episode Tom and Dominic discuss the legendary Battle of Trafalgar. Despite being outnumbered and facing the biggest ship in the world, Nelson took the battle to the French and Spanish forces.
