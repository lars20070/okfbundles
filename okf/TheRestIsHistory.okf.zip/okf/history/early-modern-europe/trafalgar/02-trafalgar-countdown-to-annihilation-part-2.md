---
type: Section
title: "Trafalgar: Countdown to Annihilation (Part 2)"
description: "Episode 244: In the second episode of Tom and Dominic's Trafalgar trilogy, the stakes could not be higher."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "trafalgar", "naval-warfare"]
---

# Trafalgar: Countdown to Annihilation (Part 2)

2022-10-20 · 54:37 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5489746159.mp3?updated=1729784420)

In the second episode of Tom and Dominic's Trafalgar trilogy, the stakes could not be higher. They discuss: Napoleon's plan to invade Britain (and the possible repercussions if he did); what developments in naval technology meant for the British and Spanish/French allies; and Nelson's own life, legacy, and strategy to "annihilate the enemy".
