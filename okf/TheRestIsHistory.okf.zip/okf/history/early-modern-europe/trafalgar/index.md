# Trafalgar: A World at War (Part 1)

## Episodes

* [Trafalgar: A World at War (Part 1)](/history/early-modern-europe/trafalgar/01-a-world-at-war.md) — Episode 243: Was the Battle of Trafalgar the most decisive battle of the 19th century?
* [Trafalgar: Countdown to Annihilation (Part 2)](/history/early-modern-europe/trafalgar/02-trafalgar-countdown-to-annihilation-part-2.md) — Episode 244: In the second episode of Tom and Dominic's Trafalgar trilogy, the stakes could not be higher.
* [Trafalgar: Victory (Part 3)](/history/early-modern-europe/trafalgar/03-trafalgar-victory-part-3.md) — Episode 245: In this final episode Tom and Dominic discuss the legendary Battle of Trafalgar.
