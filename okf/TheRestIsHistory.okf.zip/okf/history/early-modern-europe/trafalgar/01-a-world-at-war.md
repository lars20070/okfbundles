---
type: Section
title: "Trafalgar: A World at War (Part 1)"
description: "Episode 243: Was the Battle of Trafalgar the most decisive battle of the 19th century?"
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "trafalgar", "naval-warfare"]
---

# Trafalgar: A World at War (Part 1)

2022-10-17 · 49:21 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3542298238.mp3?updated=1729784394)

Was the Battle of Trafalgar the most decisive battle of the 19th century? Join Tom and Dominic as they embark on a three part series discussing this incredible conflict between the British Royal Navy and combined fleets of the French and Spanish navies.
