# The Trial of Charles I Part 1

## Episodes

* [The Trial of Charles I Part 1](/history/early-modern-europe/trial-of-charles-i/01-the-trial-of-charles-i-part-1.md) — Episode 143: Charles I was executed 373 years ago to the day on 30th January.
* [The Trial of Charles I Part 2](/history/early-modern-europe/trial-of-charles-i/02-the-trial-of-charles-i-part-2.md) — Episode 144: Tune in to hear the second part of The Rest Is History's take on the execution of Charles I and its aftermath.
