---
type: Section
title: "The Trial of Charles I Part 2"
description: "Episode 144: Tune in to hear the second part of The Rest Is History's take on the execution of Charles I and its aftermath."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "charles-i", "england"]
---

# The Trial of Charles I Part 2

2022-01-28 · 45:04 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2968292003.mp3?updated=1777394902)

Tune in to hear the second part of The Rest Is History's take on the execution of Charles I and its aftermath. Charles I was executed 373 years ago to the day on 30th January. But was his killing a sinful act of treason or merely one of retributive justice? Tom and Dominic welcome back Professor Ted Vallance from the University of Roehampton to explore one of the most extraordinary events in …