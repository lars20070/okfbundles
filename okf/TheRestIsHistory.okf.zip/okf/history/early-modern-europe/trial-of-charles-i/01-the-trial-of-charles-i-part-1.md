---
type: Section
title: "The Trial of Charles I Part 1"
description: "Episode 143: Charles I was executed 373 years ago to the day on 30th January."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "charles-i", "england"]
---

# The Trial of Charles I Part 1

2022-01-27 · 55:34 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4850801452.mp3?updated=1777394936)

Charles I was executed 373 years ago to the day on 30th January. But was his killing a sinful act of treason or merely one of retributive justice? Tom and Dominic welcome back Professor Ted Vallance from the University of Roehampton to explore the build-up, event and aftermath of the trial of Charles I.