---
type: Section
title: "Sex and Scandal (Part 1)"
description: "Episode 341: The truth is rarely pure and never simple. Oscar Wilde's life was a complicated one."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "oscar-wilde", "victorian"]
---

# Sex and Scandal (Part 1)

2023-06-15 · 50:35 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1940599692.mp3?updated=1777394822)

"The truth is rarely pure and never simple." As his most popular work, "The Importance of Being Earnest", hints at, Oscar Wilde's life was a complicated one. Perhaps the most famous gay martyr in history, Wilde is often presented as a sacrificial victim destroyed by a bigoted and puritanical establishment. But the story of how Wilde came to prominence, and eventually sued his lover's father for …