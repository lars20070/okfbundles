# Sex and Scandal (Part 1)

## Episodes

* [Sex and Scandal (Part 1)](/history/early-modern-europe/oscar-wilde/01-sex-and-scandal.md) — Episode 341: The truth is rarely pure and never simple. Oscar Wilde's life was a complicated one.
* [Downfall and Prison (Part 2)](/history/early-modern-europe/oscar-wilde/02-downfall-and-prison.md) — Episode 342: It's 1895, and with the libel case brought against the Marquess of Queensbury having collapsed, Oscar Wilde is now arrested and charged with gross indecency.
