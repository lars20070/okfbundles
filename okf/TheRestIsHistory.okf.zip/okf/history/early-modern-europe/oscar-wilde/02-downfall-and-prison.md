---
type: Section
title: "Downfall and Prison (Part 2)"
description: "Episode 342: It's 1895, and with the libel case brought against the Marquess of Queensbury having collapsed, Oscar Wilde is now arrested and charged with gross indecency."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "oscar-wilde", "victorian"]
---

# Downfall and Prison (Part 2)

2023-06-19 · 45:41 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5549466795.mp3?updated=1777394910)

It's 1895, and with the libel case brought against the Marquess of Queensbury having collapsed, Oscar Wilde is now arrested and charged with committing acts of "gross indecency". With former lovers, hotel servants and chambermaids lining up to give evidence, and the evening papers, night after night full of scandalous allegations, turning the general public against him, Wilde must now face a …