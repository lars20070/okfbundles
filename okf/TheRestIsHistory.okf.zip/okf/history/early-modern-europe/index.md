# Early Modern Europe

## Series

* [Miracles, Money, and Mud (Part 1)](/history/early-modern-europe/amsterdam/) — Series about Miracles, Money, and Mud (Part 1)
* [The Queen's Spymaster (Part 1)](/history/early-modern-europe/elizabeth-i-vs-catholics/) — Series about The Queen's Spymaster (Part 1)
* [The Fall of the Axe (Part 1)](/history/early-modern-europe/elizabeth-i/) — Series about The Fall of the Axe (Part 1)
* [Marie Antoinette (Part 1)](/history/early-modern-europe/french-revolution/) — Series about Marie Antoinette (Part 1)
* [The Battle of the Baltic (Part 1)](/history/early-modern-europe/great-northern-war/) — Series about The Battle of the Baltic (Part 1)
* [The Habsburgs' Greatest Scandal (Part 1)](/history/early-modern-europe/habsburgs/) — Series about The Habsburgs' Greatest Scandal (Part 1)
* [The Mad Life of Dr Johnson (Part 1)](/history/early-modern-europe/londons-golden-age/) — Series about The Mad Life of Dr Johnson (Part 1)
* [Mad, Bad and Dangerous to Know (Part 1)](/history/early-modern-europe/lord-byron/) — Series about Mad, Bad and Dangerous to Know (Part 1)
* [Birth of a Legend (Part 1)](/history/early-modern-europe/mary-queen-of-scots/) — Series about Birth of a Legend (Part 1)
* [Masters of Florence (Part 1)](/history/early-modern-europe/medici/) — Series about Masters of Florence (Part 1)
* [Bonaparte Prepares to Strike (Part 4)](/history/early-modern-europe/nelson/) — Series about Bonaparte Prepares to Strike (Part 4)
* [Sex and Scandal (Part 1)](/history/early-modern-europe/oscar-wilde/) — Series about Sex and Scandal (Part 1)
* [The Rise of Russia (Part 1)](/history/early-modern-europe/peter-the-great/) — Series about The Rise of Russia (Part 1)
* [Trafalgar: A World at War (Part 1)](/history/early-modern-europe/trafalgar/) — Series about Trafalgar: A World at War (Part 1)
* [The Trial of Charles I Part 1](/history/early-modern-europe/trial-of-charles-i/) — Series about The Trial of Charles I Part 1
* [Teenage Revolutionary (Part 1)](/history/early-modern-europe/young-napoleon/) — Series about Teenage Revolutionary (Part 1)
