# Early Modern Europe

## Series

* [Amsterdam](/history/early-modern-europe/amsterdam/) — 2 episodes
* [Elizabeth I vs The Catholics](/history/early-modern-europe/elizabeth-i-vs-catholics/) — 5 episodes
* [Elizabeth I](/history/early-modern-europe/elizabeth-i/) — 4 episodes
* [The French Revolution](/history/early-modern-europe/french-revolution/) — 13 episodes
* [The Great Northern War](/history/early-modern-europe/great-northern-war/) — 4 episodes
* [The Habsburgs](/history/early-modern-europe/habsburgs/) — 2 episodes
* [London's Golden Age](/history/early-modern-europe/londons-golden-age/) — 4 episodes
* [Lord Byron](/history/early-modern-europe/lord-byron/) — 4 episodes
* [Mary, Queen of Scots](/history/early-modern-europe/mary-queen-of-scots/) — 6 episodes
* [The Medici](/history/early-modern-europe/medici/) — 4 episodes
* [Nelson](/history/early-modern-europe/nelson/) — 12 episodes
* [Oscar Wilde](/history/early-modern-europe/oscar-wilde/) — 2 episodes
* [Peter the Great](/history/early-modern-europe/peter-the-great/) — 2 episodes
* [Trafalgar](/history/early-modern-europe/trafalgar/) — 3 episodes
* [The Trial of Charles I](/history/early-modern-europe/trial-of-charles-i/) — 2 episodes
* [Young Napoleon](/history/early-modern-europe/young-napoleon/) — 2 episodes
