---
type: Section
title: "Dangerous Liaisons (Part 3)"
description: "Episode 442: Byron's return to England and his notoriety as the world's first celebrity."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "lord-byron", "poetry"]
---

# Dangerous Liaisons (Part 3)

2024-04-21 · 58:39 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1176702097.mp3?updated=1713098396)

Good God I am surely in hell! Upon Lord Byron's return to England and the publication of Childe Harold's Pilgrimage, he became one of the most notorious men in Europe and the world's first celebrity. The next period of his life would be rocked by shocking scandal, moral depravity and sexual outrage. Pale and sickly but devastatingly romantic, he attracted a dedicated fan base, the likes of which …