# Mad, Bad and Dangerous to Know (Part 1)

## Episodes

* [Mad, Bad and Dangerous to Know (Part 1)](/history/early-modern-europe/lord-byron/01-mad-bad-and-dangerous-to-know.md) — Episode 440: Lord Byron's strange and exciting life and his mercurial nature.
* [Scandal, Sex and Celebrity (Part 2)](/history/early-modern-europe/lord-byron/02-scandal-sex-and-celebrity.md) — Episode 441: Byron's Eastern adventure and his hero Napoleon Bonaparte.
* [Dangerous Liaisons (Part 3)](/history/early-modern-europe/lord-byron/03-dangerous-liaisons.md) — Episode 442: Byron's return to England and his notoriety as the world's first celebrity.
* [Death of a Vampire (Part 4)](/history/early-modern-europe/lord-byron/04-death-of-a-vampire.md) — Episode 443: Byron's scandalous divorce and exile to Italy.
