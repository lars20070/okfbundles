---
type: Section
title: "Death of a Vampire (Part 4)"
description: "Episode 443: Byron's scandalous divorce and exile to Italy."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "lord-byron", "poetry"]
---

# Death of a Vampire (Part 4)

2024-04-24 · 54:34 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3247503776.mp3?updated=1713543415)

Rumours surrounding Lord Byron's scandalous divorce rippled throughout the world. Finally, he had no choice but to abandon England in disgrace and flee to Italy, an exile but still the most famous man in Europe. Then, in the summer of 1816 in Geneva, he met a young poet named Percy Bysshe Shelley, and one of the most iconic literary friendships of all time was sparked. A handsome republican with …