---
type: Section
title: "Mad, Bad and Dangerous to Know (Part 1)"
description: "Episode 440: Lord Byron's strange and exciting life and his mercurial nature."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "lord-byron", "poetry"]
---

# Mad, Bad and Dangerous to Know (Part 1)

2024-04-14 · 53:57 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4389862746.mp3?updated=1712939145)

Few lives from history can have contained as many strange and exciting strands as that of Lord Byron's, whose story reflects the great dramas of the Napoleonic era. A vampiric hero of devilish charisma; a martyr for liberty, a licentious lothario; Byron's cultural and literary impact cannot be underestimated. The remarkable course of his life, and his mercurial nature can in part be explained by …