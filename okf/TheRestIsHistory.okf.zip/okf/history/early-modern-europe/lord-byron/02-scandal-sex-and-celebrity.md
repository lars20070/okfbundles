---
type: Section
title: "Scandal, Sex and Celebrity (Part 2)"
description: "Episode 441: Byron's Eastern adventure and his hero Napoleon Bonaparte."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "lord-byron", "poetry"]
---

# Scandal, Sex and Celebrity (Part 2)

2024-04-17 · 58:10 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1954408695.mp3?updated=1712939288)

By 1809, Lord Byron found himself untethered and debt-ridden. Disenchanted with politics, frustrated by his literary career and haunted by his illicit homosexuality, he abandoned an oppressive England and set out upon his legendary Eastern adventure. First plunging into a Europe torn asunder by the exploits of his hero, Napoleon Bonaparte, Byron decried the imperialist militarism of the raging …