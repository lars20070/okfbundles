---
type: Section
title: "Birth of a Legend (Part 1)"
description: "Episode 584: Mary Queen of Scots' early life and claim to the thrones."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, mary-queen-of-scots, scotland]
---

# Birth of a Legend (Part 1)

2025-07-20 · 54:43 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7723962252.mp3?updated=1753939684)

*No description in the feed.*
