---
type: Section
title: "Downfall (Part 6)"
description: "Episode 589: Mary's flight and escape from her enemies."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, mary-queen-of-scots, scotland]
---

# Downfall (Part 6)

2025-08-06 · 1:06:13 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8999516788.mp3?updated=1754478548)

Following the murder of her husband, Lord Darnley, how did Mary Queen of Scots - thought to have conspired for his death - navigate the most precarious situation of her young life so far? Would she marry again, and if so whom? Why was she forced to flee her enemies dressed as a man, and would she escape the threat of imprisonment? Could she look to her fellow cousin, Elizabeth I, for aid, or face …
