---
type: Section
title: "The Mystery of the Exploding Mansion (Part 5)"
description: "Episode 588: The murder of Lord Darnley."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, mary-queen-of-scots, scotland]
---

# The Mystery of the Exploding Mansion (Part 5)

2025-08-03 · 1:00:08 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2383249995.mp3?updated=1754129911)

How and why was Mary Queen of Scots' traitorous husband, Lord Darnley, murdered, and by whom…? Was Mary complicit? Why was his death one of the greatest mysteries in all British history? And, with Mary's situation growing increasingly precarious, and allies few and far between, to whom would Mary turn next? Join Tom and Dominic as they unravel, tantalisingly, the build up to and enactment of Lord …
