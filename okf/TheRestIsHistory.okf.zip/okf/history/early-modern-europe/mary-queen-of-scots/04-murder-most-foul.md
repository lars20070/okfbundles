---
type: Section
title: "Murder Most Foul (Part 4)"
description: "Episode 587: Mary's marriage to Lord Darnley and civil war."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, mary-queen-of-scots, scotland]
---

# Murder Most Foul (Part 4)

2025-07-30 · 54:22 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2035316933.mp3?updated=1753936999)

Why did Mary Queen of Scots' second marriage to the volatile Lord Darnley threaten to send Scotland into civil war? In what way did she essentially declare war upon her powerful cousin, Elizabeth I? Who was the hotheaded James Hepburn, the Earl of Bothwell, and why would he come to play such a devastating role in Mary's life? Could Mary survive unburnt if the religious tensions smouldering at the …
