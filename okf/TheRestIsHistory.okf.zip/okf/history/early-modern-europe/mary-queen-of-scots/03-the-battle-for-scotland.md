---
type: Section
title: "The Battle for Scotland (Part 3)"
description: "Episode 586: Mary's return to Scotland and the nobles' plots."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, mary-queen-of-scots, scotland]
---

# The Battle for Scotland (Part 3)

2025-07-27 · 1:04:52 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1545905247.mp3?updated=1753917314)

Following the death of her husband, the King of France, was the glamorous Mary welcomed back to Scotland, her kingdom since infancy, with open arms or deep suspicion? Did she handle the precarious situation in which she found herself well, or recklessly? Did the majority of Scottish nobles side with Mary, or plot to usurp her in the shadows? When her eye turned on the crown of her wealthier …
