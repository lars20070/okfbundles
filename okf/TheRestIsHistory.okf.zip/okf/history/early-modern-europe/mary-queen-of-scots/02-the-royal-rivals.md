---
type: Section
title: "The Royal Rivals (Part 2)"
description: "Episode 585: Mary at the French court and queen of France."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, mary-queen-of-scots, scotland]
---

# The Royal Rivals (Part 2)

2025-07-23 · 1:00:52 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5612344391.mp3?updated=1753942527)

What was life like in the glittering French court, for the young and newly married Mary Queen of Scots? What momentous destiny was her formidable mother, Mary of Guise, planning for her? How did Mary become, in 1559, not only the queen of Scotland, but also of France, and - according to her Catholic French supporters - the queen of England? What would Mary do when unexpectedly widowed in a …
