# Birth of a Legend (Part 1)

## Episodes

* [Birth of a Legend (Part 1)](/history/early-modern-europe/mary-queen-of-scots/01-birth-of-a-legend.md) — Episode 584: Mary Queen of Scots' early life and claim to the thrones.
* [The Royal Rivals (Part 2)](/history/early-modern-europe/mary-queen-of-scots/02-the-royal-rivals.md) — Episode 585: Mary at the French court and queen of France.
* [The Battle for Scotland (Part 3)](/history/early-modern-europe/mary-queen-of-scots/03-the-battle-for-scotland.md) — Episode 586: Mary's return to Scotland and the nobles' plots.
* [Murder Most Foul (Part 4)](/history/early-modern-europe/mary-queen-of-scots/04-murder-most-foul.md) — Episode 587: Mary's marriage to Lord Darnley and civil war.
* [The Mystery of the Exploding Mansion (Part 5)](/history/early-modern-europe/mary-queen-of-scots/05-the-mystery-of-the-exploding-mansion.md) — Episode 588: The murder of Lord Darnley.
* [Downfall (Part 6)](/history/early-modern-europe/mary-queen-of-scots/06-downfall.md) — Episode 589: Mary's flight and escape from her enemies.
