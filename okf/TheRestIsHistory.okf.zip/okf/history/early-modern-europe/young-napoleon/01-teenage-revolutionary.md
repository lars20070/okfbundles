---
type: Section
title: "Teenage Revolutionary (Part 1)"
description: "Episode 382: Born in Corsica, Napoleon grew up in a world of political and civil unrest."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "napoleon", "french-revolution"]
---

# Teenage Revolutionary (Part 1)

2023-10-30 · 46:20 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6500252244.mp3?updated=1729781626)

"I would plunge the avenging dagger, up to the hilt, in the breast of the tyrant!" Born in Corsica a year after the island was given to France by the Genoese, Napoleon Bonaparte grew up in a world of political and civil unrest. His father had close ties with the leader of the Corsican resistance movement, Pasquale Paoli, who would leave a lasting impression on young Napoleon. However, sent to …