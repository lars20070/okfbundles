# Teenage Revolutionary (Part 1)

## Episodes

* [Teenage Revolutionary (Part 1)](/history/early-modern-europe/young-napoleon/01-teenage-revolutionary.md) — Episode 382: Born in Corsica, Napoleon grew up in a world of political and civil unrest.
* [The Shadow of the Guillotine (Part 2)](/history/early-modern-europe/young-napoleon/02-the-shadow-of-the-guillotine.md) — Episode 383: Napoleon stands out in the French Revolution, defeating the British at Toulon.
