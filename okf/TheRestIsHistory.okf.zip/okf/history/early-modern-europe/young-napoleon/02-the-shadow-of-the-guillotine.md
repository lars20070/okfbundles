---
type: Section
title: "The Shadow of the Guillotine (Part 2)"
description: "Episode 383: Napoleon stands out in the French Revolution, defeating the British at Toulon."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "napoleon", "french-revolution"]
---

# The Shadow of the Guillotine (Part 2)

2023-11-02 · 51:52 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2658259929.mp3?updated=1729781645)

Within the turmoil of the French Revolution, Napoleon Bonaparte stands out to his military superiors, first by defeating the British at Toulon, then by putting down a royalist mob in Paris when outnumbered four to one, with a "whiff of grapeshot". Having finally shaken off the humiliation of the failed invasion of Sardinia which began his career, he is made Commander of the Interior, and rewarded …