---
type: Section
title: "The Habsburgs' Greatest Scandal (Part 1)"
description: "Episode 689: Vienna in the 1880s and Crown Prince Rudolf's tragic meeting with Baroness Mary Vetsera."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, habsburgs, mayerling, austria]
---

# The Habsburgs' Greatest Scandal (Part 1)

2026-07-19 · 1:12:59 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6194086702.mp3)

What was Vienna like in the 1880s? Why was Crown Prince Rudolf of Austria seen as the outcast of the prestigious Habsburg dynasty? And, how would meeting 17 year-old Baroness Mary Vetsera on his 30th birthday change both of their lives, and the trajectory of Europe, forever? Join Dominic and Tom as they unravel the mysterious tale that is the Mayerling Incident.
