---
type: Section
title: "Death at Mayerling (Part 2)"
description: "Episode 690: The Mayerling Incident — murder suicide or murder alone?"
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, habsburgs, mayerling, austria]
---

# Death at Mayerling (Part 2)

2026-07-22 · 1:19:05 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7203783068.mp3)

What really happened at the Habsburgian hunting lodge, Mayerling? Did Crown Prince Rudolf and his mistress, Baroness Mary Vetsera, really commit a romantic murder suicide, or did the heir cold-heartedly murder the 17 year old girl? And, why did the Austrian royal family try to erase all traces of this tragic incident? Join Dominic and Tom as they solve the mysterious tale of the Mayerling …
