# The Battle of the Baltic (Part 1)

## Episodes

* [The Battle of the Baltic (Part 1)](/history/early-modern-europe/great-northern-war/01-the-battle-of-the-baltic.md) — Episode 564: The outbreak of the Great Northern War between Sweden and Russia.
* [Revenge of the Cossacks (Part 2)](/history/early-modern-europe/great-northern-war/02-revenge-of-the-cossacks.md) — Episode 565: St Petersburg and Peter's struggle against Charles XII.
* [Slaughter on the Steppes (Part 3)](/history/early-modern-europe/great-northern-war/03-slaughter-on-the-steppes.md) — Episode 566: The Battle of Poltava.
* [Murder in Moscow (Part 4)](/history/early-modern-europe/great-northern-war/04-murder-in-moscow.md) — Episode 567: Peter the Great's victory and his treatment of his son Alexis.
