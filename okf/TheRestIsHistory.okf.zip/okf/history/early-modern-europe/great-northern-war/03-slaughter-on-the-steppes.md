---
type: Section
title: "Slaughter on the Steppes (Part 3)"
description: "Episode 566: The Battle of Poltava."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, great-northern-war, sweden, russia]
---

# Slaughter on the Steppes (Part 3)

2025-05-18 · 1:01:36 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4679437587.mp3?updated=1747310607)

Why was the greatest and most climactic battle of the Great Northern War, the Battle of Poltova, one of the most important in all European history? What drove Charles XII of Sweden to invade Russia in the Summer of 1707, in the lead up to that totemic clash? Exactly what happened on the day of the Battle? Would both Peter the Great and Charles survive it unscathed, if at all? And, who would …
