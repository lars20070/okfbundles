---
type: Section
title: "The Battle of the Baltic (Part 1)"
description: "Episode 564: The outbreak of the Great Northern War between Sweden and Russia."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, great-northern-war, sweden, russia]
---

# The Battle of the Baltic (Part 1)

2025-05-11 · 1:07:07 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2662789070.mp3?updated=1747059727)

How did the Great Northern War, which saw Sweden pitted against Peter the Great's Russia and her allies, and would transform Europe forever, begin? Who was Charles XII, Sweden's King, and a worthy antagonist for the formidable Peter? What terrible miscalculation saw Russia's Danish allies brutally knocked from the war in its early stage? What dreadful havoc did Peter's Cossacks wreak upon the …
