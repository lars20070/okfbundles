---
type: Section
title: "Murder in Moscow (Part 4)"
description: "Episode 567: Peter the Great's victory and his treatment of his son Alexis."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, great-northern-war, sweden, russia]
---

# Murder in Moscow (Part 4)

2025-05-21 · 1:05:18 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4718660658.mp3?updated=1747754804)

What were the consequences of Peter the Great's mighty victory over Sweden at the Battle of Poltova in 1707? How great was the impact of his reign upon Russia overall, and was he responsible for turning it into one of Europe's greatest powers? What occurred during the later years of his life? And, what is the story behind his bloody, terrible and tragic treatment of his son, Alexis…? Join Dominic …
