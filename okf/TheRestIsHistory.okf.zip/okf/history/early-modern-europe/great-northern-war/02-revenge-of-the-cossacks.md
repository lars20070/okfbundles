---
type: Section
title: "Revenge of the Cossacks (Part 2)"
description: "Episode 565: St Petersburg and Peter's struggle against Charles XII."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, great-northern-war, sweden, russia]
---

# Revenge of the Cossacks (Part 2)

2025-05-14 · 1:07:05 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1223770243.mp3?updated=1747251724)

After establishing the city of St Petersburg, what was Peter the Great's next step in his titanic struggle against Charles XII of Sweden, for mastery of northern and eastern Europe? What drastic, brutal action did he take against Poland, to slow the Swedish advance into his territories? And, after the defection of one of his oldest and most important allies - the leader of the Ukrainian Cossacks …
