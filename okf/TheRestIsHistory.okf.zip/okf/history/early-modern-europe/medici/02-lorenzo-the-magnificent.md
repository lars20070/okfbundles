---
type: Section
title: "Lorenzo the Magnificent (Part 2)"
description: "Episode 573: The Pazzi Conspiracy and Lorenzo's almost murder."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, medici, florence]
---

# Lorenzo the Magnificent (Part 2)

2025-06-11 · 59:58 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6599592252.mp3?updated=1749655445)

Who was Lorenzo the Magnificent, the most glamorous, glittering, and blood-soaked of all the Medici, who became his family's formidable but compulsive "Godfather" from the age of only twenty one? What was the Pazzi Conspiracy, in which he was almost murdered in a bloody plot to eliminate Medici supremacy in Florence, in the middle of a church mass? Were the Medici the first Italian mafia? What …
