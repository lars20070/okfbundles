---
type: Section
title: "The Bonfire of the Vanities (Part 4)"
description: "Episode 575: Savonarrolla's rise to supreme power in Florence."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, medici, florence]
---

# The Bonfire of the Vanities (Part 4)

2025-06-19 · 1:09:09 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2280694489.mp3?updated=1784111597)

Following the death of Lorenzo the Magnificent, who was his Medici successor? Could he overcome the political turmoil and religious fervour in Florence, and rebuff the storm clouds of war gathering over his city with the approaching French army? How did this burgeoning catastrophe catapult the magnetic priest, Savonalrolla, to supreme power in Florence? Could he save it from the jaws of death …
