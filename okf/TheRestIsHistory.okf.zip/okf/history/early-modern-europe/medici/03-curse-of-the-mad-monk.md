---
type: Section
title: "Curse of the Mad Monk (Part 3)"
description: "Episode 574: Lorenzo's corrupt rule and Savonarrolla's rise."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, medici, florence]
---

# Curse of the Mad Monk (Part 3)

2025-06-15 · 59:33 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6193985064.mp3?updated=1784111483)

Did Lorenzo de'Medici's rule in Florence incur prosperity, or was it a corrupt and autocratic regime, rife with torture, that would spell the doom of the former Republic? While building an edifice of power, wealth and luxury, how was he secretly bankrupting his famous family and city? Was he really the perfect Renaissance Prince, and how did he launch the careers of both Michaelangelo and …
