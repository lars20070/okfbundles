# Masters of Florence (Part 1)

## Episodes

* [Masters of Florence (Part 1)](/history/early-modern-europe/medici/01-masters-of-florence.md) — Episode 572: The origins of the Medici and Cosimo's rise to power.
* [Lorenzo the Magnificent (Part 2)](/history/early-modern-europe/medici/02-lorenzo-the-magnificent.md) — Episode 573: The Pazzi Conspiracy and Lorenzo's almost murder.
* [Curse of the Mad Monk (Part 3)](/history/early-modern-europe/medici/03-curse-of-the-mad-monk.md) — Episode 574: Lorenzo's corrupt rule and Savonarrolla's rise.
* [The Bonfire of the Vanities (Part 4)](/history/early-modern-europe/medici/04-the-bonfire-of-the-vanities.md) — Episode 575: Savonarrolla's rise to supreme power in Florence.
