---
type: Section
title: "Masters of Florence (Part 1)"
description: "Episode 572: The origins of the Medici and Cosimo's rise to power."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, medici, florence]
---

# Masters of Florence (Part 1)

2025-06-08 · 1:03:45 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1413065864.mp3?updated=1749052325)

What are the origins of one of history's most glittering, and for a time, most powerful families in Europe; the Medici? How were they able to seize supreme power in the Republic of Florence , one of the most dazzling cities in the world, during the 15th century, at the height of the Renaissance? When did Florence's explosive growth begin, and how? Who was Cosimo Medici, the Godfather of the …
