# The Fall of the Axe (Part 1)

## Episodes

* [The Fall of the Axe (Part 1)](/history/early-modern-europe/elizabeth-i/01-the-fall-of-the-axe.md) — Episode 616: Elizabeth's early life in the court of Henry VIII.
* [Anne Boleyn's Bastard (Part 2)](/history/early-modern-europe/elizabeth-i/02-anne-boleyns-bastard.md) — Episode 617: The execution of Anne Boleyn and Elizabeth's early years.
* [The Shadow of the Tower (Part 3)](/history/early-modern-europe/elizabeth-i/03-the-shadow-of-the-tower.md) — Episode 618: Surviving Bloody Mary and imprisonment in the Tower.
* [The Virgin Queen (Part 4)](/history/early-modern-europe/elizabeth-i/04-the-virgin-queen.md) — Episode 619: Elizabeth's glorious coronation and determination to remain unmarried.
