---
type: Section
title: "The Shadow of the Tower (Part 3)"
description: "Episode 618: Surviving Bloody Mary and imprisonment in the Tower."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, elizabeth-i, tudor]
---

# The Shadow of the Tower (Part 3)

2025-11-17 · 1:12:18 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7928851339.mp3?updated=1763138973)

Why did Elizabeth I's brother, Henry VIII's heir, Edward VI, choose his cousin Jane Grey to succeed him, rather than either of his wily Tudor sisters? Later, how did Elizabeth survive the reign of her once dear Catholic sister, "Bloody Mary", given Mary's growing resentment? And, while imprisoned in the Tower of London, how did Elizabeth avoid the same bloody fate as her beheaded mother, Anne …
