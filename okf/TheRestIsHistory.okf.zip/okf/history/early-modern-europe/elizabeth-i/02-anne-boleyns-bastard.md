---
type: Section
title: "Anne Boleyn's Bastard (Part 2)"
description: "Episode 617: The execution of Anne Boleyn and Elizabeth's early years."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, elizabeth-i, tudor]
---

# Anne Boleyn's Bastard (Part 2)

2025-11-13 · 1:01:31 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2585433242.mp3?updated=1763641944)

What happened to the infant Elizabeth I following the bloody execution of her mother Anne Boleyn? How did her father Henry VIII and his next four wives treat her? And, what became of Elizabeth following the death of Henry, and the succession of her protestant brother Edward…? Join Tom and Dominic as they discuss the next, unsteady phase of the young Elizabeth's life, as she was transformed from …
