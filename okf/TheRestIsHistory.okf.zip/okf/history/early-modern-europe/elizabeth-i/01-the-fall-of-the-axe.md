---
type: Section
title: "The Fall of the Axe (Part 1)"
description: "Episode 616: Elizabeth's early life in the court of Henry VIII."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, elizabeth-i, tudor]
---

# The Fall of the Axe (Part 1)

2025-11-10 · 1:07:40 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9331634740.mp3?updated=1763641855)

How did Elizabeth I's tumultuous early life in the court of her wife murdering father, Henry VIII, influence the rest of her life? What was the nature of the Tudor world she was born into? Why did Henry VIII so desperately desire a son? And, why did Henry and Anne's marriage following his divorce from Catherine of Aragon, change the fate of Britain forever? Join Tom and Dominic as they discuss …
