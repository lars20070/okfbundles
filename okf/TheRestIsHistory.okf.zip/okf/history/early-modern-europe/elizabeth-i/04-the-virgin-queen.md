---
type: Section
title: "The Virgin Queen (Part 4)"
description: "Episode 619: Elizabeth's glorious coronation and determination to remain unmarried."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, elizabeth-i, tudor]
---

# The Virgin Queen (Part 4)

2025-11-20 · 1:09:26 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7930465337.mp3?updated=1763549960)

How was Elizabeth I finally crowned Queen of England, after long years of perilous waiting? Why was her early reign so fraught with danger? Who was William Cecil, Elizabeth's new secretary, and the key political player of her rule? And, why was she so determined to remain the unmarried, 'Virgin Queen'? Join Tom and Dominic as they reach the glorious climax of Elizabeth I's long and dangerous …
