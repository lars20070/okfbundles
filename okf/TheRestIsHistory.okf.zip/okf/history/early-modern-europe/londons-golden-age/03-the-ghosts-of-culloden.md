---
type: Section
title: "The Ghosts of Culloden (Part 3)"
description: "Episode 652: Johnson and Boswell's journey into Scotland and the Battle of Culloden."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, london, scotland, culloden]
---

# The Ghosts of Culloden (Part 3)

2026-03-16 · 1:04:55 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2422514848.mp3?updated=1773416285)

What adventures occurred during Samuel Johnson and James Boswell's journey into the heart of Scotland? How was their trip a gateway to the history of Scotland's union with England in 1707? And, was Dr Johnson embroiled in the bloody Battle of Culloden…? Join Tom and Dominic as they travel into Scotland's dark history, alongside Samuel Johnson and James Boswell, and discuss their fascinating and …
