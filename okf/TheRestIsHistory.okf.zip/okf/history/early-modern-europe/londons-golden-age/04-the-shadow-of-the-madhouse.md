---
type: Section
title: "The Shadow of the Madhouse (Part 4)"
description: "Episode 653: Samuel Johnson's final years and his devastating love."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, london, samuel-johnson]
---

# The Shadow of the Madhouse (Part 4)

2026-03-19 · 1:07:08 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2240052230.mp3?updated=1774256098)

Who did Samuel Johnson fall in love with towards the end of his life, and why did it break his heart? How did it enrage his old friend James Boswell? And, why did he fear imprisonment in an asylum…? Join Tom and Dominic as they reach the fascinating, but devastating conclusion of the life of one of Britain's greatest men, and the completion of his immortality…
