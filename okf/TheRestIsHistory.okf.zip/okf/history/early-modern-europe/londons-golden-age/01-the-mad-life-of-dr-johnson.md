---
type: Section
title: "The Mad Life of Dr Johnson (Part 1)"
description: "Episode 650: Samuel Johnson, the Dictionary, and Georgian Britain."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, london, georgian, samuel-johnson]
---

# The Mad Life of Dr Johnson (Part 1)

2026-03-09 · 1:05:32 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2687128958.mp3?updated=1773055447)

Who was Samuel Johnson, the dominant literary celebrity of 18th century London and the man who wrote the Dictionary? Why did his friendship with James Boswell, a sex and celebrity obsessed, but very talented writer, flourish? And, how does this titanic friendship open a window onto Georgian Britain; from slavery to the politics of the day? Join Tom and Dominic as they discuss one of history's …
