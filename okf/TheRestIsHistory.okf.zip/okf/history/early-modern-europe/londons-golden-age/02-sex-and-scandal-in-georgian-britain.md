---
type: Section
title: "Sex and Scandal in Georgian Britain (Part 2)"
description: "Episode 651: James Boswell's tumultuous life and meeting with Samuel Johnson."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, london, georgian, james-boswell]
---

# Sex and Scandal in Georgian Britain (Part 2)

2026-03-12 · 1:08:46 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1542242808.mp3?updated=1773416272)

Why was London such a cauldron of sexual scandal and political tumult in the 18th century? What licentious escapades did the infamous Scottish nobleman, James Boswell, get up to there? And, how did his legendary first meeting with the renowned wit Samuel Johnson, unfold? Join Tom and Dominic, as they delve into the tumultuous, salacious life of James Boswell - the ultimate celebrity hunter - his …
