# The Mad Life of Dr Johnson (Part 1)

## Episodes

* [The Mad Life of Dr Johnson (Part 1)](/history/early-modern-europe/londons-golden-age/01-the-mad-life-of-dr-johnson.md) — Episode 650: Samuel Johnson, the Dictionary, and Georgian Britain.
* [Sex and Scandal in Georgian Britain (Part 2)](/history/early-modern-europe/londons-golden-age/02-sex-and-scandal-in-georgian-britain.md) — Episode 651: James Boswell's tumultuous life and meeting with Samuel Johnson.
* [The Ghosts of Culloden (Part 3)](/history/early-modern-europe/londons-golden-age/03-the-ghosts-of-culloden.md) — Episode 652: Johnson and Boswell's journey into Scotland and the Battle of Culloden.
* [The Shadow of the Madhouse (Part 4)](/history/early-modern-europe/londons-golden-age/04-the-shadow-of-the-madhouse.md) — Episode 653: Samuel Johnson's final years and his devastating love.
