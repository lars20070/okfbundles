---
type: Section
title: "Glory at Trafalgar (Part 6)"
description: "Episode 613: The Battle of Trafalgar and Nelson's legendary victory."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, nelson, trafalgar]
---

# Glory at Trafalgar (Part 6)

2025-10-30 · 1:10:56 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7193792251.mp3?updated=1763642241)

How did the British fleet prepare for war, on the morning of the Battle of Trafalgar? With the flags of both fleets flying and both Nelson and the French admiral Villeneuve glittering in their uniforms, how did the two fleets finally collide? Amidst the rivers of blood, the blast of canons, the flying splinters, and the swirling smoke, how did Nelson's ships and sailors fare? And, cornered by …
