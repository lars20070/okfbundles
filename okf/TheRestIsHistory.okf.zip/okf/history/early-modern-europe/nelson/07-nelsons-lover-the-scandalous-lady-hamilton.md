---
type: Section
title: "Nelson's Lover: The Scandalous Lady Hamilton"
description: "Episode 607: Emma Nelson, Nelson's beautiful and famous mistress."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, nelson, lady-hamilton]
---

# Nelson's Lover: The Scandalous Lady Hamilton

2025-10-08 · 1:14:03 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1577197938.mp3?updated=1763642144)

Who was Emma Hamilton, Horatio Nelson's strikingly beautiful, and famously fashionable mistress? How did she raise herself up from dire poverty, to become a model, actress, dancer, and even an international celebrity? And, why was theirs one of the most famous love affairs of all time? Join Tom and Dominic as they discuss one of history's most remarkable woman - Lady Emma Hamilton - and explore …
