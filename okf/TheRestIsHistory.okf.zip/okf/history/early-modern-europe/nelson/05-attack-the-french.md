---
type: Section
title: "Attack the French! (Part 2)"
description: "Episode 515: Nelson takes over command of the Agamemnon in 1793."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "nelson", "trafalgar"]
---

# Attack the French! (Part 2)

2024-11-21 · 37:46 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9020085184.mp3?updated=1731889804)

It is 1793 and France has declared war on Britain, meaning that the British navy must serve as both sword and shield to Europe. Horatio Nelson is at this time a slim and sickly 34 year old captain who nevertheless burns with the zeal to serve his king and country, and has recently taken over command of the impressive Agamemnon. Meanwhile, the British navy has taken Toulon by the summer of 1793 …
