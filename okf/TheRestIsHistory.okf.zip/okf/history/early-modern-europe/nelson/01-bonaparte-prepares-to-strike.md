---
type: Section
title: "Bonaparte Prepares to Strike (Part 4)"
description: "Episode 611: Napoleon's invasion plan and the provisional peace treaty."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, nelson, trafalgar]
---

# Bonaparte Prepares to Strike (Part 4)

2025-10-22 · 1:09:28 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9281187489.mp3?updated=1763642327)

With Britain at war for more than eight long years, and her people depleted and hungry, how did her government react to the news that Napoleon Bonaparte was planning a full-scale invasion in 1801? What happened when Nelson tried to attack the French at Boulogne, and what was the terrible cost? Why was the provisional peace treaty signed between the British and the French at the end of September …
