---
type: Section
title: "The Battle of Copenhagen (Part 3)"
description: "Episode 610: Nelson's gamble at the Battle of Copenhagen."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, nelson, trafalgar]
---

# The Battle of Copenhagen (Part 3)

2025-10-19 · 1:07:25 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9153225543.mp3?updated=1763642283)

With fears that the powerful Danish fleet would join with the French against the British, what great gamble did Horatio Nelson take? After taking the drastic decision to attack the Danish fleet in their own harbour, what challenges did Nelson and his men face? How did the bloody Battle of Copenhagen in 1801 then unfold? And, what would be the consequences of this epic naval clash for Britain …
