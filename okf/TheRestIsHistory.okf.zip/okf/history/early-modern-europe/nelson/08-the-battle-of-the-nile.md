---
type: Section
title: "The Battle of the Nile (Part 5)"
description: "Episode 518: Nelson's legendary victory at the Nile in 1798."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "nelson", "trafalgar"]
---

# The Battle of the Nile (Part 5)

2024-12-02 · 51:48 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9518722562.mp3?updated=1733095800)

The 1st of August 1798 saw the British fleet sailing towards Alexandria into a land of classical history and mythology, the sun setting like blood over the River Nile and French flags flying over the city. The scene could not be more perfectly suited to the cataclysmic battle that would soon take place there, in which Horatio Nelson would guild his legend forever. Charged with leading a squadron …
