---
type: Section
title: "God of War (Part 3)"
description: "Episode 516: The British Royal Navy's clash with the Spanish at Cape St. Vincent."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "nelson", "trafalgar"]
---

# God of War (Part 3)

2024-11-25 · 38:32 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1686018300.mp3?updated=1732487389)

Valentine's day, 1797: the British Royal Navy are hoping for a decisive clash with the Spanish enemy, off the coast of Portugal, at Cape St. Vincent. Nelson has already narrowly avoided capture at the hands of the Spanish, after sailing through their fleet unnoticed, thanks to the auspicious cover of thick fog. But the British are outnumbered, and the Spanish fleet has at its head the largest …
