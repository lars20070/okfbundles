---
type: Section
title: "The Hunt for Napoleon (Part 4)"
description: "Episode 517: Nelson after the loss of his arm at Tenerife."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "nelson", "trafalgar"]
---

# The Hunt for Napoleon (Part 4)

2024-11-28 · 52:00 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5321926998.mp3?updated=1732010118)

In the wake of the Battle of Cape St. Vincent in 1797, Horatio Nelson, though a much acclaimed public hero for his bravery during the battle, is in the doldrums. Having led a harebrained attack on Tenerife, Nelson must now contend with the loss of his arm. Upon returning to England, famous and lauded, Nelson declared his intention to retire to a cottage in the countryside to recover. However …
