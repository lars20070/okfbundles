# Bonaparte Prepares to Strike (Part 4)

## Episodes

* [Bonaparte Prepares to Strike (Part 4)](/history/early-modern-europe/nelson/01-bonaparte-prepares-to-strike.md) — Episode 611: Napoleon's invasion plan and the provisional peace treaty.
* [The Final Showdown (Part 5)](/history/early-modern-europe/nelson/02-the-final-showdown.md) — Episode 612: Chasing the combined fleet and Napoleon's scheming.
* [Glory at Trafalgar (Part 6)](/history/early-modern-europe/nelson/03-glory-at-trafalgar.md) — Episode 613: The Battle of Trafalgar and Nelson's legendary victory.
* [Hero of the Seas (Part 1)](/history/early-modern-europe/nelson/04-hero-of-the-seas.md) — Episode 514: Nelson's birth in 1758 and leaving Norfolk for a life on the high seas.
* [Slaughter in Naples (Part 1)](/history/early-modern-europe/nelson/04-slaughter-in-naples.md) — Episode 608: Nelson meets Lady Emma Hamilton in Naples.
* [Attack the French! (Part 2)](/history/early-modern-europe/nelson/05-attack-the-french.md) — Episode 515: Nelson takes over command of the Agamemnon in 1793.
* [The Gathering Storm (Part 2)](/history/early-modern-europe/nelson/05-the-gathering-storm.md) — Episode 609: Nelson returns home after two years at sea.
* [God of War (Part 3)](/history/early-modern-europe/nelson/06-god-of-war.md) — Episode 516: The British Royal Navy's clash with the Spanish at Cape St. Vincent.
* [The Battle of Copenhagen (Part 3)](/history/early-modern-europe/nelson/06-the-battle-of-copenhagen.md) — Episode 610: Nelson's gamble at the Battle of Copenhagen.
* [Nelson's Lover: The Scandalous Lady Hamilton](/history/early-modern-europe/nelson/07-nelsons-lover-the-scandalous-lady-hamilton.md) — Episode 607: Emma Nelson, Nelson's beautiful and famous mistress.
* [The Hunt for Napoleon (Part 4)](/history/early-modern-europe/nelson/07-the-hunt-for-napoleon.md) — Episode 517: Nelson after the loss of his arm at Tenerife.
* [The Battle of the Nile (Part 5)](/history/early-modern-europe/nelson/08-the-battle-of-the-nile.md) — Episode 518: Nelson's legendary victory at the Nile in 1798.
