---
type: Section
title: "The Final Showdown (Part 5)"
description: "Episode 612: Chasing the combined fleet and Napoleon's scheming."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, nelson, trafalgar]
---

# The Final Showdown (Part 5)

2025-10-27 · 1:02:59 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2077045869.mp3?updated=1763642169)

After two years at sea chasing the combined fleet of France and Spain, what was Nelson's next step? Upon returning to his beloved Emma, how was the heroic Nelson received? What was the terrifying Napoleon Bonaparte scheming for his fleet across the seas? And, would Britain finally face an imminent French invasion, and with it apocalypse - for both Britain and Nelson himself? Join Dominic and Tom …
