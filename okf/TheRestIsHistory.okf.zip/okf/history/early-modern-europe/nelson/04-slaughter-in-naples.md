---
type: Section
title: "Slaughter in Naples (Part 1)"
description: "Episode 608: Nelson meets Lady Emma Hamilton in Naples."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, nelson, trafalgar]
---

# Slaughter in Naples (Part 1)

2025-10-12 · 1:22:23 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8594694484.mp3?updated=1763642104)

What happened when the heroic Horatio Nelson, victor of the Battle of the Nile, sailed into the seething city of Naples? Why would his meeting with the glamorous celebrity, Lady Emma Hamilton, shape the rest of his life? And, why would his decision to lend his support to the foolhardy Neapolitan campaign to "liberate all of Italy" from the formidable French, prove to be one of the most …
