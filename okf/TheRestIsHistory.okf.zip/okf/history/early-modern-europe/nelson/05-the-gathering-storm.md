---
type: Section
title: "The Gathering Storm (Part 2)"
description: "Episode 609: Nelson returns home after two years at sea."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, nelson, trafalgar]
---

# The Gathering Storm (Part 2)

2025-10-15 · 1:02:12 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8067718474.mp3?updated=1763642285)

After two years at sea, what happened when Horatio Nelson - now Britain's most celebrated naval commander - finally returned home, to his wife and father? Following his involvement in the poisonous politics of Naples, his terrible treatment of the Jacobite rebels, and starting an affair with the notorious Lady Emma Hamilton, how was Nelson received? And, with the storm clouds of war gathering …
