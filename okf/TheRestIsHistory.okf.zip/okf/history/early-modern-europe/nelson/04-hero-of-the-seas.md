---
type: Section
title: "Hero of the Seas (Part 1)"
description: "Episode 514: Nelson's birth in 1758 and leaving Norfolk for a life on the high seas."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "nelson", "trafalgar"]
---

# Hero of the Seas (Part 1)

2024-11-18 · 1:06:29 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4893527428.mp3?updated=1731880805)

It's 1758 and Britain's greatest naval commander has just been born. The young Horatio Nelson has inherited his father's love of god and his mother's hatred of the French. At age 12, he leaves Norfolk for a life on the high seas. As a teen, Nelson narrowly avoided death on multiple occasions. He survives a nasty encounter with the Sultan of Mysore, the blistering cold on a failed expedition in …
