# The Rise of Russia (Part 1)

## Episodes

* [The Rise of Russia (Part 1)](/history/early-modern-europe/peter-the-great/01-the-rise-of-russia.md) — Episode 562: Peter the Great's bloody early life and rise to Tsar.
* [Bloodbath in the Kremlin (Part 2)](/history/early-modern-europe/peter-the-great/02-bloodbath-in-the-kremlin.md) — Episode 563: Peter's travels through Europe and the Ottoman war.
