---
type: Section
title: "Bloodbath in the Kremlin (Part 2)"
description: "Episode 563: Peter's travels through Europe and the Ottoman war."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, peter-the-great, russia]
---

# Bloodbath in the Kremlin (Part 2)

2025-05-07 · 1:02:19 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4388388819.mp3?updated=1784112362)

What abominable mischief and hedonism did the seventeen year old Peter the Great revel in during his strange and remarkable travels through Europe, before truly stepping into the role of Tsar of all the Russias? Did it serve a secret political purpose? What was the outcome of the first war he chose to wage against the Ottoman Empire? Why did he go on a crucial and possibly dangerous diplomatic …
