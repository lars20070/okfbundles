---
type: Section
title: "The Rise of Russia (Part 1)"
description: "Episode 562: Peter the Great's bloody early life and rise to Tsar."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, peter-the-great, russia]
---

# The Rise of Russia (Part 1)

2025-05-04 · 1:03:32 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5535116202.mp3?updated=1746448094)

Why was the early life of Peter the Great - Tsar and autocrat of all the Russias, who endures to this day as an iconic symbol of Russian might - drenched in blood and violence? What amalgamation of court politics and family feuding saw him catapulted to the role of Tsar against all the odds? What did he do during the course of his colourful life and tumultuous reign to earn the moniker 'the …
