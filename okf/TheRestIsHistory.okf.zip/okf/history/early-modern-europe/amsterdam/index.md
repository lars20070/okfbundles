# Miracles, Money, and Mud (Part 1)

## Episodes

* [Miracles, Money, and Mud (Part 1)](/history/early-modern-europe/amsterdam/01-miracles-money-and-mud.md) — Episode 351: Amsterdam first gained prominence as a miraculous centre for pilgrimage.
* [Kings, Canals, and Coffee Houses (Part 2)](/history/early-modern-europe/amsterdam/02-kings-canals-and-coffee-houses.md) — Episode 352: Amsterdam has also stood in the avant-garde of European liberalism since the Second World War.
