---
type: Section
title: "Kings, Canals, and Coffee Houses (Part 2)"
description: "Episode 352: Amsterdam has also stood in the avant-garde of European liberalism since the Second World War."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "amsterdam", "netherlands", "golden-age"]
---

# Kings, Canals, and Coffee Houses (Part 2)

2023-07-20 · 55:34 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4191684359.mp3?updated=1729782338)

A city which played a fundamental role in the Dutch Golden Age and in the birth of the Dutch monarchy, Amsterdam has also stood in the avant-garde of European liberalism since the Second World War. Join Tom and Dominic on the second part of our walking tour through Amsterdam, as they look at the importance of its canals, the changing role of the Amsterdam Royal Palace, the Portuguese Synagogue …