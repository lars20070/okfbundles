---
type: Section
title: "Miracles, Money, and Mud (Part 1)"
description: "Episode 351: Amsterdam first gained prominence as a miraculous centre for pilgrimage."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "amsterdam", "netherlands", "golden-age"]
---

# Miracles, Money, and Mud (Part 1)

2023-07-17 · 41:11 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4666881212.mp3?updated=1729782312)

A city built on water, Amsterdam has often set the tone of European modernity. It first gained prominence as a miraculous centre for pilgrimage, and then stood out for its relationship with the Reformation, and for its role in the birth of modern capitalism. Join Tom and Dominic on part one of our tour of Amsterdam, as they take you on a journey through Dam Square, the birthplace of the Dutch …