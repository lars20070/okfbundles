---
type: Section
title: "England's Greatest Hero (Part 3)"
description: "Episode 693: Sir Francis Drake's remarkable life and adventures from obscure poverty."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, elizabeth-i, catholics, tudor, francis-drake]
---

# England's Greatest Hero (Part 3)

2026-08-02 · 1:16:40 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5069845329.mp3)

Why is Sir Francis Drake enshrined as one of England's greatest heroes? Where did he come from, and how did he rise to prominence and earn the adoration of Elizabeth I, from obscure poverty? And, why is he also such a controversial figure…? Join Tom and Dominic as they sail into the remarkable life and adventures of Sir Francis Drake. From his controversial piracy, and his explorations around the …
