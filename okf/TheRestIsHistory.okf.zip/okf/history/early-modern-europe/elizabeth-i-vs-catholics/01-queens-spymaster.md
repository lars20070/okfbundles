---
type: Section
title: "The Queen's Spymaster (Part 1)"
description: "Episode 691: How Elizabeth ruled England and kept her alive through her network of spies."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, elizabeth-i, catholics, tudor, spymaster]
---

# The Queen's Spymaster (Part 1)

2026-07-26 · 1:12:09 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8312620561.mp3)

How did Elizabeth I rule England? Why was she constantly in mortal peril in 1569? Who was Sir William Cecil, and why was he so crucial to her reign? And, how did his network of spies keep her alive, and England uninvaded…? Join Tom and Dominic as they discuss the secret war raging in the heart of Elizabeth I's Tudor England, the religious unrest flaming throughout Europe, and Elizabeth's master …
