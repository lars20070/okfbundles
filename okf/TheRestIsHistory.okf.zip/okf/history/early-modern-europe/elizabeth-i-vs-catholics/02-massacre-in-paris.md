---
type: Section
title: "A Massacre in Paris (Part 2)"
description: "Episode 692: The St Bartholomew's Day Massacre of 1572 and its impact on Elizabeth I's realm."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, elizabeth-i, catholics, tudor, massacre]
---

# A Massacre in Paris (Part 2)

2026-07-29 · 1:11:35 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4665799025.mp3)

What inspired the deadliest bloodbath of the Tudor age: the St Bartholomew's Day Massacre of 1572, in which protestants were slaughtered en masse? How did it drive Elizabeth I's spy master, Francis Walsingham, to repress all treasonous activity in her realm? And, what terrible treason was brewing in Rome…? Join Tom and Dominic as they discuss the St Bartholomew's Day Massacre, Sir Francis …
