# The Queen's Spymaster (Part 1)

## Episodes

* [The Queen's Spymaster (Part 1)](/history/early-modern-europe/elizabeth-i-vs-catholics/01-queens-spymaster.md) — Episode 691: How Elizabeth ruled England and kept her alive through her network of spies.
* [A Massacre in Paris (Part 2)](/history/early-modern-europe/elizabeth-i-vs-catholics/02-massacre-in-paris.md) — Episode 692: The St Bartholomew's Day Massacre of 1572 and its impact on Elizabeth I's realm.
* [England's Greatest Hero (Part 3)](/history/early-modern-europe/elizabeth-i-vs-catholics/03-englands-greatest-hero.md) — Episode 693: Sir Francis Drake's remarkable life and adventures from obscure poverty.
* [A Treacherous Conspiracy (Part 4)](/history/early-modern-europe/elizabeth-i-vs-catholics/04-treacherous-conspiracy.md) — Episode 694: Drake's return, revolts in Europe, Catholic unrest, and the plot to assassinate Elizabeth.
* [The Shadow War (Part 5)](/history/early-modern-europe/elizabeth-i-vs-catholics/05-shadow-war.md) — Episode 695: The high point of the Tudor Cold War with Spain, Holland, and the Catholic threat.
