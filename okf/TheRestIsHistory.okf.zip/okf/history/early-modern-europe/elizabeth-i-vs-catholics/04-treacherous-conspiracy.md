---
type: Section
title: "A Treacherous Conspiracy (Part 4)"
description: "Episode 694: Drake's return, revolts in Europe, Catholic unrest, and the plot to assassinate Elizabeth."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, elizabeth-i, catholics, tudor, conspiracy]
---

# A Treacherous Conspiracy (Part 4)

2026-08-05 · 1:12:34 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1627515087.mp3)

After ransacking Spanish treasure ships, would Elizabeth I betray Sir Francis Drake to her enemies? Who did she back in the French civil wars? And, with the help of English conspirators, would Mary Queen of Scots, incur a Spanish invasion, and see her rival Elizabeth assassinated? Join Tom and Dominic as they discuss Sir Francis Drake's return to England, revolts in Europe, Catholic unrest, and …
