---
type: Section
title: "The Shadow War (Part 5)"
description: "Episode 695: The high point of the Tudor Cold War with Spain, Holland, and the Catholic threat."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, elizabeth-i, catholics, tudor, shadow-war]
---

# The Shadow War (Part 5)

2026-08-09 · 1:01:55 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5637968455.mp3)

Who was the charismatic Sir Philip Sidney, a beloved but also suspect courtier to Elizabeth I? Why, in 1585, was England in such danger from a Spanish invasion? And, would Sydney, with his friend Sir Francis Drake, help to save their beloved queen? Join Tom and Dominic as they plunge into the high point of the Tudor Cold War: with Philip II brooding on war in Spain, Holland ablaze, and religious …
