---
type: Section
title: "The Storming of the Bastille (Part 5)"
description: "Episode 479: Violence and chaos at the Bastille."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "french-revolution", "bastille"]
---

# The Storming of the Bastille (Part 5)

2024-08-04 · 59:24 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5485693441.mp3?updated=1729780519)

"It was violence that made the revolution revolutionary". The storming of the Bastille is viewed by many across the world as a moment of celebration, when the French people were liberated from the shackles of tyranny and royal despotism. Yet, it was also a moment of horrific violence and chaos, culminating in countless acts of blunt, bloody murder. With a widespread sense of social unrest …
