---
type: Section
title: "Marie Antoinette (Part 1)"
description: "Episode 475: The queen whose name defined the French Revolution."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "french-revolution", "marie-antoinette"]
---

# Marie Antoinette (Part 1)

2024-07-28 · 55:51 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3119389535.mp3?updated=1729780273)

The French Revolution is one of the great seismic events of global history. A devouring conflagration of bloodshed, violence and utopianism, it changed France and then latterly the whole of Europe forever. Yet, amidst the panoply of colossal, colourful names that defined this cataclysmic event, few have endured as iconically as that of Marie Antoinette, the Queen of France, who has in many ways …
