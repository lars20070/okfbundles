# Marie Antoinette (Part 1)

## Episodes

* [Marie Antoinette (Part 1)](/history/early-modern-europe/french-revolution/01-marie-antoinette.md) — Episode 475: The queen whose name defined the French Revolution.
* [The Diamond Necklace Scandal (Part 2)](/history/early-modern-europe/french-revolution/02-the-diamond-necklace-scandal.md) — Episode 476: A scandal that became a decisive moment in the French Revolution.
* [The Violence Begins (Part 3)](/history/early-modern-europe/french-revolution/03-the-violence-begins.md) — Episode 477: What made the French Revolution the most important political event.
* [Showdown in Versailles (Part 4)](/history/early-modern-europe/french-revolution/04-showdown-in-versailles.md) — Episode 478: Storm, drought, and the path to bankruptcy in 1788.
* [The Storming of the Bastille (Part 5)](/history/early-modern-europe/french-revolution/05-the-storming-of-the-bastille.md) — Episode 479: Violence and chaos at the Bastille.
* [The Rights of Man (Part 6)](/history/early-modern-europe/french-revolution/06-the-rights-of-man.md) — Episode 480: The Declaration of the Rights of Man and utopian idealism.
* [The Women's March on Versailles (Part 7)](/history/early-modern-europe/french-revolution/07-the-womens-march-on-versailles.md) — Episode 481: The sections of the revolution at loggerheads.
* [The Royal Family Escapes (Part 8)](/history/early-modern-europe/french-revolution/08-the-royal-family-escapes.md) — Episode 482: Louis XVI feigning cooperation while torn by Catholicism.
* [The Marseillaise, Song of War (Part 5)](/history/early-modern-europe/french-revolution/09-the-marseillaise-song-of-war.md) — Episode 507: La Marseillaise and the fédérés from Marseille.
* [Massacre at the Palace (Part 4)](/history/early-modern-europe/french-revolution/10-massacre-at-the-palace.md) — Episode 506: Prussians threatening vengeance on the French royal family.
* [The Shadow of the Guillotine (Part 3)](/history/early-modern-europe/french-revolution/11-the-shadow-of-the-guillotine.md) — Episode 505: Executioners in revolutionary France.
* [War to the Death (Part 2)](/history/early-modern-europe/french-revolution/12-war-to-the-death.md) — Episode 504: The Gironde calling for war against Austria in 1792.
* [Bloodbath in Paris (Part 1)](/history/early-modern-europe/french-revolution/13-bloodbath-in-paris.md) — Episode 503: Revolutionary fervour engulfing the streets of Paris.
