---
type: Section
title: "Bloodbath in Paris (Part 1)"
description: "Episode 503: Revolutionary fervour engulfing the streets of Paris."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "french-revolution", "champ-de-mars"]
---

# Bloodbath in Paris (Part 1)

2024-10-13 · 1:03:05 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8447202194.mp3?updated=1729780235)

Welcome to Season 2 of The French Revolution! Revolutionary fervour threatens to engulf the streets of Paris, as demonstrators have gathered on the Champ de Mars to sign a petition demanding the removal of the King. Two days prior, the National Assembly had decreed that Louis XVI would remain King under a constitutional monarchy, even after his failed escape to Varennes, an inexcusable betrayal …
