---
type: Section
title: "The Marseillaise, Song of War (Part 5)"
description: "Episode 507: La Marseillaise and the fédérés from Marseille."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "french-revolution", "marseillaise"]
---

# The Marseillaise, Song of War (Part 5)

2024-10-24 · 46:01 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5535769124.mp3?updated=1729810871)

"Let us march! Let us march! May impure blood water our fields!" Written after the declaration of war against Austria in 1792, "La Marseillaise" was born in the provinces of France, away from the Parisian metropole, and immediately became popular as a unifying rallying cry against foreign invaders, and the enemies of the Revolution. It was the "fédérés" from Marseille, instrumental in the …
