---
type: Section
title: "The Women's March on Versailles (Part 7)"
description: "Episode 481: The sections of the revolution at loggerheads."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "french-revolution", "versailles"]
---

# The Women's March on Versailles (Part 7)

2024-08-07 · 58:37 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9783455254.mp3?updated=1729780566)

By the summer of 1789 the different sections of the Revolution were at loggerheads, and the recently created National Assembly riven in two. Both factions, the radicals on the left and the more moderate revolutionaries on the right, upheld different interpretations of how the new system of governance, so firmly rooted in the idea of 'la nation', should be organised, particularly as concerned the …
