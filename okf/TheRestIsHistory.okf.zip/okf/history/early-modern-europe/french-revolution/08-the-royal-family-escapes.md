---
type: Section
title: "The Royal Family Escapes (Part 8)"
description: "Episode 482: Louis XVI feigning cooperation while torn by Catholicism."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "french-revolution", "flight-to-varennes"]
---

# The Royal Family Escapes (Part 8)

2024-08-08 · 1:04:52 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3336151355.mp3?updated=1729780594)

Twelve months after the dramatic Women's March on Versailles, the Revolution proper was well into its stride, and while Paris overflowed with a sense of unbridled political freedom, the King and Queen were little more than prisoners in their echoing palace. For the past year Louis XVI had feigned cooperation with the National Assembly, all the while torn by his profound Catholicism and frozen by …
