---
type: Section
title: "Showdown in Versailles (Part 4)"
description: "Episode 478: Storm, drought, and the path to bankruptcy in 1788."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "french-revolution", "versailles"]
---

# Showdown in Versailles (Part 4)

2024-08-01 · 1:08:10 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4803391126.mp3?updated=1729780496)

In the summer of 1788, a monstrous storm swept across France, wiping out the crucial wheat harvest. With the nation already in the throes of political and financial calamity, this meteorological disaster - followed by an apocalyptic drought, and latterly the cruellest winter France had ever known - exacerbated the growing sense of catastrophe. With bankruptcy declared that August and unemployment …
