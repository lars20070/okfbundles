---
type: Section
title: "The Shadow of the Guillotine (Part 3)"
description: "Episode 505: Executioners in revolutionary France."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "french-revolution", "guillotine"]
---

# The Shadow of the Guillotine (Part 3)

2024-10-20 · 55:44 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1620539569.mp3?updated=1729780187)

During the "Ancien Regime", royal executioners held an unholy status, and would strike up fear in the crowds as they walked the streets of Paris. But with the Revolution, the role of executioners in society was reformed, and whilst they lost some of their privileges, they were ushered into to a new, universalist France. And as the Revolution brought forward more and more enemies of the state …
