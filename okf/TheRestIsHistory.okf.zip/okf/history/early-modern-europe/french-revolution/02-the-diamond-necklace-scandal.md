---
type: Section
title: "The Diamond Necklace Scandal (Part 2)"
description: "Episode 476: A scandal that became a decisive moment in the French Revolution."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "french-revolution", "marie-antoinette"]
---

# The Diamond Necklace Scandal (Part 2)

2024-07-29 · 51:58 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9914208350.mp3?updated=1729780305)

In August 1785 a shocking affair came to light which would prove so detrimental to the reputation and standing of the French King Louis XVI, and more especially his already unpopular wife, Queen Marie Antoinette, that it would become a decisive moment in the rising tide of the French Revolution. It concerned a gaudy but incalculably expensive diamond necklace commissioned by Louis XV for his …
