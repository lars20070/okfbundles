---
type: Section
title: "War to the Death (Part 2)"
description: "Episode 504: The Gironde calling for war against Austria in 1792."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "french-revolution"]
---

# War to the Death (Part 2)

2024-10-16 · 1:01:02 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3201191708.mp3?updated=1729780213)

"You have shaken off the yoke of your despots, but surely this was not to bend the knee before a foreign tyrant…" It's January 1792, and one of the largest factions in revolutionary France, the Gironde, is calling for war against Austria. The French people's hatred of Marie Antoinette has always fuelled suspicion of the Austrians, and at the same time, there has been constant, treacherous …
