---
type: Section
title: "The Violence Begins (Part 3)"
description: "Episode 477: What made the French Revolution the most important political event."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "french-revolution"]
---

# The Violence Begins (Part 3)

2024-07-31 · 1:00:21 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6535380991.mp3?updated=1729780334)

With seismic antecedents such as the Glorious Revolution in England and the American War of Independence, what was it about the French Revolution that saw it become arguably the most important episode in all early modern political history? And what unique combination of factors converged to unleash this colossal, world-shaking event; the paradigmatic example of a people trying to reshape their …
