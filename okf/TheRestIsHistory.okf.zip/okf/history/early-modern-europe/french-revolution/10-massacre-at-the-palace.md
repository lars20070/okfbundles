---
type: Section
title: "Massacre at the Palace (Part 4)"
description: "Episode 506: Prussians threatening vengeance on the French royal family."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "french-revolution", "tuileries"]
---

# Massacre at the Palace (Part 4)

2024-10-23 · 58:16 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9954902163.mp3?updated=1729780149)

The war between revolutionary France and the allied powers of Prussia and Austria has reached fever pitch, and in early August 1792, the latter party threaten a terrible vengeance on Paris should harm be done to the French royal family. But far from calming tensions, this threat puts the King, Marie Antoinette and their children in terrible danger. They've been kept in the Tuileries Palace since …
