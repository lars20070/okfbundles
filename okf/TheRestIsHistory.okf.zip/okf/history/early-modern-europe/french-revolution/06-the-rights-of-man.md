---
type: Section
title: "The Rights of Man (Part 6)"
description: "Episode 480: The Declaration of the Rights of Man and utopian idealism."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "french-revolution"]
---

# The Rights of Man (Part 6)

2024-08-05 · 58:42 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8413639265.mp3?updated=1729780546)

"Liberté, égalité, fraternité!" Alongside violence, the French Revolution is a story of principles and values. It is the ultimate intersection of brutality and Enlightenment idealism, as epitomised by the Fall of the Bastille. So too the creation and implementation of the Declaration of the Rights of Man - a totemic manifesto for the French state, which seemingly embodied a shockingly overt …
