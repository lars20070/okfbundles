---
type: Section
title: "South Korea: The Riddle of Hwang Jini"
description: "Episode 266: Join Tom and Dominic on their journey to the 16th century Korean peninsula."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "south-korea", "hwang-jini"]
---

# South Korea: The Riddle of Hwang Jini

2022-11-28 · 28:20 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1910695360.mp3?updated=1777394744)

Join Tom and Dominic on their journey to the 16th century Korean peninsula, as they discuss Hwang Jini - a gisaeng, poet, and entertainer - and her everlasting impact on Korean culture.
