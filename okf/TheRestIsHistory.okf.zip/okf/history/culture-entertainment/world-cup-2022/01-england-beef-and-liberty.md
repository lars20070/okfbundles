---
type: Section
title: "England: Beef and Liberty"
description: "Episode 286: Britain's most iconic dish was once - indisputably - Roast Beef."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "england", "world-cup", "food"]
---

# England: Beef and Liberty

2022-12-18 · 51:21 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5964129806.mp3?updated=1777394897)

England: Roast Beef and Liberty While it has now been dethroned by the mighty Tikka Masala and the moreish fish and chips, Britain's most iconic dish was once - indisputably - Roast Beef. In the final episode of this World Cup marathon, Tom and Dominic chart the dish's prominence over the years and how, as an affront to the French, it became a rallying point for British patriotism and …