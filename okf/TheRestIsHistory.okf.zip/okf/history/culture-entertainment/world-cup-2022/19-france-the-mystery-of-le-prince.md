---
type: Section
title: "France: The Mystery of Le Prince"
description: "Episode 278: In today's episode, Tom and Dominic explore the origins of the motion-picture camera."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "france", "le-prince"]
---

# France: The Mystery of Le Prince

2022-12-10 · 27:50 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1101934476.mp3?updated=1777394642)

In today's episode, Tom and Dominic explore the origins of the motion-picture camera, a device invented by "gentle giant" Louis Le Prince, who's œuvre spanned from working with pots and pans to photographing Queen Victoria or Gladstone.
