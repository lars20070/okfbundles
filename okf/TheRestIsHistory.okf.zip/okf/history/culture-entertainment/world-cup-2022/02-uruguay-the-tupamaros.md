---
type: Section
title: "Uruguay: The Tupamaros"
description: "Episode 261: In 1963, with the influence of the Cuban Revolution strong in South America."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "uruguay", "tupamaros"]
---

# Uruguay: The Tupamaros

2022-11-23 · 40:13 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1539968794.mp3?updated=1777394589)

In 1963, with the influence of the Cuban Revolution strong in South America, the left wing guerrilla group the Tupamaros emerged. Listen to tales of kidnappings, shootings, imprisonment and torture in the Tupamaros' quest for political power.
