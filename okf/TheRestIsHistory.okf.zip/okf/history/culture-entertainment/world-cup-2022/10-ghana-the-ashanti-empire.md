---
type: Section
title: "Ghana: The Ashanti Empire"
description: "Episode 269: On today's World Cup episode, Tom and Dominic discuss the Ashanti Empire."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "ghana", "ashanti-empire"]
---

# Ghana: The Ashanti Empire

2022-12-01 · 47:55 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3638102749.mp3?updated=1777394992)

On today's World Cup episode, Tom and Dominic discuss the Ashanti Empire. Tune in to hear about the Anglo-Ashanti wars, the Golden Stool, the role of Robert Baden-Powell and much, much more.
