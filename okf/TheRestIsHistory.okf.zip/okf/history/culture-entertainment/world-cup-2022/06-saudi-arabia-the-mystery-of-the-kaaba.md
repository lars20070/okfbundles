---
type: Section
title: "Saudi Arabia: The Mystery of the Kaaba"
description: "Episode 265: Join Tom and Dominic for their World Cup episode on Saudi Arabia."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "saudi-arabia", "kaaba"]
---

# Saudi Arabia: The Mystery of the Kaaba

2022-11-27 · 51:48 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1528147434.mp3?updated=1777394934)

Join Tom and Dominic for their World Cup episode on Saudi Arabia, where they discuss 'the most famous structure in global Islam' - the Kaaba in Mecca.
