---
type: Section
title: "Belgium: History's Greatest Artist"
description: "Episode 271: Who is the greatest artist of all time?"
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "belgium", "art"]
---

# Belgium: History's Greatest Artist

2022-12-03 · 43:01 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1331750756.mp3?updated=1777394200)

Who is the greatest artist of all time? Join Tom and Dominic as Belgian historian Bart van Loo puts forward the case for the hyper-realistic and highly influential art of early Northern Renaissance painter Jan van Eyck.
