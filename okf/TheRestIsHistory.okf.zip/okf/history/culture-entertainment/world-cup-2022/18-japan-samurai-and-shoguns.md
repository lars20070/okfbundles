---
type: Section
title: "Japan: Samurai and Shoguns"
description: "Episode 277: In today's episode, Tom and Dominic discuss the history of Japan through six characters."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "japan", "samurai"]
---

# Japan: Samurai and Shoguns

2022-12-09 · 1:02:14 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3851919583.mp3?updated=1777394956)

In today's episode, Tom and Dominic discuss the history of Japan through six characters, with leading cultural historian of Japan, Chris Harding, as they cover feuding lords and buddhist monks, both world wars, Japanese medieval poetry, Manga culture, and much, much more.
