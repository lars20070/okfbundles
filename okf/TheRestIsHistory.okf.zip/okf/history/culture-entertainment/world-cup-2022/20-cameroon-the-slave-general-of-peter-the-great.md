---
type: Section
title: "Cameroon: The Slave General of Peter the Great"
description: "Episode 279: In today's World Cup special on Cameroon, Tom and Dominic tell the fascinating story."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "cameroon", "peter-the-great"]
---

# Cameroon: The Slave General of Peter the Great

2022-12-11 · 35:38 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8175760918.mp3?updated=1777394916)

In today's World Cup special on Cameroon, Tom and Dominic tell the fascinating story of "probably the most famous Cameroonian to become a Russian General". Learn about the extraordinary life of Major-General Abram Petrovich Gannibal, the great-grandfather of Russia's most famous poet, Alexander Pushkin.
