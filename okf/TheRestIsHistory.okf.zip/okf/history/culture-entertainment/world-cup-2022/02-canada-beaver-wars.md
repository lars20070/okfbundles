---
type: Section
title: "Canada: Beaver Wars"
description: "Episode 285: Join Tom and Dominic as they discuss the illustrious history of the beaver."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "canada", "world-cup", "beaver"]
---

# Canada: Beaver Wars

2022-12-17 · 46:19 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6084067740.mp3?updated=1777394215)

Canada: Beaver Wars Join Tom and Dominic as they discuss the illustrious history of the beaver. This story intertwines these small bundles of fur with tribal wars, the monopoly of the Hudson's Bay Company, and Grey Owl - the original beaver conservationist. Join The Rest Is History Club (www.restishistorypod.com) for ad-free listening to the full archive, weekly bonus episodes, live streamed …