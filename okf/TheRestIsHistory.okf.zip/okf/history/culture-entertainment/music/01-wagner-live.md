---
type: Section
title: "Wagner: LIVE at the Royal Albert Hall"
description: "Episode 631: Richard Wagner — revolutionary artist or egotist mired in scandal?"
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, music, wagner]
---

# Wagner: LIVE at the Royal Albert Hall

2026-01-01 · 1:13:00 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7214350401.mp3?updated=1766537584)

Was Richard Wagner a revolutionary artist who reshaped music forever, or an egotists mired in scandal, whose dangerous ideas were inseparable from the operas he created? How did the legendary worlds encapsulated in his bombastic music - featuring gods, heroes, and monsters - become entangled with politics and power? And, did Wagner inspire Hitler and the Nazis…? Join Tom and Dominic at the Royal …
