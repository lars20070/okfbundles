# Wagner: LIVE at the Royal Albert Hall

## Episodes

* [Wagner: LIVE at the Royal Albert Hall](/history/culture-entertainment/music/01-wagner-live.md) — Episode 631: Richard Wagner — revolutionary artist or egotist mired in scandal?
* [Tchaikovsky: LIVE at the Royal Albert Hall](/history/culture-entertainment/music/02-tchaikovsky-live.md) — Episode 630: Pyotr Ilyich Tchaikovsky's complex origins and inner conflicts.
* [The Christmas Truce](/history/culture-entertainment/music/03-christmas-truce.md) — Episode 629: The Christmas Truce of 1914 — myth or reality?
