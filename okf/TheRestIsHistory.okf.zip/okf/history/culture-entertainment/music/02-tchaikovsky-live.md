---
type: Section
title: "Tchaikovsky: LIVE at the Royal Albert Hall"
description: "Episode 630: Pyotr Ilyich Tchaikovsky's complex origins and inner conflicts."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, music, tchaikovsky]
---

# Tchaikovsky: LIVE at the Royal Albert Hall

2025-12-29 · 1:19:28 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2445190309.mp3?updated=1766537673)

What are the complex origins of Russia's most renowned composer, Pyotr Ilyich Tchaikovsky? What inner conflicts and private contradictions lay behind his romantic music, and how did these struggles shape it? And, what dark secrets lie hidden beneath Tchaikovsky's sweeping, lyrical melodies…? Join Tom and Dominic at the Royal Albert Hall, featuring the renowned Philharmonia Orchestra, conducted by …
