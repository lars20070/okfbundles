---
type: Section
title: "The Christmas Truce"
description: "Episode 629: The Christmas Truce of 1914 — myth or reality?"
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, world-war-i, christmas-truce]
---

# The Christmas Truce

2025-12-25 · 58:42 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5393732684.mp3?updated=1766065378)

Did the Christmas Truce - which saw a number of unofficial ceasefires between the combatants of the First World War, during the Christmas of 1914 - really occur, or was it a myth? What is the real story behind this legendary event? And, did German and British soldiers really play football across no-man's land? Join Dominic and Tom as they delve into the history behind one of the most famous and …
