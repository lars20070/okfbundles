---
type: Section
title: "God Save the King (Part 2)"
description: "Episode 678: The creation of Britain's legendary national anthem."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, britain, anthem, national-anthem]
---

# God Save the King (Part 2)

2026-06-10 · 1:11:09 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2603959218.mp3)

How did the Napoleonic Wars contribute to the enshrinement of the British national anthem? What are the Jacobite origins of this legendary melody? And, which British monarch was it written for? Join Tom and Dominic as they discuss the creation of Britain's legendary national anthem, God Save the King, and its mysterious composer.
