# The Song Hitler Stole (Part 3)

## Episodes

* [The Song Hitler Stole (Part 3)](/history/culture-entertainment/national-anthems/01-germany-the-song-hitler-stole.md) — Episode 679: The history of Germany and its various different national anthems.
* [God Save the King (Part 2)](/history/culture-entertainment/national-anthems/02-god-save-the-king.md) — Episode 678: The creation of Britain's legendary national anthem.
* [The Star-Spangled Banner (Part 1)](/history/culture-entertainment/national-anthems/03-star-spangled-banner.md) — Episode 677: The War of 1812 and the origin of America's national anthem.
