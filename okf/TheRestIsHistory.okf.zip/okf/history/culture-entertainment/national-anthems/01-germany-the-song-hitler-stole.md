---
type: Section
title: "The Song Hitler Stole (Part 3)"
description: "Episode 679: The history of Germany and its various different national anthems."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, germany, anthem, national-anthem]
---

# The Song Hitler Stole (Part 3)

2026-06-14 · 1:13:11 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6217148052.mp3)

Why is the German national anthem the most controversial of all? Is it true that it is Austrian in origin? And, what happened when Germany split after the Second World War? Did it perhaps lead to an absolute banger in the form of East Germany's new anthem..? Join Tom and Dominic as they discuss the history of Germany and its various different anthems.
