---
type: Section
title: "The Star-Spangled Banner (Part 1)"
description: "Episode 677: The War of 1812 and the origin of America's national anthem."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, usa, anthem, national-anthem]
---

# The Star-Spangled Banner (Part 1)

2026-06-07 · 1:10:44 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7890467734.mp3)

How did the War of 1812 result in America's national anthem, the Star Spangled Banner? Who came up with it? And, why does this origin story make the anthem so controversial? Join Dominic and Tom as they launch into the first episode of their Football World Cup special, with the story behind America's national anthem, and its secret story.
