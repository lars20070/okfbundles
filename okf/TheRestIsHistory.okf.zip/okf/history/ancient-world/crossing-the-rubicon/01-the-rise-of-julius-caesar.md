---
type: Section
title: "The rise of Julius Caesar"
description: "Episode 134: Julius Caesar crossed the banks of the Rubicon river with his legion on this day (maybe) over 2000 years ago."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "julius-caesar", "rome", "rubicon"]
---

# The rise of Julius Caesar

2022-01-10 · 39:32 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1501343977.mp3?updated=1777394760)

Julius Caesar crossed the banks of the Rubicon river with his legion on this day (maybe) over 2000 years ago. In the first of a two-parter, Tom explains how Caesar rose to become powerful enough to take the decision that would eventually lead to him becoming the sole 'dictator' of Rome. If you can't wait to find out how the story ends, sign up for the Rest Is History Club to access the full …