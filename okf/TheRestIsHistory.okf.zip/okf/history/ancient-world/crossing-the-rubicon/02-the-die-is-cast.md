---
type: Section
title: "The die is cast"
description: "Episode 135: Now ready to take on Pompey and the Senate, Julius Caesar must take the final step and cross over into Italy with his legion."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "julius-caesar", "rome", "rubicon"]
---

# The die is cast

2022-01-11 · 37:20 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1750785311.mp3?updated=1777394859)

Now ready to take on Pompey and the Senate, Julius Caesar must take the final step and cross over into Italy with his legion.