# The rise of Julius Caesar

## Episodes

* [The rise of Julius Caesar](/history/ancient-world/crossing-the-rubicon/01-the-rise-of-julius-caesar.md) — Episode 134: Julius Caesar crossed the banks of the Rubicon river with his legion on this day (maybe) over 2000 years ago.
* [The die is cast](/history/ancient-world/crossing-the-rubicon/02-the-die-is-cast.md) — Episode 135: Now ready to take on Pompey and the Senate, Julius Caesar must take the final step and cross over into Italy with his legion.
