---
type: Section
title: "The Murder of Julius Caesar"
description: "Episode 304: 'He was trapped - he couldn't get up. There was blood everywhere.'"
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "julius-caesar", "rome"]
---

# The Murder of Julius Caesar

2023-02-13 · 57:44 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3561951089.mp3?updated=1777394177)

"He was trapped - he couldn't get up. There was blood everywhere. The faces were coming closer, the knives rose and fell. And then, to his relief, he saw Brutus." One of the most iconic deaths in history, Caesar's assassination is the brutal climax to an impressive series of victories: from triumphing during the First Triumvirate, to outlasting Pompey and Cato, gaining Imperator status and …