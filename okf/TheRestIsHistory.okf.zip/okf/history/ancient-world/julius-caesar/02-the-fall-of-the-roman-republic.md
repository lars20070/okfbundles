---
type: Section
title: "The Fall of the Roman Republic"
description: "Episode 305: The bloody and chaotic aftermath of the death of Julius Caesar."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "julius-caesar", "rome"]
---

# The Fall of the Roman Republic

2023-02-16 · 56:31 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6995332578.mp3?updated=1777394203)

In this second episode on perhaps the most notorious assasination in world history, Tom and Dominic look at the bloody and chaotic aftermath of the death of Julius Caesar. They discuss the fate of the senators turned assassins, their failure to restore the institutions of the republic, and the ensuing civil war that brought about the first emperor of Rome.