# The Murder of Julius Caesar

## Episodes

* [The Murder of Julius Caesar](/history/ancient-world/julius-caesar/01-the-murder-of-julius-caesar.md) — Episode 304: 'He was trapped - he couldn't get up. There was blood everywhere.'
* [The Fall of the Roman Republic](/history/ancient-world/julius-caesar/02-the-fall-of-the-roman-republic.md) — Episode 305: The bloody and chaotic aftermath of the death of Julius Caesar.
