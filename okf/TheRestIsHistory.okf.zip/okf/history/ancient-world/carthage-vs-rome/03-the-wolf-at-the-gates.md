---
type: Section
title: "The Wolf at the Gates (Part 3)"
description: "Episode 423: How Rome rose to become one of the most ruthless powers of all time."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "carthage", "rome", "punice-wars"]
---

# The Wolf at the Gates (Part 3)

2024-02-26 · 49:29 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2669872613.mp3?updated=1708964126)

"Every man is the architect of his own destiny" Long before Rome reigned over the Mediterranean, there was Carthage: the supreme predator of Antiquity. But how did Rome rise to become one of the most ruthless powers of all time, united in cold, disciplined violence? And what was it about the Roman people that made them the greatest threat Carthage would ever face? Whilst the Carthaginians …