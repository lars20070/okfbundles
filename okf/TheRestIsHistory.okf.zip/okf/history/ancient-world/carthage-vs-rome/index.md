# Lords of the Sea (Part 1)

## Episodes

* [Lords of the Sea (Part 1)](/history/ancient-world/carthage-vs-rome/01-lords-of-the-sea.md) — Episode 421: The origins of the supposedly decadent and sinister city of Carthage.
* [Rise of a Superpower (Part 2)](/history/ancient-world/carthage-vs-rome/02-rise-of-a-superpower.md) — Episode 422: The mysterious, wealthy and glamorous city of Carthage.
* [The Wolf at the Gates (Part 3)](/history/ancient-world/carthage-vs-rome/03-the-wolf-at-the-gates.md) — Episode 423: How Rome rose to become one of the most ruthless powers of all time.
* [Carthage vs. Rome: Total War (Part 4)](/history/ancient-world/carthage-vs-rome/04-total-war.md) — Episode 424: The clash between Rome and Carthage that erupted in 263 BC.
