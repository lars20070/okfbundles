---
type: Section
title: "Lords of the Sea (Part 1)"
description: "Episode 421: The origins of the supposedly decadent and sinister city of Carthage."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "carthage", "rome", "punice-wars"]
---

# Lords of the Sea (Part 1)

2024-02-19 · 58:17 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1311066631.mp3?updated=1708310361)

"Carthago delenda est." Carthage must be destroyed: this was the rallying cry of Cato the Elder, the senator endlessly pushing for war against Rome's sworn enemy, Carthage. But what are the origins of this supposedly decadent and sinister city, and did the Carthaginians really sacrifice their children? Starting as a crafty, seafaring people called the Phoenicians, a mighty mercantile civilisation …