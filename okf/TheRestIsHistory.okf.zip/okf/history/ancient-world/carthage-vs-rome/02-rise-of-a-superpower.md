---
type: Section
title: "Rise of a Superpower (Part 2)"
description: "Episode 422: The mysterious, wealthy and glamorous city of Carthage."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "carthage", "rome", "punice-wars"]
---

# Rise of a Superpower (Part 2)

2024-02-22 · 53:31 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7946297144.mp3?updated=1708537688)

"An aristocratic republic, secret and well-ordered, where individuals are subject to the harsh laws of the austere and disciplined rich…" The mysterious, wealthy and glamorous city of Carthage flourished between the ninth and second centuries BC, becoming one of the greatest naval and mercantile powers in the world. By the sixth century BC the Carthaginians were a force to be reckoned with …