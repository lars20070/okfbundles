---
type: Section
title: "A Family of Blood (Part 2)"
description: "Episode 458: The discovery of Troy by Heinrich Schliemann and the legend of Helen."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "helen-of-troy", "trojan-war"]
---

# A Family of Blood (Part 2)

2024-06-05 · 49:04 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7255356131.mp3?updated=1717361381)

In 1870 the German archaeologist Heinrich Schliemann - a man of remarkable energy, desperately fascinated with Helen of Troy - discovered in Turkey the burnt remains of what he claimed to be the legendary city of Troy, and with it, a horde of gold and treasure which he attributed to Helen. Following this breakthrough, he went in search of another, more obscure prize: Mycenae, one of the most …