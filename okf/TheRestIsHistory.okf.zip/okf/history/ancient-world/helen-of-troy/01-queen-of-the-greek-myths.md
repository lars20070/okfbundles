---
type: Section
title: "Queen of the Greek Myths (Part 1)"
description: "Episode 457: Helen of Troy's remarkable birth and her infamous love affair with Paris."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "helen-of-troy", "trojan-war"]
---

# Queen of the Greek Myths (Part 1)

2024-06-02 · 52:07 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7058693674.mp3?updated=1717377472)

The story of Helen of Troy, her remarkable birth and her infamous love affair with Paris, the Trojan prince, resounds across the centuries. A figure of condemnation, pity and tragedy, her beauty set in motion the most legendary literary conflict of all time: the Trojan Wars. Yet, Helen's story reaches far beyond Homer and the Iliad. From her godly parentage and the egg from which she hatched, to …