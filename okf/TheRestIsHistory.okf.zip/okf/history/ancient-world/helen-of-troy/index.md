# Queen of the Greek Myths (Part 1)

## Episodes

* [Queen of the Greek Myths (Part 1)](/history/ancient-world/helen-of-troy/01-queen-of-the-greek-myths.md) — Episode 457: Helen of Troy's remarkable birth and her infamous love affair with Paris.
* [A Family of Blood (Part 2)](/history/ancient-world/helen-of-troy/02-a-family-of-blood.md) — Episode 458: The discovery of Troy by Heinrich Schliemann and the legend of Helen.
