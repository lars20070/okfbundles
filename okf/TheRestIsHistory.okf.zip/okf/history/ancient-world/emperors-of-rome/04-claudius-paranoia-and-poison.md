---
type: Section
title: "Claudius, Paranoia and Poison (Part 4)"
description: "Episode 537: Claudius rising to the fore after Caligula's assassination."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "rome", "emperors"]
---

# Claudius, Paranoia and Poison (Part 4)

2025-02-06 · 1:06:10 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8484602825.mp3?updated=1738860427)

Following the bloody assassination of the twenty-eight year old Emperor Caligula, Rome found herself without a leader. Who then should fill the enormous power vacuum left by the death of an emperor? Should Rome return to a Republic? Then, one overlooked candidate - a scion of the hallowed family of Augustus long lurking in the wings of imperial power - unexpectedly rose to the fore: Claudius …
