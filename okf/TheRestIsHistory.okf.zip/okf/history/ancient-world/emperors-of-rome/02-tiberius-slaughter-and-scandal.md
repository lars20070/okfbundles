---
type: Section
title: "Tiberius, Slaughter and Scandal (Part 2)"
description: "Episode 535: The controversial Emperor Tiberius and Suetonius's biography."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "rome", "emperors"]
---

# Tiberius, Slaughter and Scandal (Part 2)

2025-01-30 · 58:52 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6029756405.mp3?updated=1738542150)

The Roman historian Suetonius' biography of the controversial Emperor Tiberius is one of his most shocking and salacious, condemning Tiberius to infamy. But was Tiberius really the perverted monster Suetonius would have us believe? Born of Rome's most illustrious family and a sacred bloodline - the Claudians - Tiberius' mother Livia was unceremoniously taken from his father while she carried him …
