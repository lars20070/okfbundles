# Sex Secrets of the Caesars (Part 1)

## Episodes

* [Sex Secrets of the Caesars (Part 1)](/history/ancient-world/emperors-of-rome/01-sex-secrets-of-the-caesars.md) — Episode 534: Suetonius's The Lives of the Caesars and the biographies of early emperors.
* [Tiberius, Slaughter and Scandal (Part 2)](/history/ancient-world/emperors-of-rome/02-tiberius-slaughter-and-scandal.md) — Episode 535: The controversial Emperor Tiberius and Suetonius's biography.
* [Caligula, Incest and Insanity (Part 3)](/history/ancient-world/emperors-of-rome/03-caligula-incest-and-insanity.md) — Episode 536: Caligula as a byword for sexual degeneracy, cruelty and corruption.
* [Claudius, Paranoia and Poison (Part 4)](/history/ancient-world/emperors-of-rome/04-claudius-paranoia-and-poison.md) — Episode 537: Claudius rising to the fore after Caligula's assassination.
