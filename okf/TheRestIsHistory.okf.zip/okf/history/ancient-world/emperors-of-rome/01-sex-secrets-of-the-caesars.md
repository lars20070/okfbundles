---
type: Section
title: "Sex Secrets of the Caesars (Part 1)"
description: "Episode 534: Suetonius's The Lives of the Caesars and the biographies of early emperors."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "rome", "emperors"]
---

# Sex Secrets of the Caesars (Part 1)

2025-01-27 · 53:41 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3696933602.mp3?updated=1738008610)

The Roman historian Suetonius' The Lives of the Caesars, written during the early imperial period of the Roman Empire, is a seminal biography covering the biographies of the early emperors of Rome, during two spectacular centuries of Roman history. Delving deep into the personal lives of the caesars and sparing no detail, no matter how prurient, pungent, explicit or salacious, it vividly captures …
