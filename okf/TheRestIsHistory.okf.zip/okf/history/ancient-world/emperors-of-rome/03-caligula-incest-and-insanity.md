---
type: Section
title: "Caligula, Incest and Insanity (Part 3)"
description: "Episode 536: Caligula as a byword for sexual degeneracy, cruelty and corruption."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "rome", "emperors"]
---

# Caligula, Incest and Insanity (Part 3)

2025-02-03 · 1:05:46 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6260105026.mp3?updated=1738534057)

"Enough of the Princeps, what remains to be described, is the monster..." The Roman emperor Caligula endures as one of the most notorious figures in not only Roman history, but the history of the world. Famed as a byword for sexual degeneracy, cruelty and corruption, the account of his life written by the Roman historian Suetonius has, above all, enshrined him as such for posterity. Throughout …
