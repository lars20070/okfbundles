---
type: Section
title: "The Riddle of the Sphinx (Part 2)"
description: "Episode 603: Oedipus, the cursed king of Thebes."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, greek-myths, ancient-greece]
---

# The Riddle of the Sphinx (Part 2)

2025-09-24 · 1:05:34 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9108845593.mp3?updated=1758732761)

What is the story behind the writing of Oedipus, the notorious king of Thebes who murdered his father and unwittingly married his mother? Was it based on a real historical event? What are Oedipus' cursed mythic origins in Thebes? Who was Sophocles, the legendary Greek playwright? Why was the play a product of 5th century Athens; its rivalries with other greek city states such as Thebes, a raging …
