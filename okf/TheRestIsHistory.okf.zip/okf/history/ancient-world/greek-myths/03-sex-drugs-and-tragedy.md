---
type: Section
title: "Sex, Drugs & Tragedy (Part 3)"
description: "Episode 604: Dionysus, god of ecstasy and the Bacchae."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, greek-myths, ancient-greece]
---

# Sex, Drugs & Tragedy (Part 3)

2025-09-28 · 1:04:34 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7123647684.mp3?updated=1759100706)

Who was Dionysus, the son of Zeus, and Greek god of ecstasy, revelry and madness? Why was he so central to the ancient Greeks? What is the story of the Bacchae, the play in which a young man is ripped apart by the handmaidens of the goddess Artemis? What did it mean to be a Bacchae, one of the followers of Dionysus, and what shocking acts did it entail? Why were female cults like this believed to …
