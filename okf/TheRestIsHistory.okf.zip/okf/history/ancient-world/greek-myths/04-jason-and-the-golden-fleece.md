---
type: Section
title: "Jason & The Quest for the Golden Fleece (Part 4)"
description: "Episode 605: Jason and the Argonauts' trials for the Golden Fleece."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, greek-myths, ancient-greece]
---

# Jason & The Quest for the Golden Fleece (Part 4)

2025-10-01 · 1:03:02 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3067620137.mp3?updated=1759342659)

What terrifying trials did Jason and the Argonauts have to overcome to win the famous Golden Fleece from a fire-breathing dragon, in one of the greatest greek myths of all time? When and where does this thrilling story come from? How does it tie together the tales of Odysseus, Orpheus, Achilles and Circe? Is there any historical evidence for the story of Jason and the Argonauts? What are the …
