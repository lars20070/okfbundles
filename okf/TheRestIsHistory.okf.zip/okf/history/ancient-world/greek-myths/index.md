# Zeus, King of the Gods (Part 1)

## Episodes

* [Zeus, King of the Gods (Part 1)](/history/ancient-world/greek-myths/01-zeus-king-of-the-gods.md) — Episode 602: The mythic origins of Zeus and the Olympians.
* [The Riddle of the Sphinx (Part 2)](/history/ancient-world/greek-myths/02-the-riddle-of-the-sphinx.md) — Episode 603: Oedipus, the cursed king of Thebes.
* [Sex, Drugs & Tragedy (Part 3)](/history/ancient-world/greek-myths/03-sex-drugs-and-tragedy.md) — Episode 604: Dionysus, god of ecstasy and the Bacchae.
* [Jason & The Quest for the Golden Fleece (Part 4)](/history/ancient-world/greek-myths/04-jason-and-the-golden-fleece.md) — Episode 605: Jason and the Argonauts' trials for the Golden Fleece.
