---
type: Section
title: "Zeus, King of the Gods (Part 1)"
description: "Episode 602: The mythic origins of Zeus and the Olympians."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, greek-myths, ancient-greece]
---

# Zeus, King of the Gods (Part 1)

2025-09-21 · 1:01:17 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4871750364.mp3?updated=1758288034)

What are the mythic origins of Zeus, King of the Olympians, and the other Greek gods? From what period did the earliest of the Greek myths derive? Who was Hesiod - alongside Homer, the greatest of the Greek poets, and the father of European literature - who first recorded Zeus' story? When was the golden age of Greek myth? Who were the Titans, and why were they consigned to the fiery pit of …
