---
type: Section
title: "To the Ends of the Earth (Part 4)"
description: "Episode 502: Boudicca's uprising and the process of Romanisation in Britain."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "rome", "britain", "boudicca"]
---

# To the Ends of the Earth (Part 4)

2024-10-09 · 59:47 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1970351222.mp3?updated=1728515096)

In the aftermath of Boudicca's uprising, the Romans felt they could not withdraw from the British Isles. They sent their most competent fighters and leaders to suppress the indigenous Britons in the south. As the Druids of Wales were defeated, and the resistant Caledonians were massacred, the process of Romanisation in Britain began. London became the urbanised imperial capital, and the Roman …
