---
type: Section
title: "The Empire Strikes Back (Part 2)"
description: "Episode 500: Claudius launches a two-pronged attack on the British Isles."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "rome", "britain", "claudius"]
---

# The Empire Strikes Back (Part 2)

2024-10-02 · 56:52 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3137178317.mp3?updated=1727886683)

Viewed as an idiot by those around him, Claudius felt the need to prove himself. In the century since Caesar had invaded Britain, the mythology surrounding the island had taken hold in Roman imaginations. Stories of sea monsters, terrifying Druids, and human sacrifice by barbarians, instilled fear into the imperial legions. But Claudius was determined, and launched a two-pronged attack on the …
