---
type: Section
title: "Boudicca's Reign of Blood (Part 3)"
description: "Episode 501: Boudicca as Rome's supervillain and freedom fighter."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "rome", "britain", "boudicca"]
---

# Boudicca's Reign of Blood (Part 3)

2024-10-06 · 54:23 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3128836892.mp3?updated=1728255952)

"Two cities were sacked, eighty thousand of the Romans and of their allies perished, and the island was lost to Rome. Moreover, all this ruin was brought upon by a woman…" Few figures have statues dedicated to them in the towns they incinerated. But Boudicca was no ordinary figure. With a name that means "she who brings victory", Boudicca was Rome's supervillain. She was a freedom fighter who …
