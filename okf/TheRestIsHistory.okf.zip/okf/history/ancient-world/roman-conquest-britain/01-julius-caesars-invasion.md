---
type: Section
title: "Julius Caesar's Invasion (Part 1)"
description: "Episode 499: Caesar launches an invasion of Britain as part of his Gallic Wars campaign."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "rome", "britain", "julius-caesar"]
---

# Julius Caesar's Invasion (Part 1)

2024-09-29 · 48:48 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9770560726.mp3?updated=1727648896)

Julius Caesar saw the Britons as brutal savages. Yet the Romans romanticised their lack of civilisation, deeming them as untainted by Mediterranean luxury. In 55 BC, after sending scouts along the Kentish coast, Caesar launched an invasion of the island as part of his Gallic Wars campaign. After a disastrous first attempt marred by storms, the "menacing horde of barbarians" of the English Home …
