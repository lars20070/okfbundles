---
type: Section
title: "Hero of the Trojan Horse (Part 1)"
description: "Episode 687: Homer's Odyssey — the legendary story and its historical precedents."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, ancient-greece, odyssey, homer]
---

# Hero of the Trojan Horse (Part 1)

2026-07-12 · 1:11:48 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2393125423.mp3)

How does The Odyssey, one of the greatest stories of all time, unfold? What historical events may it be based on? And, where might Odysseus, the hero of Homer's epic, have faced his various trials in real life? Join Tom and Dominic as they unravel the legendary story of Homer's Odyssey, and its historical precedents.
