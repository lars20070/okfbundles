# Hero of the Trojan Horse (Part 1)

## Episodes

* [Hero of the Trojan Horse (Part 1)](/history/ancient-world/odyssey/01-hero-of-the-trojan-horse.md) — Episode 687: Homer's Odyssey — the legendary story and its historical precedents.
* [Return of the King (Part 2)](/history/ancient-world/odyssey/02-return-of-the-king.md) — Episode 688: Odysseus' dramatic conclusion and return to Penelope and her suitors.
