---
type: Section
title: "Return of the King (Part 2)"
description: "Episode 688: Odysseus' dramatic conclusion and return to Penelope and her suitors."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, ancient-greece, odyssey, homer]
---

# Return of the King (Part 2)

2026-07-15 · 1:05:48 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2882541084.mp3)

How did the second half of Odysseus' long journey home to Ithaca play out? What does the epic's account of the Olympian gods indicate about Ancient Greek religion? And, how did Odysseus finally make it home to Penelope and her suitors? Join Tom and Dominic as they reach the dramatic conclusion of Homer's Odyssey, and the story of Odysseus' dreadful return…
