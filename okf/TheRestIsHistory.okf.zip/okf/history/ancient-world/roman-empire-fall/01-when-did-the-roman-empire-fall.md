---
type: Section
title: "When did the Roman Empire fall?"
description: "Episode 156: Tom and Dominic explore what Edward Gibbon called 'the greatest, perhaps, and most awful scene in the history of mankind'."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "roman-empire", "fall-of-rome"]
---

# When did the Roman Empire fall?

2022-02-28 · 54:11 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4933356600.mp3?updated=1777394939)

Tom and Dominic explore what Edward Gibbon called "the greatest, perhaps, and most awful scene in the history of mankind": the decline and fall of the Roman Empire. Join The Rest Is History Club for ad-free listening to the full archive, weekly bonus episodes, live streamed shows and access to an exclusive chatroom community.