---
type: Section
title: "Byzantium and the Ghosts of Rome"
description: "Episode 157: What happened to the Roman Empire after its fall? In the second of two episodes."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "roman-empire", "byzantium"]
---

# Byzantium and the Ghosts of Rome

2022-03-01 · 48:19 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1014708592.mp3?updated=1777394971)

What happened to the Roman Empire after its fall? In the second of two episodes, Tom and Dominic discuss where Rome endured, how its ghost still haunts 21st century geopolitics, and which member of the British Royal Family Tom thinks is the last true Roman! Join The Rest Is History Club for ad-free listening to the full archive, weekly bonus episodes, live streamed shows and access to an …