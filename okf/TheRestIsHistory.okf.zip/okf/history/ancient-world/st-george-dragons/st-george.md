---
type: Section
title: "St George: Dragon-Slayer"
description: "Episode 462: The historical truth of Saint George and the dragon."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "saint-george"]
---

# St George: Dragon-Slayer

2024-06-19 · 50:07 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5334319363.mp3?updated=1718815298)

The image of Saint George astride his horse, sword and spear in hand, slaying a dragon, is one of the most iconic iconographical spectacles of all time. But what was the historical truth of this deeply mythologised figure? The conventional take on his story is well known: once, long ago, there lived a pagan king who refused to honour the one God. As punishment, a terrible dragon was sent to …
