# Dragons

## Episodes

* [Dragons](/history/ancient-world/st-george-dragons/dragons.md) — Episode 461: The legend of the dragon and its enduring resonance.
* [St George: Dragon-Slayer](/history/ancient-world/st-george-dragons/st-george.md) — Episode 462: The historical truth of Saint George and the dragon.
