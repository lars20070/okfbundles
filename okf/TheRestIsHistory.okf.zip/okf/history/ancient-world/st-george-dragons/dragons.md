---
type: Section
title: Dragons
description: "Episode 461: The legend of the dragon and its enduring resonance."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "dragons"]
---

# Dragons

2024-06-16 · 54:16 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6416738853.mp3?updated=1718583039)

"When dragons flew to war… everything burned. I do not wish to rule over a kingdom of ash and bone." Dragons - the most compelling of mythical beasts - are one of the most vivid creations of all human imagination, and their enduring resonance is captivatingly displayed by their role in George R.R. Martin's House of the Dragon and Game of Thrones. But how did the legend of the dragon, prominent …
