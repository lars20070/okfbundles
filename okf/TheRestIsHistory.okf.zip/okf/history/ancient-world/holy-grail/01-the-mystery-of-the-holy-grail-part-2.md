---
type: Section
title: "The Mystery of the Holy Grail (Part 2)"
description: "Episode 346: A deeply mysterious object which doesn't appear in the Bible, was the Holy Grail really the chalice used by Jesus during the Last Supper?"
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "holy-grail", "medieval"]
---

# The Mystery of the Holy Grail (Part 2)

2023-06-29 · 54:22 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9518077570.mp3?updated=1777394178)

"Who drinks the water I shall give him, will have a spring inside him welling up for eternal life." A deeply mysterious object which doesn't appear in the Bible, was the Holy Grail really the chalice used by Jesus during the Last Supper, and the very cup that caught his blood at the crucifixion? Or is it merely a symbol representing Christ's bloodline? Join Tom and Dominic as they discuss the …