---
type: Section
title: "Raiders of the Lost Ark (Part 1)"
description: "Episode 345: The most important object in the universe, the Ark of the Covenant has fuelled stories for millennia."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "holy-grail", "ark-of-the-covenant"]
---

# Raiders of the Lost Ark (Part 1)

2023-06-26 · 57:47 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1189467433.mp3?updated=1777394791)

The most important object in the universe, but also a somewhat invisible presence in the Bible, the Ark of the Covenant has fuelled stories for millennia, whether as a weapon of mass destruction, an elaborate filling cabinet for sacred laws, or as the very location where God and man meet. Join Tom and Dominic as they delve into the mysteries surrounding the Ark of the Covenant, its creation, its …