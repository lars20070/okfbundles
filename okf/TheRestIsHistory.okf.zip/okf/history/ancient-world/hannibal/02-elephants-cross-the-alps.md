---
type: Section
title: "Elephants Cross the Alps (Part 2)"
description: "Episode 569: Hannibal's decision to cross the Alps in 218 BC."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, hannibal, carthage, rome]
---

# Elephants Cross the Alps (Part 2)

2025-05-28 · 58:28 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8313087633.mp3?updated=1784112214)

Why did Hannibal choose to cross the Alps with his elephants in 218 BC, when invading Rome? Was it a brilliant stratagem or a military disaster? What was the secret to the Roman Republic's growing military success at this time? And, why did Carthage, under Hannibal's formidable generalship, believe they were more than capable of taking on the might of Rome? Join Tom and Dominic as they charge …
