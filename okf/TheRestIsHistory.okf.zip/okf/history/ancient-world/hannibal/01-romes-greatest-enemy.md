---
type: Section
title: "Rome's Greatest Enemy (Part 1)"
description: "Episode 568: Hannibal, Hamilcar's son, and the third century BC rivalry."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, hannibal, carthage, rome]
---

# Rome's Greatest Enemy (Part 1)

2025-05-25 · 55:36 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7606824410.mp3?updated=1748000703)

Who was Hannibal, the flawed but brilliant Carthaginian general? What makes Rome vs Carthage in the third century BC one of the most totemic ancient rivalries of all time? How did Hamilcar, father of Hannibal, restore the fortunes of Carthage following their devastating defeat to the Romans in 264 BC? And, what personal tragedy spurred Hannibal on to seize his destiny by the reins, take command …
