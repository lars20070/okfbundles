---
type: Section
title: "Roman Bloodbath at Cannae (Part 4)"
description: "Episode 571: Hannibal's brilliant tactics at the Battle of Cannae."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, hannibal, carthage, rome]
---

# Roman Bloodbath at Cannae (Part 4)

2025-06-04 · 58:26 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2444504695.mp3?updated=1749055048)

How did the Battle of Cannae - one of the most important battles of all time for Ancient Rome, with a whole Empire at stake, and a reputation that had reverberated across the centuries - in 216 BC, unfold? What brilliant tactics did Hannibal adopt in order to overcome the Roman killing machine, with its vast numbers and relentless soldiers? Why did so many men die in such horrific circumstances? …
