---
type: Section
title: "The Invasion of Italy (Part 3)"
description: "Episode 570: The clash at the Trebbia River in 218 BC."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, hannibal, carthage, rome]
---

# The Invasion of Italy (Part 3)

2025-06-01 · 56:00 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2952414067.mp3?updated=1784112251)

How did Hannibal achieve the remarkable feat of crossing the Alps with his army, and elephants? How many of his men survived the treacherous journey? Was it worth sacrificing so much of his army in order to fight the Romans in Italy? And, what unfolded during the first great clash between Hannibal and Rome, at dawn, by the Trebbia River, in 218 BC…? Join Tom and Dominic as they discuss Hannibal's …
