# Rome's Greatest Enemy (Part 1)

## Episodes

* [Rome's Greatest Enemy (Part 1)](/history/ancient-world/hannibal/01-romes-greatest-enemy.md) — Episode 568: Hannibal, Hamilcar's son, and the third century BC rivalry.
* [Elephants Cross the Alps (Part 2)](/history/ancient-world/hannibal/02-elephants-cross-the-alps.md) — Episode 569: Hannibal's decision to cross the Alps in 218 BC.
* [The Invasion of Italy (Part 3)](/history/ancient-world/hannibal/03-the-invasion-of-italy.md) — Episode 570: The clash at the Trebbia River in 218 BC.
* [Roman Bloodbath at Cannae (Part 4)](/history/ancient-world/hannibal/04-roman-bloodbath-at-cannae.md) — Episode 571: Hannibal's brilliant tactics at the Battle of Cannae.
