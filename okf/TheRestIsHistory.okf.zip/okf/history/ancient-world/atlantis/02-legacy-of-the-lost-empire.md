---
type: Section
title: "Legacy of the Lost Empire (Part 2)"
description: "Episode 315: From claims that the alphabet was originated by Atlantians to the Nazis co-opting Atlantis."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "atlantis", "greece", "plato"]
---

# Legacy of the Lost Empire (Part 2)

2023-03-23 · 53:48 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2807981945.mp3?updated=1777394247)

From claims that the alphabet was originated by Atlantians, Francis Bacon using the story as a model of utopia, to the Nazis co-opting Atlantis as the birthplace of the Aryan race, everyone seems to have wanted a slice of the Atlantian pie. Join Tom and Dominic as they explore the academics and the amateurs who lay claim to discovering the real Atlantis.