---
type: Section
title: "The Legend (Part 1)"
description: "Episode 314: Majestic palaces, untold riches, and indeterminable power... the story of Atlantis is a tale as old as time."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "atlantis", "greece", "plato"]
---

# The Legend (Part 1)

2023-03-20 · 55:13 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4735672898.mp3?updated=1777394202)

Majestic palaces, untold riches, and indeterminable power... the story of Atlantis is a tale as old as time. But is there really any truth behind the ancient tome, or was Plato simply trying his hand at political satire? Join Tom and Dominic as they discuss the origins of the legend of Atlantis.