# The Legend (Part 1)

## Episodes

* [The Legend (Part 1)](/history/ancient-world/atlantis/01-the-legend.md) — Episode 314: Majestic palaces, untold riches, and indeterminable power... the story of Atlantis is a tale as old as time.
* [Legacy of the Lost Empire (Part 2)](/history/ancient-world/atlantis/02-legacy-of-the-lost-empire.md) — Episode 315: From claims that the alphabet was originated by Atlantians to the Nazis co-opting Atlantis.
