---
type: Section
title: "The History (Part 2)"
description: "Episode 288: Join Tom and Dominic for the second of two episodes on 'Historical Jesus'."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "jesus", "christianity"]
---

# The History (Part 2)

2022-12-22 · 1:02:12 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4776258433.mp3?updated=1777394247)

Join Tom and Dominic for the second of two episodes on 'Historical Jesus'. They discuss scepticism around his existence, the theories about resurrection and crucifixion, and the role of his disciples.