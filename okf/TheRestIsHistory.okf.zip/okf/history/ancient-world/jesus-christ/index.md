# The Mystery (Part 1)

## Episodes

* [The Mystery (Part 1)](/history/ancient-world/jesus-christ/01-the-mystery.md) — Episode 287: Jesus Christ - The Mystery.
* [The History (Part 2)](/history/ancient-world/jesus-christ/02-the-history.md) — Episode 288: Join Tom and Dominic for the second of two episodes on 'Historical Jesus'.
