# Ancient World

## Series

* [The Legend (Part 1)](/history/ancient-world/atlantis/) — Series about The Legend (Part 1)
* [Lords of the Sea (Part 1)](/history/ancient-world/carthage-vs-rome/) — Series about Lords of the Sea (Part 1)
* [Carthage at the Gates (Part 1)](/history/ancient-world/carthage/) — Series about Carthage at the Gates (Part 1)
* [The rise of Julius Caesar](/history/ancient-world/crossing-the-rubicon/) — Series about The rise of Julius Caesar
* [Sex Secrets of the Caesars (Part 1)](/history/ancient-world/emperors-of-rome/) — Series about Sex Secrets of the Caesars (Part 1)
* [Zeus, King of the Gods (Part 1)](/history/ancient-world/greek-myths/) — Series about Zeus, King of the Gods (Part 1)
* [Rome's Greatest Enemy (Part 1)](/history/ancient-world/hannibal/) — Series about Rome's Greatest Enemy (Part 1)
* [Queen of the Greek Myths (Part 1)](/history/ancient-world/helen-of-troy/) — Series about Queen of the Greek Myths (Part 1)
* [The Mystery of the Holy Grail (Part 2)](/history/ancient-world/holy-grail/) — Series about The Mystery of the Holy Grail (Part 2)
* [The Mystery (Part 1)](/history/ancient-world/jesus-christ/) — Series about The Mystery (Part 1)
* [The Murder of Julius Caesar](/history/ancient-world/julius-caesar/) — Series about The Murder of Julius Caesar
* [Hero of the Trojan Horse (Part 1)](/history/ancient-world/odyssey/) — Series about Hero of the Trojan Horse (Part 1)
* [Julius Caesar's Invasion (Part 1)](/history/ancient-world/roman-conquest-britain/) — Series about Julius Caesar's Invasion (Part 1)
* [When did the Roman Empire fall?](/history/ancient-world/roman-empire-fall/) — Series about When did the Roman Empire fall?
* [Dragons](/history/ancient-world/st-george-dragons/) — Series about Dragons
