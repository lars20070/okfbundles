---
type: Section
title: "Henry V's Invasion of France (Part 1)"
description: "Episode 487: Henry V takes up the English claim to the French throne."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "hundred-years-war", "henry-v"]
---

# Henry V's Invasion of France (Part 1)

2024-08-25 · 56:46 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7554933021.mp3?updated=1724590135)

"Once more unto the breach, dear friends. Once more, we'll close the wall up with our English dead […] And upon this charge, cry God for Harry, England and St. George!" Such was Henry V's call to arms at the siege of Harfleur, as written by Shakespeare. The son of the Usurper King, Henry V has decided to take up the English claim to the French throne, thereby putting an end to the truce that had …
