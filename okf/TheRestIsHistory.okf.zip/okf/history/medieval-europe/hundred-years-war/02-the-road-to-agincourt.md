---
type: Section
title: "The Road to Agincourt (Part 2)"
description: "Episode 488: Henry V sets sail for France with 15,000 ships."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "hundred-years-war", "henry-v", "agincourt"]
---

# The Road to Agincourt (Part 2)

2024-08-28 · 51:38 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2110427983.mp3?updated=1724841234)

On the 11th of August 1415, King Henry V of England - an austere, pious, thoughtful and terrifying warlord in only his late-twenties - set sail for France. He embarked in the largest ship ever built on English soil at the head of some 15,000 ships, his nobles, brothers and hordes of Welsh longbow-men in tow. Two days later, they made land, and their target: the Port of Harfleur, a nest of …
