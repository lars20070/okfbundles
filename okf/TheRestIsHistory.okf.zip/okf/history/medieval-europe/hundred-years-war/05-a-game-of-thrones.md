---
type: Section
title: "A Game of Thrones (Part 1)"
description: "Episode 318: Dynastic turmoil, inconvenient treaties with Scotland, tales of knights, longbows and the golden age of chivalry."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "hundred-years-war", "england", "france"]
---

# A Game of Thrones (Part 1)

2023-04-03 · 51:18 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5584156008.mp3?updated=1777394199)

Dynastic turmoil, inconvenient treaties with Scotland, tales of knights, longbows and the golden age of chivalry. In a time of chaos across Europe, England, a minor power of the time, takes on the mighty kingdom of France. Join Tom and Dominic to learn how the Hundred Years' War began.