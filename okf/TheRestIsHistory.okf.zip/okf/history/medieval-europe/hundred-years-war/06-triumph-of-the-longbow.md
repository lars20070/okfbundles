---
type: Section
title: "Triumph of the Longbow (Part 2)"
description: "Episode 319: State of the art military technology, blind battle commanders, iconic kingly lines."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "hundred-years-war", "england", "france"]
---

# Triumph of the Longbow (Part 2)

2023-04-06 · 54:22 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3100937638.mp3?updated=1777394182)

State of the art military technology. Blind battle commanders. Iconic kingly lines. Tom and Dominic continue to delve into the 100 Years' War, as they patriotically explore the mighty battles of Sluys and Crécy.