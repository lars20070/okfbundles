# The Hundred Years' War

## Episodes

* [Henry V's Invasion of France (Part 1)](/history/medieval-europe/hundred-years-war/01-henry-vs-invasion-of-france.md) — Episode 487: Henry V takes up the English claim to the French throne.
* [The Road to Agincourt (Part 2)](/history/medieval-europe/hundred-years-war/02-the-road-to-agincourt.md) — Episode 488: Henry V sets sail for France with 15,000 ships.
* [Bloodbath at Agincourt (Part 3)](/history/medieval-europe/hundred-years-war/03-bloodbath-at-agincourt.md) — Episode 489: The most totemic battle in English history.
* [England Triumphant (Part 4)](/history/medieval-europe/hundred-years-war/04-england-triumphant.md) — Episode 490: Henry V stands victorious after Agincourt.
* [A Game of Thrones (Part 1)](/history/medieval-europe/hundred-years-war/05-a-game-of-thrones.md) — Episode 318: Dynastic turmoil, inconvenient treaties with Scotland, tales of knights, longbows and the golden age of chivalry.
* [Triumph of the Longbow (Part 2)](/history/medieval-europe/hundred-years-war/06-triumph-of-the-longbow.md) — Episode 319: The next phase of the Hundred Years' War.
* [The Black Prince (Part 3)](/history/medieval-europe/hundred-years-war/07-the-black-prince.md) — Episode 320: The legendary English commander.
* [A Storm of Swords (Part 4)](/history/medieval-europe/hundred-years-war/08-a-storm-of-swords.md) — Episode 321: The final phase of the Hundred Years' War.
