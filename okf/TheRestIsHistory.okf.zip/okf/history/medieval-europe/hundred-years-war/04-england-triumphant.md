---
type: Section
title: "England Triumphant (Part 4)"
description: "Episode 490: Henry V stands victorious after Agincourt."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "hundred-years-war", "agincourt"]
---

# England Triumphant (Part 4)

2024-09-04 · 55:06 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2692942762.mp3?updated=1725452804)

St Crispin's day, 1415: Henry V stands victorious, after a tremendous defeat of the French forces at the Battle of Agincourt. He is just about to make a historic speech which will be retold by Shakespeare nearly two centuries later. There are mounds of bodies, too many dead for the chroniclers to count. Those who escaped the bloodshed have been taken prisoner back to England, including the young …
