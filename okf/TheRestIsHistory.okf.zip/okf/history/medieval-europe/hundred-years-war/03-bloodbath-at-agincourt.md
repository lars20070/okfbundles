---
type: Section
title: "Bloodbath at Agincourt (Part 3)"
description: "Episode 489: The most totemic battle in English history."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "hundred-years-war", "agincourt"]
---

# Bloodbath at Agincourt (Part 3)

2024-09-01 · 54:10 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5834061192.mp3?updated=1725037473)

"We few, we happy few, we band of brothers". The Battle of Agincourt in 1415 endures as perhaps the most totemic battle in the whole of English history. Thanks in part to Shakespeare's masterful Henry V, the myths and legends of that bloody day echo across time, forever enshrining the young Henry as the greatest warrior king England had ever known. So too the enduring idea of the English as …
