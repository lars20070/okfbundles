---
type: Section
title: "The Black Prince (Part 3)"
description: "Episode 320: As the spectre of the Black Death haunts Europe, a more tangible foe terrorises the French king: the Black Prince."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "hundred-years-war", "england", "france"]
---

# The Black Prince (Part 3)

2023-04-10 · 53:35 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6004693022.mp3?updated=1777394213)

As the spectre of the Black Death haunts Europe, a more tangible foe terrorises the French king and his subjects: the Black Prince, Edward of Woodstock. After his great victory leading the vanguard at Crécy, he continues with his regular incursions into France, before eventually being cornered by John II and his vast army at Poitiers in 1356: has the Black Prince's luck finally run out?