---
type: Section
title: "A Storm of Swords (Part 4)"
description: "Episode 321: The Black Prince has gained lands in Aquitaine and Gascony through his brutal and thorough attacks."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "hundred-years-war", "england", "france"]
---

# A Storm of Swords (Part 4)

2023-04-13 · 49:42 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1570526345.mp3?updated=1777394905)

The Black Prince has gained lands in Aquitaine and Gascony through his brutal and thorough attacks. But faced with financial difficulties, sickness, and a notable family death, can he retain his territories? Listen to Tom and Dominic as they conclude this epic four-part series on The 100 Years War.