---
type: Section
title: "Heroine in Chains (Part 3)"
description: "Episode 634: Charles VII's coronation and Joan's capture by the English."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, france, joan-of-arc]
---

# Heroine in Chains (Part 3)

2026-01-12 · 1:03:11 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6235222836.mp3?updated=1768217618)

How was Charles VII, with the help of Joan of Arc, able to fight his way to Reims to be crowned in the ancient seat of French kings? Why was she able to continually defeat the formidable soldiers of England, in battle? And, how was Joan's legendary ascent finally brought shatteringly down, as she fell into the hands of her dreaded English enemies…? Join Tom and Dominic as the discuss the apex of …
