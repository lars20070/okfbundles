---
type: Section
title: "For Fear of the Flames (Part 4)"
description: "Episode 635: Joan's imprisonment, trial, and fiery end."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, france, joan-of-arc]
---

# For Fear of the Flames (Part 4)

2026-01-15 · 1:02:30 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8113477235.mp3?updated=1768476106)

What were the harsh conditions of Joan of Arc's imprisonment, at the hands of her English captors? How did Joan's trial unfold, and with what was she charged? And, would Joan confess at the last moment in order to save her own life…? Join Tom and Dominic as they discuss the terrible culmination of the life of Joan of Arc, as she endured imprisonment, stood on trial for her life, fought bravely …
