---
type: Section
title: "Saviour of France (Part 2)"
description: "Episode 633: Joan's plan to crown the Dauphin and save France from the English."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, france, joan-of-arc]
---

# Saviour of France (Part 2)

2026-01-08 · 55:59 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5406937184.mp3?updated=1767891416)

How did a young, uneducated peasant girl dressed in men's clothing, Joan of Arc, plan to crown the son of the mad and feeble Charles VI, the King of all France, and save them from the English? What happened when she met with the Dauphin? And, what happened when, in April 1429, Joan of Arc finally road to war, dressed in a suit of white armour, and clasping her mighty sword…? Join Tom and Dominic …
