---
type: Section
title: "Warrior Maid (Part 1)"
description: "Episode 632: Joan of Arc, the French maid who saved France during the Hundred Years' War."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, france, joan-of-arc]
---

# Warrior Maid (Part 1)

2026-01-05 · 1:09:16 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6592271090.mp3?updated=1767622369)

What are the origins of the legendary Joan of Arc, the famous French maid who saved France from the English during the Hundred Years' War, dressed all the while in men's clothes? Why is hers one of the most remarkable stories of all time? And, was she really under divine influence when, as only a teenager, she demanded to be taken from her humble French village to Charles of Valois, the would-be …
