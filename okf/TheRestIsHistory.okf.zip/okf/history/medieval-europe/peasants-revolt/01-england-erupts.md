---
type: Section
title: "England Erupts (Part 1)"
description: "Episode 413: An uprising broke out in southern England in 1381."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "peasants-revolt"]
---

# England Erupts (Part 1)

2024-01-29 · 52:26 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8198769595.mp3?updated=1706483816)

By the late 14th century, England was in decline. Already weakened by the Hundred Years' War, both Edward III and his son, the Black Prince, had died, leaving the country in a perilous state. Richard II, the new king, was only a child. With the poor facing increasingly harsh poll taxes, and distrust of the nobility growing among them, an uprising broke out in southern England in 1381. It was led …