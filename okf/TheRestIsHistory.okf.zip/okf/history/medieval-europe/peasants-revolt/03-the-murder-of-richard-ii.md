---
type: Section
title: "The Murder of Richard II (Part 3)"
description: "Episode 415: Richard II, son of the dashing Black Prince, became King at only ten."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "richard-ii", "england"]
---

# The Murder of Richard II (Part 3)

2024-02-05 · 53:57 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6435684837.mp3?updated=1706885536)

"For within the hollow crown that rounds the hollow temple of a king..." Richard II, son of the dashing Black Prince and grandson of Edward III, became King of England at only ten years old. By the age of fifteen he had overcome one of the most terrifying threats to the English Crown up to that point: the Peasants' Revolt of 1381. In the ensuing years, Richard's rule became increasingly …