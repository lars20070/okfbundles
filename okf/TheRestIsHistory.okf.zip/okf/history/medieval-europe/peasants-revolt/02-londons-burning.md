---
type: Section
title: "London's Burning (Part 2)"
description: "Episode 414: Wat Tyler and the rebel army entering London on 13 June 1381."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "peasants-revolt", "wat-tyler"]
---

# London's Burning (Part 2)

2024-02-01 · 50:42 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6726049231.mp3?updated=1706795730)

On the 13th of June 1381, the rebel army of English peasants, led by Wat Tyler, entered London and brought chaos, death and destruction upon some of the city's most important buildings and figures, among them the Archbishop of Canterbury and his home at Lambeth Palace. Within the Tower of London, the 14 year-old Richard II and his government still cowered, with the rebels demanding that Richard's …