# England Erupts (Part 1)

## Episodes

* [England Erupts (Part 1)](/history/medieval-europe/peasants-revolt/01-england-erupts.md) — Episode 413: An uprising broke out in southern England in 1381.
* [London's Burning (Part 2)](/history/medieval-europe/peasants-revolt/02-londons-burning.md) — Episode 414: Wat Tyler and the rebel army entering London on 13 June 1381.
* [The Murder of Richard II (Part 3)](/history/medieval-europe/peasants-revolt/03-the-murder-of-richard-ii.md) — Episode 415: Richard II, son of the dashing Black Prince, became King at only ten.
