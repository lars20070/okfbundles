---
type: Section
title: "The Princes in the Tower Part 2"
description: "Episode 139: Who killed the Princes in the Tower? The inspiration behind Shakespeare's Richard III, their murder remains one of the greatest mysteries in English history."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "princes-in-the-tower", "tudor"]
---

# The Princes in the Tower Part 2

2022-01-18 · 58:10 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4685691538.mp3?updated=1777394945)

Who killed the Princes in the Tower? The inspiration behind Shakespeare's Richard III, their murder remains one of the greatest mysteries in English history. In the second of two episodes, all eyes turn to Richard III, prime suspect in the disappearance of Edward IV's sons. Tom and Dominic discuss whether Richard likely did kill his nephews, potential other suspects, and whether it was a matter …