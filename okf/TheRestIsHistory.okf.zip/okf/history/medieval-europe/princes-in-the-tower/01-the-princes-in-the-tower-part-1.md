---
type: Section
title: "The Princes in the Tower Part 1"
description: "Episode 138: Who killed the Princes in the Tower? The inspiration behind Shakespeare's Richard III, their murder is one of the greatest mysteries in English history."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "princes-in-the-tower", "tudor"]
---

# The Princes in the Tower Part 1

2022-01-17 · 49:24 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6274021473.mp3?updated=1777394752)

Who killed the Princes in the Tower? The inspiration behind Shakespeare's Richard III, their murder is one of the greatest mysteries in English history. In the first of two episodes, we start with the princes' father, Edward IV. Tom and Dominic discuss the remarkable parallels between Edward IV and his grandson, Henry VIII, and why Edward's brother, Duke of Clarence, is certainly not a friend of …