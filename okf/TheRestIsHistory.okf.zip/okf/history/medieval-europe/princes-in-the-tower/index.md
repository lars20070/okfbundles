# The Princes in the Tower Part 1

## Episodes

* [The Princes in the Tower Part 1](/history/medieval-europe/princes-in-the-tower/01-the-princes-in-the-tower-part-1.md) — Episode 138: Who killed the Princes in the Tower? The inspiration behind Shakespeare's Richard III, their murder is one of the greatest mysteries in English history.
* [The Princes in the Tower Part 2](/history/medieval-europe/princes-in-the-tower/02-the-princes-in-the-tower-part-2.md) — Episode 139: Who killed the Princes in the Tower? The inspiration behind Shakespeare's Richard III, their murder remains one of the greatest mysteries in English history.
