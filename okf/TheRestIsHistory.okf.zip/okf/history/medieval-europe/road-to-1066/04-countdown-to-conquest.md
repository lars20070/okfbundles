---
type: Section
title: "Countdown to Conquest (Part 4)"
description: "Episode 551: Harold Godwinson and the Godwins' rise to power."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "1066", "godwins"]
---

# Countdown to Conquest (Part 4)

2025-03-27 · 59:33 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9351236299.mp3?updated=1743507297)

In the triumvirate of 1066, William of Normandy, Harald Hardrada, and Harold Godwinson, the latter has above all endured as one of the great heroes of English history. But how did he become the short-lived King during that tumultuous year? The answer lies in his formidable family, the Godwins. Often symbolised as the last of the Anglo-Saxons, their stratospheric rise to power was engineered by …
