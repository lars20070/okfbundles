# Anglo-Saxon Apocalypse (Part 1)

## Episodes

* [Anglo-Saxon Apocalypse (Part 1)](/history/medieval-europe/road-to-1066/01-anglo-saxon-apocalypse.md) — Episode 548: The true nature of the events leading to the Battle of Hastings.
* [Revenge of the Vikings (Part 2)](/history/medieval-europe/road-to-1066/02-revenge-of-the-vikings.md) — Episode 549: Sweyn Forkbeard and the Danes seeking revenge after St Brice's Day Massacre.
* [Rise of the Normans (Part 3)](/history/medieval-europe/road-to-1066/03-rise-of-the-normans.md) — Episode 550: William the Bastard and the forging of Normandy.
* [Countdown to Conquest (Part 4)](/history/medieval-europe/road-to-1066/04-countdown-to-conquest.md) — Episode 551: Harold Godwinson and the Godwins' rise to power.
