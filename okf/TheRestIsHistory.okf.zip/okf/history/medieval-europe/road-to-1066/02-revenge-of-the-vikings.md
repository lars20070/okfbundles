---
type: Section
title: "Revenge of the Vikings (Part 2)"
description: "Episode 549: Sweyn Forkbeard and the Danes seeking revenge after St Brice's Day Massacre."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "1066", "vikings"]
---

# Revenge of the Vikings (Part 2)

2025-03-20 · 1:04:36 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2312975985.mp3?updated=1742408238)

Following the bloody St Brice's Day Massacre, of the 13th of November 1002, which saw King Æthelred brutally exterminating the Danes from England, the Vikings were hungry for revenge. None more so than the terrifying Scandinavian King, Sweyn Forkbeard. Having capitalised on his famous father, Harold Bluetooth's unification of Norway and Denmark, through his aggressive christianisation of the …
