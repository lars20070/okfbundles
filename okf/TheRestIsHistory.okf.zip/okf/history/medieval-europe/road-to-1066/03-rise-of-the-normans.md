---
type: Section
title: "Rise of the Normans (Part 3)"
description: "Episode 550: William the Bastard and the forging of Normandy."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "1066", "normans"]
---

# Rise of the Normans (Part 3)

2025-03-24 · 57:42 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9316865693.mp3?updated=1742557768)

Born into a world of treachery, violence and death, William of Normandy defied all expectations, forging a legacy that lasts to this day. Born out of wedlock and dismissed as an upstart, he was originally known as William the Bastard. Inheriting the Duchy of Normandy at just eight years old, William was faced with betrayal, bloodshed, and anarchy. From the restless Normans, who expanded across …
