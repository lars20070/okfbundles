---
type: Section
title: "Anglo-Saxon Apocalypse (Part 1)"
description: "Episode 548: The true nature of the events leading to the Battle of Hastings."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "1066", "norman-conquest"]
---

# Anglo-Saxon Apocalypse (Part 1)

2025-03-17 · 58:05 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9632339286.mp3?updated=1742156513)

The Norman Conquest of 1066, culminating in the legendary Battle of Hastings, is perhaps the greatest turning point in the history of the English nation. It was a year that changed the fate of England forever, forging empires, and settling continents. And yet, despite its infamy and significance, the true nature of those totemic events are often forgotten. So what happened in the build up to the …
