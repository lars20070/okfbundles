---
type: Section
title: "The Shadows of War (Part 1)"
description: "Episode 554: The three candidates for the English throne on the eve of Edward the Confessor's death."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "1066", "norman-conquest"]
---

# The Shadows of War (Part 1)

2025-04-06 · 1:01:09 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1461163139.mp3?updated=1744035271)

Why is 1066 the most important year in English history? Who were the three main candidates vying for the English throne on the eve of Edward the Confessor's death? And how did the coronation of one of them on the 14th of October 1066 trigger one of the most famous invasions of all time? Join Tom and Dominic as they launch into the dramatic series of events, at the dawn of 1066, that sparked the …
