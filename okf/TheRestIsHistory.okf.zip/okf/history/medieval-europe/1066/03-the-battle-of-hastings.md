---
type: Section
title: "The Battle of Hastings (Part 3)"
description: "Episode 556: The Battle of Hastings on 14 October 1066."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "1066", "norman-conquest"]
---

# The Battle of Hastings (Part 3)

2025-04-13 · 57:01 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3522014441.mp3?updated=1744371038)

Following King Harold Godwinson's climactic victory at the Battle of Stanford Bridge, and the death of Harald Hardrada, what did he do when news reached him that William of Normandy's army had landed further south? How did the two armies finally come together for one of the most totemic clashes of all time, on the morning of the 14th of October 1066? What exactly unfolded during the infamous …
