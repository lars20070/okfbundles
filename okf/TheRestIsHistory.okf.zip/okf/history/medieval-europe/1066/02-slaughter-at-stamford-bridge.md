---
type: Section
title: "Slaughter at Stamford Bridge (Part 2)"
description: "Episode 555: Harold Godwinson vs Harald Hardrada at Stamford Bridge."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "1066", "norman-conquest"]
---

# Slaughter at Stamford Bridge (Part 2)

2025-04-09 · 1:09:27 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1524879968.mp3?updated=1744220170)

In the tumultuous climax of 1066, why was Harold's very own brother Tostig the first of the mighty foes he had to face? How did Harald Hardrada then launch his invasion of England, and how much resistance did he initially receive? And, what unfolded at the bloody battle of Stamford Bridge, in which Harold Godwinson and Harald Hardrada, two terrible kings, faced off at long last? Join Tom and …
