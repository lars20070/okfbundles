# The Shadows of War (Part 1)

## Episodes

* [The Shadows of War (Part 1)](/history/medieval-europe/1066/01-the-shadows-of-war.md) — Episode 554: The three candidates for the English throne on the eve of Edward the Confessor's death.
* [Slaughter at Stamford Bridge (Part 2)](/history/medieval-europe/1066/02-slaughter-at-stamford-bridge.md) — Episode 555: Harold Godwinson vs Harald Hardrada at Stamford Bridge.
* [The Battle of Hastings (Part 3)](/history/medieval-europe/1066/03-the-battle-of-hastings.md) — Episode 556: The Battle of Hastings on 14 October 1066.
* [The Norman Conquest (Part 4)](/history/medieval-europe/1066/04-the-norman-conquest.md) — Episode 557: William the Conqueror's new reign.
