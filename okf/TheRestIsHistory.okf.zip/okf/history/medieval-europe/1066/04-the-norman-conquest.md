---
type: Section
title: "The Norman Conquest (Part 4)"
description: "Episode 557: William the Conqueror's new reign."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "1066", "norman-conquest"]
---

# The Norman Conquest (Part 4)

2025-04-16 · 1:03:47 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5156716826.mp3?updated=1744847594)

What happened in the aftermath of the Battle of Hastings? What horrors did William the Conqueror have to inflict upon his Anglo Saxon subjects in order to consolidate his new realm? And, what role did castles, the Harrowing of the North, and the Doomsday Book play in the creation of a new England? Join Tom and Dominic as they discuss William the Conquerer's new reign in the wake of the Battle of …
