---
type: Section
title: "Treason in Modern Britain (Part 2)"
description: "Episode 249: Join Tom and Dominic for the second part of their exploration of the history of treason."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "treason", "britain"]
---

# Treason in Modern Britain (Part 2)

2022-11-03 · 53:58 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2159531504.mp3?updated=1729783868)

Join Tom and Dominic for the second part of their exploration of the history of treason. How has the 1351 treason act impacted Britain and the world since the 17th century?
