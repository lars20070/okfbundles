---
type: Section
title: "Medieval Treason (Part 1)"
description: "Episode 248: Join Tom and Dominic at the National Archives as they explore the history of treason in Britain."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "treason", "medieval"]
---

# Medieval Treason (Part 1)

2022-10-31 · 52:29 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9532907553.mp3?updated=1729783899)

Join Tom and Dominic at the National Archives as they explore the history of treason in Britain, going right back to the 1351 treason act. How has treason changed since its inception? Why are traitors hanged, drawn, and quartered?
