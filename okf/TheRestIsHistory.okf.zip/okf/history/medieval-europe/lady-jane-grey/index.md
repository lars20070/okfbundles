# The Nine Days' Queen (Part 1)

## Episodes

* [The Nine Days' Queen (Part 1)](/history/medieval-europe/lady-jane-grey/01-the-nine-days-queen.md) — Episode 293: Edward VI is dead - but who will succeed him on the throne?
* [The Axe Falls (Part 2)](/history/medieval-europe/lady-jane-grey/02-the-axe-falls.md) — Episode 294: Reigning for the shortest period of any British monarch, can Lady Jane even be considered an official queen?
