---
type: Section
title: "The Nine Days' Queen (Part 1)"
description: "Episode 293: Edward VI is dead - but who will succeed him on the throne?"
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "lady-jane-grey", "england", "tudor"]
---

# The Nine Days' Queen (Part 1)

2023-01-09 · 51:33 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2281550812.mp3?updated=1777394177)

Edward VI is dead - but who will succeed him on the throne? In the first of two episodes, Tom and Dominic discuss the succession question that surrounded the reign of Edward VI, the sole male heir of Henry VIII - and how a 15-year-old Lady Jane Grey ended up Queen of England and Ireland. Tune in to hear about svengalis, the deeply embedded memory of Henry VIII, and why the people of Guildford are …