---
type: Section
title: "The Axe Falls (Part 2)"
description: "Episode 294: Reigning for the shortest period of any British monarch, can Lady Jane even be considered an official queen?"
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "lady-jane-grey", "england", "tudor"]
---

# The Axe Falls (Part 2)

2023-01-12 · 49:12 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7286066638.mp3?updated=1777394924)

'It had the alchemy of a bitter Tory leadership race'. Reigning for the shortest period of any British monarch, can Lady Jane even be considered an official queen of England and Ireland? In the second of two episodes, tune in to hear Tom and Dominic drill down into the story of her turbulent nine days on the throne, plus her deposition, trial, and execution.