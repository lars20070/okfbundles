# The Saga of Harald Hardrada (Part 1)

## Episodes

* [The Saga of Harald Hardrada (Part 1)](/history/medieval-europe/last-viking/01-the-saga-of-harald-hardrada.md) — Episode 552: Harald Hardrada's extraordinary life.
* [Warrior of the New Rome (Part 2)](/history/medieval-europe/last-viking/02-warrior-of-the-new-rome.md) — Episode 553: Harald in Constantinople with the Varangian Guard.
