---
type: Section
title: "The Saga of Harald Hardrada (Part 1)"
description: "Episode 552: Harald Hardrada's extraordinary life."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "harald-hardrada", "viking", "1066"]
---

# The Saga of Harald Hardrada (Part 1)

2025-03-30 · 1:02:28 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8286135160.mp3?updated=1743514879)

"I swear I will not flee from this fight. I will triumph, or I will die!" In the 1066 game of thrones for the crown of England, the most extraordinary of the three contenders is arguably Harald Hardrada: viking warrior, daring explorer, emperor's bodyguard, serpent slayer, alleged lover to an empress, King of Norway, and legend of Norse mythology. How did this titan of a man come to cross the …
