---
type: Section
title: "Warrior of the New Rome (Part 2)"
description: "Episode 553: Harald in Constantinople with the Varangian Guard."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "harald-hardrada", "viking", "1066"]
---

# Warrior of the New Rome (Part 2)

2025-04-02 · 1:04:25 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5802152245.mp3?updated=1743594277)

Harald Hardrada; exiled prince of Norway and mercenary, has landed in the greatest city on Earth: Constantinople. There he joins one of the most prestigious military organisations in the world, the Varangian Guard, charged with protecting the Emperor. Almost the next ten years of Harald's young life are spent at war protecting the city from enslaving raiders. But then, he becomes embroiled in the …
