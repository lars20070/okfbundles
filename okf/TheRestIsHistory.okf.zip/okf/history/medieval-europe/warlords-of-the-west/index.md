# Barbarian Heirs of Rome (Part 1)

## Episodes

* [Barbarian Heirs of Rome (Part 1)](/history/medieval-europe/warlords-of-the-west/01-barbarian-heirs-of-rome.md) — Episode 520: The rise of the Franks under Charlemagne.
* [Killer Queens (Part 2)](/history/medieval-europe/warlords-of-the-west/02-killer-queens.md) — Episode 521: Clothar I divides the realm and Chilperic seizes Paris.
* [A Clash of Ice and Fire (Part 3)](/history/medieval-europe/warlords-of-the-west/03-a-clash-of-ice-and-fire.md) — Episode 522: The Umayyads' incursion into the Frankish kingdom in Gaul.
