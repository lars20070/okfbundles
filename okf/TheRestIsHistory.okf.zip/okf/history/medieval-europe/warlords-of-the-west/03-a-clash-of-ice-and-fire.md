---
type: Section
title: "A Clash of Ice and Fire (Part 3)"
description: "Episode 522: The Umayyads' incursion into the Frankish kingdom in Gaul."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "franks", "warlords"]
---

# A Clash of Ice and Fire (Part 3)

2024-12-16 · 59:41 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3154320009.mp3?updated=1733688591)

By 711 Europe and the Frankish warlords were facing a graver threat than ever before. Bands of Northern African, nominally Muslim raiders had begun a steady incursion throughout the West, loosely unified under the banner of the Umayyads. Having already taken and plundered the Christian territories of the Goths, their eyes now fell upon the Frankish kingdom in Gaul, by now the greatest power in …
