---
type: Section
title: "Barbarian Heirs of Rome (Part 1)"
description: "Episode 520: The rise of the Franks under Charlemagne."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "franks", "warlords"]
---

# Barbarian Heirs of Rome (Part 1)

2024-12-09 · 51:54 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4921093273.mp3?updated=1733512289)

The Rise of the Franks - a mighty host of warlords; forefathers of the western world and forgers of medieval civilisation, under the totemic leadership of history's most glorious King: Charlemagne. It is a tale rich in fantasy and myth, transporting us into a distant age and the dark debris of a crumbling Roman empire; landscapes scarred by ruins, clashing queens, poisonings, sorcery, bloody …
