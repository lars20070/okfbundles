---
type: Section
title: "Killer Queens (Part 2)"
description: "Episode 521: Clothar I divides the realm and Chilperic seizes Paris."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "franks", "warlords"]
---

# Killer Queens (Part 2)

2024-12-12 · 1:00:12 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5666966864.mp3?updated=1733512319)

Following the death of the legendary Frankish King Clovis, his son Clothar I divided the mighty realm his father had hacked out from the warring warlords of Europe between his four sons. But peace was not to reign…the most ambitious of his brood - Chilperic - seized Paris, his brother's domain, following his death. Drawn to his swelling power, a seemingly humble yet beautiful slave girl …
