---
type: Section
title: "The Revolution Begins (Part 2)"
description: "Episode 434: Three events that transformed Luther from young lawyer to fervent monk."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "martin-luther", "reformation"]
---

# The Revolution Begins (Part 2)

2024-03-28 · 48:48 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4080973410.mp3?updated=1711540975)

Martin Luther is one of the few people to have genuinely changed the world, igniting a religious revolution that tore Christendom in two, and undermined European tradition in ways that still reverberate today. But along with Luther's uniquely tortured psyche, three events contributed to his extreme transformation from young lawyer to fervent monk: the loss of a dear friend, a near fatal accident …