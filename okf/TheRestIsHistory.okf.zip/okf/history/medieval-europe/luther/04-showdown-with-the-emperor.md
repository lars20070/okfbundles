---
type: Section
title: "Showdown with the Emperor (Part 4)"
description: "Episode 436: The Diet of Worms in April 1521."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "martin-luther", "reformation"]
---

# Showdown with the Emperor (Part 4)

2024-04-01 · 58:53 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5159022101.mp3?updated=1712045087)

"I cannot and will not recant anything for to go against conscience is neither right nor safe.…Here I stand, I can do no other" The Diet of Worms in April 1521 was one of history's most dramatic confrontations, a clash of the old world and the new. It saw the celebrity professor Martin Luther summoned to the imperial free city of Worms by the Holy Roman Emperor, Charles V, to defend his radical …