---
type: Section
title: "The Man Who Changed the World (Part 1)"
description: "Episode 433: Martin Luther, the humble monk of obscure origins."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "martin-luther", "reformation"]
---

# The Man Who Changed the World (Part 1)

2024-03-25 · 49:28 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7298373279.mp3?updated=1711317562)

The Reformation, launched in 1517, stands as one of the most convulsive and transformative events of all time, shattering Christendom and dividing Europe for centuries. Its outcome determined the fates of Kings and Emperors, and saw the souls of millions consigned to the fiery pit of heresy. The man behind it all was Martin Luther, a humble monk of obscure origins. Bold, intellectually arrogant …