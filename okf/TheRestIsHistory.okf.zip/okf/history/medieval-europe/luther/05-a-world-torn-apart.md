---
type: Section
title: "A World Torn Apart (Part 5)"
description: "Episode 437: Martin Luther's dramatic abduction by Frederick III."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "martin-luther", "reformation"]
---

# A World Torn Apart (Part 5)

2024-04-03 · 1:08:49 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3328267667.mp3?updated=1711276960)

"I think there is not a devil left in hell, they have all gone into the peasants… smite, stab and slay all". Following on from Martin Luther's dramatic abduction by his powerful protector, Frederick III, he had been secretly kept safe at Wartburg. There, he abandoned his priestly garments for good, and violently wrestled against the devil, in unorthodox ways…Meanwhile, the religious revolution …