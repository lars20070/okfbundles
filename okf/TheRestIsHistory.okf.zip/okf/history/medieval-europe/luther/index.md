# The Man Who Changed the World (Part 1)

## Episodes

* [The Man Who Changed the World (Part 1)](/history/medieval-europe/luther/01-the-man-who-changed-the-world.md) — Episode 433: Martin Luther, the humble monk of obscure origins.
* [The Revolution Begins (Part 2)](/history/medieval-europe/luther/02-the-revolution-begins.md) — Episode 434: Three events that transformed Luther from young lawyer to fervent monk.
* [The Battle Against Satan (Part 3)](/history/medieval-europe/luther/03-the-battle-against-satan.md) — Episode 435: Luther's increasingly radical beliefs founded in his readings of Christian.
* [Showdown with the Emperor (Part 4)](/history/medieval-europe/luther/04-showdown-with-the-emperor.md) — Episode 436: The Diet of Worms in April 1521.
* [A World Torn Apart (Part 5)](/history/medieval-europe/luther/05-a-world-torn-apart.md) — Episode 437: Martin Luther's dramatic abduction by Frederick III.
