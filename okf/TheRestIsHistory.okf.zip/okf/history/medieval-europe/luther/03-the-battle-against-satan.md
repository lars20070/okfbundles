---
type: Section
title: "The Battle Against Satan (Part 3)"
description: "Episode 435: Luther's increasingly radical beliefs founded in his readings of Christian."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "martin-luther", "reformation"]
---

# The Battle Against Satan (Part 3)

2024-03-31 · 59:00 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9360370091.mp3?updated=1711652238)

Three years on from Martin Luther's publication of the Ninety-Five Theses - a shocking attack on the corruption of the Catholic Church and the selling of indulgences - his radical new ideas and brilliant use of the printing press had unleashed chaos in Christendom. Still in Wittenberg under the Protection of Frederick III, Luther's increasingly radical beliefs founded in his readings of Christian …