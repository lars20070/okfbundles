# The Vikings Go East

## Episodes

* [The Vikings Go East](/history/medieval-europe/vikings-east/01-the-vikings-go-east.md) — Episode 148: Tom and Dominic take a look at the actions, influence and brutalisation of the Vikings in Eastern Europe.
* [The Birth of Russia](/history/medieval-europe/vikings-east/02-the-birth-of-russia.md) — Episode 149: In the second of two episodes on the Vikings in the East, Tom and Dominic investigate their role in the birth of Russia.
