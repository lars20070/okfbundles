---
type: Section
title: "The Vikings Go East"
description: "Episode 148: Tom and Dominic take a look at the actions, influence and brutalisation of the Vikings in Eastern Europe."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "vikings", "russia"]
---

# The Vikings Go East

2022-02-07 · 42:56 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1476178706.mp3?updated=1706888368)

In this week's episode, Tom and Dominic take a look at the actions, influence and brutalisation of the Vikings in Eastern Europe, including their role in the formation of Russia and Ukraine.