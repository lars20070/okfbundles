---
type: Section
title: "The Birth of Russia"
description: "Episode 149: In the second of two episodes on the Vikings in the East, Tom and Dominic investigate their role in the birth of Russia."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "vikings", "russia"]
---

# The Birth of Russia

2022-02-08 · 50:29 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2354182753.mp3?updated=1777394951)

In the second of two episodes on the Vikings in the East, Tom and Dominic investigate their role in the birth of Russia.