# Return of the Kings (Part 1)

## Episodes

* [Return of the Kings (Part 1)](/history/medieval-europe/charlemagne/01-return-of-the-kings.md) — Episode 523: Charlemagne's rise to supreme power and the father of Europe.
* [Pagan Killer (Part 2)](/history/medieval-europe/charlemagne/02-pagan-killer.md) — Episode 524: Charles the Great ruling as joint king of the Franks alongside Carloman.
* [Emperor of the West (Part 3)](/history/medieval-europe/charlemagne/03-emperor-of-the-west.md) — Episode 525: The coronation of Charlemagne on Christmas Day 800 AD.
