---
type: Section
title: "Emperor of the West (Part 3)"
description: "Episode 525: The coronation of Charlemagne on Christmas Day 800 AD."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "charlemagne"]
---

# Emperor of the West (Part 3)

2024-12-25 · 1:03:47 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6103469677.mp3?updated=1734100735)

"And from that moment on, he was addressed as emperor and Augustus!" The coronation of Charlemagne on Christmas Day 800 AD, is one of the landmark moments in all world history. More than three centuries after the fall of the Roman Empire in the West, the emperors had returned once more, and a Caesar ruled in Rome. But how did this legendary event come to pass? For many years Charlemagne, though a …
