---
type: Section
title: "Pagan Killer (Part 2)"
description: "Episode 524: Charles the Great ruling as joint king of the Franks alongside Carloman."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "charlemagne", "franks"]
---

# Pagan Killer (Part 2)

2024-12-23 · 53:51 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1992648453.mp3?updated=1734098988)

"Here was a program to wet the ambitions of warlords as well as scholars, and to send men into battle beneath the fluttering of banners, the hiss of arrows, and the shadow of carrion crows…" The year is 777 and Charles the Great - Charlemagne - has ruled as joint king of the Franks alongside his brother, Carloman, for nine years. Now though his brother and greatest impediment to sole authority …
