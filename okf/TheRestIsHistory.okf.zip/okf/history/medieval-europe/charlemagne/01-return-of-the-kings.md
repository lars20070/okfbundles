---
type: Section
title: "Return of the Kings (Part 1)"
description: "Episode 523: Charlemagne's rise to supreme power and the father of Europe."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "charlemagne", "franks"]
---

# Return of the Kings (Part 1)

2024-12-19 · 50:31 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5104943454.mp3?updated=1734097576)

The Frankish king, Charlemagne the Great, is one of the titanic figures of European history, simultaneously renowned and shadowy. His rise to supreme power is a staggering story of warring religious empires, betrayal, battle, blindings and brutal conquest. How, then, did this one time Frankish interloper become the father of Europe, progenitor of a Holy Roman Empire whose descendants would rule …
