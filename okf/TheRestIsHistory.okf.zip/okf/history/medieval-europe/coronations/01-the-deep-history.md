---
type: Section
title: "The Deep History (Part 1)"
description: "Episode 327: The roots of the coronation ritual are fabulously ancient."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "coronations", "britain", "royalty"]
---

# The Deep History (Part 1)

2023-05-04 · 49:41 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4746607803.mp3?updated=1777394985)

The roots of the coronation ritual are fabulously ancient: certain elements of the ceremony are vestiges from the later Roman Empire, others have their origins in the Old Testament and ancient Egypt. The liturgy used can be traced back to the 10th century, and the very idea of kings taking part in rituals comes from Charlemagne. In light of the first British coronation in more than half a century …