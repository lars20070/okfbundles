---
type: Section
title: "Chaos, Ceremony and Empire (Part 3)"
description: "Episode 329: Tom and Dominic answer all these questions as they explore the most recent coronations in British history."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "coronations", "britain", "royalty"]
---

# Chaos, Ceremony and Empire (Part 3)

2023-05-06 · 53:23 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8755026279.mp3?updated=1777394194)

What was the most calamitous coronation of all time? Which ceremony does Tom think is the most boring topic he's ever discussed on the podcast? How will Charles III's big day compare to that of his ancestors? In the third and final episode, Tom and Dominic answer all these questions as they explore the most recent coronations in British history.