# The Deep History (Part 1)

## Episodes

* [The Deep History (Part 1)](/history/medieval-europe/coronations/01-the-deep-history.md) — Episode 327: The roots of the coronation ritual are fabulously ancient.
* [Sex, Holy Oil and Civil War (Part 2)](/history/medieval-europe/coronations/02-sex-holy-oil-and-civil-war.md) — Episode 328: Charles III will certainly be hoping that History does not repeat itself this weekend.
* [Chaos, Ceremony and Empire (Part 3)](/history/medieval-europe/coronations/03-chaos-ceremony-and-empire.md) — Episode 329: Tom and Dominic answer all these questions as they explore the most recent coronations in British history.
