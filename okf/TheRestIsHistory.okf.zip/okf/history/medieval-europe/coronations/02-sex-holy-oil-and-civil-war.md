---
type: Section
title: "Sex, Holy Oil and Civil War (Part 2)"
description: "Episode 328: Charles III will certainly be hoping that History does not repeat itself this weekend."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "coronations", "britain", "royalty"]
---

# Sex, Holy Oil and Civil War (Part 2)

2023-05-05 · 53:06 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8165021855.mp3?updated=1777394177)

Whether it's London descending into a riot, a bad hangover with Samuel Pepys, or a royal lacking discretion… Charles III will certainly be hoping that History does not repeat itself this weekend. In the second of our episodes on coronations, Tom and Dominic take a look at some of the bad behaviour that occurred at coronations in the past, and whether that serves as an omen for the monarch's reign …