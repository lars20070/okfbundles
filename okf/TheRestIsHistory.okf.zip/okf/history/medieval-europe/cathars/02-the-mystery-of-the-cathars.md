---
type: Section
title: "The Mystery of the Cathars (Part 2)"
description: "Episode 302: Was the Catholic Church Europe's first revolutionary group? How are the Cathars linked to the genesis of genocide?"
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "cathars", "crusade", "medieval"]
---

# The Mystery of the Cathars (Part 2)

2023-02-07 · 51:56 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9956144594.mp3?updated=1777394211)

Was the Catholic Church Europe's first revolutionary group? How are the Cathars linked to the genesis of genocide? Where does the term crusade come from? Listen as Tom and Dominic discuss the real history around the mysterious group known as the Cathars.