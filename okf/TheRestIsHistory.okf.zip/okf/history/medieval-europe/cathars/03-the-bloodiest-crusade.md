---
type: Section
title: "The Bloodiest Crusade (Part 3)"
description: "Episode 303: Thought by some as the first genocide in Europe, the Albigensian Crusade was the bloodiest crusade in history."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "cathars", "crusade", "medieval"]
---

# The Bloodiest Crusade (Part 3)

2023-02-09 · 53:25 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7887097153.mp3?updated=1777394824)

Thought by some as the first genocide in Europe, the Albigensian Crusade was the bloodiest crusade in history. Following the Mystery of the Cathars and the Real Da Vinci Code, Tom and Dominic come to the conclusion of their series on the Cathars with an extraordinary and bloody tale of ideological tyranny.