---
type: Section
title: "The Real Da Vinci Code (Part 1)"
description: "Episode 301: Secret societies, Jesus' ancient bloodline, Catholic conspirators; all backed up by documents in the Bibliothèque Nationale."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "cathars", "crusade", "medieval"]
---

# The Real Da Vinci Code (Part 1)

2023-02-06 · 57:45 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5654192229.mp3?updated=1777394620)

Secret societies, Jesus' ancient bloodline, Catholic conspirators; all backed up by documents in the Bibliothèque Nationale. It must be true, mustn't it? Join Tom and Dominic in the first of three episodes on the Cathars, starting off with a deep dive into the Da Vinci code and the story surrounding it.