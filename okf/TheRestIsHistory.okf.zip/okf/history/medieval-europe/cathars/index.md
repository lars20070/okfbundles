# The Real Da Vinci Code (Part 1)

## Episodes

* [The Real Da Vinci Code (Part 1)](/history/medieval-europe/cathars/01-the-real-da-vinci-code.md) — Episode 301: Secret societies, Jesus' ancient bloodline, Catholic conspirators; all backed up by documents in the Bibliothèque Nationale.
* [The Mystery of the Cathars (Part 2)](/history/medieval-europe/cathars/02-the-mystery-of-the-cathars.md) — Episode 302: Was the Catholic Church Europe's first revolutionary group? How are the Cathars linked to the genesis of genocide?
* [The Bloodiest Crusade (Part 3)](/history/medieval-europe/cathars/03-the-bloodiest-crusade.md) — Episode 303: Thought by some as the first genocide in Europe, the Albigensian Crusade was the bloodiest crusade in history.
