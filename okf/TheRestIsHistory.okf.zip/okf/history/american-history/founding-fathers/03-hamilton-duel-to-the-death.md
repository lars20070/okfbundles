---
type: Section
title: "Hamilton: Duel to the Death (Part 3)"
description: "Episode 685: Alexander Hamilton's fiery life from orphan to founding father."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, america, founding-fathers, hamilton]
---

# Hamilton: Duel to the Death (Part 3)

2026-07-05 · 1:15:33 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9231431046.mp3)

How did Alexander Hamilton go from impoverished orphan to one of the most important figures in the creation of the American constitution? Why was his relationship with Thomas Jefferson so strained? And, what happened in the famous duel that would ultimately claim his life…? Join Dominic and Tom as they discuss one of America's most fiery founding fathers: Alexander Hamilton, and his duel with …
