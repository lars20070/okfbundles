---
type: Section
title: "Franklin: Revenge of the American Genius (Part 2)"
description: "Episode 684: Benjamin Franklin's unique life and role in the American Revolutionary cause."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, america, founding-fathers, franklin]
---

# Franklin: Revenge of the American Genius (Part 2)

2026-07-01 · 1:13:18 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6013835340.mp3)

Was Benjamin Franklin really an American? What was his childhood like? How was he finally converted to the American Revolutionary cause? And, what role did he play in setting the struggle in motion? Join Tom and Dominic as they discuss the life of the most unique of the American founding fathers: Benjamin Franklin.
