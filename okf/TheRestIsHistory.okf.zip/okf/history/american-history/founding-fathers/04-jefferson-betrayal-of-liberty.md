---
type: Section
title: "Jefferson: The Betrayal of Liberty (Part 4)"
description: "Episode 686: Thomas Jefferson — the most controversial figure among the men who made America."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, america, founding-fathers, jefferson]
---

# Jefferson: The Betrayal of Liberty (Part 4)

2026-07-08 · 1:21:37 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6535571769.mp3)

What part did Thomas Jefferson play in writing the American Declaration of Independence? Where did he come from, and how did it shape his attitude to the future of the U.S.A? And, why was he such a contentious figure? Join Tom and Dominic as they reach the epic conclusion of their series delving into the lives of the men who made America, and end with the most controversial figure of them all …
