# Washington: Hero of the Revolution (Part 1)

## Episodes

* [Washington: Hero of the Revolution (Part 1)](/history/american-history/founding-fathers/01-washington-hero-of-the-revolution.md) — Episode 683: George Washington's extraordinary life and origins in the American Revolution.
* [Franklin: Revenge of the American Genius (Part 2)](/history/american-history/founding-fathers/02-franklin-revenge-of-the-american-genius.md) — Episode 684: Benjamin Franklin's unique life and role in the American Revolutionary cause.
* [Hamilton: Duel to the Death (Part 3)](/history/american-history/founding-fathers/03-hamilton-duel-to-the-death.md) — Episode 685: Alexander Hamilton's fiery life from orphan to founding father.
* [Jefferson: The Betrayal of Liberty (Part 4)](/history/american-history/founding-fathers/04-jefferson-betrayal-of-liberty.md) — Episode 686: Thomas Jefferson — the most controversial figure among the men who made America.
