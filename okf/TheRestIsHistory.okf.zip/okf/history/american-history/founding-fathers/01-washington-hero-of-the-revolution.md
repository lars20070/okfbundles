---
type: Section
title: "Washington: Hero of the Revolution (Part 1)"
description: "Episode 683: George Washington's extraordinary life and origins in the American Revolution."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, america, founding-fathers, washington]
---

# Washington: Hero of the Revolution (Part 1)

2026-06-28 · 1:16:04 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3752138067.mp3)

Where did George Washington come from, and what was he like? How did he come to take on such a pivotal role in the American Revolution? And, was he really central to America's triumphant struggle for independence? Join Dominic and Tom as they launch into the extraordinary life and origins of George Washington.
