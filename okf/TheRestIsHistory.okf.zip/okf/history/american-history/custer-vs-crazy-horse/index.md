# Civil War (Part 1)

## Episodes

* [Civil War (Part 1)](/history/american-history/custer-vs-crazy-horse/01-civil-war.md) — Episode 446: The American Indian Wars of 1862-68 and the figures of Custer and Crazy Horse.
* [The Winning of the West (Part 2)](/history/american-history/custer-vs-crazy-horse/02-the-winning-of-the-west.md) — Episode 447: Custer's alliance with Andrew Johnson after the Civil War.
* [Horse-Lords of the Plains (Part 3)](/history/american-history/custer-vs-crazy-horse/03-horse-lords-of-the-plains.md) — Episode 448: Crazy Horse, the Lakota Sioux warrior and military tactician.
* [Rise of Sitting Bull (Part 4)](/history/american-history/custer-vs-crazy-horse/04-rise-of-sitting-bull.md) — Episode 449: The aftermath of the Fetterman Fight and the new treaty.
