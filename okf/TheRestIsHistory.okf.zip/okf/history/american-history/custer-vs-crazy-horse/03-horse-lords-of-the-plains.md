---
type: Section
title: "Horse-Lords of the Plains (Part 3)"
description: "Episode 448: Crazy Horse, the Lakota Sioux warrior and military tactician."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "custer", "crazy-horse", "native-american"]
---

# Horse-Lords of the Plains (Part 3)

2024-05-08 · 49:28 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4947798648.mp3?updated=1715072213)

Of all the great characters entangled in the story of George A. Custer and the American Indian Wars, few are as captivating as Crazy Horse. A mighty warrior of the Lakota Sioux, and a tremendous military tactician, he was a charismatic but enigmatic figure. The Sioux, of which the Lakota are a subculture, are groups of Native American tribes and First Nations people from the Great Plains. Their …