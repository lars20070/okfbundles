---
type: Section
title: "Rise of Sitting Bull (Part 4)"
description: "Episode 449: The aftermath of the Fetterman Fight and the new treaty."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "custer", "crazy-horse", "sitting-bull", "native-american"]
---

# Rise of Sitting Bull (Part 4)

2024-05-12 · 49:04 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2415947095.mp3?updated=1715183920)

"What would you do if your home was attacked? You would stand up like a brave man and defend it. That is our story." Following the bloody Fetterman Fight, which saw the Lakota warlord Crazy Horse and his warriors ambush and massacre American troops, the American public was left stunned, its government and civilian population hungry for revenge. In the wake of this a new treaty was signed, further …