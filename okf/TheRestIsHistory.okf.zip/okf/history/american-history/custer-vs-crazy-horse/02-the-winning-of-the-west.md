---
type: Section
title: "The Winning of the West (Part 2)"
description: "Episode 447: Custer's alliance with Andrew Johnson after the Civil War."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "custer", "crazy-horse", "native-american"]
---

# The Winning of the West (Part 2)

2024-05-06 · 1:06:25 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1593887977.mp3?updated=1715070354)

With the American Civil War coming to a close in April 1865, George Custer, cavalry commander in the Union army, and a man of dubious political leanings for a unionist officer, was sent to Texas. Reckless, daring and bloodthirsty, the conclusion of the war came as a disappointment to him. Then, having allied himself with the new, anti-Reconstruction American president, Andrew Johnson, Custer …