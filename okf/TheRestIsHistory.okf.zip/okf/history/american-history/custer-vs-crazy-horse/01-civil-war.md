---
type: Section
title: "Civil War (Part 1)"
description: "Episode 446: The American Indian Wars of 1862-68 and the figures of Custer and Crazy Horse."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "custer", "crazy-horse", "native-american"]
---

# Civil War (Part 1)

2024-05-05 · 58:33 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9088781244.mp3?updated=1714926980)

"Come on, you Wolverines!" The story of the American Indian Wars of 1862-68 is an enthralling tale of hubris, politics, recklessness, and the merciless assault of industrialisation and modernity on an old world, nearly extinguished. An immense tragedy, it is also a story of great adventure, with formidable heroes and villains on both sides. No two figures encapsulate this better than the …