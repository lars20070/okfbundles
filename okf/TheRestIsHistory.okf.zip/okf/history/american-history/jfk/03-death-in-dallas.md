---
type: Section
title: "Death in Dallas (Part 3)"
description: "Episode 394: John F. Kennedy awoke with just hours to live on Friday, 22nd November 1963."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "jfk", "assassination"]
---

# Death in Dallas (Part 3)

2023-11-30 · 43:19 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6387392381.mp3?updated=1701022619)

"It wouldn't be very difficult to kill the president of the United States, you just have to be in a high building with a high powered rifle, telescopic sight and there's nothing anyone could do about it…." On the morning of Friday, 22nd November 1963, John F. Kennedy awoke with just hours to live. Ahead was a flight to Love Field, Dallas; then a motorcade into the heart of the city's business …