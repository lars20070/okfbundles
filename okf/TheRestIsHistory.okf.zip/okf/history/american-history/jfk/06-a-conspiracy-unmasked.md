---
type: Section
title: "A Conspiracy Unmasked (Part 6)"
description: "Episode 397: The murder of Lee Harvey Oswald by Jack Ruby changed everything."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "jfk", "assassination"]
---

# A Conspiracy Unmasked (Part 6)

2023-12-07 · 58:10 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4318220159.mp3?updated=1700749154)

"We can't accept very comfortably that two nobodies, two nothings - Lee Harvey Oswald and Jack Ruby - were able to change the course of world history." The murder of Lee Harvey Oswald, JFK's apparent assassin, by the night club owner Jack Ruby on 24th November 1963 changed everything. Right from the start, rumours had circulated that Oswald had not been acting alone, building on the deep …