---
type: Section
title: "Hunt for a Killer (Part 4)"
description: "Episode 395: Three shots had rung out from the direction of the Texas Book Depository."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "jfk", "assassination"]
---

# Hunt for a Killer (Part 4)

2023-12-04 · 45:05 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1345279222.mp3?updated=1700749081)

It's 12:31pm on Friday 22nd November 1963, and in Dallas, Texas, President John F. Kennedy lies slumped against his screaming wife, half of his head cradled in her hands and his blood spattered across her elegant pink suit and the seats of their car. Just moments earlier, three shots had rung out from the direction of the Texas Book Depository. Or had they? Who had fired the shots? A single …