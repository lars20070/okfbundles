---
type: Section
title: "The Second Assassin Strikes (Part 5)"
description: "Episode 396: Just hours after the assassination, the Dallas police are confident they have solved the case."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "jfk", "assassination"]
---

# The Second Assassin Strikes (Part 5)

2023-12-05 · 40:17 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7803941061.mp3?updated=1700845231)

"Jack, you son of a bitch, don't do it!" Just hours after President Kennedy's assassination, in the full glare of the world's media, the Dallas police are confident they have solved the case. They have found the murder weapon, and are poised to charge their chief suspect, a strange loner called Lee Harvey Oswald. But as they prepare to move him to the county jail, one local businessman has other …