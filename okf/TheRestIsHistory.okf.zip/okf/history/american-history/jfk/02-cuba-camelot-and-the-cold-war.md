---
type: Section
title: "Cuba, Camelot and the Cold War (Part 2)"
description: "Episode 393: John F. Kennedy, the youngest ever President of the United States."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "jfk", "assassination"]
---

# Cuba, Camelot and the Cold War (Part 2)

2023-11-28 · 54:02 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9682768005.mp3?updated=1700749003)

By the late 1950s, John F. Kennedy was a rich and handsome Democratic senator with a beautiful wife and young family, heading for the White House despite his Catholicism, his affairs and his secret illnesses. In January 1961 he became the youngest ever President of the United States, during a period of heightened political and social tensions at home and abroad, with the Cold War raging …