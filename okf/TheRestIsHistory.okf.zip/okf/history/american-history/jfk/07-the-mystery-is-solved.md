---
type: Section
title: "The Mystery is Solved (Part 7)"
description: "Episode 398: Dominic and Tom reveal the astonishing solution to the mystery."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "jfk", "assassination"]
---

# The Mystery is Solved (Part 7)

2023-12-11 · 51:21 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6409828878.mp3?updated=1702048064)

In this landmark edition of The Rest is History, Dominic and Tom reveal the astonishing solution to the mystery that has fascinated so many people for the last sixty years. In thrillingly definitive detail, they explain just who killed President Kennedy and why he did it. Step by step, they trace his journey to the killing ground, and delve into the psychology of a murderer. They unmask his …