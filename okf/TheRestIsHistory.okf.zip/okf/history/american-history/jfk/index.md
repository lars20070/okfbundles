# The Road to the White House (Part 1)

## Episodes

* [The Road to the White House (Part 1)](/history/american-history/jfk/01-the-road-to-the-white-house.md) — Episode 392: The youngest ever President of the United States during the Cold War.
* [Cuba, Camelot and the Cold War (Part 2)](/history/american-history/jfk/02-cuba-camelot-and-the-cold-war.md) — Episode 393: John F. Kennedy, the youngest ever President of the United States.
* [Death in Dallas (Part 3)](/history/american-history/jfk/03-death-in-dallas.md) — Episode 394: John F. Kennedy awoke with just hours to live on Friday, 22nd November 1963.
* [Hunt for a Killer (Part 4)](/history/american-history/jfk/04-hunt-for-a-killer.md) — Episode 395: Three shots had rung out from the direction of the Texas Book Depository.
* [The Second Assassin Strikes (Part 5)](/history/american-history/jfk/05-the-second-assassin-strikes.md) — Episode 396: Just hours after the assassination, the Dallas police are confident they have solved the case.
* [A Conspiracy Unmasked (Part 6)](/history/american-history/jfk/06-a-conspiracy-unmasked.md) — Episode 397: The murder of Lee Harvey Oswald by Jack Ruby changed everything.
* [The Mystery is Solved (Part 7)](/history/american-history/jfk/07-the-mystery-is-solved.md) — Episode 398: Dominic and Tom reveal the astonishing solution to the mystery.
