---
type: Section
title: "The Road to the White House (Part 1)"
description: "Episode 392: The youngest ever President of the United States during the Cold War."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "jfk", "assassination"]
---

# The Road to the White House (Part 1)

2023-11-27 · 47:54 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3759679497.mp3?updated=1700748935)

"There were a lot of people who wanted Kennedy dead, a lot of powerful people. There are secrets still being held and I never bought for a minute that Oswald operated alone." The assassination of President John F. Kennedy in Dallas on 22nd November 1963 is one of history's most iconic stories, a moment of terrible innocence lost and a foundational myth for modern America. The tragedy of the …