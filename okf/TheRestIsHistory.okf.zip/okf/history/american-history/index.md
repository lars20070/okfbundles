# American History

## Series

* [Death at the Theatre (Part 1)](/history/american-history/abraham-lincoln/) — Series about Death at the Theatre (Part 1)
* [Nightmare in Vietnam (Part 1)](/history/american-history/america-68/) — Series about Nightmare in Vietnam (Part 1)
* [The Causes (Part 1)](/history/american-history/american-civil-war/) — Series about The Causes (Part 1)
* [The American Revolution (Part 1)](/history/american-history/american-revolution/) — Series about The American Revolution (Part 1)
* [Civil War (Part 1)](/history/american-history/custer-vs-crazy-horse/) — Series about Civil War (Part 1)
* [Death in the Black Hills (Part 5)](/history/american-history/custers-last-stand/) — Series about Death in the Black Hills (Part 5)
* [Death of Crazy Horse (Part 1)](/history/american-history/fall-of-sioux/) — Series about Death of Crazy Horse (Part 1)
* [Washington: Hero of the Revolution (Part 1)](/history/american-history/founding-fathers/) — Series about Washington: Hero of the Revolution (Part 1)
* [The Road to the White House (Part 1)](/history/american-history/jfk/) — Series about The Road to the White House (Part 1)
* [The Rise of Evil (Part 1)](/history/american-history/kkk/) — Series about The Rise of Evil (Part 1)
* [Ronald Reagan and the American Dream (Part 1)](/history/american-history/reagan/) — Series about Ronald Reagan and the American Dream (Part 1)
