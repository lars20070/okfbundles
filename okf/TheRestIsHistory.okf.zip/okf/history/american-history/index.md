# American History

## Series

* [Abraham Lincoln](/history/american-history/abraham-lincoln/) — 2 episodes
* [America in '68](/history/american-history/america-68/) — 6 episodes
* [The American Civil War](/history/american-history/american-civil-war/) — 4 episodes
* [The American Revolution](/history/american-history/american-revolution/) — 4 episodes
* [Custer vs Crazy Horse](/history/american-history/custer-vs-crazy-horse/) — 4 episodes
* [Custer's Last Stand](/history/american-history/custers-last-stand/) — 4 episodes
* [The Fall of the Sioux](/history/american-history/fall-of-sioux/) — 3 episodes
* [The Founding Fathers](/history/american-history/founding-fathers/) — 4 episodes
* [John F. Kennedy](/history/american-history/jfk/) — 7 episodes
* [The Ku Klux Klan](/history/american-history/kkk/) — 4 episodes
* [Ronald Reagan](/history/american-history/reagan/) — 3 episodes
