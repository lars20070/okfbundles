---
type: Section
title: "The Chicago Riots (Part 5)"
description: "Episode 512: Anti-war protestors flooding Chicago's streets during the Democratic Convention."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "america", "1968", "chicago"]
---

# The Chicago Riots (Part 5)

2024-11-11 · 1:09:35 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9860410495.mp3?updated=1731270135)

The Democratic National Convention is in Chicago, and the incumbent president, Lyndon B. Johnson, has pulled out of the race. Anti-war protestors are flooding the streets of the city, and Johnson continues to press on with the war in Vietnam. Bobby Kennedy's assassination has turned the Democratic candidacy contest into a two-horse race between Hubert Humphrey and Eugene McCarthy. And while …
