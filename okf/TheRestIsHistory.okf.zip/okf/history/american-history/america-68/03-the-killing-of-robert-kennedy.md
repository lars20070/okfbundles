---
type: Section
title: "The Killing of Robert Kennedy (Part 3)"
description: "Episode 510: Bobby Kennedy's distinct political identity and his assassination."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "america", "1968", "robert-kennedy"]
---

# The Killing of Robert Kennedy (Part 3)

2024-11-04 · 1:04:46 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6589354101.mp3?updated=1730644471)

"What we need in the United States is not division; what we need in the United States is not hatred; what we need in the United States is not violence and lawlessness, but is love, and wisdom, and compassion toward one another" As Attorney General during JFK's presidency, Bobby had often played second fiddle to his older brother. But by 1968, Robert F. Kennedy had become a distinct political …
