---
type: Section
title: "The Assassination of Martin Luther King Jr. (Part 2)"
description: "Episode 509: Dr. King losing popularity and contending with FBI threats."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "america", "1968", "martin-luther-king"]
---

# The Assassination of Martin Luther King Jr. (Part 2)

2024-10-31 · 1:02:48 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4373367265.mp3?updated=1731418996)

The peaceful figurehead of the Civil Rights movement in the early 1960s, Dr Martin Luther King had inspired hundreds of thousands to demand equal rights for African Americans. But by 1968, the once uniting leader seemed to be losing popularity, both amongst activists and in the press. As he grappled with being hunted and threatened by the FBI, he was also contending with a new generation of more …
