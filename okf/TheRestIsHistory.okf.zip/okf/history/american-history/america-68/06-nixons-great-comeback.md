---
type: Section
title: "Nixon's Great Comeback (Part 6)"
description: "Episode 513: Nixon running as Republican presidential candidate after losing to JFK."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "america", "1968", "nixon"]
---

# Nixon's Great Comeback (Part 6)

2024-11-14 · 57:45 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3853956463.mp3?updated=1731270226)

"Nixon now! Nixon now! More than ever we need Nixon now!" It's the 5th of November 1968, and Richard M. Nixon is on tenterhooks, alone in his dark hotel room. He watches as the final states are called in the presidential election. Will he fall at the same hurdle as he did in 1960? Off the back of losing to JFK eight years prior, Nixon is running as the Republican presidential candidate. This time …
