---
type: Section
title: "Nightmare in Vietnam (Part 1)"
description: "Episode 508: LBJ ends the bombing of North Vietnam and drops out of the race."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "america", "1968", "vietnam"]
---

# Nightmare in Vietnam (Part 1)

2024-10-28 · 1:13:29 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6375459097.mp3?updated=1730076936)

"Tonight I want to speak to you of peace in Vietnam and Southeast Asia." On the night of Sunday, 31st of March 1968, President Lyndon B. Johnson, after announcing an end to the bombing of North Vietnam, stunned the world by revealing he would not seek the democratic nomination for that year's presidential election. The seemingly never-ending Vietnam War had already made LBJ hugely unpopular with …
