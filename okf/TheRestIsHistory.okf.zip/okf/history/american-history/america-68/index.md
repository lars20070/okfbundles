# Nightmare in Vietnam (Part 1)

## Episodes

* [Nightmare in Vietnam (Part 1)](/history/american-history/america-68/01-nightmare-in-vietnam.md) — Episode 508: LBJ ends the bombing of North Vietnam and drops out of the race.
* [The Assassination of Martin Luther King Jr. (Part 2)](/history/american-history/america-68/02-the-assassination-of-martin-luther-king-jr.md) — Episode 509: Dr. King losing popularity and contending with FBI threats.
* [The Killing of Robert Kennedy (Part 3)](/history/american-history/america-68/03-the-killing-of-robert-kennedy.md) — Episode 510: Bobby Kennedy's distinct political identity and his assassination.
* [George Wallace, The First Donald Trump (Part 4)](/history/american-history/america-68/04-george-wallace-the-first-donald-trump.md) — Episode 511: Wallace's populist campaign against the Civil Rights movement.
* [The Chicago Riots (Part 5)](/history/american-history/america-68/05-the-chicago-riots.md) — Episode 512: Anti-war protestors flooding Chicago's streets during the Democratic Convention.
* [Nixon's Great Comeback (Part 6)](/history/american-history/america-68/06-nixons-great-comeback.md) — Episode 513: Nixon running as Republican presidential candidate after losing to JFK.
