---
type: Section
title: "George Wallace, The First Donald Trump (Part 4)"
description: "Episode 511: Wallace's populist campaign against the Civil Rights movement."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "america", "1968", "george-wallace"]
---

# George Wallace, The First Donald Trump (Part 4)

2024-11-07 · 1:06:49 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8855008412.mp3?updated=1730940586)

"Segregation now, segregation tomorrow, segregation forever!" George Wallace, Governor of Alabama, was one of the most successful third-party presidential candidates in American history. In 1968, he ran a populist campaign pitching himself against the Civil Rights movement. He pushed to uphold formal structures of white supremacy in the South, forever employing racist dog whistles at his rallies …
