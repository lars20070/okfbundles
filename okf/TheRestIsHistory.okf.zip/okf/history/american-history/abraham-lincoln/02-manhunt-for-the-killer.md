---
type: Section
title: "Manhunt for the Killer (Part 2)"
description: "Episode 591: The chase and capture of John Wilkes Booth."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, abraham-lincoln, civil-war]
---

# Manhunt for the Killer (Part 2)

2025-08-13 · 1:07:56 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7618197031.mp3?updated=1755122723)

How was President Abraham Lincoln murdered on Good Friday 1865, at Ford's Theatre, just five days after Robert E. Lee's surrender? Who was John Wilkes Booth, the racist actor with southern sympathies, who assassinated him? How did he escape before the shocked eyes of the packed theatre, and evade his captors to go on the run? Would they get him in the end? And, what were the long term …
