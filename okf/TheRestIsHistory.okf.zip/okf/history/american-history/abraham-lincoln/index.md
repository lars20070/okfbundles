# Death at the Theatre (Part 1)

## Episodes

* [Death at the Theatre (Part 1)](/history/american-history/abraham-lincoln/01-death-at-the-theatre.md) — Episode 590: Lincoln's decision on the rebel states and John Wilkes Booth.
* [Manhunt for the Killer (Part 2)](/history/american-history/abraham-lincoln/02-manhunt-for-the-killer.md) — Episode 591: The chase and capture of John Wilkes Booth.
