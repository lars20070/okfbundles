---
type: Section
title: "Death at the Theatre (Part 1)"
description: "Episode 590: Lincoln's decision on the rebel states and John Wilkes Booth."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, abraham-lincoln, civil-war]
---

# Death at the Theatre (Part 1)

2025-08-10 · 1:02:24 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2286421954.mp3?updated=1754871827)

After passing the 13th amendment, in the closing weeks of the brutal American Civil War, what did president Abraham Lincoln - recently re-elected - do next to inflame his detractors? Crippled with guilt for the death and destruction of the war, was he indeed a unionist tyrant? What did Lincoln decide to do with the defeated rebel states? And, with time ticking for Lincoln's life, who was John …
