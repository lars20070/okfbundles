# Death of Crazy Horse (Part 1)

## Episodes

* [Death of Crazy Horse (Part 1)](/history/american-history/fall-of-sioux/01-death-of-crazy-horse.md) — Episode 454: The beginning of the end for the Lakota after the Battle of the Little Bighorn.
* [The Ghost Dance (Part 2)](/history/american-history/fall-of-sioux/02-the-ghost-dance.md) — Episode 455: Sitting Bull's pitiful fate and the rise of the Ghost Dance.
* [The Massacre at Wounded Knee (Part 3)](/history/american-history/fall-of-sioux/03-the-massacre-at-wounded-knee.md) — Episode 456: The last of the great Native American leaders picked off by the U.S. Government.
