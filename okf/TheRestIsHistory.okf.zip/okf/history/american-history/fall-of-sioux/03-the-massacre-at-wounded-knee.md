---
type: Section
title: "The Massacre at Wounded Knee (Part 3)"
description: "Episode 456: The last of the great Native American leaders picked off by the U.S. Government."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "sioux", "native-american"]
---

# The Massacre at Wounded Knee (Part 3)

2024-05-30 · 1:02:15 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7996658277.mp3?updated=1716571435)

"I will bury my heart, at Wounded Knee" With Native American culture in free fall in the years following their triumph at the Battle of the Little Bighorn, the rise of the Ghost Dance - a form of spiritual expression that promised liberty from the oppression of 19th century American politics, modernisation and mass entertainment - brought a new hope to the Sioux. Even so, the once great war …