---
type: Section
title: "Death of Crazy Horse (Part 1)"
description: "Episode 454: The beginning of the end for the Lakota after the Battle of the Little Bighorn."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "sioux", "native-american"]
---

# Death of Crazy Horse (Part 1)

2024-05-26 · 52:59 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1647500583.mp3?updated=1716885922)

Though the Battle of the Little Bighorn seemed for the triumphant Lakota and their allies - the largest gathering of Plains Indians ever assembled - a miraculous victory, it was for them the beginning of the end. A great council was held near the battlefield in which they made the fateful decision to split up. Meanwhile, in Washington, Custer's death and the military defeat of the army was being …