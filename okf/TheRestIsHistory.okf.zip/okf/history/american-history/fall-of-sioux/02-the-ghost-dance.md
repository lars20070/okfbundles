---
type: Section
title: "The Ghost Dance (Part 2)"
description: "Episode 455: Sitting Bull's pitiful fate and the rise of the Ghost Dance."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "sioux", "native-american"]
---

# The Ghost Dance (Part 2)

2024-05-29 · 44:50 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2320133118.mp3?updated=1716889721)

Following the tragic death of Crazy Horse and the ruthless cessation of the Sioux way of life, the last of the great Native American leaders were gradually picked off or repressed by the U.S. Government. Few though had so pitiful a fate as the once mighty Lakota War Chieftain, Sitting Bull. Having fled to Canada in search of peace from the relentless harrowing of his people, Sitting Bull finally …