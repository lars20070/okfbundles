---
type: Section
title: "The Charge of the 7th Cavalry (Part 6)"
description: "Episode 451: The government's plan to strike into the heart of Montana."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "custer", "native-american"]
---

# The Charge of the 7th Cavalry (Part 6)

2024-05-16 · 1:00:42 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4301705603.mp3?updated=1716163669)

The U.S. was cast into a spiralling panic following the economic depression of 1873, and waves of paramilitary violence swept through the south as the debates surrounding Reconstruction swirled on. Amidst this uncertainty, the government, under the leadership of Ulysses S. Grant and his chief advisors, began drawing up a cold blooded plan to strike into the heart of Montana and settle the issue …