---
type: Section
title: "The Battle of the Little Bighorn (Part 7)"
description: "Episode 452: One of the totemic moments of American frontier history."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "custer", "little-bighorn", "native-american"]
---

# The Battle of the Little Bighorn (Part 7)

2024-05-20 · 1:01:04 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7290391290.mp3?updated=1716164561)

"You and I are going home today, and by a trail that is strange to us both…" The Battle of The Little Bighorn is one of the totemic moments of American frontier history. However, it is also mysterious, with the exact events of that blood-soaked day difficult to trace. On the 22nd of June, George Custer marched out with vague orders to drive the vast gathering of the Lakota and their allies, under …