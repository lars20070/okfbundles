# Death in the Black Hills (Part 5)

## Episodes

* [Death in the Black Hills (Part 5)](/history/american-history/custers-last-stand/01-death-in-the-black-hills.md) — Episode 450: Custer drifting after the Washita River massacre.
* [The Charge of the 7th Cavalry (Part 6)](/history/american-history/custers-last-stand/02-the-charge-of-the-7th-cavalry.md) — Episode 451: The government's plan to strike into the heart of Montana.
* [The Battle of the Little Bighorn (Part 7)](/history/american-history/custers-last-stand/03-the-battle-of-the-little-bighorn.md) — Episode 452: One of the totemic moments of American frontier history.
* [The Final Showdown (Part 8)](/history/american-history/custers-last-stand/04-the-final-showdown.md) — Episode 453: The gruesome discovery of Custer's forces at the Little Bighorn.
