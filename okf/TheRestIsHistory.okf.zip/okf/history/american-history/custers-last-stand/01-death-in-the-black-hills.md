---
type: Section
title: "Death in the Black Hills (Part 5)"
description: "Episode 450: Custer drifting after the Washita River massacre."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "custer", "native-american"]
---

# Death in the Black Hills (Part 5)

2024-05-15 · 56:33 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1497339770.mp3?updated=1715612784)

In the wake of the barbaric Washita River massacre, George Custer found himself drifting; addicted to gambling, at odds with his wife, and failing in his efforts to take advantage of the American gold rush in New York. Finally, Custer was sent to Kentucky to suppress the terrible post war fighting there, but again found himself alienated from many of his companions by his controversial views on …