---
type: Section
title: "The Final Showdown (Part 8)"
description: "Episode 453: The gruesome discovery of Custer's forces at the Little Bighorn."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "custer", "little-bighorn", "native-american"]
---

# The Final Showdown (Part 8)

2024-05-22 · 1:04:17 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT8261745977.mp3?updated=1716402472)

What happened between the moment that George A. Custer dispatched a trumpeter with his famous final plea for back-up, and the gruesome discovery of his forces at the Little Bighorn? Certainly, the morning of the 26th of June 1876 found the overwhelmed Major Reno and what remained of his men, along with Captain Benteen, gathered atop a hill, bloody, dehydrated, surrounding by putrefying corpses …