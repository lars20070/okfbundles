---
type: Section
title: "The Rise of Evil (Part 1)"
description: "Episode 654: The formation of the first Ku Klux Klan in 1866 and its impact on former slaves."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, usa, kkk]
---

# The Rise of Evil (Part 1)

2026-03-23 · 1:09:05 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2601231794.mp3?updated=1774193991)

How did the three iterations of the Ku Klux Klan come into being in 1866, 1915, and the late 1940s? What was the impact of the American Civil War and the Abolition of slavery in 1863 on the rise of this terrifying institution? And, what was the condition of the former slaves in the American South? Join Dominic and Tom as they unfold the history behind the formation of the first Ku Klux Klan, its …
