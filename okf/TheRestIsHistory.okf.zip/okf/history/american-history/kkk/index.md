# The Rise of Evil (Part 1)

## Episodes

* [The Rise of Evil (Part 1)](/history/american-history/kkk/01-the-rise-of-evil.md) — Episode 654: The formation of the first Ku Klux Klan in 1866 and its impact on former slaves.
* [Terror in the South (Part 2)](/history/american-history/kkk/02-terror-in-the-south.md) — Episode 655: The escalating violence and political context of the Ku Klux Klan.
* [Birth of a Nation (Part 3)](/history/american-history/kkk/03-birth-of-a-nation.md) — Episode 656: The second incarnation of the KKK and its nationwide growth.
* [American Fascists (Part 4)](/history/american-history/kkk/04-american-fascists.md) — Episode 657: The Klan's move on American elections and its reckoning.
