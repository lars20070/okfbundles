---
type: Section
title: "Terror in the South (Part 2)"
description: "Episode 655: The escalating violence and political context of the Ku Klux Klan."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, usa, kkk]
---

# Terror in the South (Part 2)

2026-03-26 · 1:10:56 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT2904395784.mp3?updated=1774286562)

How and why did the terrible violence of the Ku Klux Klan escalate? What was the political context in America for their rising popularity? And, how was this first iteration of the Klan finally brought down? Join Dominic and Tom as they discuss American politics after the Civil War, the growing popularity of the Ku Klux Klan in the American south and their increasingly barbaric treatment of …
