---
type: Section
title: "American Fascists (Part 4)"
description: "Episode 657: The Klan's move on American elections and its reckoning."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, usa, kkk]
---

# American Fascists (Part 4)

2026-04-01 · 1:11:31 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4147819855.mp3?updated=1774886633)

After resurrecting in 1915, how did the Ku Klux Klan make its move on the next major American election? What was the role of women in the Klan? And, would this violent organisation finally meet its reckoning? Join Tom and Dominic as they reach the tragic climax of their exploration into the rise and fall of the Ku Klux Klan.
