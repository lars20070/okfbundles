---
type: Section
title: "Birth of a Nation (Part 3)"
description: "Episode 656: The second incarnation of the KKK and its nationwide growth."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, usa, kkk]
---

# Birth of a Nation (Part 3)

2026-03-29 · 1:15:09 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9883414135.mp3?updated=1774622635)

How did the second incarnation of the clan, born in Georgia in 1915, grow into a seemingly indomitable nation-wide fraternal organisation, numbering millions? Who were its new targets? And, with the Klan's momentum seemingly unstoppable and an election on the horizon, would their appalling violence be publicly condemned? Join Tom and Dominic as they chart the second rise of the violent …
