---
type: Section
title: "The Causes (Part 1)"
description: "Welcome to The Rest Is History 'American Civil War' series. The first of a four part series."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "american-civil-war"]
---

# The Causes (Part 1)

2022-06-27 · 57:58 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1124511401.mp3?updated=1777394940)

Welcome to The Rest Is History 'American Civil War' series. The release schedule of the four episodes is as follows: The Causes (Monday 27th June) Outbreak (Tuesday 28th June) Gettysburg (Thursday 30th June) Aftermath & Legacy (Monday 4th July) However, members of The Rest Is History Club get all four episodes RIGHT NOW, so head to restishistorypod.com to sign up. In the first of a four part …
