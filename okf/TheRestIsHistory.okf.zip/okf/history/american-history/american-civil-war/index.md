# The Causes (Part 1)

## Episodes

* [The Causes (Part 1)](/history/american-history/american-civil-war/01-the-causes.md) — Welcome to The Rest Is History 'American Civil War' series. The first of a four part series.
* [Outbreak (Part 2)](/history/american-history/american-civil-war/02-outbreak.md) — Welcome to the second episode in The Rest Is History's 'American Civil War' series.
* [Gettysburg (Part 3)](/history/american-history/american-civil-war/03-gettysburg.md) — Tom, Dominic and historian Adam Smith look at the most famous battle of the war.
* [Aftermath & Legacy (Part 4)](/history/american-history/american-civil-war/04-aftermath-and-legacy.md) — In the final episode of this 'American Civil War' series, Tom, Dominic and historian Adam Smith look at the end of the conflict.
