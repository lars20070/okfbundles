---
type: Section
title: "Gettysburg (Part 3)"
description: "Tom, Dominic and historian Adam Smith look at the most famous battle of the war."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "american-civil-war"]
---

# Gettysburg (Part 3)

2022-06-30 · 50:02 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5256515778.mp3?updated=1777395017)

Tom, Dominic and historian Adam Smith look at the most famous battle of the war and Abraham Lincoln's 272 word address that became one of the best known speeches of all time. They also discuss the conditions of the black population during the conflict. The release date of the last episode, 'Aftermath & Legacy', is Monday 4th July. However, members of The Rest Is History Club get all episodes …
