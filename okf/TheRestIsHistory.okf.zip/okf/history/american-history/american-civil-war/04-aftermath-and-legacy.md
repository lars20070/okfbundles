---
type: Section
title: "Aftermath & Legacy (Part 4)"
description: "In the final episode of this 'American Civil War' series, Tom, Dominic and historian Adam Smith look at the end of the conflict."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "american-civil-war"]
---

# Aftermath & Legacy (Part 4)

2022-07-04 · 49:12 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3990109453.mp3?updated=1777394871)

In the final episode of this 'American Civil War' series, Tom, Dominic and historian Adam Smith look at the end of the conflict, the subsequent assassination of Abraham Lincoln and how the war is viewed in modern day America. Join The Rest Is History Club for ad-free listening to the full archive, weekly bonus episodes, live streamed shows and access to an exclusive chatroom community.
