---
type: Section
title: "Outbreak (Part 2)"
description: "Welcome to the second episode in The Rest Is History's 'American Civil War' series."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "american-civil-war"]
---

# Outbreak (Part 2)

2022-06-28 · 50:25 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4100428000.mp3?updated=1777394891)

Welcome to the second episode in The Rest Is History's 'American Civil War' series. The release schedule of the remaining two episodes is as follows: Gettysburg (Thursday 30th June) Aftermath & Legacy (Monday 4th July) However, members of The Rest Is History Club get all episodes RIGHT NOW, so head to restishistorypod.com to sign up. In today's pod, Dominic, Tom and historian Adam Smith discuss …
