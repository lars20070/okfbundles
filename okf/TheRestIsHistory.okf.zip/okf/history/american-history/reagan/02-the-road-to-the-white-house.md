---
type: Section
title: "The Road to the White House (Part 2)"
description: "Episode 311: His Hollywood career drying up, Ronald Reagan works for the Screen Actors Guild and General Electric in the 1950s."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "ronald-reagan", "usa"]
---

# The Road to the White House (Part 2)

2023-03-09 · 59:51 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9813084891.mp3?updated=1777394923)

His Hollywood career drying up, Ronald Reagan works both for the Screen Actors Guild and General Electric in the 1950s. Building connections with the Californian elite, and having gained national attention with a speech for the Republican presidential candidate in 1964, he becomes Governor of California in 1966. A pragmatic, anti-hippie, centre-right governor, he goes on to win the Republican …