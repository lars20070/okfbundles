# Ronald Reagan and the American Dream (Part 1)

## Episodes

* [Ronald Reagan and the American Dream (Part 1)](/history/american-history/reagan/01-ronald-reagan-and-the-american-dream.md) — Episode 310: Ronald 'Dutch' Reagan was born in 1911 to a humble family of Illinois.
* [The Road to the White House (Part 2)](/history/american-history/reagan/02-the-road-to-the-white-house.md) — Episode 311: His Hollywood career drying up, Ronald Reagan works for the Screen Actors Guild and General Electric in the 1950s.
* [Reagan, Iran-Contra and the Cold War (Part 3)](/history/american-history/reagan/03-reagan-iran-contra-and-the-cold-war.md) — Episode 312: Warmonger or nuclear disarmer? Ronald Reagan's presidency survived an assassination attempt, the AIDS epidemic and the Iranian hostage crisis.
