---
type: Section
title: "Reagan, Iran-Contra and the Cold War (Part 3)"
description: "Episode 312: Warmonger or nuclear disarmer? Ronald Reagan's presidency survived an assassination attempt, the AIDS epidemic and the Iranian hostage crisis."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "ronald-reagan", "usa", "cold-war"]
---

# Reagan, Iran-Contra and the Cold War (Part 3)

2023-03-13 · 58:29 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT4042202229.mp3?updated=1777394895)

Warmonger or nuclear disarmer? Ronald Reagan's presidency survived an assassination attempt, the AIDS epidemic and the Iranian hostage crisis. He powered through the 1980s, creating his own truth and narrative, in a series of events that read like a Hollywood screenplay. Tom and Dominic take a look at the impact of Reagan's presidency, the enduring effects of his politics, and why none of the …