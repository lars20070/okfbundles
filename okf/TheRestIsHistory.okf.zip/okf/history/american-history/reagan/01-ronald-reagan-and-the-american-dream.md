---
type: Section
title: "Ronald Reagan and the American Dream (Part 1)"
description: "Episode 310: Ronald 'Dutch' Reagan was born in 1911 to a humble family of Illinois."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "ronald-reagan", "usa"]
---

# Ronald Reagan and the American Dream (Part 1)

2023-03-06 · 56:58 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3254036306.mp3?updated=1777394149)

Ronald "Dutch" Reagan was born in 1911 to a humble family of Illinois, his father an FDR-loving democrat, his mother a notable member of the local Christian community. A high school football star, "Dutch" would grow up to become one of America's favourite sports broadcasters, a Hollywood actor and a union leader, before finally entering American political life in 1964. The first episode of our …