---
type: Section
title: "The Birth of the United States (Part 3)"
description: "Episode 349: The U.S. Congress votes for independence on the 2nd of July 1776."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "american-revolution", "usa"]
---

# The Birth of the United States (Part 3)

2023-07-10 · 48:08 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9804967639.mp3?updated=1777394758)

"O ye that love mankind! Ye that dare oppose, not only the tyranny, but the tyrant, stand forth!" The U.S. Congress votes for independence on the 2nd of July 1776, and George Washington reads the Declaration of Independence to his troops a few days later, after which they pull down the statue of George III in New York, melting it down to make bullets. The king is now the target of the …