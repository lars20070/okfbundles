---
type: Section
title: "The Boston Tea Party (Part 2)"
description: "Episode 348: The Boston Tea Party occurs amid the growing disagreements between the British parliament and the people of colonial America."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "american-revolution", "usa"]
---

# The Boston Tea Party (Part 2)

2023-07-06 · 57:34 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT5189620267.mp3?updated=1777394801)

"Last night three cargos of tea were emptied into the sea. This morning a man of war sails. This is the most magnificent movement of all. There is a dignity, a majesty, a sublimity, in this last effort of the patriots, that I greatly admire." The Boston Tea Party occurs amid the growing disagreements between the British parliament and the people of colonial America, as New Englanders, and …