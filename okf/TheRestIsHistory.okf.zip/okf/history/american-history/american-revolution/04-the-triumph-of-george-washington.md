---
type: Section
title: "The Triumph of George Washington (Part 4)"
description: "Episode 350: With the French and Spanish siding with George Washington's revolutionaries."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "american-revolution", "usa", "washington"]
---

# The Triumph of George Washington (Part 4)

2023-07-13 · 57:53 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT1619660676.mp3?updated=1776972844)

With the French and Spanish siding with George Washington's revolutionaries, the game is up for the British, and it seems time for them to cut their losses. Following the surrender of General Cornwallis at Yorktown, the war is effectively over, but what are the short and long term consequences of this? In our final episode on the American revolution, Tom, Dominic and Professor Adam Smith look at …