# The American Revolution (Part 1)

## Episodes

* [The American Revolution (Part 1)](/history/american-history/american-revolution/01-the-american-revolution.md) — Episode 347: The American Revolution came about due to growing tensions between the American colonies and Great Britain.
* [The Boston Tea Party (Part 2)](/history/american-history/american-revolution/02-the-boston-tea-party.md) — Episode 348: The Boston Tea Party occurs amid the growing disagreements between the British parliament and the people of colonial America.
* [The Birth of the United States (Part 3)](/history/american-history/american-revolution/03-the-birth-of-the-united-states.md) — Episode 349: The U.S. Congress votes for independence on the 2nd of July 1776.
* [The Triumph of George Washington (Part 4)](/history/american-history/american-revolution/04-the-triumph-of-george-washington.md) — Episode 350: With the French and Spanish siding with George Washington's revolutionaries.
