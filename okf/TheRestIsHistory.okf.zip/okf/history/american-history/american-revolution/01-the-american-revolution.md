---
type: Section
title: "The American Revolution (Part 1)"
description: "Episode 347: The American Revolution came about due to growing tensions between the American colonies and Great Britain."
timestamp: 2026-08-12T11:42:04Z
tags: ["podcast", "history", "american-revolution", "usa"]
---

# The American Revolution (Part 1)

2023-07-03 · 57:45 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3042850673.mp3?updated=1777394912)

"America, late the strength, now the foe to Britain, dismembered, torn, I fear forever lost to England, whence she sprung." The American Revolution came about due to growing tensions between the American colonies and Great Britain, primarily over issues of taxation and representation. It led to the birth of the United States of America, established upon Enlightenment principles of liberal …