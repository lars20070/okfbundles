# Asia Pacific

## Series

* [Lady Murasaki and the Shining Prince (Part 1)](/history/asia-pacific/golden-age-of-japan/) — Series about Lady Murasaki and the Shining Prince (Part 1)
* [The Shadow of the Sword (Part 1)](/history/asia-pacific/samurai/) — Series about The Shadow of the Sword (Part 1)
