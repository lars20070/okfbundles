# Asia Pacific

## Series

* [The Golden Age of Japan](/history/asia-pacific/golden-age-of-japan/) — 2 episodes
* [The Samurai](/history/asia-pacific/samurai/) — 4 episodes
