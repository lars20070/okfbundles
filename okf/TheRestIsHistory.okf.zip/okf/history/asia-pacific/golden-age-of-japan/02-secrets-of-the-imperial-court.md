---
type: Section
title: "Secrets of the Imperial Court (Part 2)"
description: "Episode 561: Sei Shōnagon and life around the Japanese Empress."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, japan, heian, sei-shonagon]
---

# Secrets of the Imperial Court (Part 2)

2025-04-30 · 1:06:47 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT9428275194.mp3?updated=1746033394)

In the vibrant but vicious golden age of Imperial Japan, how did women use writing as a way to secure their status, and express their deepest desires? Who was Sei Shōnagon, the witty courtier whose account of life around the Japanese Empress during the iconic Heian period, provides a scintillating insight into this colourful world? And, behind the sophisticated melee of the Imperial court, with …
