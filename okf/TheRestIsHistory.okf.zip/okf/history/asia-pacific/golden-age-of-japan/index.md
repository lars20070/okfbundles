# Lady Murasaki and the Shining Prince (Part 1)

## Episodes

* [Lady Murasaki and the Shining Prince (Part 1)](/history/asia-pacific/golden-age-of-japan/01-lady-murasaki-and-the-shining-prince.md) — Episode 560: The Tale of Genji and the imperial family.
* [Secrets of the Imperial Court (Part 2)](/history/asia-pacific/golden-age-of-japan/02-secrets-of-the-imperial-court.md) — Episode 561: Sei Shōnagon and life around the Japanese Empress.
