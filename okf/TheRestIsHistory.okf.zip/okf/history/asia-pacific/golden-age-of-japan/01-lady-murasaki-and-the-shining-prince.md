---
type: Section
title: "Lady Murasaki and the Shining Prince (Part 1)"
description: "Episode 560: The Tale of Genji and the imperial family."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, japan, heian, tale-of-genji]
---

# Lady Murasaki and the Shining Prince (Part 1)

2025-04-27 · 54:14 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT6500007351.mp3?updated=1745945479)

At the height of Imperial Japan, during a golden age of court intrigue, obsessive hierarchy, and fabulous sophistication, who was the legendary lothario and emperor's son, Genji? What can the Tale of Genji - a great masterpiece of Japanese literature - tell us about this remarkable and alien world, and the imperial family at the heart of it? Who was the woman who wrote it, at a time when in the …
