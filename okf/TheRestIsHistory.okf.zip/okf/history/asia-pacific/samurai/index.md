# The Shadow of the Sword (Part 1)

## Episodes

* [The Shadow of the Sword (Part 1)](/history/asia-pacific/samurai/01-shadow-of-the-sword.md) — Episode 658: The origin and rise of the mighty Samurai in 12th century Japan.
* [Bloodbath at the Bridge (Part 2)](/history/asia-pacific/samurai/02-bloodbath-at-the-bridge.md) — Episode 659: The ferocious Samurai civil war between the Minamoto and Taira dynasties.
* [Japan's Greatest Warrior (Part 3)](/history/asia-pacific/samurai/03-japans-greatest-warrior.md) — Episode 660: Yoshitsune and the decisive victory in Samurai history.
* [The Shōgun Triumphant (Part 4)](/history/asia-pacific/samurai/04-the-shogun-triumphant.md) — Episode 661: The greatest female Samurai warrior and the rise of the Samurai.
