---
type: Section
title: "Bloodbath at the Bridge (Part 2)"
description: "Episode 659: The ferocious Samurai civil war between the Minamoto and Taira dynasties."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, japan, samurai]
---

# Bloodbath at the Bridge (Part 2)

2026-04-08 · 1:07:26 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3420393571.mp3?updated=1775760569)

*No description in the feed.*
