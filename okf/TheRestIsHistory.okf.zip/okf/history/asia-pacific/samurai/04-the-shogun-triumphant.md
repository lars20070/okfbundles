---
type: Section
title: "The Shōgun Triumphant (Part 4)"
description: "Episode 661: The greatest female Samurai warrior and the rise of the Samurai."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, japan, samurai]
---

# The Shōgun Triumphant (Part 4)

2026-04-15 · 1:04:51 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7837412375.mp3?updated=1776592324)

Who was the greatest female Samurai warrior of all time? What would unfold in the next phase of the terrible civil war between the Minamoto and the Taira dynasties? And, how did the Samurai finally become the masters of Japan? Join Tom and Dominic as they reach the climactic conclusion of their journey into the rise of the Samurai.
