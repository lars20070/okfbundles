---
type: Section
title: "The Shadow of the Sword (Part 1)"
description: "Episode 658: The origin and rise of the mighty Samurai in 12th century Japan."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, japan, samurai]
---

# The Shadow of the Sword (Part 1)

2026-04-05 · 1:03:27 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT7378881498.mp3?updated=1775643305)

*No description in the feed.*
