---
type: Section
title: "Japan's Greatest Warrior (Part 3)"
description: "Episode 660: Yoshitsune and the decisive victory in Samurai history."
timestamp: 2026-08-12T11:42:04Z
tags: [podcast, history, japan, samurai]
---

# Japan's Greatest Warrior (Part 3)

2026-04-12 · 1:01:28 · [audio](https://pdst.fm/e/traffic.megaphone.fm/GLT3581345898.mp3?updated=1776098535)

Who was Yoshitsune, one of the greatest generals in all Japanese history? What part did he play in the ferocious Samurai civil war between the Minamoto clan and the Taira? And, who would win the most decisive victory in all of Samurai history? Join Tom and Dominic as they delve deeper into the origin, rise, and triumph of the mighty Samurai, in 12th century Japan.
