---
type: Section
title: "Interviews & Guest Episodes"
description: "Tom and Dominic in conversation."
tags: [specials]
timestamp: "2026-08-16T00:00:00Z"
---

# Interviews & Guest Episodes

Tom and Dominic in conversation.

2 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 37 | [Spies, with Ben MacIntyre](https://pdst.fm/e/traffic.megaphone.fm/GLT4382644548.mp3?updated=1777394940) | 2021-03-25 |
| 670 | [Tom Holland Meets Paul McCartney](https://pdst.fm/e/traffic.megaphone.fm/GLT5781731754.mp3) | 2026-05-14 |
