# Specials & Extras

Live shows, interviews, 12 Days specials, World Cup brackets, and one-offs.

32 episodes.

## Subtopics
* [Miscellaneous Specials](/specials/misc-specials.md) — Standalone one-off episodes. (13 episodes)
* [European Country Specials](/specials/europe-countries.md) — World Cup country-themed episodes. (13 episodes)
* [Interviews & Guest Episodes](/specials/interviews.md) — Tom and Dominic in conversation. (2 episodes)
* [12 Days Specials](/specials/twelve-days.md) — The annual Christmas series. (4 episodes)
