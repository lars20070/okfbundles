---
type: Section
title: "12 Days Specials"
description: "The annual Christmas series."
tags: [specials]
timestamp: "2026-08-16T00:00:00Z"
---

# 12 Days Specials

The annual Christmas series.

4 episodes.

| # | Episode | Date |
| --- | --- | --- |
| — | [12 Days: Good King Wenceslas and the first Gilbert & Sullivan](https://pdst.fm/e/traffic.megaphone.fm/GLT4255677286.mp3?updated=1777394755) | 2021-12-26 |
| — | [12 Days: Massacre of the Innocents and the Tay Bridge disaster](https://pdst.fm/e/traffic.megaphone.fm/GLT2451242270.mp3?updated=1777394811) | 2021-12-28 |
| — | [12 Days: The Battle of Wakefield and Emperor Karl I](https://pdst.fm/e/traffic.megaphone.fm/GLT9919744248.mp3?updated=1777394720) | 2021-12-30 |
| — | [12 Days: Solomon Northup and Albert Camus](https://pdst.fm/e/traffic.megaphone.fm/GLT6039583450.mp3?updated=1777394817) | 2022-01-04 |
