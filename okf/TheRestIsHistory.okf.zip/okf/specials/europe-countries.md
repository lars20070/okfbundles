---
type: Section
title: "European Country Specials"
description: "World Cup country-themed episodes."
tags: [specials]
timestamp: "2026-08-16T00:00:00Z"
---

# European Country Specials

World Cup country-themed episodes.

13 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 227 | [Portugal: On the Edge of the World (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT1834337589.mp3?updated=1729784908) | 2022-09-05 |
| 255 | [Qatar: A History](https://pdst.fm/e/traffic.megaphone.fm/GLT4853394229.mp3?updated=1777394995) | 2022-11-17 |
| 261 | [Uruguay: The Tupamaros](https://pdst.fm/e/traffic.megaphone.fm/GLT1539968794.mp3?updated=1777394589) | 2022-11-23 |
| 266 | [South Korea: The Riddle of Hwang Jini](https://pdst.fm/e/traffic.megaphone.fm/GLT1910695360.mp3?updated=1777394744) | 2022-11-28 |
| 267 | [Wales: The Roar of the Red Dragon](https://pdst.fm/e/traffic.megaphone.fm/GLT2657098007.mp3?updated=1777395002) | 2022-11-29 |
| 270 | [Poland: Copernicus, the Dragon and the Salt Mine](https://pdst.fm/e/traffic.megaphone.fm/GLT2590789810.mp3?updated=1777394218) | 2022-12-02 |
| 271 | [Belgium: History's Greatest Artist](https://pdst.fm/e/traffic.megaphone.fm/GLT1331750756.mp3?updated=1777394200) | 2022-12-03 |
| 273 | [Portugal: The Carnation Revolution](https://pdst.fm/e/traffic.megaphone.fm/GLT3297148398.mp3?updated=1777394212) | 2022-12-05 |
| 276 | [Netherlands: The Maid of Holland](https://pdst.fm/e/traffic.megaphone.fm/GLT8981353378.mp3?updated=1777394174) | 2022-12-08 |
| 280 | [Serbia: The Birthplace of Civilisation](https://pdst.fm/e/traffic.megaphone.fm/GLT4941340070.mp3?updated=1777394165) | 2022-12-12 |
| 283 | [Ecuador: Darwin's Adventure to the Galapagos](https://pdst.fm/e/traffic.megaphone.fm/GLT2992613399.mp3?updated=1777394176) | 2022-12-15 |
| 285 | [Canada: Beaver Wars](https://pdst.fm/e/traffic.megaphone.fm/GLT6084067740.mp3?updated=1777394215) | 2022-12-17 |
| 680 | [The Netherlands: The Revolt that Made The Modern World (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT4209356543.mp3) | 2026-06-17 |
