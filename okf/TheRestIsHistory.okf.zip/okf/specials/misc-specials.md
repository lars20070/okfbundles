---
type: Section
title: "Miscellaneous Specials"
description: "Standalone one-off episodes."
tags: [specials]
timestamp: "2026-08-16T00:00:00Z"
---

# Miscellaneous Specials

Standalone one-off episodes.

13 episodes.

| # | Episode | Date |
| --- | --- | --- |
| — | [Trailer](https://pdst.fm/e/traffic.megaphone.fm/GLT4186105386.mp3?updated=1773403834) | 2020-10-28 |
| 27 | [Tutankhamun](https://pdst.fm/e/traffic.megaphone.fm/GLT2697164979.mp3?updated=1777394975) | 2021-03-01 |
| 109 | [Dinosaurs](https://pdst.fm/e/traffic.megaphone.fm/GLT4328792494.mp3?updated=1777395015) | 2021-10-18 |
| 127 | [Neanderthals](https://pdst.fm/e/traffic.megaphone.fm/GLT5202048433.mp3?updated=1777395073) | 2021-12-02 |
| 299 | [The Greatest Female Pharaoh](https://pdst.fm/e/traffic.megaphone.fm/GLT5076645168.mp3?updated=1777394196) | 2023-01-30 |
| 361 | [The Lost Library of Alexandria](https://pdst.fm/e/traffic.megaphone.fm/GLT1578679297.mp3?updated=1692571845) | 2023-08-20 |
| 427 | [Titanic: The Tragedy Begins (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT3124111041.mp3?updated=1710109452) | 2024-03-11 |
| 428 | [Titanic: Kings of the World (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT7773063166.mp3?updated=1710109933) | 2024-03-12 |
| 429 | [Titanic: Countdown to Disaster (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT1273657377.mp3?updated=1710410949) | 2024-03-14 |
| 430 | [Titanic: The Iceberg Strikes (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT2129072034.mp3?updated=1710526023) | 2024-03-18 |
| 431 | [Titanic: Nightmare at Midnight (Part 5)](https://pdst.fm/e/traffic.megaphone.fm/GLT2941711597.mp3?updated=1710797587) | 2024-03-19 |
| 432 | [Titanic: The Survivors (Part 6)](https://pdst.fm/e/traffic.megaphone.fm/GLT4613169046.mp3?updated=1710797624) | 2024-03-21 |
| 690 | [A Murderous Affair: Death at Mayerling (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT7203783068.mp3) | 2026-07-22 |
