---
type: Section
title: "Mary, Queen of Scots"
description: "The rival queen whose life was a cascade of scandal and tragedy."
tags: [tudor-stuart-britain]
timestamp: "2026-08-16T00:00:00Z"
---

# Mary, Queen of Scots

The rival queen whose life was a cascade of scandal and tragedy.

6 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 584 | [Mary, Queen of Scots: Birth of a Legend (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT7723962252.mp3?updated=1753939684) | 2025-07-20 |
| 585 | [Mary, Queen of Scots: The Royal Rivals (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT5612344391.mp3?updated=1753942527) | 2025-07-23 |
| 586 | [Mary, Queen of Scots: The Battle for Scotland (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT1545905247.mp3?updated=1753917314) | 2025-07-27 |
| 587 | [Mary, Queen of Scots: Murder Most Foul (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT2035316933.mp3?updated=1753936999) | 2025-07-30 |
| 588 | [Mary, Queen of Scots: The Mystery of the Exploding Mansion (Part 5)](https://pdst.fm/e/traffic.megaphone.fm/GLT2383249995.mp3?updated=1754129911) | 2025-08-03 |
| 589 | [Mary, Queen of Scots: Downfall (Part 6)](https://pdst.fm/e/traffic.megaphone.fm/GLT8999516788.mp3?updated=1754478548) | 2025-08-06 |
