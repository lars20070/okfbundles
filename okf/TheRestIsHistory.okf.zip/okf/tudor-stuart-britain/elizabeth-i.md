---
type: Section
title: "Elizabeth I"
description: "The Virgin Queen, her rivals, and the wars of religion."
tags: [tudor-stuart-britain]
timestamp: "2026-08-16T00:00:00Z"
---

# Elizabeth I

The Virgin Queen, her rivals, and the wars of religion.

13 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 39 | [Elizabeth I](https://pdst.fm/e/traffic.megaphone.fm/GLT7302124935.mp3?updated=1777394989) | 2021-04-01 |
| 232 | [Queen Elizabeth II (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT5667149245.mp3?updated=1775852029) | 2022-09-09 |
| 231 | [Queen Elizabeth II (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT2826379729.mp3?updated=1775851953) | 2022-09-09 |
| 542 | [Elizabeth I’s Sorcerer: Angels and Demons in Renaissance Europe](https://pdst.fm/e/traffic.megaphone.fm/GLT4512754016.mp3?updated=1740334108) | 2025-02-24 |
| 616 | [Elizabeth I: The Fall of the Axe (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT9331634740.mp3?updated=1763641855) | 2025-11-10 |
| 617 | [Elizabeth I: Anne Boleyn's Bastard (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT2585433242.mp3?updated=1763641944) | 2025-11-13 |
| 618 | [Elizabeth I: The Shadow of the Tower (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT7928851339.mp3?updated=1763138973) | 2025-11-17 |
| 619 | [Elizabeth I: The Virgin Queen (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT7930465337.mp3?updated=1763549960) | 2025-11-20 |
| 691 | [Elizabeth I vs The Catholics: The Queen’s Spymaster (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT8312620561.mp3) | 2026-07-26 |
| 692 | [Elizabeth I vs The Catholics: A Massacre in Paris (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT4665799025.mp3) | 2026-07-29 |
| 693 | [Elizabeth I vs The Catholics: England’s Greatest Hero (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT5069845329.mp3) | 2026-08-02 |
| 694 | [Elizabeth I vs The Catholics: A Treacherous Conspiracy (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT1627515087.mp3) | 2026-08-05 |
| 695 | [Elizabeth I vs The Catholics: The Shadow War (Part 5)](https://pdst.fm/e/traffic.megaphone.fm/GLT5637968455.mp3) | 2026-08-09 |
