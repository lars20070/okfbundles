---
type: Section
title: "Civil War & Commonwealth"
description: "The trial of Charles I, Cromwell, and the Republic."
tags: [tudor-stuart-britain]
timestamp: "2026-08-16T00:00:00Z"
---

# Civil War & Commonwealth

The trial of Charles I, Cromwell, and the Republic.

9 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 30 | [A Royal Row](https://pdst.fm/e/traffic.megaphone.fm/GLT5120507213.mp3?updated=1777394855) | 2021-03-09 |
| 54 | [Cromwell and the Protectorate](https://pdst.fm/e/traffic.megaphone.fm/GLT5457562231.mp3?updated=1777395002) | 2021-05-20 |
| 115 | [The Gunpowder Plot](https://pdst.fm/e/traffic.megaphone.fm/GLT1711431752.mp3?updated=1777394980) | 2021-11-04 |
| 143 | [The Trial of Charles I Part 1](https://pdst.fm/e/traffic.megaphone.fm/GLT4850801452.mp3?updated=1777394936) | 2022-01-27 |
| 144 | [The Trial of Charles I Part 2](https://pdst.fm/e/traffic.megaphone.fm/GLT2968292003.mp3?updated=1777394902) | 2022-01-28 |
| 293 | [Lady Jane Grey: The Nine Days' Queen (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT2281550812.mp3?updated=1777394177) | 2023-01-09 |
| 294 | [Lady Jane Grey: The Axe Falls (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT7286066638.mp3?updated=1777394924) | 2023-01-12 |
| 333 | [The Republic of Britain: Life under Cromwell](https://pdst.fm/e/traffic.megaphone.fm/GLT3360112790.mp3?updated=1777394918) | 2023-05-18 |
| 336 | [Ireland: Celts, Conquest and Cromwell (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT6280042699.mp3?updated=1777394205) | 2023-05-29 |
