# Tudor & Stuart Britain

From the Tudor dynasty through the Civil War to the Glorious Revolution.

28 episodes.

## Subtopics
* [Elizabeth I](/tudor-stuart-britain/elizabeth-i.md) — The Virgin Queen, her rivals, and the wars of religion. (13 episodes)
* [Mary, Queen of Scots](/tudor-stuart-britain/mary-queen-of-scots.md) — The rival queen whose life was a cascade of scandal and tragedy. (6 episodes)
* [Civil War & Commonwealth](/tudor-stuart-britain/civil-war-commonwealth.md) — The trial of Charles I, Cromwell, and the Republic. (9 episodes)
