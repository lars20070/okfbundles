# Africa

The history of the African continent.

7 episodes.

## Subtopics
* [Southern Africa](/africa/southern-africa.md) — South Africa and apartheid. (1 episodes)
* [Central Africa](/africa/central-africa.md) — The Congo and its troubled history. (3 episodes)
* [Other African Topics](/africa/other-africa.md) — Across the continent. (3 episodes)
