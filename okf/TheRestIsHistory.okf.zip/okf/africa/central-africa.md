---
type: Section
title: "Central Africa"
description: "The Congo and its troubled history."
tags: [africa]
timestamp: "2026-08-16T00:00:00Z"
---

# Central Africa

The Congo and its troubled history.

3 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 538 | [Horror in the Congo: The Nightmare Begins  (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT1431012085.mp3?updated=1738860407) | 2025-02-10 |
| 539 | [Horror in the Congo: The Crimes of Empire (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT5467841243.mp3?updated=1740400440) | 2025-02-13 |
| 541 | [Heart of Darkness: Fear and Loathing in the Congo](https://pdst.fm/e/traffic.megaphone.fm/GLT5482142786.mp3?updated=1784112568) | 2025-02-20 |
