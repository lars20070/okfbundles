---
type: Section
title: "The Roman Empire"
description: "The emperors, conquests, and daily life of Imperial Rome."
tags: [ancient-rome]
timestamp: "2026-08-16T00:00:00Z"
---

# The Roman Empire

The emperors, conquests, and daily life of Imperial Rome.

18 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 16 | [Pompeii](https://pdst.fm/e/traffic.megaphone.fm/GLT3349011345.mp3?updated=1777395023) | 2021-01-21 |
| 56 | [Nero](https://pdst.fm/e/traffic.megaphone.fm/GLT7241559003.mp3?updated=1777394991) | 2021-05-24 |
| — | [12 Days: Nero's succession and the fall of the Byzantine Empire](https://pdst.fm/e/traffic.megaphone.fm/GLT6148714296.mp3?updated=1777394847) | 2022-01-01 |
| 218 | [Theodora: Empress of Byzantium (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT5957583440.mp3?updated=1729785075) | 2022-08-08 |
| 219 | [Justinian: Making Rome Great Again (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT2369595847.mp3?updated=1729785106) | 2022-08-09 |
| 220 | [Justinian & Theodora: The Secret History (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT6795699757.mp3?updated=1729785125) | 2022-08-11 |
| 224 | [Roman Holidays](https://pdst.fm/e/traffic.megaphone.fm/GLT9939678940.mp3?updated=1694605641) | 2022-08-25 |
| 340 | [Hadrian and Antinous](https://pdst.fm/e/traffic.megaphone.fm/GLT4184410900.mp3?updated=1777394884) | 2023-06-12 |
| 355 | [Roman Apocalypse: Pompeii 79 AD](https://pdst.fm/e/traffic.megaphone.fm/GLT6664993493.mp3?updated=1692016065) | 2023-07-30 |
| 369 | [The Colosseum: Rome's Arena of Death](https://pdst.fm/e/traffic.megaphone.fm/GLT7808118779.mp3?updated=1694986733) | 2023-09-17 |
| 412 | [Romans in Space: Star Wars, Dune and Beyond...](https://pdst.fm/e/traffic.megaphone.fm/GLT3832078172.mp3?updated=1706183833) | 2024-01-25 |
| 500 | [The Roman Conquest of Britain: The Empire Strikes Back (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT3137178317.mp3?updated=1727886683) | 2024-10-02 |
| 501 | [The Roman Conquest of Britain: Boudicca’s Reign of Blood (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT3128836892.mp3?updated=1728255952) | 2024-10-06 |
| 502 | [The Roman Conquest of Britain: To the Ends of the Earth (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT1970351222.mp3?updated=1728515096) | 2024-10-09 |
| 534 | [Emperors of Rome: Sex Secrets of the Caesars (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT3696933602.mp3?updated=1738008610) | 2025-01-27 |
| 535 | [Emperors of Rome: Tiberius, Slaughter and Scandal (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT6029756405.mp3?updated=1738542150) | 2025-01-30 |
| 536 | [Emperors of Rome: Caligula, Incest and Insanity (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT6260105026.mp3?updated=1738534057) | 2025-02-03 |
| 537 | [Emperors of Rome: Claudius, Paranoia and Poison (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT8484602825.mp3?updated=1738860427) | 2025-02-06 |
