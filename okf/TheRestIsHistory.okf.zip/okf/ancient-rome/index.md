# Ancient Rome

The Roman Republic, Empire, and their rivals — from the Punic Wars to the fall of Rome.

52 episodes.

## Subtopics
* [The Punic Wars & Carthage](/ancient-rome/punic-wars.md) — Rome's greatest rival and the wars that shaped the Mediterranean. (13 episodes)
* [The Roman Empire](/ancient-rome/roman-empire.md) — The emperors, conquests, and daily life of Imperial Rome. (18 episodes)
* [The Late Empire & Byzantium](/ancient-rome/late-empire-byzantium.md) — Christianity, the Eastern Empire, and the long decline. (7 episodes)
* [The Roman Republic](/ancient-rome/roman-republic.md) — From the rise of Julius Caesar to the fall of the Republic. (9 episodes)
* [Judea & Early Christianity](/ancient-rome/judea-early-christianity.md) — The Jewish Revolt, crucifixion, and the birth of Christianity. (5 episodes)
