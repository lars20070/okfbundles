---
type: Section
title: "The Punic Wars & Carthage"
description: "Rome's greatest rival and the wars that shaped the Mediterranean."
tags: [ancient-rome]
timestamp: "2026-08-16T00:00:00Z"
---

# The Punic Wars & Carthage

Rome's greatest rival and the wars that shaped the Mediterranean.

13 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 262 | [Tunisia: Dido of Carthage](https://pdst.fm/e/traffic.megaphone.fm/GLT5520362156.mp3?updated=1777394634) | 2022-11-24 |
| 421 | [Ancient Carthage: Lords of the Sea (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT1311066631.mp3?updated=1708310361) | 2024-02-19 |
| 422 | [Ancient Carthage: Rise of a Superpower (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT7946297144.mp3?updated=1708537688) | 2024-02-22 |
| 423 | [Carthage vs. Rome: The Wolf at the Gates (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT2669872613.mp3?updated=1708964126) | 2024-02-26 |
| 424 | [Carthage vs. Rome: Total War (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT9312780357.mp3?updated=1708623379) | 2024-02-29 |
| 568 | [Hannibal: Rome's Greatest Enemy (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT7606824410.mp3?updated=1748000703) | 2025-05-25 |
| 569 | [Hannibal: Elephants Cross the Alps (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT8313087633.mp3?updated=1784112214) | 2025-05-28 |
| 570 | [Hannibal: The Invasion of Italy (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT2952414067.mp3?updated=1784112251) | 2025-06-01 |
| 571 | [Hannibal: Roman Bloodbath at Cannae (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT2444504695.mp3?updated=1749055048) | 2025-06-04 |
| 640 | [Rome’s Greatest Enemy: Carthage at the Gates (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT9223169972.mp3?updated=1770030511) | 2026-02-02 |
| 641 | [Rome’s Greatest Enemy: Hannibal’s Nemesis (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT6811115289.mp3?updated=1770288466) | 2026-02-05 |
| 642 | [Rome's Greatest Enemy: Bloodbath in Africa (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT1285518636.mp3?updated=1770658202) | 2026-02-09 |
| 643 | [Rome’s Greatest Enemy: Carthage Destroyed (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT7699509622.mp3?updated=1770914051) | 2026-02-12 |
