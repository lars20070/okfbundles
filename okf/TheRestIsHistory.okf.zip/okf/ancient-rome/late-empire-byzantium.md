---
type: Section
title: "The Late Empire & Byzantium"
description: "Christianity, the Eastern Empire, and the long decline."
tags: [ancient-rome]
timestamp: "2026-08-16T00:00:00Z"
---

# The Late Empire & Byzantium

Christianity, the Eastern Empire, and the long decline.

7 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 156 | [When did the Roman Empire fall?](https://pdst.fm/e/traffic.megaphone.fm/GLT4933356600.mp3?updated=1777394939) | 2022-02-28 |
| 157 | [Byzantium and the Ghosts of Rome](https://pdst.fm/e/traffic.megaphone.fm/GLT1014708592.mp3?updated=1777394971) | 2022-03-01 |
| 217 | [Plague and the decline of the Roman Empire](https://pdst.fm/e/traffic.megaphone.fm/GLT2583859060.mp3?updated=1694606702) | 2022-08-04 |
| 260 | [Croatia: The Man Who Saved The Roman Empire](https://pdst.fm/e/traffic.megaphone.fm/GLT9631298578.mp3?updated=1777394899) | 2022-11-22 |
| 520 | [Warlords of the West: Barbarian Heirs of Rome (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT4921093273.mp3?updated=1733512289) | 2024-12-09 |
| 521 | [Warlords of the West: Killer Queens (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT5666966864.mp3?updated=1733512319) | 2024-12-12 |
| 522 | [Warlords of the West: A Clash of Ice and Fire (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT3154320009.mp3?updated=1733688591) | 2024-12-16 |
