---
type: Section
title: "Judea & Early Christianity"
description: "The Jewish Revolt, crucifixion, and the birth of Christianity."
tags: [ancient-rome]
timestamp: "2026-08-16T00:00:00Z"
---

# Judea & Early Christianity

The Jewish Revolt, crucifixion, and the birth of Christianity.

5 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 175 | [Crucifixion (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT5186420966.mp3?updated=1777395049) | 2022-04-14 |
| 176 | [The Jews Against Rome (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT3414103581.mp3?updated=1777394755) | 2022-04-18 |
| 177 | [The Jewish Revolt (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT1109135413.mp3?updated=1777394981) | 2022-04-21 |
| 287 | [Jesus Christ: The Mystery (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT4572965796.mp3?updated=1777394246) | 2022-12-19 |
| 288 | [Jesus Christ: The History (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT4776258433.mp3?updated=1777394247) | 2022-12-22 |
