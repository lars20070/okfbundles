---
type: Section
title: "The Roman Republic"
description: "From the rise of Julius Caesar to the fall of the Republic."
tags: [ancient-rome]
timestamp: "2026-08-16T00:00:00Z"
---

# The Roman Republic

From the rise of Julius Caesar to the fall of the Republic.

9 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 134 | [Crossing the Rubicon: The rise of Julius Caesar](https://pdst.fm/e/traffic.megaphone.fm/GLT1501343977.mp3?updated=1777394760) | 2022-01-10 |
| 135 | [Crossing the Rubicon: The die is cast](https://pdst.fm/e/traffic.megaphone.fm/GLT1750785311.mp3?updated=1777394859) | 2022-01-11 |
| 195 | [Young Cleopatra (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT1502910094.mp3?updated=1777395036) | 2022-06-13 |
| 196 | [Julius Caesar & Cleopatra (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT3216275988.mp3?updated=1777394758) | 2022-06-14 |
| 197 | [Antony & Cleopatra (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT1953107818.mp3?updated=1777394952) | 2022-06-15 |
| 198 | [Cleopatra's Downfall (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT1186341405.mp3?updated=1777394709) | 2022-06-16 |
| 304 | [The Murder of Julius Caesar](https://pdst.fm/e/traffic.megaphone.fm/GLT3561951089.mp3?updated=1777394177) | 2023-02-13 |
| 305 | [The Fall of the Roman Republic](https://pdst.fm/e/traffic.megaphone.fm/GLT6995332578.mp3?updated=1777394203) | 2023-02-16 |
| 499 | [The Roman Conquest of Britain: Julius Caesar’s Invasion (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT9770560726.mp3?updated=1727648896) | 2024-09-29 |
