---
type: Section
title: "Ancient Mesopotamia"
description: "Babylon and the first cities."
tags: [middle-east-islamic]
timestamp: "2026-08-16T00:00:00Z"
---

# Ancient Mesopotamia

Babylon and the first cities.

4 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 41 | [Persia](https://pdst.fm/e/traffic.megaphone.fm/GLT6414068538.mp3?updated=1777394967) | 2021-04-08 |
| 145 | [Babylon](https://pdst.fm/e/traffic.megaphone.fm/GLT7141377161.mp3?updated=1777394964) | 2022-01-31 |
| 181 | [The Birth of Babylon](https://pdst.fm/e/traffic.megaphone.fm/GLT1570061216.mp3?updated=1775852082) | 2022-05-02 |
| 519 | [The World's First City](https://pdst.fm/e/traffic.megaphone.fm/GLT2603135981.mp3?updated=1733159112) | 2024-12-05 |
