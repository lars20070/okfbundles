---
type: Section
title: "Modern Iran"
description: "The revolution and its consequences."
tags: [middle-east-islamic]
timestamp: "2026-08-16T00:00:00Z"
---

# Modern Iran

The revolution and its consequences.

3 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 120 | [The Oil Weapon](https://pdst.fm/e/traffic.megaphone.fm/GLT6620754143.mp3?updated=1777395076) | 2021-11-15 |
| 167 | [Oil: The Making of the Modern World](https://pdst.fm/e/traffic.megaphone.fm/GLT7483911964.mp3?updated=1777394864) | 2022-03-24 |
| 168 | [Oil: Conflict, Chaos and Climate Change](https://pdst.fm/e/traffic.megaphone.fm/GLT4572551005.mp3?updated=1777394988) | 2022-03-25 |
