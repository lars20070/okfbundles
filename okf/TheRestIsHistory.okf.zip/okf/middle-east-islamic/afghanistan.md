---
type: Section
title: "Afghanistan"
description: "The Anglo-Afghan wars."
tags: [middle-east-islamic]
timestamp: "2026-08-16T00:00:00Z"
---

# Afghanistan

The Anglo-Afghan wars.

2 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 87 | [Afghanistan - Part 1](https://pdst.fm/e/traffic.megaphone.fm/GLT7464087190.mp3?updated=1777395018) | 2021-08-18 |
| 88 | [The First Anglo-Afghan War](https://pdst.fm/e/traffic.megaphone.fm/GLT5156371854.mp3?updated=1777395000) | 2021-08-19 |
