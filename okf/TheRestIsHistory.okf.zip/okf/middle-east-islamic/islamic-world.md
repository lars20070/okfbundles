---
type: Section
title: "The Islamic World"
description: "Baghdad, the Caliphate, and Islamic civilisation."
tags: [middle-east-islamic]
timestamp: "2026-08-16T00:00:00Z"
---

# The Islamic World

Baghdad, the Caliphate, and Islamic civilisation.

8 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 60 | [Muhammad](https://pdst.fm/e/traffic.megaphone.fm/GLT7621065751.mp3?updated=1777395002) | 2021-06-03 |
| — | [12 Days: Reconquest of Spain and the Old Queen of Hawaii](https://pdst.fm/e/traffic.megaphone.fm/GLT9407596415.mp3?updated=1777394811) | 2022-01-02 |
| 265 | [Saudi Arabia: The Mystery of the Kaaba](https://pdst.fm/e/traffic.megaphone.fm/GLT1528147434.mp3?updated=1777394934) | 2022-11-27 |
| 281 | [Spain: The Caliphate of Córdoba](https://pdst.fm/e/traffic.megaphone.fm/GLT2203638069.mp3?updated=1777394206) | 2022-12-13 |
| 376 | [Baghdad: The Forging of Islam (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT9529602805.mp3?updated=1729781750) | 2023-10-08 |
| 377 | [Baghdad: Crossroads of the Universe (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT9127243683.mp3?updated=1729781768) | 2023-10-11 |
| 378 | [Baghdad: The Golden Age (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT9689814482.mp3?updated=1729781786) | 2023-10-15 |
| 379 | [Baghdad: The Arabian Nights (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT8529456010.mp3?updated=1729781852) | 2023-10-18 |
