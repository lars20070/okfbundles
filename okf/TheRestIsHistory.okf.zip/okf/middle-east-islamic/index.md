# Middle East & Islamic World

From ancient Mesopotamia to modern Iran.

17 episodes.

## Subtopics
* [Ancient Mesopotamia](/middle-east-islamic/ancient-mesopotamia.md) — Babylon and the first cities. (4 episodes)
* [The Islamic World](/middle-east-islamic/islamic-world.md) — Baghdad, the Caliphate, and Islamic civilisation. (8 episodes)
* [Modern Iran](/middle-east-islamic/modern-iran.md) — The revolution and its consequences. (3 episodes)
* [Afghanistan](/middle-east-islamic/afghanistan.md) — The Anglo-Afghan wars. (2 episodes)
