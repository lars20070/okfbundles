# Update Log

## 2026-08-12
* **Structure**: Organized 108 flat series into 10 thematic clusters under okf/history/. Updated all cross-links.
* **Fix**: Corrected all cluster index files to show proper series names (e.g., "The First World War" instead of "Blood in the Trenches (Part 1)"). Each series now displays its actual name with episode count.

### Cluster Breakdown
* [Ancient World](/history/ancient-world/) — 15 series (Greek, Roman, ancient Mediterranean)
* [Medieval Europe](/history/medieval-europe/) — 15 series (1066 to Reformation)
* [Early Modern Europe](/history/early-modern-europe/) — 16 series (Renaissance to Napoleonic era)
* [British & Irish History](/history/british-irish-history/) — 11 series (Britain, Ireland, Commonwealth)
* [Empire & Colonialism](/history/empire-colonialism/) — 8 series (Exploration, conquest, empire)
* [American History](/history/american-history/) — 11 series (Colonial era to modern United States)
* [World Wars](/history/world-wars/) — 16 series (WWI, WWII, 20th century conflicts)
* [Culture & Entertainment](/history/culture-entertainment/) — 11 series (Music, film, sports)
* [Asia-Pacific](/history/asia-pacific/) — 2 series (Japanese and Asian history)
* [Modern Geopolitics](/history/modern-geopolitics/) — 3 series (Cold War, contemporary conflicts)

* **Cleanup**: Consolidated directories with `-2` suffixes. Renamed `columbus-2` → `columbus`, `elizabeth-i-2` → `elizabeth-i`, `french-revolution-2` → `french-revolution`, `portugal-2` → `portugal`. Merged `hundred-years-war-2` into `hundred-years-war` (8 episodes total). All links updated.
* **Completion**: All 694 numbered episodes from The Rest Is History podcast are now compiled (100% coverage).
* **Update**: Added World Cup trilogy (episodes 252-254) to [The World Cup](/history/world-cup-2022/) series.
* **Cleanup**: Removed 12 empty single-episode directories that were dead weight.
* **Update**: Generated proper link lists in all 108 series index files.
