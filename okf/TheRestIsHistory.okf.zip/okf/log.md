# Update Log

## 2026-08-16
* **Creation**: Added [root index](/index.md) and the full topic structure with 16 categories.
* **Creation**: Added [Ancient Rome](/ancient-rome/) (52 episodes) — Punic Wars, Roman Republic, Empire, Late Empire & Byzantium, Judea & Early Christianity.
* **Creation**: Added [Ancient Greece](/ancient-greece/) (19 episodes) — Greek Myths, Persian Wars & Sparta, Alexander the Great.
* **Creation**: Added [Medieval Europe](/medieval-europe/) (85 episodes) — Vikings & Normans, Charlemagne, Crusades, High Middle Ages, Renaissance & Reformation.
* **Creation**: Added [Tudor & Stuart Britain](/tudor-stuart-britain/) (28 episodes) — Elizabeth I, Mary Queen of Scots, Civil War & Commonwealth.
* **Creation**: Added [Modern Britain](/modern-britain/) (104 episodes) — British Empire, Ireland, Falklands War, 20th-Century Britain, London.
* **Creation**: Added [World War I](/world-war-one/) (23 episodes) — First World War series and specials.
* **Creation**: Added [World War II](/world-war-two/) (49 episodes) — Rise of the Nazis, War in Europe, Hitler, Holocaust & Memory.
* **Creation**: Added [Russia & the Soviet Union](/russia-soviet/) (19 episodes) — Early Russia, Soviet Union, Modern Russia.
* **Creation**: Added [American History](/american-history/) (75 episodes) — Founding Fathers, Civil War, JFK, Cold War, American West, Lincoln, Vietnam.
* **Creation**: Added [France](/france/) (33 episodes) — French Revolution, Napoleon, Modern France.
* **Creation**: Added [East Asia](/east-asia/) (13 episodes) — China, Japan, Mongols.
* **Creation**: Added [Latin America](/latin-america/) (30 episodes) — Aztecs, Incas, Brazil, other topics.
* **Creation**: Added [Middle East & Islamic World](/middle-east-islamic/) (17 episodes) — Ancient Mesopotamia, Islamic World, Modern Iran, Afghanistan.
* **Creation**: Added [Africa](/africa/) (7 episodes) — Southern Africa, Central Africa, other topics.
* **Creation**: Added [Cultural & Social History](/cultural-social/) (127 episodes) — Sport, Music, Literature & Film, Food & Drink, Festivals, Social History, Historical Method, Ghosts & Mysteries.
* **Creation**: Added [Specials & Extras](/specials/) (32 episodes) — Live shows, 12 Days, Interviews, World Cup brackets, European Country specials, and miscellany.
