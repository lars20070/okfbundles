---
type: Section
title: "Modern France"
description: "Presidents, Paris, and French culture."
tags: [france]
timestamp: "2026-08-16T00:00:00Z"
---

# Modern France

Presidents, Paris, and French culture.

12 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 57 | [Paris](https://pdst.fm/e/traffic.megaphone.fm/GLT6186083108.mp3?updated=1777394987) | 2021-05-27 |
| — | [12 Days: Death of Edward the Confessor and the Dreyfus Affair](https://pdst.fm/e/traffic.megaphone.fm/GLT1738062149.mp3?updated=1777394832) | 2022-01-05 |
| 178 | [French Presidents: 1958-1981 (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT1396593896.mp3?updated=1777394918) | 2022-04-25 |
| 179 | [French Presidents: 1981-2022 (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT2206497694.mp3?updated=1777394784) | 2022-04-26 |
| 242 | [French History on Film](https://pdst.fm/e/traffic.megaphone.fm/GLT2672520929.mp3?updated=1694603446) | 2022-10-13 |
| 278 | [France: The Mystery of Le Prince](https://pdst.fm/e/traffic.megaphone.fm/GLT1101934476.mp3?updated=1777394642) | 2022-12-10 |
| 352 | [Amsterdam: Kings, Canals, and Coffee Houses (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT4191684359.mp3?updated=1729782338) | 2023-07-20 |
| 353 | [Paris 1968: The Students' Revolt (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT6124707164.mp3?updated=1729782201) | 2023-07-24 |
| 354 | [Paris 1968: The Return of De Gaulle (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT6246374874.mp3?updated=1729782223) | 2023-07-27 |
| 365 | [Le Marquis de Sade: Sex and Violence](https://pdst.fm/e/traffic.megaphone.fm/GLT8871465113.mp3?updated=1693839248) | 2023-09-03 |
| 411 | [The Man in the Iron Mask](https://pdst.fm/e/traffic.megaphone.fm/GLT3787137343.mp3?updated=1705679615) | 2024-01-22 |
| 667 | [The Mystery of the Mona Lisa](https://pdst.fm/e/traffic.megaphone.fm/GLT1735270133.mp3?updated=1777982084) | 2026-05-06 |
