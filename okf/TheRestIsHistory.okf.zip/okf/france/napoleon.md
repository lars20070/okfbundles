---
type: Section
title: "Napoleon"
description: "The rise and fall of the Emperor."
tags: [france]
timestamp: "2026-08-16T00:00:00Z"
---

# Napoleon

The rise and fall of the Emperor.

3 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 126 | [Napoleon in Egypt](https://pdst.fm/e/traffic.megaphone.fm/GLT3691914095.mp3?updated=1777395008) | 2021-11-29 |
| 382 | [Young Napoleon: Teenage Revolutionary (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT6500252244.mp3?updated=1729781626) | 2023-10-30 |
| 383 | [Young Napoleon: The Shadow of the Guillotine (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT2658259929.mp3?updated=1729781645) | 2023-11-02 |
