# France

French history from the Revolution to the present.

33 episodes.

## Subtopics
* [Modern France](/france/modern-france.md) — Presidents, Paris, and French culture. (12 episodes)
* [The French Revolution](/france/french-revolution.md) — The revolution that changed the world. (18 episodes)
* [Napoleon](/france/napoleon.md) — The rise and fall of the Emperor. (3 episodes)
