---
type: Section
title: "The French Revolution"
description: "The revolution that changed the world."
tags: [france]
timestamp: "2026-08-16T00:00:00Z"
---

# The French Revolution

The revolution that changed the world.

18 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 48 | [The French Revolution](https://pdst.fm/e/traffic.megaphone.fm/GLT2092335857.mp3?updated=1777395011) | 2021-05-03 |
| 475 | [The French Revolution: Marie Antoinette (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT3119389535.mp3?updated=1729780273) | 2024-07-28 |
| 476 | [The French Revolution: The Diamond Necklace Scandal (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT9914208350.mp3?updated=1729780305) | 2024-07-29 |
| 477 | [The French Revolution: The Violence Begins (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT6535380991.mp3?updated=1729780334) | 2024-07-31 |
| 478 | [The French Revolution: Showdown in Versailles (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT4803391126.mp3?updated=1729780496) | 2024-08-01 |
| 479 | [The French Revolution: The Storming of the Bastille (Part 5)](https://pdst.fm/e/traffic.megaphone.fm/GLT5485693441.mp3?updated=1729780519) | 2024-08-04 |
| 480 | [The French Revolution: The Rights of Man (Part 6)](https://pdst.fm/e/traffic.megaphone.fm/GLT8413639265.mp3?updated=1729780546) | 2024-08-05 |
| 481 | [The French Revolution: The Women's March on Versailles (Part 7)](https://pdst.fm/e/traffic.megaphone.fm/GLT9783455254.mp3?updated=1729780566) | 2024-08-07 |
| 482 | [The French Revolution: The Royal Family Escapes (Part 8)](https://pdst.fm/e/traffic.megaphone.fm/GLT3336151355.mp3?updated=1729780594) | 2024-08-08 |
| 503 | [The French Revolution: Bloodbath in Paris (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT8447202194.mp3?updated=1729780235) | 2024-10-13 |
| 504 | [The French Revolution: War to the Death (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT3201191708.mp3?updated=1729780213) | 2024-10-16 |
| 505 | [The French Revolution: The Shadow of the Guillotine (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT1620539569.mp3?updated=1729780187) | 2024-10-20 |
| 506 | [The French Revolution: Massacre at the Palace (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT9954902163.mp3?updated=1729780149) | 2024-10-23 |
| 507 | [The French Revolution: The Marseillaise, Song of War (Part 5)](https://pdst.fm/e/traffic.megaphone.fm/GLT5535769124.mp3?updated=1729810871) | 2024-10-24 |
| 544 | [The French Revolution: The September Massacres (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT8301042051.mp3?updated=1740758267) | 2025-03-03 |
| 545 | [The French Revolution: The First Feminist (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT4335903757.mp3?updated=1741269951) | 2025-03-06 |
| 546 | [The French Revolution: The Monarchy Falls (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT3779628370.mp3?updated=1741366301) | 2025-03-10 |
| 547 | [The French Revolution: The Execution of the King (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT2184509954.mp3?updated=1742407669) | 2025-03-13 |
