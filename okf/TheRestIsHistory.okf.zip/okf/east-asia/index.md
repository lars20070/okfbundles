# East Asia

China, Japan, and the Mongols.

13 episodes.

## Subtopics
* [Japan](/east-asia/japan.md) — Samurai, shōguns, and the imperial court. (7 episodes)
* [China](/east-asia/china.md) — From the First Emperor to Mao. (4 episodes)
* [The Mongols](/east-asia/mongols.md) — Genghis Khan and the largest land empire in history. (2 episodes)
