---
type: Section
title: "China"
description: "From the First Emperor to Mao."
tags: [east-asia]
timestamp: "2026-08-16T00:00:00Z"
---

# China

From the First Emperor to Mao.

4 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 20 | [China](https://pdst.fm/e/traffic.megaphone.fm/GLT4329327216.mp3?updated=1777395005) | 2021-02-04 |
| 173 | [Chairman Mao & the Cultural Revolution](https://pdst.fm/e/traffic.megaphone.fm/GLT2886812821.mp3?updated=1777395023) | 2022-04-07 |
| 366 | [The Architect of Modern China](https://pdst.fm/e/traffic.megaphone.fm/GLT1902993082.mp3?updated=1694041584) | 2023-09-06 |
| 444 | [The First Emperor of China](https://pdst.fm/e/traffic.megaphone.fm/GLT5076517033.mp3?updated=1714341064) | 2024-04-28 |
