---
type: Section
title: "Japan"
description: "Samurai, shōguns, and the imperial court."
tags: [east-asia]
timestamp: "2026-08-16T00:00:00Z"
---

# Japan

Samurai, shōguns, and the imperial court.

7 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 277 | [Japan: Samurai and Shoguns](https://pdst.fm/e/traffic.megaphone.fm/GLT3851919583.mp3?updated=1777394956) | 2022-12-09 |
| 560 | [The Golden Age of Japan: Lady Murasaki and the Shining Prince (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT6500007351.mp3?updated=1745945479) | 2025-04-27 |
| 561 | [The Golden Age of Japan: Secrets of the Imperial Court (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT9428275194.mp3?updated=1746033394) | 2025-04-30 |
| 658 | [Dawn of the Samurai: The Shadow of the Sword (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT7378881498.mp3?updated=1775643305) | 2026-04-05 |
| 659 | [Dawn of the Samurai: Bloodbath at the Bridge (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT3420393571.mp3?updated=1775760569) | 2026-04-08 |
| 660 | [Dawn of the Samurai: Japan’s Greatest Warrior  (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT3581345898.mp3?updated=1776098535) | 2026-04-12 |
| 661 | [Dawn of the Samurai: The Shōgun Triumphant (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT7837412375.mp3?updated=1776592324) | 2026-04-15 |
