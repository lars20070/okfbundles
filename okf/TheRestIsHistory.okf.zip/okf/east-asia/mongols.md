---
type: Section
title: "The Mongols"
description: "Genghis Khan and the largest land empire in history."
tags: [east-asia]
timestamp: "2026-08-16T00:00:00Z"
---

# The Mongols

Genghis Khan and the largest land empire in history.

2 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 165 | [The Rise of Genghis Khan](https://pdst.fm/e/traffic.megaphone.fm/GLT3370086758.mp3?updated=1777394926) | 2022-03-21 |
| 166 | [Genghis Khan: Lord of the Mongols](https://pdst.fm/e/traffic.megaphone.fm/GLT4398796320.mp3?updated=1777395013) | 2022-03-22 |
