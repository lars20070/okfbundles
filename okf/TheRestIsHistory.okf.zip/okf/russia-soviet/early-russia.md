---
type: Section
title: "Early Russia"
description: "The birth of the Rus, Peter the Great, and the Great Northern War."
tags: [russia-soviet]
timestamp: "2026-08-16T00:00:00Z"
---

# Early Russia

The birth of the Rus, Peter the Great, and the Great Northern War.

10 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 128 | [Rasputin](https://pdst.fm/e/traffic.megaphone.fm/GLT1290733613.mp3?updated=1777394969) | 2021-12-06 |
| 149 | [The Birth of Russia](https://pdst.fm/e/traffic.megaphone.fm/GLT2354182753.mp3?updated=1777394951) | 2022-02-08 |
| 279 | [Cameroon: The Slave General of Peter the Great](https://pdst.fm/e/traffic.megaphone.fm/GLT8175760918.mp3?updated=1777394916) | 2022-12-11 |
| 492 | [The War on Beards: From Peter the Great to John Lennon (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT5427522678.mp3?updated=1725966975) | 2024-09-09 |
| 562 | [Peter the Great: The Rise of Russia (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT5535116202.mp3?updated=1746448094) | 2025-05-04 |
| 563 | [Peter the Great: Bloodbath in the Kremlin (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT4388388819.mp3?updated=1784112362) | 2025-05-07 |
| 564 | [The Great Northern War: The Battle of the Baltic (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT2662789070.mp3?updated=1747059727) | 2025-05-11 |
| 565 | [The Great Northern War: Revenge of the Cossacks (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT1223770243.mp3?updated=1747251724) | 2025-05-14 |
| 566 | [The Great Northern War: Slaughter on the Steppes (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT4679437587.mp3?updated=1747310607) | 2025-05-18 |
| 567 | [The Great Northern War: Murder in Moscow (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT4718660658.mp3?updated=1747754804) | 2025-05-21 |
