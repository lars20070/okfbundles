---
type: Section
title: "Modern Russia"
description: "Yeltsin, Putin, and the war in Ukraine."
tags: [russia-soviet]
timestamp: "2026-08-16T00:00:00Z"
---

# Modern Russia

Yeltsin, Putin, and the war in Ukraine.

4 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 69 | [England v Ukraine](https://pdst.fm/e/traffic.megaphone.fm/GLT5469973001.mp3?updated=1777394941) | 2021-07-02 |
| 155 | [Ukraine and Russia](https://pdst.fm/e/traffic.megaphone.fm/GLT2859413707.mp3?updated=1777395031) | 2022-02-23 |
| 161 | [Yeltsin, Economic Chaos and President Putin](https://pdst.fm/e/traffic.megaphone.fm/GLT3048619920.mp3?updated=1777394773) | 2022-03-09 |
| 162 | [Putin's Russia](https://pdst.fm/e/traffic.megaphone.fm/GLT4575290976.mp3?updated=1777394824) | 2022-03-10 |
