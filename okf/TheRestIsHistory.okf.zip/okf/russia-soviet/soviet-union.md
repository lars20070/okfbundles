---
type: Section
title: "The Soviet Union"
description: "The USSR from Lenin to its collapse."
tags: [russia-soviet]
timestamp: "2026-08-16T00:00:00Z"
---

# The Soviet Union

The USSR from Lenin to its collapse.

5 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 38 | [Communism](https://pdst.fm/e/traffic.megaphone.fm/GLT7587678050.mp3?updated=1777394990) | 2021-03-29 |
| 83 | [The Berlin Wall](https://pdst.fm/e/traffic.megaphone.fm/GLT1824879961.mp3?updated=1777395052) | 2021-08-05 |
| 159 | [Young Putin, the KGB and the Soviet Union](https://pdst.fm/e/traffic.megaphone.fm/GLT7336670203.mp3?updated=1777394844) | 2022-03-07 |
| 160 | [The Fall of the Soviet Union](https://pdst.fm/e/traffic.megaphone.fm/GLT9472343994.mp3?updated=1777394738) | 2022-03-08 |
| 322 | [East Germany: Life Behind the Iron Curtain](https://pdst.fm/e/traffic.megaphone.fm/GLT4069689977.mp3?updated=1777394215) | 2023-04-17 |
