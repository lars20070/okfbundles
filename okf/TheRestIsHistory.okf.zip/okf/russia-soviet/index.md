# Russia & the Soviet Union

From the birth of Russia to Putin's rule.

19 episodes.

## Subtopics
* [Early Russia](/russia-soviet/early-russia.md) — The birth of the Rus, Peter the Great, and the Great Northern War. (10 episodes)
* [The Soviet Union](/russia-soviet/soviet-union.md) — The USSR from Lenin to its collapse. (5 episodes)
* [Modern Russia](/russia-soviet/modern-russia.md) — Yeltsin, Putin, and the war in Ukraine. (4 episodes)
