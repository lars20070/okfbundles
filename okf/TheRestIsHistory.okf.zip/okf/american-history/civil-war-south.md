---
type: Section
title: "The American Civil War & The South"
description: "The war between the states, and the Ku Klux Klan."
tags: [american-history]
timestamp: "2026-08-16T00:00:00Z"
---

# The American Civil War & The South

The war between the states, and the Ku Klux Klan.

12 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 2 | [Civil War](https://pdst.fm/e/traffic.megaphone.fm/GLT5809911007.mp3?updated=1777394993) | 2020-11-02 |
| 200 | [American Civil War: The Causes (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT1124511401.mp3?updated=1777394940) | 2022-06-27 |
| 201 | [American Civil War: Outbreak (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT4100428000.mp3?updated=1777394891) | 2022-06-28 |
| 202 | [American Civil War: Gettysburg (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT5256515778.mp3?updated=1777395017) | 2022-06-30 |
| 203 | [American Civil War: Aftermath & Legacy (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT3990109453.mp3?updated=1777394871) | 2022-07-04 |
| 204 | [Gone with the Wind](https://pdst.fm/e/traffic.megaphone.fm/GLT3666140136.mp3?updated=1777395032) | 2022-07-07 |
| 258 | [Costa Rica: Civil War](https://pdst.fm/e/traffic.megaphone.fm/GLT4854467564.mp3?updated=1777394842) | 2022-11-20 |
| 446 | [Custer vs. Crazy Horse: Civil War (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT9088781244.mp3?updated=1714926980) | 2024-05-05 |
| 654 | [The Ku Klux Klan: The Rise of Evil (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT2601231794.mp3?updated=1774193991) | 2026-03-23 |
| 655 | [The Ku Klux Klan: Terror in the South (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT2904395784.mp3?updated=1774286562) | 2026-03-26 |
| 656 | [The Ku Klux Klan: Birth of a Nation (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT9883414135.mp3?updated=1774622635) | 2026-03-29 |
| 657 | [The Ku Klux Klan: American Fascists (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT4147819855.mp3?updated=1774886633) | 2026-04-01 |
