---
type: Section
title: "Cold War & Modern America"
description: "From the Cold War through Watergate, Reagan, 9/11, and beyond."
tags: [american-history]
timestamp: "2026-08-16T00:00:00Z"
---

# Cold War & Modern America

From the Cold War through Watergate, Reagan, 9/11, and beyond.

19 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 3 | [Is Trump Caesar or Nixon?](https://pdst.fm/e/traffic.megaphone.fm/GLT4982990068.mp3?updated=1777394973) | 2020-11-09 |
| 92 | [Nuclear Weapons](https://pdst.fm/e/traffic.megaphone.fm/GLT2236644203.mp3?updated=1777394991) | 2021-09-01 |
| 93 | [Silicon Valley Part 1](https://pdst.fm/e/traffic.megaphone.fm/GLT5734449332.mp3?updated=1777394995) | 2021-09-06 |
| 94 | [Silicon Valley Part 2](https://pdst.fm/e/traffic.megaphone.fm/GLT3075342575.mp3?updated=1777394919) | 2021-09-07 |
| 95 | [9/11](https://pdst.fm/e/traffic.megaphone.fm/GLT8208243510.mp3?updated=1777394983) | 2021-09-09 |
| 106 | [Watergate: Part 1](https://pdst.fm/e/traffic.megaphone.fm/GLT6675580126.mp3?updated=1777394990) | 2021-10-11 |
| 107 | [Watergate: Part 2](https://pdst.fm/e/traffic.megaphone.fm/GLT9677344742.mp3?updated=1777395036) | 2021-10-12 |
| 125 | [The CIA](https://pdst.fm/e/traffic.megaphone.fm/GLT6232412389.mp3?updated=1777394986) | 2021-11-25 |
| 228 | [Portugal: The Golden Age of Discovery (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT7949934800.mp3?updated=1729784931) | 2022-09-06 |
| 310 | [Ronald Reagan and the American Dream (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT3254036306.mp3?updated=1777394149) | 2023-03-06 |
| 311 | [Reagan: The Road to the White House (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT9813084891.mp3?updated=1777394923) | 2023-03-09 |
| 360 | [Fear City: New York in the 1970s](https://pdst.fm/e/traffic.megaphone.fm/GLT7107047696.mp3?updated=1692227469) | 2023-08-16 |
| 370 | [The 1973 Chilean Coup: Allende, Nixon and the CIA (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT6405070034.mp3?updated=1729782085) | 2023-09-20 |
| 439 | [Disco: Sex and Race in Seventies America](https://pdst.fm/e/traffic.megaphone.fm/GLT8206137792.mp3?updated=1712764022) | 2024-04-10 |
| 508 | [America in '68: Nightmare in Vietnam (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT6375459097.mp3?updated=1730076936) | 2024-10-28 |
| 510 | [America in '68: The Killing of Robert Kennedy (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT6589354101.mp3?updated=1730644471) | 2024-11-04 |
| 511 | [America in '68: George Wallace, The First Donald Trump (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT8855008412.mp3?updated=1730940586) | 2024-11-07 |
| 512 | [America in '68: The Chicago Riots (Part 5)](https://pdst.fm/e/traffic.megaphone.fm/GLT9860410495.mp3?updated=1731270135) | 2024-11-11 |
| 513 | [America in '68: Nixon's Great Comeback (Part 6)](https://pdst.fm/e/traffic.megaphone.fm/GLT3853956463.mp3?updated=1731270226) | 2024-11-14 |
