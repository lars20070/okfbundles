# American History

From the Revolution through to the modern era.

75 episodes.

## Subtopics
* [The Founding Fathers](/american-history/founding-fathers.md) — Washington, Hamilton, Franklin, Jefferson, and the birth of the United States. (8 episodes)
* [The American Civil War & The South](/american-history/civil-war-south.md) — The war between the states, and the Ku Klux Klan. (12 episodes)
* [Other American Topics](/american-history/other-us.md) — Walt Disney, scandals, and culture. (13 episodes)
* [Abraham Lincoln](/american-history/lincoln.md) — The assassination of the 16th president. (2 episodes)
* [Cold War & Modern America](/american-history/cold-war-america.md) — From the Cold War through Watergate, Reagan, 9/11, and beyond. (19 episodes)
* [The American West & Native American History](/american-history/american-west.md) — Custer, Crazy Horse, the Sioux, and the frontier. (12 episodes)
* [The JFK Assassination](/american-history/jfk-assassination.md) — The murder of President Kennedy and its aftermath. (6 episodes)
* [The Vietnam War](/american-history/vietnam.md) — America's war in Southeast Asia. (3 episodes)
