---
type: Section
title: "Other American Topics"
description: "Walt Disney, scandals, and culture."
tags: [american-history]
timestamp: "2026-08-16T00:00:00Z"
---

# Other American Topics

Walt Disney, scandals, and culture.

13 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 24 | [Sex in the City](https://pdst.fm/e/traffic.megaphone.fm/GLT9221135938.mp3?updated=1777394968) | 2021-02-18 |
| 26 | [Witches](https://pdst.fm/e/traffic.megaphone.fm/GLT8850594772.mp3?updated=1777395029) | 2021-02-25 |
| 29 | [Americanisation](https://pdst.fm/e/traffic.megaphone.fm/GLT9683168458.mp3?updated=1777394981) | 2021-03-08 |
| 46 | [Culture Wars](https://pdst.fm/e/traffic.megaphone.fm/GLT4237848862.mp3?updated=1777394968) | 2021-04-26 |
| 153 | [God and the American Empire](https://pdst.fm/e/traffic.megaphone.fm/GLT8752091834.mp3?updated=1777394623) | 2022-02-18 |
| 237 | [Marilyn Monroe](https://pdst.fm/e/traffic.megaphone.fm/GLT5351991903.mp3?updated=1694604069) | 2022-09-26 |
| 331 | [American Witches](https://pdst.fm/e/traffic.megaphone.fm/GLT9152886733.mp3?updated=1777394196) | 2023-05-11 |
| 343 | [Oppenheimer: The Father of the Atom Bomb (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT9202576882.mp3?updated=1777394186) | 2023-06-22 |
| 344 | [Oppenheimer: The Witch Hunt (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT1594914557.mp3?updated=1777394723) | 2023-06-23 |
| 438 | [The Moonwalkers, with Tom Hanks](https://pdst.fm/e/traffic.megaphone.fm/GLT1422432857.mp3?updated=1712609922) | 2024-04-07 |
| 601 | [Scandal in the White House](https://pdst.fm/e/traffic.megaphone.fm/GLT1369800109.mp3?updated=1758146111) | 2025-09-17 |
| 614 | [Walt Disney: The Great American Storyteller](https://pdst.fm/e/traffic.megaphone.fm/GLT5465018421.mp3?updated=1763642278) | 2025-11-03 |
| 615 | [Disneyland: The Modern American Utopia](https://pdst.fm/e/traffic.megaphone.fm/GLT8516268220.mp3?updated=1763642381) | 2025-11-06 |
