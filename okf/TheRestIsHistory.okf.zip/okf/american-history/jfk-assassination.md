---
type: Section
title: "The JFK Assassination"
description: "The murder of President Kennedy and its aftermath."
tags: [american-history]
timestamp: "2026-08-16T00:00:00Z"
---

# The JFK Assassination

The murder of President Kennedy and its aftermath.

6 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 392 | [JFK: The Road to the White House (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT3759679497.mp3?updated=1700748935) | 2023-11-27 |
| 393 | [JFK: Cuba, Camelot and the Cold War (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT9682768005.mp3?updated=1700749003) | 2023-11-28 |
| 394 | [JFK: Death in Dallas (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT6387392381.mp3?updated=1701022619) | 2023-11-30 |
| 395 | [JFK: Hunt for a Killer (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT1345279222.mp3?updated=1700749081) | 2023-12-04 |
| 396 | [JFK: The Second Assassin Strikes (Part 5)](https://pdst.fm/e/traffic.megaphone.fm/GLT7803941061.mp3?updated=1700845231) | 2023-12-05 |
| 398 | [JFK: The Mystery is Solved (Part 7)](https://pdst.fm/e/traffic.megaphone.fm/GLT6409828878.mp3?updated=1702048064) | 2023-12-11 |
