---
type: Section
title: "The American West & Native American History"
description: "Custer, Crazy Horse, the Sioux, and the frontier."
tags: [american-history]
timestamp: "2026-08-16T00:00:00Z"
---

# The American West & Native American History

Custer, Crazy Horse, the Sioux, and the frontier.

12 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 42 | [The Wild West](https://pdst.fm/e/traffic.megaphone.fm/GLT7464073840.mp3?updated=1777394984) | 2021-04-12 |
| 61 | [California](https://pdst.fm/e/traffic.megaphone.fm/GLT2438679240.mp3?updated=1777394958) | 2021-06-07 |
| 447 | [Custer vs. Crazy Horse: The Winning of the West (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT1593887977.mp3?updated=1715070354) | 2024-05-06 |
| 448 | [Custer vs. Crazy Horse: Horse-Lords of the Plains (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT4947798648.mp3?updated=1715072213) | 2024-05-08 |
| 449 | [Custer vs. Crazy Horse: Rise of Sitting Bull (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT2415947095.mp3?updated=1715183920) | 2024-05-12 |
| 450 | [Custer's Last Stand: Death in the Black Hills (Part 5)](https://pdst.fm/e/traffic.megaphone.fm/GLT1497339770.mp3?updated=1715612784) | 2024-05-15 |
| 451 | [Custer's Last Stand: The Charge of the 7th Cavalry (Part 6)](https://pdst.fm/e/traffic.megaphone.fm/GLT4301705603.mp3?updated=1716163669) | 2024-05-16 |
| 452 | [Custer's Last Stand: The Battle of the Little Bighorn (Part 7)](https://pdst.fm/e/traffic.megaphone.fm/GLT7290391290.mp3?updated=1716164561) | 2024-05-20 |
| 453 | [Custer's Last Stand: The Final Showdown (Part 8)](https://pdst.fm/e/traffic.megaphone.fm/GLT8261745977.mp3?updated=1716402472) | 2024-05-22 |
| 454 | [Fall of the Sioux: Death of Crazy Horse (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT1647500583.mp3?updated=1716885922) | 2024-05-26 |
| 455 | [Fall of the Sioux: The Ghost Dance (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT2320133118.mp3?updated=1716889721) | 2024-05-29 |
| 456 | [Fall of the Sioux: The Massacre at Wounded Knee (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT7996658277.mp3?updated=1716571435) | 2024-05-30 |
