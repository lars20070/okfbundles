---
type: Section
title: "The Founding Fathers"
description: "Washington, Hamilton, Franklin, Jefferson, and the birth of the United States."
tags: [american-history]
timestamp: "2026-08-16T00:00:00Z"
---

# The Founding Fathers

Washington, Hamilton, Franklin, Jefferson, and the birth of the United States.

8 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 347 | [The American Revolution (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT3042850673.mp3?updated=1777394912) | 2023-07-03 |
| 348 | [The Boston Tea Party (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT5189620267.mp3?updated=1777394801) | 2023-07-06 |
| 349 | [The Birth of the United States (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT9804967639.mp3?updated=1777394758) | 2023-07-10 |
| 350 | [The Triumph of George Washington (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT1619660676.mp3?updated=1776972844) | 2023-07-13 |
| 683 | [Washington: Hero of the Revolution (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT3752138067.mp3) | 2026-06-28 |
| 684 | [Franklin: Revenge of the American Genius (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT6013835340.mp3) | 2026-07-01 |
| 685 | [Hamilton: Duel to the Death (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT9231431046.mp3) | 2026-07-05 |
| 686 | [Jefferson: The Betrayal of Liberty (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT6535571769.mp3) | 2026-07-08 |
