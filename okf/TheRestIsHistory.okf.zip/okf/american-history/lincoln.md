---
type: Section
title: "Abraham Lincoln"
description: "The assassination of the 16th president."
tags: [american-history]
timestamp: "2026-08-16T00:00:00Z"
---

# Abraham Lincoln

The assassination of the 16th president.

2 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 590 | [The Assassination of Abraham Lincoln: Death at the Theatre (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT2286421954.mp3?updated=1754871827) | 2025-08-10 |
| 591 | [The Assassination of Abraham Lincoln: Manhunt for the Killer (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT7618197031.mp3?updated=1755122723) | 2025-08-13 |
