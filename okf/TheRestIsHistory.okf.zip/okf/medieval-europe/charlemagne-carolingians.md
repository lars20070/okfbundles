---
type: Section
title: "Charlemagne & the Carolingians"
description: "The Frankish empire that laid the foundations of medieval Europe."
tags: [medieval-europe]
timestamp: "2026-08-16T00:00:00Z"
---

# Charlemagne & the Carolingians

The Frankish empire that laid the foundations of medieval Europe.

5 episodes.

| # | Episode | Date |
| --- | --- | --- |
| — | [12 Days: Coronation of Charlemagne and the collapse of the Soviet Union](https://pdst.fm/e/traffic.megaphone.fm/GLT9083951211.mp3?updated=1777394936) | 2021-12-25 |
| 523 | [Charlemagne: Return of the Kings (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT5104943454.mp3?updated=1734097576) | 2024-12-19 |
| 524 | [Charlemagne: Pagan Killer (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT1992648453.mp3?updated=1734098988) | 2024-12-23 |
| 525 | [Charlemagne: Emperor of the West (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT6103469677.mp3?updated=1734100735) | 2024-12-25 |
| — | [Empress Matilda: Civil War and the Fight for the Throne](https://pdst.fm/e/traffic.megaphone.fm/GLT3399401666.mp3) | 2026-05-19 |
