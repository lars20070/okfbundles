---
type: Section
title: "Vikings & The Norman Conquest"
description: "Scandinavian raiders, the North Sea Empire, and 1066."
tags: [medieval-europe]
timestamp: "2026-08-16T00:00:00Z"
---

# Vikings & The Norman Conquest

Scandinavian raiders, the North Sea Empire, and 1066.

19 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 44 | [1066](https://pdst.fm/e/traffic.megaphone.fm/GLT5177665423.mp3?updated=1777395024) | 2021-04-19 |
| 71 | [England v Denmark](https://pdst.fm/e/traffic.megaphone.fm/GLT2805859297.mp3?updated=1777395103) | 2021-07-06 |
| 122 | [Athelstan: England's Greatest Monarch](https://pdst.fm/e/traffic.megaphone.fm/GLT8211065813.mp3?updated=1777394965) | 2021-11-19 |
| — | [12 Days: Alfred the Great and Pepys' 'Fanatiques'](https://pdst.fm/e/traffic.megaphone.fm/GLT3956381618.mp3?updated=1777394832) | 2022-01-06 |
| 148 | [The Vikings Go East](https://pdst.fm/e/traffic.megaphone.fm/GLT1476178706.mp3?updated=1706888368) | 2022-02-07 |
| 250 | [Alfred the Great: Fury of the Vikings (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT7924523463.mp3?updated=1777395005) | 2022-11-07 |
| 251 | [Alfred the Great: Return of the King (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT9621369023.mp3?updated=1729783806) | 2022-11-10 |
| 284 | [Denmark: The Great Escape](https://pdst.fm/e/traffic.megaphone.fm/GLT4809968647.mp3?updated=1777394180) | 2022-12-16 |
| 358 | [Viking Sorcery](https://pdst.fm/e/traffic.megaphone.fm/GLT1200485419.mp3?updated=1692015904) | 2023-08-09 |
| 548 | [The Road to 1066: Anglo-Saxon Apocalypse (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT9632339286.mp3?updated=1742156513) | 2025-03-17 |
| 549 | [The Road to 1066: Revenge of the Vikings (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT2312975985.mp3?updated=1742408238) | 2025-03-20 |
| 550 | [The Road to 1066: Rise of the Normans (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT9316865693.mp3?updated=1742557768) | 2025-03-24 |
| 551 | [The Road to 1066: Countdown to Conquest (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT9351236299.mp3?updated=1743507297) | 2025-03-27 |
| 552 | [The Last Viking: The Saga of Harald Hardrada (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT8286135160.mp3?updated=1743514879) | 2025-03-30 |
| 553 | [The Last Viking: Warrior of the New Rome (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT5802152245.mp3?updated=1743594277) | 2025-04-02 |
| 554 | [1066: The Shadows of War (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT1461163139.mp3?updated=1744035271) | 2025-04-06 |
| 555 | [1066: Slaughter at Stamford Bridge (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT1524879968.mp3?updated=1744220170) | 2025-04-09 |
| 556 | [1066: The Battle of Hastings (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT3522014441.mp3?updated=1744371038) | 2025-04-13 |
| 557 | [1066: The Norman Conquest (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT5156716826.mp3?updated=1744847594) | 2025-04-16 |
