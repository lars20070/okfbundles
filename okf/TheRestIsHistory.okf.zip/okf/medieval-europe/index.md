# Medieval Europe

From the fall of Rome to the Renaissance — Vikings, Crusades, kings, and cathedrals.

85 episodes.

## Subtopics
* [The High Middle Ages](/medieval-europe/high-medieval.md) — Kings, treason, and the flowering of medieval civilisation. (41 episodes)
* [Charlemagne & the Carolingians](/medieval-europe/charlemagne-carolingians.md) — The Frankish empire that laid the foundations of medieval Europe. (5 episodes)
* [Renaissance & Reformation](/medieval-europe/renaissance-reformation.md) — The rebirth of learning and the religious upheaval. (13 episodes)
* [Vikings & The Norman Conquest](/medieval-europe/vikings-normans.md) — Scandinavian raiders, the North Sea Empire, and 1066. (19 episodes)
* [The Crusades](/medieval-europe/crusades.md) — Holy war in the medieval world. (7 episodes)
