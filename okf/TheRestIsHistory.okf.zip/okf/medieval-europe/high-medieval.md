---
type: Section
title: "The High Middle Ages"
description: "Kings, treason, and the flowering of medieval civilisation."
tags: [medieval-europe]
timestamp: "2026-08-16T00:00:00Z"
---

# The High Middle Ages

Kings, treason, and the flowering of medieval civilisation.

41 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 19 | [King Arthur](https://pdst.fm/e/traffic.megaphone.fm/GLT1076701162.mp3?updated=1777394962) | 2021-02-01 |
| 34 | [St Cuthbert’s Day](https://pdst.fm/e/traffic.megaphone.fm/GLT9977520388.mp3?updated=1777394852) | 2021-03-20 |
| 53 | [Game of Thrones](https://pdst.fm/e/traffic.megaphone.fm/GLT6687512105.mp3?updated=1777394997) | 2021-05-17 |
| 62 | [Magna Carta](https://pdst.fm/e/traffic.megaphone.fm/GLT5613809659.mp3?updated=1777394820) | 2021-06-10 |
| 74 | [The Six Wives of Henry VIII](https://pdst.fm/e/traffic.megaphone.fm/GLT6913826589.mp3?updated=1777395007) | 2021-07-12 |
| 112 | [Medieval Science](https://pdst.fm/e/traffic.megaphone.fm/GLT3839934134.mp3?updated=1777394945) | 2021-10-28 |
| 131 | [Burgundy: Europe's forgotten superpower](https://pdst.fm/e/traffic.megaphone.fm/GLT6941072856.mp3?updated=1777395010) | 2021-12-16 |
| 133 | [Christmas churches](https://pdst.fm/e/traffic.megaphone.fm/GLT8843719433.mp3?updated=1777395009) | 2021-12-23 |
| — | [12 Days: The Murder of Thomas Becket and the Wounded Knee Massacre](https://pdst.fm/e/traffic.megaphone.fm/GLT4510547363.mp3?updated=1777394876) | 2021-12-29 |
| 138 | [The Princes in the Tower Part 1](https://pdst.fm/e/traffic.megaphone.fm/GLT6274021473.mp3?updated=1777394752) | 2022-01-17 |
| 139 | [The Princes in the Tower Part 2](https://pdst.fm/e/traffic.megaphone.fm/GLT4685691538.mp3?updated=1777394945) | 2022-01-18 |
| 164 | [Saint Patrick](https://pdst.fm/e/traffic.megaphone.fm/GLT2665917893.mp3?updated=1777395038) | 2022-03-17 |
| 174 | [Merlin, Magic and the British](https://pdst.fm/e/traffic.megaphone.fm/GLT5141910845.mp3?updated=1777394926) | 2022-04-11 |
| 192 | [Robin Hood](https://pdst.fm/e/traffic.megaphone.fm/GLT1296880830.mp3?updated=1777394938) | 2022-06-06 |
| 248 | [Medieval Treason (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT9532907553.mp3?updated=1729783899) | 2022-10-31 |
| 318 | [Hundred Years' War: A Game of Thrones (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT5584156008.mp3?updated=1777394199) | 2023-04-03 |
| 319 | [Hundred Years' War: Triumph of the Longbow (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT3100937638.mp3?updated=1777394182) | 2023-04-06 |
| 320 | [Hundred Years' War: The Black Prince (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT6004693022.mp3?updated=1777394213) | 2023-04-10 |
| 321 | [Hundred Years' War: A Storm of Swords (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT1570526345.mp3?updated=1777394905) | 2023-04-13 |
| 327 | [Coronations: The Deep History (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT4746607803.mp3?updated=1777394985) | 2023-05-04 |
| 328 | [Coronations: Sex, Holy Oil and Civil War (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT8165021855.mp3?updated=1777394177) | 2023-05-05 |
| 329 | [Coronations: Chaos, Ceremony and Empire (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT8755026279.mp3?updated=1777394194) | 2023-05-06 |
| 413 | [The Peasants' Revolt: England Erupts (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT8198769595.mp3?updated=1706483816) | 2024-01-29 |
| 415 | [The Murder of Richard II (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT6435684837.mp3?updated=1706885536) | 2024-02-05 |
| 416 | [The Canterbury Tales (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT1956280616.mp3?updated=1706885602) | 2024-02-08 |
| 445 | [The Habsburgs: Secrets of a Dynasty](https://pdst.fm/e/traffic.megaphone.fm/GLT9923460597.mp3?updated=1714615267) | 2024-05-01 |
| 462 | [St George: Dragon-Slayer](https://pdst.fm/e/traffic.megaphone.fm/GLT5334319363.mp3?updated=1718815298) | 2024-06-19 |
| 485 | [Henry IV: The Usurper King (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT8868267122.mp3?updated=1724025396) | 2024-08-18 |
| 486 | [Henry IV: Warrior Princes and Fat Knights (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT8391310611.mp3?updated=1724282528) | 2024-08-21 |
| 487 | [Hundred Years' War: Henry V’s Invasion of France (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT7554933021.mp3?updated=1724590135) | 2024-08-25 |
| 488 | [Hundred Years' War: The Road to Agincourt (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT2110427983.mp3?updated=1724841234) | 2024-08-28 |
| 489 | [Hundred Years' War: Bloodbath at Agincourt (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT5834061192.mp3?updated=1725037473) | 2024-09-01 |
| 490 | [Hundred Years' War: England Triumphant (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT2692942762.mp3?updated=1725452804) | 2024-09-04 |
| 491 | [History's Greatest Beards: From Egyptian Queens to Medieval Conquerors (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT6058938613.mp3?updated=1725837801) | 2024-09-08 |
| 582 | [The Body in the Woods: A Medieval Murder Mystery](https://pdst.fm/e/traffic.megaphone.fm/GLT7904466685.mp3?updated=1752446388) | 2025-07-13 |
| 599 | [The First World War: Downfall of the Habsburgs (Part 6)](https://pdst.fm/e/traffic.megaphone.fm/GLT3258664296.mp3?updated=1757523887) | 2025-09-10 |
| 632 | [Joan of Arc: Warrior Maid (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT6592271090.mp3?updated=1767622369) | 2026-01-05 |
| 633 | [Joan of Arc: Saviour of France (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT5406937184.mp3?updated=1767891416) | 2026-01-08 |
| 634 | [Joan of Arc: Heroine in Chains (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT6235222836.mp3?updated=1768217618) | 2026-01-12 |
| 635 | [Joan of Arc: For Fear of the Flames (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT8113477235.mp3?updated=1768476106) | 2026-01-15 |
| 689 | [A Murderous Affair: The Habsburgs’ Greatest Scandal (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT6194086702.mp3) | 2026-07-19 |
