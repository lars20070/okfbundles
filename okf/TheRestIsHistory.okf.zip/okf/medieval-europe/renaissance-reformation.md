---
type: Section
title: "Renaissance & Reformation"
description: "The rebirth of learning and the religious upheaval."
tags: [medieval-europe]
timestamp: "2026-08-16T00:00:00Z"
---

# Renaissance & Reformation

The rebirth of learning and the religious upheaval.

13 episodes.

| # | Episode | Date |
| --- | --- | --- |
| — | [12 Days: Martin Luther and J.R.R. Tolkien](https://pdst.fm/e/traffic.megaphone.fm/GLT9800831013.mp3?updated=1777394826) | 2022-01-03 |
| 274 | [Switzerland: Calvin's Cancel Culture](https://pdst.fm/e/traffic.megaphone.fm/GLT2874543265.mp3?updated=1777394174) | 2022-12-06 |
| 359 | [Martin Luther King's Dream](https://pdst.fm/e/traffic.megaphone.fm/GLT8593313865.mp3?updated=1692015861) | 2023-08-13 |
| 433 | [Luther: The Man Who Changed the World (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT7298373279.mp3?updated=1711317562) | 2024-03-25 |
| 434 | [Luther: The Revolution Begins (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT4080973410.mp3?updated=1711540975) | 2024-03-28 |
| 435 | [Luther: The Battle Against Satan (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT9360370091.mp3?updated=1711652238) | 2024-03-31 |
| 436 | [Luther: Showdown with the Emperor (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT5159022101.mp3?updated=1712045087) | 2024-04-01 |
| 437 | [Luther: A World Torn Apart (Part 5)](https://pdst.fm/e/traffic.megaphone.fm/GLT3328267667.mp3?updated=1711276960) | 2024-04-03 |
| 509 | [America in '68: The Assassination of Martin Luther King Jr. (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT4373367265.mp3?updated=1731418996) | 2024-10-31 |
| 572 | [The Medici: Masters of Florence (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT1413065864.mp3?updated=1749052325) | 2025-06-08 |
| 573 | [The Medici: Lorenzo the Magnificent (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT6599592252.mp3?updated=1749655445) | 2025-06-11 |
| 574 | [The Medici: Curse of the Mad Monk (Part 3)](https://pdst.fm/e/traffic.megaphone.fm/GLT6193985064.mp3?updated=1784111483) | 2025-06-15 |
| 575 | [The Medici: The Bonfire of the Vanities (Part 4)](https://pdst.fm/e/traffic.megaphone.fm/GLT2280694489.mp3?updated=1784111597) | 2025-06-19 |
