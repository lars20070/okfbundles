---
type: Section
title: "The Crusades"
description: "Holy war in the medieval world."
tags: [medieval-europe]
timestamp: "2026-08-16T00:00:00Z"
---

# The Crusades

Holy war in the medieval world.

7 episodes.

| # | Episode | Date |
| --- | --- | --- |
| 152 | [American Crusades](https://pdst.fm/e/traffic.megaphone.fm/GLT4400059090.mp3?updated=1777394894) | 2022-02-17 |
| 301 | [The Real Da Vinci Code](https://pdst.fm/e/traffic.megaphone.fm/GLT5654192229.mp3?updated=1777394620) | 2023-02-06 |
| 302 | [The Mystery of the Cathars](https://pdst.fm/e/traffic.megaphone.fm/GLT9956144594.mp3?updated=1777394211) | 2023-02-07 |
| 303 | [The Bloodiest Crusade](https://pdst.fm/e/traffic.megaphone.fm/GLT7887097153.mp3?updated=1777394824) | 2023-02-09 |
| 332 | [King Solomon's Mines](https://pdst.fm/e/traffic.megaphone.fm/GLT4960691587.mp3?updated=1777394193) | 2023-05-15 |
| 345 | [Raiders of the Lost Ark (Part 1)](https://pdst.fm/e/traffic.megaphone.fm/GLT1189467433.mp3?updated=1777394791) | 2023-06-26 |
| 346 | [The Mystery of the Holy Grail (Part 2)](https://pdst.fm/e/traffic.megaphone.fm/GLT9518077570.mp3?updated=1777394178) | 2023-06-29 |
