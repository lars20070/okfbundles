---
type: Location
title: "Coombe Tracey"
description: "A village near Baskerville Hall; home of Laura Lyons and a station on the railway line."
tags: [dartmoor, village]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Coombe Tracey is the village where Laura Lyons lives and works at her
typewriting business, where Stapleton picked up supplies, and where the railway
station serves the district. Holmes secretly lodged there during his
investigation. The wagonette from the station is paid off there during the
final ambush.

# Appearances

* [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 10, 11, 13.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md)
