# Locations

* [221B Baker Street](/locations/baker-street.md) - Sherlock Holmes and Dr. Watson's shared residence and consulting rooms in London.
* [Baskerville Hall](/locations/baskerville-hall.md) - The ancestral seat of the Baskerville family on Dartmoor, Devonshire; a gloomy, ancient manor with twin towers, a yew alley, and the moor at its doorstep.
* [The Yew Alley](/locations/yew-alley.md) - A long walk between twelve-foot yew hedges at Baskerville Hall; the scene of Sir Charles Baskerville's death.
* [Dartmoor](/locations/dartmoor-moor.md) - The desolate moorland of Devonshire surrounding Baskerville Hall; a place of Neolithic ruins, treacherous bogs, tors, and ancient mystery.
* [Grimpen Mire](/locations/grimpen-mire.md) - A vast, treacherous bog on Dartmoor; a false step means death to man or beast; Stapleton's hiding place for the hound and the site of his death.
* [Merripit House](/locations/merripit-house.md) - The Stapletons' bleak moorland residence, once a grazier's farm; where the naturalist kept his butterfly collection and imprisoned his wife.
* [Lafter Hall](/locations/lafter-hall.md) - Residence of Mr. Frankland, four miles south of Baskerville Hall; notable for the telescope on its roof.
* [Grimpen](/locations/grimpen.md) - Small grey hamlet on Dartmoor; home of Dr. Mortimer, with a post office, inn, and telegraph office.
* [Coombe Tracey](/locations/coombe-tracey.md) - A village near Baskerville Hall; home of Laura Lyons and a station on the railway line.
* [Princetown](/locations/princetown.md) - The great convict prison on Dartmoor, fourteen miles from Baskerville Hall; Selden escaped from here.
* [Northumberland Hotel](/locations/northumberland-hotel.md) - The London hotel where Sir Henry Baskerville stayed upon his arrival from Canada; site of the boot thefts and the warning letter delivery.
* [The Neolithic Huts](/locations/neolithic-huts.md) - Prehistoric stone dwellings scattered across the moor; one served as Holmes's secret observation post.
* [The Tors of Dartmoor](/locations/dartmoor-tors.md) - The jagged granite peaks dotting the moor: Black Tor, Cleft Tor, Belliver Tor, and Vixen Tor.
* [The Hound's Lair](/locations/hounds-lair.md) - An abandoned tin mine on an island in the heart of the Grimpen Mire; Stapleton's hiding place for the hound.
