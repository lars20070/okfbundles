---
type: Location
title: "Lafter Hall"
description: "Residence of Mr. Frankland, four miles south of Baskerville Hall; notable for the telescope on its roof."
tags: [dartmoor, frankland, residence]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Lafter Hall is the home of the litigious Mr. Frankland. Its notable feature is
the telescope mounted on the flat leads of the roof, through which Frankland
sweeps the moor daily in hopes of spotting the escaped convict. It is through
this telescope that Frankland observes the boy Cartwright carrying supplies to
Holmes's hiding place.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 8, 11.
