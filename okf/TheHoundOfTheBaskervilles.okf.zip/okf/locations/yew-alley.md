---
type: Location
title: "The Yew Alley"
description: "A long walk between twelve-foot yew hedges at Baskerville Hall; the scene of Sir Charles Baskerville's death."
tags: [baskerville-hall, crime-scene]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

The yew alley is a long, dismal walk between two high walls of clipped yew
hedge, twelve feet high and impenetrable, with a six-foot-wide strip of grass
on either side and an eight-foot-wide gravel path in the centre. Halfway down
is the moor-gate — a white wooden wicket-gate with a latch, about four feet
high, opening onto the moor. At the far end stands an old tumble-down
summer-house with an exit. Sir Charles lay dead about fifty yards from the
summer-house.

On the night of his death, the gate was closed and padlocked. Anyone could
climb over it. Sir Charles stood at the gate for five or ten minutes (deduced
from twice-dropped cigar ash on the gravel). No footprints but his own and
Barrymore's were visible on the path. The hound kept to the grassy border,
leaving no tracks, though Dr. Mortimer found giant hound prints near the body.

# Appearances

* [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 2, 3, 8.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 3 (Holmes's interrogation of Dr.
Mortimer).

## From the Source

> It is a long, dismal walk, the yew alley, between two high walls of
> clipped hedge, with a narrow band of grass upon either side. At the far
> end is an old tumble-down summer-house. Halfway down is the moor-gate,
> where the old gentleman left his cigar-ash. It is a white wooden gate
> with a latch. Beyond it lies the wide moor. I remembered your theory of
> the affair and tried to picture all that had occurred. As the old man
> stood there he saw something coming across the moor, something which
> terrified him so that he lost his wits and ran and ran until he died of
> sheer horror and exhaustion.
>
> — Watson visits the yew alley and reconstructs the crime (ch. 8)
