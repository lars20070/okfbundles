---
type: Location
title: "Northumberland Hotel"
description: "The London hotel where Sir Henry Baskerville stayed upon his arrival from Canada; site of the boot thefts and the warning letter delivery."
tags: [london, hotel]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

The Northumberland Hotel, near Charing Cross, London, is where Sir Henry
Baskerville stayed upon arriving from Canada. Here he received the anonymous
warning letter cut from the *Times*, and here his boots were stolen — first a
new brown one (returned), then an old black one (never returned). The hotel
register showed guests Theophilus Johnson (coal-owner, of Newcastle) and Mrs.
Oldmore (invalid lady, of High Lodge, Alton, widow of a former mayor of
Gloucester). Holmes and Watson lunched here with Sir Henry and Dr. Mortimer.

# Appearances

* [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 4, 5.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 4, 5.
