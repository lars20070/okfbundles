---
type: Location
title: "Dartmoor"
description: "The desolate moorland of Devonshire surrounding Baskerville Hall; a place of Neolithic ruins, treacherous bogs, tors, and ancient mystery."
tags: [dartmoor, devonshire]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

The moor is a vast, undulating plain of peat and granite, mottled with green
patches of bog and broken by jagged tors. It is sparsely inhabited, dotted with
Neolithic stone huts, monoliths, and barrows (including a barrow at Long Down where Dr. Mortimer excavated a prehistoric skull). Key landmarks include the Black
Tor, Cleft Tor, Belliver Tor, Vixen Tor, and the Grimpen Mire. Within a radius
of five miles of Baskerville Hall are only a few scattered dwellings: Grimpen
hamlet, Lafter Hall, Merripit House, and the farms High Tor and Foulmire.
Fourteen miles away is Princetown convict prison. A strange, melancholy cry
haunts the moor — the hound's baying.

# Appearances

* [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — throughout.

## From the Source

> "It is a wonderful place, the moor," said he, looking round over the
> undulating downs, long green rollers, with crests of jagged granite
> foaming up into fantastic surges. "You never tire of the moor. You
> cannot think the wonderful secrets which it contains. It is so vast, and
> so barren, and so mysterious."
>
> — Stapleton, describing the moor to Watson (ch. 7)

> The longer one stays here the more does the spirit of the moor sink into
> one's soul, its vastness, and also its grim charm. When you are once out
> upon its bosom you have left all traces of modern England behind you,
> but, on the other hand, you are conscious everywhere of the homes and
> the work of the prehistoric people.
>
> — Watson, in his first report to Holmes (ch. 8)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 3, 6, 7.
