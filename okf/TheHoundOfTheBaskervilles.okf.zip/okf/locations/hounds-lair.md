---
type: Location
title: "The Hound's Lair"
description: "An abandoned tin mine on an island in the heart of the Grimpen Mire, reached by a zigzag path marked with guiding wands; Stapleton's hiding place for the hound."
tags: [dartmoor, grimpen-mire, hideout]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

In the heart of the Grimpen Mire — an island of firm ground surrounded by
treacherous bog — stands an abandoned tin mine. The path to it is marked by
small wands planted by Stapleton and Beryl, zigzagging from tuft to tuft of
rushes. A huge driving-wheel and a shaft half-filled with rubbish mark the mine
entrance. Beside it are crumbling remains of miners' cottages, driven away by
the foul reek of the swamp.

In one cottage, a staple and chain with gnawed bones show where the hound was
confined. A skeleton with brown hair — Dr. Mortimer's spaniel — lay among the
débris. A tin of phosphorus paste was found there. The hound's voice, carrying
across the mire, produced the strange cries heard day and night.

Stapleton fled here after the hound was killed but never reached it; the rising
mud swallowed his footprints.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 14 (exploration of the lair), ch. 15.
