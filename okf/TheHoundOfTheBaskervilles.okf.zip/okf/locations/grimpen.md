---
type: Location
title: "Grimpen"
description: "Small grey hamlet on Dartmoor; home of Dr. Mortimer, with a post office, inn, and telegraph office."
tags: [dartmoor, village]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Grimpen is the nearest hamlet to Baskerville Hall, where Dr. Mortimer has his
house and surgery. The postmaster is also the village grocer. Holmes sends a
test telegram here to verify Barrymore's presence at the Hall.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 3, 7.
