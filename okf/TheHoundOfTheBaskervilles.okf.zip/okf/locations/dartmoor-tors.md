---
type: Location
title: "The Tors of Dartmoor"
description: "The jagged granite peaks dotting the moor: Black Tor, Cleft Tor, Belliver Tor, and Vixen Tor — landmarks in the Baskerville investigation."
tags: [dartmoor, landmark]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

The tors are jagged granite pinnacles that rise from the undulating moor. Key
tors in the investigation:

* **Black Tor** — where Watson first saw the mysterious figure (Holmes)
  silhouetted against the moon. Frankland's telescope was trained upon the
  slopes below it. Holmes's hut lay in a cleft of the hills beneath it.
* **Cleft Tor** — near which Selden's signal candle was placed; approximately a
  mile or two from Baskerville Hall.
* **Belliver Tor** — one of the fantastic shapes jutting from the distant
  skyline.
* **Vixen Tor** — another distant landmark visible from the moor.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 3, 9, 11.
