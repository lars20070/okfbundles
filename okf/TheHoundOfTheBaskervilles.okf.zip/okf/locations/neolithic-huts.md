---
type: Location
title: "The Neolithic Huts"
description: "Prehistoric stone dwellings scattered across the moor; one served as Holmes's secret observation post."
tags: [dartmoor, prehistoric, hiding-place]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

The slopes of the Dartmoor hills are thickly covered with the stone huts of
Neolithic inhabitants — grey circular rings of stone, "their wigwams with the
roofs off," with hearth and couch still visible within. Selden used these as
hiding places. Holmes occupied one near the Black Tor — a hut with sufficient
remaining roof to act as a screen against the weather — as his base of
operations. It contained blankets rolled in a waterproof, a fire-grate with
ashes, cooking utensils, a water bucket, empty tins, a pannikin, a bottle of
spirits, and a flat stone table. A vague pathway among the boulders led to the
dilapidated opening.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 7 ("prehistoric man lived thickly on
the moor"), ch. 11 (Holmes's hut).
