---
type: Location
title: "221B Baker Street"
description: "Sherlock Holmes and Dr. Watson's shared residence and consulting rooms in London."
tags: [london, detective]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

221B Baker Street is the London flat shared by Holmes and Watson. The
sitting-room features a fireplace, a settee, a breakfast table, a
well-polished silver-plated coffee-pot, and Holmes's indexed case files. The
case opens here with the examination of Dr. Mortimer's stick, and closes here
with Holmes's retrospection in late November.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 1, 15.
