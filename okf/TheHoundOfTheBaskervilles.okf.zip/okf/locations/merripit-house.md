---
type: Location
title: "Merripit House"
description: "The Stapletons' bleak moorland residence, once a grazier's farm; where the naturalist kept his butterfly collection and imprisoned his wife."
tags: [dartmoor, stapleton, residence]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Merripit House is a bleak moorland house, once a farm, put into repair as a
modern dwelling. A stunted orchard surrounds it. Inside are large rooms
furnished with elegance reflecting Beryl's taste. The upstairs contains a
small museum of butterflies and moths — the collection of a recognised
lepidopterist — with an upright beam where Beryl was bound and gagged. An
out-house in the orchard corner was used to temporarily hold the hound on the
night of the final attack.

# Appearances

* [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 7, 14.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md)
