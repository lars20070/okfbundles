---
type: Location
title: "Princetown"
description: "The great convict prison on Dartmoor, fourteen miles from Baskerville Hall; Selden escaped from here."
tags: [dartmoor, prison]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Princetown is a convict prison situated fourteen miles from Baskerville Hall on
Dartmoor. It is the source of the escaped convict Selden (the Notting Hill
murderer), whose flight prompts warders to watch every road and station. Holmes
sends a report from Grimpen to Princetown regarding Selden's death.

# Appearances

* [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 3 (mentioned on Holmes's map),
  ch. 6 (convict escape), ch. 9, 13.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 3, 6.
