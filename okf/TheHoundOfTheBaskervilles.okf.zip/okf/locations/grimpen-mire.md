---
type: Location
title: "Grimpen Mire"
description: "A vast, treacherous bog on Dartmoor; a false step means death to man or beast; Stapleton's hiding place for the hound and the site of his death."
tags: [dartmoor, bog, danger]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

The great Grimpen Mire is an expanse of bright green sedge and rushes on the
moor, deceptively fertile in appearance but lethal. Ponies and other animals
wander in and are sucked down. Stapleton alone knows the paths through it,
marked by guiding wands, which lead to islands where rare plants and
butterflies grow — and where he concealed the hound in an abandoned tin mine.
Dense fog banks frequently roll from the mire. Stapleton drowned in its depths
during his final flight; his body was never recovered.

# Appearances

* [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 7, 14.

## From the Source

> "That is the great Grimpen Mire," said he. "A false step yonder means
> death to man or beast. Only yesterday I saw one of the moor ponies
> wander into it. He never came out. I saw his head for quite a long time
> craning out of the bog-hole, but it sucked him down at last. Even in dry
> seasons it is a danger to cross it, but after these autumn rains it is
> an awful place."
>
> — Stapleton, describing the mire to Watson (ch. 7)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 7 ("A false step yonder means death to
man or beast").
