---
type: Location
title: "Baskerville Hall"
description: "The ancestral seat of the Baskerville family on Dartmoor, Devonshire; a gloomy, ancient manor with twin towers, a yew alley, and the moor at its doorstep."
tags: [dartmoor, baskerville-family, manor]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Baskerville Hall is approached through lodge-gates of wrought iron with the
boars' heads of the Baskervilles, past a ruined lodge and a new half-constructed
building (Sir Charles's first South-African-funded improvement), down an avenue
of old trees forming a sombre tunnel, to a broad expanse of turf before the
house. The centre is a heavy block with a projecting porch, draped in ivy, from
which rise twin ancient crenellated towers. More modern wings of black granite
extend to right and left. High mullioned windows, a steep high-angled roof, and
tall chimneys complete the silhouette.

Inside: a great old-fashioned fireplace with high iron dogs, stained glass
windows, oak panelling, stags' heads and coats of arms on the walls. A square
balustraded gallery runs round the top, approached by a double stair. The
dining-room is a long chamber with a daïs, a minstrel's gallery, black beams,
and rows of ancestral portraits. A modern billiard-room adjoins.

The yew alley is a long walk between two lines of old yew hedge, twelve feet
high and impenetrable, with an eight-foot-wide path and six-foot grass strips
on either side. A wicket-gate halfway down leads to the moor; a tumble-down
summer-house stands at the far end.

# Appearances

* [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 6–14.

## From the Source

> It was a fine apartment in which we found ourselves, large, lofty, and
> heavily raftered with huge baulks of age-blackened oak. In the great
> old-fashioned fireplace behind the high iron dogs a log-fire crackled
> and snapped. Then we gazed round us at the high, thin window of old
> stained glass, the oak panelling, the stags' heads, the coats of arms
> upon the walls, all dim and sombre in the subdued light of the central
> lamp.
>
> — Watson's first impression of the great hall (ch. 6)

> The dining-room which opened out of the hall was a place of shadow and
> gloom. It was a long chamber with a step separating the daïs where the
> family sat from the lower portion reserved for their dependents. At one
> end a minstrel's gallery overlooked it. Black beams shot across above
> our heads, with a smoke-darkened ceiling beyond them. A dim line of
> ancestors, in every variety of dress, from the Elizabethan knight to the
> buck of the Regency, stared down upon us and daunted us by their silent
> company.
>
> — Watson describes the dining-room (ch. 6)

> "It's no wonder my uncle felt as if trouble were coming on him in such a
> place as this. It's enough to scare any man."
>
> — Sir Henry, upon arriving at the Hall (ch. 6)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 6 (description).
