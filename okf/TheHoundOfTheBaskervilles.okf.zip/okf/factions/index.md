# Factions

* [The Baskerville Family](/factions/baskerville-family.md) - An ancient Devonshire family, lords of Baskerville Hall since at least the 17th century; haunted by the legend of a demon-hound that kills members of the line.
