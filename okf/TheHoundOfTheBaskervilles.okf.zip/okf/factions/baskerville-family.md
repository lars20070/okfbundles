---
type: Faction
title: "The Baskerville Family"
description: "An ancient Devonshire family, lords of Baskerville Hall since at least the 17th century; haunted by the legend of a demon-hound that kills members of the line."
tags: [family, devonshire, legend]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
home: /locations/baskerville-hall.md
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Lineage

* **Hugo Baskerville** (17th c.) — the wicked ancestor; killed by the hound.
  Sons: Rodger, John, daughter Elizabeth.
* **Sir Charles Baskerville** (d. 1889) — eldest of three brothers; made
  fortune in South Africa; died of fright in the yew alley.
* **Second brother** (d. young) — father of Sir Henry.
* **Rodger Baskerville** (d. 1876, Central America, yellow fever) — the black
  sheep; father of Stapleton (Rodger Baskerville Jr.), who was his only child
  and the secret Baskerville heir.
* **Sir Henry Baskerville** — the last of the Baskervilles, heir to the estate.
* **James Desmond** — elderly clergyman in Westmoreland, distant cousin and next
  heir should Sir Henry die childless.

# Members

* [/characters/hugo-baskerville.md](/characters/hugo-baskerville.md)
* [/characters/charles-baskerville.md](/characters/charles-baskerville.md)
* [/characters/henry-baskerville.md](/characters/henry-baskerville.md)
* [/characters/stapleton.md](/characters/stapleton.md) — secret member, Rodger Baskerville Jr.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 2, 5, 15.
