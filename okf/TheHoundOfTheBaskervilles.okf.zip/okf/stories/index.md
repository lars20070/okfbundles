# Stories

* [The Hound of the Baskervilles](/stories/the-hound-of-the-baskervilles.md) - Sherlock Holmes investigates the death of Sir Charles Baskerville and the legendary demon-hound that haunts the Baskerville family on Dartmoor.
