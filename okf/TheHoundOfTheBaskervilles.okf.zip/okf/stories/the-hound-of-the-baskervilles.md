---
type: Story
title: "The Hound of the Baskervilles"
description: "Sherlock Holmes investigates the death of Sir Charles Baskerville and the legendary demon-hound that haunts the Baskerville family on Dartmoor."
tags: [sherlock-holmes, novel, mystery, gothic]
timestamp: 2026-08-17T00:00:00Z
canon: hard
status: published
author: "Arthur Conan Doyle"
in_world_span: "1889, autumn"
pov: [/characters/john-watson.md]
provenance: human
resource: https://www.gutenberg.org/ebooks/2852
---

# Description

*The Hound of the Baskervilles* is a Sherlock Holmes novel set in 1889 on
Dartmoor in Devonshire. Dr. James Mortimer consults Holmes about the death of
his friend and patient Sir Charles Baskerville, who appears to have died of
fright while walking the yew alley of Baskerville Hall at night. Giant hound
footprints were found near the body.

The legend of a spectral hound that has haunted the Baskerville family since
the time of the Great Rebellion — when the wicked Hugo Baskerville's throat was
torn out by a great black beast — forms the supernatural backdrop against which
Holmes unravels a scheme of murder, inheritance, and deception.

Dr. Watson is dispatched to Dartmoor as Sir Henry Baskerville's guardian while
Holmes conducts a parallel investigation from hiding. The mystery unfolds
through Watson's reports to Holmes, culminating in the exposure of the
naturalist Stapleton — secretly a Baskerville heir — as the mastermind who used
a phosphorescent-painted hound to frighten Sir Charles to death and who
attempted the same on Sir Henry.

# Structure

15 chapters, narrated by Dr. Watson (first-person), with embedded letters and
diary extracts.

# Citations

[1] [Project Gutenberg eBook #2852](https://www.gutenberg.org/ebooks/2852)
