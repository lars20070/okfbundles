# Arcs

* [Stapleton's Scheme](/arcs/stapleton-scheme.md) - Stapleton's plot to murder the Baskerville heirs and claim the estate escalates from patience to desperate action.
