---
type: Arc
title: "Stapleton's Scheme"
description: "Stapleton's plot to murder the Baskerville heirs and claim the estate escalates from patience to desperate action."
tags: [villain-arc, murder-plot]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
arc_kind: plot
subject: /characters/stapleton.md
spans_stories:
  - /stories/the-hound-of-the-baskervilles.md
payoff_event: /events/hound-confrontation.md
provenance: human
---

# Promise
Stapleton establishes himself near Baskerville Hall, cultivates Sir Charles's
friendship, and learns the weak points he can exploit: the family legend, the
baronet's weak heart, and his superstitious nature.

# Progress
* [x] Purchases the hound from Ross and Mangles and conceals it in the Grimpen
  Mire.
* [x] Uses Laura Lyons to lure Sir Charles to the moor-gate; releases the
  hound. Sir Charles dies of fright.
* [x] Follows Sir Henry to London, attempts to steal a boot for the hound's
  scent. Sends warning letter (via his wife) and shadows with a cab.
* [x] Returns to Devonshire, poses as a naturalist neighbour. His wife warns
  Sir Henry.
* [x] Sets the hound on Sir Henry's trail; the hound kills Selden by mistake.
* [x] Arranges the final dinner trap; hound attacks Sir Henry.
* [x] Flees into the Grimpen Mire and drowns.

# Payoff
[The Hound Confrontation](/events/hound-confrontation.md) — hound killed,
Stapleton perishes in the mire.

# Citations
[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 15 (full retrospection).
