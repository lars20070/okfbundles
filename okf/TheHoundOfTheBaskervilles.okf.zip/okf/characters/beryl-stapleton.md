---
type: Character
title: "Beryl Stapleton"
description: "Wife of Stapleton, passed off as his sister; a Costa Rican beauty who repeatedly tries to warn Sir Henry of danger."
tags: [victim, costa-rica, warning]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: alive
aliases: ["Beryl Garcia", "Mrs. Vandeleur", "Miss Stapleton"]
home: /locations/merripit-house.md
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Beryl Stapleton (née Garcia) is darker than any brunette Watson has seen in
England — slim, elegant, and tall. She has a proud, finely cut face, a
sensitive mouth, and beautiful dark, eager eyes. She speaks with a curious
lisp. Originally from Costa Rica, she married Rodger Baskerville Jr. (alias
Vandeleur, then Stapleton). She speaks good English with a Spanish-American
accent.

# Role

Stapleton forced her to pose as his sister. She resisted his attempt to use her
as direct accomplice in the murder of Sir Charles, for which she was beaten.
When Sir Henry arrived, she tried repeatedly to warn him: she told Watson (whom
she mistook for Sir Henry) to "go back to London, instantly," then intercepted
Watson on the moor path to reiterate the warning.

On the night of the final trap, she learned of the hound and confronted
Stapleton. He revealed she had a rival (Laura Lyons), then bound and gagged her
in the upstairs museum. Holmes found her tied to a post with a weal of a
whiplash across her neck. After being freed, she guided the investigators
through the Grimpen Mire to Stapleton's lair.

# Appearances

* [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 7, 9, 14.

## From the Source

> There could not have been a greater contrast between brother and sister,
> for Stapleton was neutral tinted, with light hair and grey eyes, while
> she was darker than any brunette whom I have seen in England — slim,
> elegant, and tall. She had a proud, finely cut face, so regular that it
> might have seemed impassive were it not for the sensitive mouth and the
> beautiful dark, eager eyes. With her perfect figure and elegant dress she
> was, indeed, a strange apparition upon a lonely moorland path.
>
> — Watson's first impression of Beryl (ch. 7)

> "Go back!" she said. "Go straight back to London, instantly."
>
> — Beryl's warning to Watson (whom she mistook for Sir Henry) on the
> moor path (ch. 7)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 7 (first meeting, warning), ch. 14
(rescue).
