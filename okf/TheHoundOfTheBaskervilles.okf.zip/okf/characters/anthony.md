---
type: Character
title: "Anthony"
description: "The old manservant at Merripit House; likely a Spanish-American confidant of Stapleton who cared for the hound in his master's absence."
tags: [servant, merripit-house, accomplice]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: unknown
home: /locations/merripit-house.md
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Anthony is a strange, wizened, rusty-coated old manservant at Merripit House.
He speaks good English with a curious lisping accent — like Mrs. Stapleton,
suggesting a Spanish or Spanish-American origin (where "Antonio" is common).
His connection with the Stapletons can be traced back to their
school-mastering days in Yorkshire.

Holmes deduces that Anthony was Stapleton's confidant — not necessarily in the
murder plot, but certainly in the care of the hound. During Stapleton's trip to
London, Anthony likely fed and tended the beast, crossing the Grimpen Mire by
the path Stapleton had marked out. He disappeared after the case concluded and
escaped the country.

# Appearances

* [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 7 (admits Watson and Stapleton),
  ch. 14 (meets Holmes, Watson, and Lestrade at the door), ch. 15 (Holmes's
  retrospection).

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 7 ("a strange, wizened,
rusty-coated old manservant"), ch. 15 ("This man has disappeared and has
escaped from the country").
