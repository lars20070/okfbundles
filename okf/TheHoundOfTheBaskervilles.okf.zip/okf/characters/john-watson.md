---
type: Character
title: "Dr. John Watson"
description: "Holmes's friend, chronicler, and fellow investigator; narrator of the Baskerville case."
tags: [narrator, doctor, baker-street]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: alive
aliases: ["Watson"]
home: /locations/baker-street.md
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Dr. John Watson is a medical doctor, Holmes's friend and flatmate at 221B Baker
Street, and the first-person narrator of the Baskerville case. Holmes describes
him as "not yourself luminous, but a conductor of light." Watson is a man of
action and common sense, armed with a revolver during his time on the moor.

# Role in the case

Holmes dispatches Watson to Baskerville Hall as Sir Henry's protector and
clandestine reporter. From there Watson sends regular reports by letter and
keeps a diary. He investigates the Barrymores' midnight signals (which prove to
be aid to Mrs. Barrymore's escaped-convict brother Selden), interviews Laura
Lyons at Coombe Tracey, discovers the mysterious stranger on the moor (who
proves to be Holmes), and witnesses the final confrontation with the hound.

Watson feels deeply the deception of Holmes concealing his presence on the moor
but is mollified by Holmes's praise of his reports.

# Appearances

* [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 1–15 (narrator
  throughout).

## From the Source

> "It may be that you are not yourself luminous, but you are a conductor of
> light. Some people without possessing genius have a remarkable power of
> stimulating it. I confess, my dear fellow, that I am very much in your
> debt."
>
> — Holmes to Watson, after Watson's deductions about the walking stick
> (ch. 1)

# Relationships

* [Sherlock Holmes](/characters/sherlock-holmes.md) — friend and colleague.
* [Sir Henry Baskerville](/characters/henry-baskerville.md) — charge and ward during the Devonshire
  expedition.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md)
