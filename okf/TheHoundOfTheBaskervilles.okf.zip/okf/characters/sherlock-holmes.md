---
type: Character
title: "Sherlock Holmes"
description: "Consulting detective; the world's first and only consulting detective, based at 221B Baker Street, London."
tags: [protagonist, detective, baker-street]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: alive
home: /locations/baker-street.md
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Sherlock Holmes is a consulting detective who operates from 221B Baker Street,
London. He possesses extraordinary powers of observation and deduction. Holmes
is characterised by his intense mental concentration, his ability to detach his
mind at will, and his method of concealing his full plans until their
fulfilment. He is a connoisseur of crime, a specialist in the detection of
types, and claims expertise in distinguishing seventy-five perfumes. He keeps
an indexed list of cases.

# Role in the case

Dr. James Mortimer consults Holmes about the death of Sir Charles Baskerville.
Holmes initially remains in London, sending Dr. Watson to Dartmoor as his
agent, while secretly travelling to Devonshire himself and hiding in a
Neolithic hut on the moor. He uses Cartwright, a boy from a district messenger
office, as his supply runner. Holmes identifies Stapleton as a Baskerville
heir, deduces the existence of a real hound treated with phosphorus, and
orchestrates the final trap using Sir Henry as bait.

Holmes reveals the case in retrospection: the hound was purchased from Ross and
Mangles of Fulham Road, treated with a luminous phosphorus preparation, and
kept on an island in the Grimpen Mire. Stapleton drowned in the mire during his
final flight.

# Appearances

* [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 1–5, 11–15.

## From the Source

> "It is a lovely evening, my dear Watson," said a well-known voice. "I
> really think that you will be more comfortable outside than in."
>
> — Holmes reveals himself to Watson at the Neolithic hut (ch. 11)

> "The nets are all in place, and the drag is about to begin. We'll know
> before the day is out whether we have caught our big, lean-jawed pike, or
> whether he has got through the meshes."
>
> — Holmes, the morning of the final trap (ch. 13)

# Relationships

* [Dr. John Watson](/characters/john-watson.md) — friend, chronicler, and agent. Holmes values Watson's
  reports but withholds his own presence on the moor until chapter 11.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 1, ch. 11 (reveal), ch. 13 ("nets
are all in place"), ch. 15 (retrospection).
