---
type: Character
title: "Laura Lyons"
description: "Daughter of Mr. Frankland; estranged wife of an artist; Stapleton's unwitting tool in luring Sir Charles to his death."
tags: [coombe-tracey, divorce, tool]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: alive
home: /locations/coombe-tracey.md
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Laura Lyons (née Frankland) is a woman of extreme beauty with rich hazel eyes
and hair, freckled cheeks, but a coarseness of expression, hardness of eye, and
looseness of lip that mar her looks. Estranged from her father for marrying
without his consent, she was deserted by her artist husband and set up in a
typewriting business by the charity of Sir Charles, Stapleton, and Dr.
Mortimer.

Stapleton, posing as an unmarried man, promised to marry her if she obtained a
divorce. He dictated the letter summoning Sir Charles to the moor-gate, then
dissuaded her from keeping the appointment. When Holmes reveals that Stapleton
is married, she turns on him and provides the evidence needed to complete the
case.

# Appearances

* [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 10, 11, 13.

## From the Source

> The first impression left by Mrs. Lyons was one of extreme beauty. Her
> eyes and hair were of the same rich hazel colour, and her cheeks, though
> considerably freckled, were flushed with the exquisite bloom of the
> brunette, the dainty pink which lurks at the heart of the sulphur rose.
> Admiration was, I repeat, the first impression. But the second was
> criticism. There was something subtly wrong with the face, some
> coarseness of expression, some hardness, perhaps, of eye, some looseness
> of lip which marred its perfect beauty.
>
> — Watson's first impression of Laura Lyons (ch. 11)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md)
