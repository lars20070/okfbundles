---
type: Character
title: "Hugo Baskerville"
description: "The wicked 17th-century ancestor whose crimes gave rise to the legend of the Hound of the Baskervilles."
tags: [baskerville-family, legend, historical]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: dead
faction: [/factions/baskerville-family.md]
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Hugo Baskerville held the Manor of Baskerville during the time of the Great
Rebellion (mid-17th century). He was a wild, profane, and godless man with a
wanton and cruel humour that made his name a by-word through the West. His
portrait hangs in Baskerville Hall, dated 1647, showing him in black velvet and
lace — a quiet, meek-mannered face with a lurking devil in the eyes. Holmes
identifies a striking family resemblance to Stapleton.

# The legend

On a Michaelmas night, Hugo abducted the daughter of a local yeoman and brought
her to the Hall. While he caroused, she escaped down the ivy-covered south wall
and fled homeward across the moor. Hugo, discovering her gone, swore he would
render his body and soul to the Powers of Evil if he might overtake her. He
rode out with his hounds.

That night, shepherds saw Hugo pass on his black mare, followed by "such a
hound of hell as God forbid should ever be at my heels." Later, the black mare
returned riderless. Hugo's companions found the maiden dead of fear and fatigue
in a clearing between two ancient stones. Standing over Hugo's body was "a
great, black beast, shaped like a hound, yet larger than any hound that ever
mortal eye has rested upon." As they watched, it tore out Hugo's throat, then
turned blazing eyes upon them. One of the three who saw it died that night; the
other two were broken men for the rest of their days.

Hugo left the account in manuscript, dated 1742, addressed to his sons Rodger
and John, with instructions not to tell their sister Elizabeth.

# Appearances

* [/events/hugo-legend.md](/events/hugo-legend.md) — the legendary account.
* [/items/baskerville-manuscript.md](/items/baskerville-manuscript.md) — the 1742 manuscript.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 2 (manuscript read by Dr.
Mortimer), ch. 13 (portrait identification).
