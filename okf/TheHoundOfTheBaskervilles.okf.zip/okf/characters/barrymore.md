---
type: Character
title: "Barrymore"
description: "Butler of Baskerville Hall; tall, handsome, black-bearded servant whose family has served the Baskervilles for four generations."
tags: [butler, baskerville-hall, suspect]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: alive
home: /locations/baskerville-hall.md
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Barrymore is a tall, handsome man with a square black beard, pale distinguished
features, and the subdued manner of a well-trained servant. He is somewhat
deaf. His family has served the Baskervilles for four generations. He and his
wife received £500 each from Sir Charles's will.

Initially a suspect — his black beard matches the description of the man in the
cab, he was the first to discover Sir Charles's body, and he lied about the
test telegram — Barrymore is exonerated when his midnight candle-signalling is
revealed to be aid for his brother-in-law, the escaped convict Selden. He later
reveals the existence of Laura Lyons's burned letter with the initials "L. L."

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 6–10.

## From the Source

> He was a remarkable-looking man, tall, handsome, with a square black
> beard and pale, distinguished features.
>
> — Watson describes Barrymore (ch. 6)

> "I know something, Sir Henry, and perhaps I should have said it before,
> but it was long after the inquest that I found it out. I've never
> breathed a word about it yet to mortal man. It's about poor Sir
> Charles's death."
>
> — Barrymore reveals the existence of the burned letter from L. L.
> (ch. 10)
