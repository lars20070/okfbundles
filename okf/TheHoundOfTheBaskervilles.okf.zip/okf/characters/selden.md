---
type: Character
title: "Selden"
description: "The Notting Hill murderer; escaped convict from Princetown; brother of Eliza Barrymore; killed by the hound while wearing Sir Henry's cast-off clothes."
tags: [convict, murderer, victim]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: dead
death_date: "October 1889"
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Selden is the Notting Hill murderer, of peculiar ferocity and wanton
brutality — his death sentence was commuted to penal servitude due to doubts
about his sanity. He is a short, squat, strongly built man with an evil yellow
face, a bristling beard, and matted hair. He hid on the moor after escaping
Princetown, sustained by food left by the Barrymores at a signal point near
Cleft Tor.

Selden died when Stapleton set the hound on Sir Henry's scent. The convict,
wearing Sir Henry's discarded tweed suit (passed to him by Barrymore), was
tracked by the beast instead. Holmes and Watson heard his screams, found his
body with a crushed skull at the base of a cliff, and initially believed it to
be Sir Henry.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 6, 9, 10, 12 (death).

## From the Source

> Over the rocks, in the crevice of which the candle burned, there was
> thrust out an evil yellow face, a terrible animal face, all seamed and
> scored with vile passions. Foul with mire, with a bristling beard, and
> hung with matted hair, it might well have belonged to one of those old
> savages who dwelt in the burrows on the hillsides.
>
> — Watson and Sir Henry catch sight of Selden on the moor (ch. 9)
