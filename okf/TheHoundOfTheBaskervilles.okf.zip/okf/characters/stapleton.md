---
type: Character
title: "Stapleton"
description: "Naturalist and lepidopterist of Merripit House; secretly Rodger Baskerville Jr., a Baskerville heir who murdered Sir Charles and attempts to murder Sir Henry."
tags: [villain, baskerville-family, naturalist, murderer, alias]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: dead
aliases: ["Rodger Baskerville Jr.", "Vandeleur"]
home: /locations/merripit-house.md
faction: [/factions/baskerville-family.md]
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Stapleton is a small, slim, clean-shaven, prim-faced man, flaxen-haired and
lean-jawed, between thirty and forty years of age. He carries a green
butterfly-net and a tin specimen box. His grey eyes have a dry glitter and his
thin lips a firm set that suggests a positive and possibly harsh nature. Holmes
describes him as "a creature of infinite patience and craft, with a smiling
face and a murderous heart."

He is the son of Rodger Baskerville (the black-sheep younger brother of Sir
Charles) and was born in South America. He married Beryl Garcia of Costa Rica,
embezzled public money under the name Vandeleur, and fled to England where he
ran St. Oliver's private school in the east of Yorkshire. The school succeeded
initially through the ability of a consumptive tutor named Fraser, whom
Stapleton had befriended on the voyage to England. After Fraser died, the
school sank; a serious epidemic killed three boys and it never recovered. The
Vandeleurs then changed their name to Stapleton and moved to Devonshire. Stapleton is a recognised authority on entomology; a moth bears the
name Vandeleur in his honour.

# The scheme

Stapleton established himself near Baskerville Hall knowing only two lives
stood between him and the estate. He cultivated Sir Charles's friendship and
learned of the family legend, Sir Charles's weak heart, and his superstitious
nature. He purchased the strongest and most savage hound from Ross and Mangles
of Fulham Road, kept it on an island in the Grimpen Mire, and daubed it with
phosphorus to create the appearance of the legendary hell-hound.

He used Laura Lyons (to whom he posed as a single man offering marriage) to
lure Sir Charles to the yew-alley gate, then released the hound. Sir Charles
died of fright. For Sir Henry, Stapleton stole a boot in London to give the
hound the scent, then arranged the dinner at Merripit House so Sir Henry would
walk home alone across the moor.

When his plot failed and the hound was killed, Stapleton fled into the Grimpen
Mire and drowned in the bog. His body was never recovered.

# Appearances

* [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 7–14.

## From the Source

> He was a small, slim, clean-shaven, prim-faced man, flaxen-haired and
> lean-jawed, between thirty and forty years of age, dressed in a grey suit
> and wearing a straw hat. A tin box for botanical specimens hung over his
> shoulder and he carried a green butterfly-net in one of his hands.
>
> — Watson's first impression of Stapleton (ch. 7)

> In that impassive colourless man, with his straw hat and his
> butterfly-net, I seemed to see something terrible — a creature of
> infinite patience and craft, with a smiling face and a murderous heart.
>
> — Watson, after Holmes reveals Stapleton is the murderer (ch. 12)

> "A pin, a cork, and a card, and we add him to the Baker Street
> collection!"
>
> — Holmes, after identifying Stapleton as a Baskerville from the portrait
> (ch. 13)

# Relationships

* [Beryl Stapleton](/characters/beryl-stapleton.md) — his wife, passed off as his sister; he beat and
  bound her when she tried to warn Sir Henry.
* [Laura Lyons](/characters/laura-lyons.md) — his unwitting tool, deceived by a false promise of
  marriage.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 7 (introduction), ch. 12 (Holmes
reveals identity), ch. 15 (full retrospection).
