---
type: Character
title: "Cartwright"
description: "A fourteen-year-old boy from a London district messenger office; Holmes's runner and supply-carrier during the Dartmoor investigation."
tags: [messenger, assistant, london]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: alive
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Cartwright is a fourteen-year-old boy with a bright, keen face, employed at a
district messenger office managed by Wilson. Holmes previously helped Wilson
save his good name (and perhaps his life), and Cartwright showed ability during
that earlier investigation.

# Role

Holmes first tasks Cartwright in London: visit twenty-three hotels near Charing
Cross searching waste-paper baskets for the cut *Times* leader page (ch. 4).
Cartwright reports failure by wire.

Holmes then brings Cartwright to Dartmoor as his secret assistant. Disguised as
a country boy, Cartwright carries supplies (bread, tinned tongue, preserved
peaches, clean linen) to Holmes's Neolithic hut on the moor, and watches
Watson's movements. Frankland spots Cartwright through his telescope and
mistakes him for the convict's food-supplier.

In the final phase, Cartwright is sent back to London by train from Coombe
Tracey with instructions to wire Sir Henry about a fictitious lost pocketbook —
a ruse to convince the Stapletons that Holmes has left Devonshire.

# Appearances

* [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 4, 5, 12, 13.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 4 ("a lad of fourteen, with a bright,
keen face"), ch. 12–13.
