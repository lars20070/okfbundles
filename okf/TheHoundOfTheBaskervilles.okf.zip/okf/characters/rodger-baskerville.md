---
type: Character
title: "Rodger Baskerville"
description: "The youngest of the three Baskerville brothers; the black sheep who fled England for Central America, died of yellow fever in 1876, and was secretly the father of Stapleton."
tags: [baskerville-family, central-america]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: dead
death_date: "1876"
faction: [/factions/baskerville-family.md]
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Rodger Baskerville was the youngest of three brothers — Sir Charles was the
eldest, the second died young (leaving a son, Henry). Rodger was the black
sheep: he came of the "old masterful Baskerville strain" and was "the very
image of the family picture of old Hugo." He made England too hot to hold him
and fled to Central America.

Contrary to the family's belief, Rodger did marry — to Beryl Garcia, one of the
beauties of Costa Rica — and had one child, a son also named Rodger. This son,
after embezzling public money, changed his name to Vandeleur and later to
Stapleton. The senior Rodger died of yellow fever in 1876.

# Appearances

* [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 2 (mentioned by Dr. Mortimer),
  ch. 15 (full biography from Holmes).

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 2, ch. 15.
