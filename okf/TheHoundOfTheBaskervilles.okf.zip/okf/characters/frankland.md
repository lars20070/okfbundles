---
type: Character
title: "Mr. Frankland"
description: "Litigious elderly resident of Lafter Hall; estranged father of Laura Lyons; amateur astronomer whose telescope inadvertently helps Watson."
tags: [lafter-hall, litigious, astronomer]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: alive
home: /locations/lafter-hall.md
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Mr. Frankland of Lafter Hall is an elderly, red-faced, white-haired, choleric
man who has spent a large fortune in litigation, fighting for the pleasure of
it. He has about seven lawsuits pending. He disowned his daughter Laura for
marrying without his consent. An amateur astronomer, he uses a telescope on his
roof to sweep the moor for the escaped convict. Through him, Watson learns of
the boy carrying supplies to the mysterious stranger on the moor, leading
Watson to Holmes's hiding place.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 8, 11.

## From the Source

> "I have brought off a double event. I mean to teach them in these parts
> that law is law, and that there is a man here who does not fear to
> invoke it. I have established a right of way through the centre of old
> Middleton's park, slap across it, sir, within a hundred yards of his own
> front door."
>
> — Mr. Frankland, celebrating his legal victories (ch. 11)
