---
type: Character
title: "Sir Charles Baskerville"
description: "The recently deceased baronet of Baskerville Hall; died of fright in the yew alley after being pursued by Stapleton's phosphorescent hound."
tags: [baskerville-family, victim, baronet]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: dead
death_date: "May 4"
home: /locations/baskerville-hall.md
faction: [/factions/baskerville-family.md]
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Sir Charles Baskerville was a strong-minded, shrewd, practical man who made his
fortune in South African speculation and returned to England to restore
Baskerville Hall. He was childless, a widower, and the eldest of three brothers. He had been
mentioned as the probable Liberal candidate for Mid-Devon at the next
election. He had resided at Baskerville Hall for only two years since
returning from South Africa. He had an eccentric habit of mind, simple personal tastes, and
extreme generosity — his donations to local charities were frequently
chronicled. His health had been impaired, with an affection of the heart
causing changes of colour, breathlessness, and nervous depression. He was
superstitious and took the family legend of the hound exceedingly to heart.

# Death

On the night of May 4, Sir Charles went for his habitual nocturnal walk down
the yew alley, smoking a cigar. At the moor-gate he waited (as deduced from
twice-dropped cigar ash) for Laura Lyons, who had written asking him to meet
her there at ten o'clock — a letter dictated by Stapleton. Stapleton released
the phosphorescent hound, which sprang over the wicket-gate. Sir Charles fled
down the alley, running on his toes, until his diseased heart burst. He fell
dead on his face, his features so convulsed that Dr. Mortimer at first
questioned his identity. Beside the body were the footprints of a gigantic
hound.

Sir Charles was fond of discussing his will provisions. He left £500 each to
the Barrymores, £1,000 to Dr. Mortimer, sundry sums to individuals and many
public charities, and the residue — £740,000 — to Sir Henry. The total estate
was close on to a million pounds. His death left the entailed estate to Sir
Henry, with James Desmond (elderly clergyman of Westmoreland) as next heir
should Sir Henry die childless.

# Appearances

* [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — mentioned throughout; dead before ch. 1.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 2 (newspaper report, will), ch. 15
(retrospection).

## From the Source

> "The recent sudden death of Sir Charles Baskerville, whose name has been
> mentioned as the probable Liberal candidate for Mid-Devon at the next
> election, has cast a gloom over the county."
>
> — The *Devon County Chronicle*, May 14 (ch. 2)

> "He was a strong-minded man, sir, shrewd, practical, and as
> unimaginative as I am myself. Yet he took this document very seriously,
> and his mind was prepared for just such an end as did eventually
> overtake him."
>
> — Dr. Mortimer, on Sir Charles and the legend (ch. 2)
