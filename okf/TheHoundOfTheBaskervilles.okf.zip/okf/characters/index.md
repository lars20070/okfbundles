# Characters

* [Sherlock Holmes](/characters/sherlock-holmes.md) - Consulting detective; the world's first and only consulting detective, based at 221B Baker Street, London.
* [Dr. John Watson](/characters/john-watson.md) - Holmes's friend, chronicler, and fellow investigator; narrator of the Baskerville case.
* [Sir Henry Baskerville](/characters/henry-baskerville.md) - Last of the Baskervilles; a Canadian-raised baronet who inherits Baskerville Hall and becomes the target of Stapleton's murder plot.
* [Dr. James Mortimer](/characters/james-mortimer.md) - Country medical practitioner of Grimpen, Dartmoor; friend and medical attendant of Sir Charles Baskerville; brings the case to Holmes.
* [Stapleton](/characters/stapleton.md) - Naturalist and lepidopterist of Merripit House; secretly Rodger Baskerville Jr., a Baskerville heir who murdered Sir Charles and attempts to murder Sir Henry.
* [Beryl Stapleton](/characters/beryl-stapleton.md) - Wife of Stapleton, passed off as his sister; a Costa Rican beauty who repeatedly tries to warn Sir Henry of danger.
* [Sir Charles Baskerville](/characters/charles-baskerville.md) - The recently deceased baronet of Baskerville Hall; died of fright in the yew alley after being pursued by Stapleton's phosphorescent hound.
* [Hugo Baskerville](/characters/hugo-baskerville.md) - The wicked 17th-century ancestor whose crimes gave rise to the legend of the Hound of the Baskervilles.
* [Barrymore](/characters/barrymore.md) - Butler of Baskerville Hall; tall, handsome, black-bearded servant whose family has served the Baskervilles for four generations.
* [Eliza Barrymore](/characters/eliza-barrymore.md) - Housekeeper of Baskerville Hall, née Selden; sister of the escaped convict Selden; her sobbing in the night reveals the family secret.
* [Selden](/characters/selden.md) - The Notting Hill murderer; escaped convict from Princetown; brother of Eliza Barrymore; killed by the hound while wearing Sir Henry's cast-off clothes.
* [Laura Lyons](/characters/laura-lyons.md) - Daughter of Mr. Frankland; estranged wife of an artist; Stapleton's unwitting tool in luring Sir Charles to his death.
* [Mr. Frankland](/characters/frankland.md) - Litigious elderly resident of Lafter Hall; estranged father of Laura Lyons; amateur astronomer whose telescope inadvertently helps Watson.
* [Inspector Lestrade](/characters/lestrade.md) - Scotland Yard detective summoned by Holmes for the final confrontation with the hound.
* [Cartwright](/characters/cartwright.md) - A fourteen-year-old boy from a London district messenger office; Holmes's runner and supply-carrier during the Dartmoor investigation.
* [Perkins](/characters/perkins.md) - Groom and coachman at Baskerville Hall; a hard-faced, gnarled little fellow who drives the wagonette.
* [Anthony](/characters/anthony.md) - The old manservant at Merripit House; likely a Spanish-American confidant of Stapleton who cared for the hound in his master's absence.
* [Rodger Baskerville](/characters/rodger-baskerville.md) - The youngest of the three Baskerville brothers; the black sheep who fled England for Central America, died of yellow fever in 1876, and was secretly the father of Stapleton.
* [James Desmond](/characters/james-desmond.md) - Elderly clergyman of Westmoreland, distant cousin of the Baskervilles; next heir to the estate should Sir Henry die childless.
