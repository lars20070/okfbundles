---
type: Character
title: "Perkins"
description: "Groom and coachman at Baskerville Hall; a hard-faced, gnarled little fellow who drives the wagonette."
tags: [servant, baskerville-hall, groom]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: alive
home: /locations/baskerville-hall.md
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Perkins is a hard-faced, gnarled little fellow who serves as groom at
Baskerville Hall. He drives the wagonette (with a pair of cobs) that meets Sir
Henry, Dr. Mortimer, and Dr. Watson at the railway station upon their arrival
in Devonshire. He was the one who rode on horseback to summon Dr. Mortimer on
the night of Sir Charles's death. Watson later takes Perkins to drive him to
Coombe Tracey for the Laura Lyons interview.

# Appearances

* [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 2 (mentioned), ch. 6 (drives
  wagonette), ch. 8 (suggested to sleep at Stapletons'), ch. 11 (drives Watson
  to Coombe Tracey).

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 6 ("a hard-faced, gnarled little
fellow").
