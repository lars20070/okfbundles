---
type: Character
title: "Eliza Barrymore"
description: "Housekeeper of Baskerville Hall, née Selden; sister of the escaped convict Selden; her sobbing in the night reveals the family secret."
tags: [housekeeper, baskerville-hall, selden]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: alive
home: /locations/baskerville-hall.md
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Mrs. Eliza Barrymore is a large, impassive, heavy-featured woman with a stern
set expression of mouth, intensely respectable and inclined to be puritanical.
Despite her stolid exterior, she is the sister of Selden, the Notting Hill
murderer, and weeps bitterly for him in the night. She and Barrymore signal
Selden by candle from the western window and carry food to him on the moor.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 7–9.

## From the Source

> "My unhappy brother is starving on the moor. We cannot let him perish at
> our very gates. The light is a signal to him that food is ready for him,
> and his light out yonder is to show the spot to which to bring it."
>
> — Mrs. Barrymore confesses to Sir Henry and Watson (ch. 9)
