---
type: Character
title: "James Desmond"
description: "Elderly clergyman of Westmoreland, distant cousin of the Baskervilles; next heir to the estate should Sir Henry die childless."
tags: [clergyman, heir, westmoreland]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: alive
faction: [/factions/baskerville-family.md]
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

James Desmond is an elderly clergyman of Westmoreland, a distant cousin of the
Baskervilles. Since Rodger Baskerville (Sir Charles's younger brother) died
unmarried — as was publicly believed — the entailed estate would descend to the
Desmonds. Mr. Desmond is a man of venerable appearance and saintly life. He
once visited Sir Charles and refused to accept any settlement, though Sir
Charles pressed it upon him. Holmes's inquiries confirm he is of a very amiable
disposition and can be eliminated from suspicion.

# Appearances

* [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 5 (mentioned in will
  discussion), ch. 6 (Holmes confirms his innocence).

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 5 ("a man of venerable appearance
and of saintly life"), ch. 6.
