---
type: Character
title: "Inspector Lestrade"
description: "Scotland Yard detective summoned by Holmes for the final confrontation with the hound."
tags: [police, scotland-yard]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: alive
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Lestrade is a small, wiry bulldog of a man from Scotland Yard. Holmes
telegraphs for him with an unsigned warrant, and he arrives on the 5:40
express. He participates in the ambush at Merripit House, is terrified by the
apparition of the hound, and assists in freeing Mrs. Stapleton from her bonds.
Holmes calls him "the best of the professionals."

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 13–14.
