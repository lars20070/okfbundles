---
type: Character
title: "Sir Henry Baskerville"
description: "Last of the Baskervilles; a Canadian-raised baronet who inherits Baskerville Hall and becomes the target of Stapleton's murder plot."
tags: [baskerville-family, baronet, victim]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: alive
home: /locations/baskerville-hall.md
faction: [/factions/baskerville-family.md]
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Sir Henry Baskerville is a small, alert, dark-eyed man about thirty years of
age, very sturdily built, with thick black eyebrows and a strong, pugnacious
face. He wears a ruddy-tinted tweed suit and has the weather-beaten appearance
of one who has spent most of his time in the open air. Raised in America and
Canada, he speaks with a Western American accent that broadens when he is
angry. He possesses the fiery temper of the Baskerville line.

He is the son of Sir Charles Baskerville's younger brother (the second of three
brothers). His uncle Rodger was the black sheep who died of yellow fever in
Central America in 1876. Sir Henry is the last of the Baskervilles. He inherits
an estate worth close on to a million pounds.

# Role

Sir Henry receives a cut-out warning letter at the Northumberland Hotel: "As
you value your life or your reason keep away from the moor." One of his new
brown boots is stolen, then an old black one, then the brown one is returned.
Holmes deduces the thief needed an article of Sir Henry's clothing to set the
hound on his scent.

On the moor, Sir Henry falls deeply in love with Beryl Stapleton (whom he
believes to be Miss Stapleton). Her "brother" — actually her husband — violently
opposes the match, then apologises and invites Sir Henry to dinner at Merripit
House. Holmes uses this dinner as the trap: Sir Henry walks home alone across
the moor and is attacked by the hound, but Holmes shoots it dead. The shock
leaves Sir Henry with shattered nerves; he embarks on a round-the-world voyage
with Dr. Mortimer to recover.

# Appearances

* [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 4–14.

## From the Source

> Over the green squares of the fields and the low curve of a wood there
> rose in the distance a grey, melancholy hill, with a strange jagged
> summit, dim and vague in the distance, like some fantastic landscape in
> a dream. Baskerville sat for a long time, his eyes fixed upon it, and I
> read upon his eager face how much it meant to him, this first sight of
> that strange spot where the men of his blood had held sway so long and
> left their mark so deep. There he sat, with his tweed suit and his
> American accent, in the corner of a prosaic railway-carriage, and yet as
> I looked at his dark and expressive face I felt more than ever how true
> a descendant he was of that long line of high-blooded, fiery, and
> masterful men.
>
> — Watson describes Sir Henry's first sight of the moor (ch. 6)

> "There is no devil in hell, Mr. Holmes, and there is no man upon earth
> who can prevent me from going to the home of my own people, and you may
> take that to be my final answer."
>
> — Sir Henry, refusing to be scared away from Baskerville Hall (ch. 4)

# Relationships

* [Beryl Stapleton](/characters/beryl-stapleton.md) — deeply in love; the deception devastates him.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 4 (description, "small, alert,
dark-eyed man"), ch. 5 (boot thefts), ch. 14 (hound attack).
