---
type: Character
title: "Dr. James Mortimer"
description: "Country medical practitioner of Grimpen, Dartmoor; friend and medical attendant of Sir Charles Baskerville; brings the case to Holmes."
tags: [doctor, grimpen, trustee]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: alive
home: /locations/grimpen.md
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Dr. James Mortimer, M.R.C.S., is a very tall, thin man with a long nose like a
beak, two keen grey eyes set closely together, and gold-rimmed glasses. He was
a house-surgeon at Charing Cross Hospital from 1882 to 1884, winner of the
Jackson prize for Comparative Pathology, and author of papers including "Some
Freaks of Atavism" and "Do We Progress?" He is Medical Officer for the parishes
of Grimpen, Thorsley, and High Barrow.

Holmes deduces from his walking stick that he is a country practitioner, under
thirty, amiable, unambitious, absent-minded, and the owner of a curly-haired
spaniel. He received the stick as a presentation from friends at Charing Cross
Hospital on the occasion of his marriage. Mortimer is an enthusiast of
craniology and in his first meeting with Holmes expresses interest in Holmes's
dolichocephalic skull.

# Role

Mortimer is a trustee and executor of Sir Charles's will. He brings the
Baskerville manuscript (dated 1742) and the newspaper report of Sir Charles's
death to Holmes. He accompanies Sir Henry to Devonshire and continues his
medical practice there. His spaniel vanishes on the moor and is later found
dead at the hound's lair.

# Appearances

* [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 1–9, 14.

## From the Source

> He was a very tall, thin man, with a long nose like a beak, which jutted
> out between two keen, grey eyes, set closely together and sparkling
> brightly from behind a pair of gold-rimmed glasses. He was clad in a
> professional but rather slovenly fashion, for his frock-coat was dingy
> and his trousers frayed. Though young, his long back was already bowed,
> and he walked with a forward thrust of his head and a general air of
> peering benevolence.
>
> — Watson's first impression of Dr. Mortimer (ch. 1)

> "A dabbler in science, Mr. Holmes, a picker up of shells on the shores
> of the great unknown ocean."
>
> — Dr. Mortimer describes himself (ch. 1)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 1 (stick, skull examination), ch. 2
(manuscript, Sir Charles's death).
