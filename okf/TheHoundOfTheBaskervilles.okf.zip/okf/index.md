---
okf_version: "0.1"
---

# What exists

* [Stories](/stories/) - the works that source all canon.
* [Characters](/characters/) - everyone who appears or is named in the story.
* [Locations](/locations/) - places, from London to the desolate moor.
* [Events](/events/) - what has happened, in world order.
* [Items](/items/) - objects of significance to the case.
* [Factions](/factions/) - families and their allegiances.
* [Rules](/rules/) - invariants the world must never contradict.

# What moves

* [Arcs](/arcs/) - changes tracked from promise to payoff.
* [Threads](/threads/) - questions opened and setups not yet fired.
* [Relationships](/relationships/) - the pairs that carry the tension.
