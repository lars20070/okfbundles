---
type: Thread
title: "The Baskerville Curse"
description: "The spectral hound legend — is the threat supernatural or mortal? Opened by the manuscript and Sir Charles's death, resolved by the revelation of Stapleton's scheme."
tags: [supernatural, legend, mystery]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
thread_kind: question
raised_in: /stories/the-hound-of-the-baskervilles.md
raised_at: /events/hugo-legend.md
involves: [/factions/baskerville-family.md, /characters/stapleton.md]
last_touched: /stories/the-hound-of-the-baskervilles.md
resolved_by: /events/hound-confrontation.md
provenance: human
---

# The question
Does a supernatural hell-hound truly haunt the Baskerville family, or is there
a mortal explanation? Opened by the 1742 manuscript and seemingly confirmed by
Sir Charles's death with hound footprints beside the body and peasant sightings
of a spectral creature on the moor.

# Resolution
The hound is real but mortal — a savage cross-breed daubed with phosphorus by
Stapleton. The legend is exploited, not vindicated. The "supernatural" cry on
the moor is the hound's baying.

# Citations
[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 2 (manuscript), ch. 14 (hound
killed), ch. 15 (retrospection).
