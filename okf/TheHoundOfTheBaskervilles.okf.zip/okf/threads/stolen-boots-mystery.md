---
type: Thread
title: "The Stolen Boots Mystery"
description: "Why would anyone steal one new brown boot, then an old black one, and then return the brown boot? A seemingly purposeless theft that Holmes recognised as the key to the entire case."
tags: [clue, theft, hound, scent]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
thread_kind: setup
raised_in: /stories/the-hound-of-the-baskervilles.md
raised_at: /events/london-incidents.md
involves: [/characters/henry-baskerville.md, /characters/stapleton.md, /characters/sherlock-holmes.md]
last_touched: /events/hounds-lair-explored.md
resolved_by: /events/holmes-retrospection.md
provenance: human
---

# The question

At the Northumberland Hotel, Sir Henry's new brown boot is stolen from outside
his door. The next day, an old black boot is taken — and the brown boot is
mysteriously returned, found under a cabinet. Holmes calls it "a singularly
useless thing to steal." But later he declares: "The more *outré* and grotesque
an incident is the more carefully it deserves to be examined, and the very
point which appears to complicate a case is, when duly considered and
scientifically handled, the one which is most likely to elucidate it."

# Resolution

Stapleton needed an article of Sir Henry's clothing carrying his scent, so the
hound could be set on his trail. The first boot stolen was new — useless,
having never been worn. Stapleton had it returned and stole an old one instead.
The black boot was later found in the Grimpen Mire during the lair exploration,
marked "Meyers, Toronto." This proved conclusively to Holmes that a real hound
was involved: "no other supposition could explain this anxiety to obtain an old
boot and this indifference to a new one."

# From the Source

> \"It seems a singularly useless thing to steal,\" said Sherlock Holmes.
>
> — Holmes's initial reaction (ch. 4)

> \"It is a stake for which a man might well play a desperate game.\"
>
> — Holmes, on learning the estate is worth nearly a million (ch. 5)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 4, 5 (thefts), ch. 14 (boot found
in mire), ch. 15 (Holmes explains the significance).
