---
type: Thread
title: "The Midnight Signal"
description: "Why does Barrymore creep through the corridors at night carrying a candle to the western window — and who answers from the moor?"
tags: [mystery, barrymore, signal, selden]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
thread_kind: question
raised_in: /stories/the-hound-of-the-baskervilles.md
raised_at: /events/hugo-legend.md
involves: [/characters/barrymore.md, /characters/eliza-barrymore.md, /characters/selden.md, /characters/henry-baskerville.md, /characters/john-watson.md]
last_touched: /events/barrymores-secret-revealed.md
resolved_by: /events/barrymores-secret-revealed.md
provenance: human
---

# The question

On successive nights, Watson hears stealthy footsteps in the corridor. He
follows Barrymore to an empty room where the butler crouches at the western
window, candle pressed to the glass, staring intently into the blackness of the
moor. A deep groan, then the candle is extinguished. Who is Barrymore
signalling, and why? And why does his wife weep so bitterly in the night?

Sir Henry and Watson stake out the corridor. On the second night they catch
Barrymore red-handed. Watson takes the candle, holds it to the window — and a
tiny pinpoint of yellow light answers from the moor.

# Resolution

Mrs. Barrymore reveals the truth: her brother is Selden, the escaped Notting
Hill murderer, hiding on the moor. The candle signal checks that he is still
there; the answering light marks the spot to which Barrymore carries bread and
meat. Every second night, for weeks, they have sustained him. "My unhappy
brother is starving on the moor. We cannot let him perish at our very gates."

# From the Source

> Barrymore was crouching at the window with the candle held against the glass.
> His profile was half turned towards me, and his face seemed to be rigid with
> expectation as he stared out into the blackness of the moor.
>
> — Watson's first observation (ch. 8)

> \"He must have been holding it as a signal,\" said I. \"Let us see if there is
> any answer.\" I held it as he had done, and stared out into the darkness of
> the night. Vaguely I could discern the black bank of the trees and the
> lighter expanse of the moor, for the moon was behind the clouds. And then I
> gave a cry of exultation, for a tiny pinpoint of yellow light had suddenly
> transfixed the dark veil, and glowed steadily in the centre of the black
> square framed by the window.
>
> — Watson discovers the answering signal (ch. 9)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 8 (first sightings), ch. 9
(confrontation and confession).
