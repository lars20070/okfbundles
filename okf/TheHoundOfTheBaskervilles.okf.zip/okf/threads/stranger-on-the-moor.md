---
type: Thread
title: "The Stranger on the Moor"
description: "Who is the unknown man hiding in the Neolithic huts, watching Baskerville Hall? Opened by Barrymore's revelation, resolved when Watson discovers Holmes."
tags: [mystery, watcher]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
thread_kind: question
raised_in: /stories/the-hound-of-the-baskervilles.md
raised_at: /events/hugo-legend.md
involves: [/characters/sherlock-holmes.md, /characters/john-watson.md, /characters/barrymore.md]
last_touched: /stories/the-hound-of-the-baskervilles.md
resolved_by: /events/hound-confrontation.md
provenance: human
---

# The question

Watson sees a tall, thin man silhouetted on the Black Tor after the abortive
pursuit of Selden. Barrymore later confirms "there is another man upon the
moor" besides Selden — a gentleman, hiding in the stone huts, supplied by a
boy. Frankland's telescope also spots the boy. Watson investigates and
discovers the hut. Who is this man? Enemy or guardian?

# Resolution

The man is Sherlock Holmes, conducting his own parallel investigation from the
moor. He reveals himself in chapter 11: "It is a lovely evening, my dear
Watson."

## From the Source

> The moon was low upon the right, and the jagged pinnacle of a granite tor
> stood up against the lower curve of its silver disc. There, outlined as
> black as an ebony statue on that shining background, I saw the figure of
> a man upon the tor. He stood with his legs a little separated, his arms
> folded, his head bowed, as if he were brooding over that enormous
> wilderness of peat and granite which lay before him. He might have been
> the very spirit of that terrible place.
>
> — Watson sees the mysterious figure on the tor (ch. 9)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 9 (sighting on the tor), ch. 10
(Barrymore's revelation), ch. 11 (discovery and reveal).
