---
type: Thread
title: "Who Sent the Warning Letter?"
description: "An anonymous message warns Sir Henry to keep away from the moor — cut from a newspaper by someone who meant him good, yet dared not sign their name."
tags: [warning, anonymous, mystery]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
thread_kind: question
raised_in: /stories/the-hound-of-the-baskervilles.md
raised_at: /events/london-incidents.md
involves: [/characters/beryl-stapleton.md, /characters/henry-baskerville.md, /characters/sherlock-holmes.md]
last_touched: /stories/the-hound-of-the-baskervilles.md
resolved_by: /events/holmes-retrospection.md
provenance: human
---

# The question

On his first morning in London, Sir Henry receives a letter at the
Northumberland Hotel: "As you value your life or your reason keep away from the
moor." The words (except "moor") are cut from a *Times* leader with
nail-scissors and pasted with gum. The address is printed in rough characters
to disguise the handwriting. Holmes detects a faint scent of white jessamine —
one of seventy-five perfumes he can distinguish — indicating a woman. Who sent
it, and why the elaborate disguise?

# Resolution

Beryl Stapleton cut and pasted the letter in the Mexborough Private Hotel,
Craven Street, where Stapleton kept her imprisoned. She dared not write openly
because her husband — who had already beaten her for refusing to help lure Sir
Charles — would have killed her. Holmes: "The scent suggested the presence of a
lady, and already my thoughts began to turn towards the Stapletons."

# From the Source

> \"Someone seems to be very deeply interested in your movements.\"
>
> — Holmes, examining the letter (ch. 4)

> \"It seems to show that someone knows more than we do about what goes on upon
> the moor,\" said Dr. Mortimer. \"And also,\" said Holmes, \"that someone is
> not ill-disposed towards you, since they warn you of danger.\"
>
> — Dr. Mortimer and Holmes (ch. 4)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 4 (receipt and analysis), ch. 15
(resolution: white jessamine).
