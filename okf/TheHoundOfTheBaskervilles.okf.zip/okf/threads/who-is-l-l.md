---
type: Thread
title: "Who Is L. L.?"
description: "A burned letter in Sir Charles's study grate reveals only a postscript and the initials 'L. L.' — the woman who summoned him to the gate on the night of his death."
tags: [mystery, letter, laura-lyons, clue]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
thread_kind: question
raised_in: /stories/the-hound-of-the-baskervilles.md
raised_at: /events/barrymores-secret-revealed.md
involves: [/characters/barrymore.md, /characters/laura-lyons.md, /characters/john-watson.md]
last_touched: /events/holmes-interviews-laura-lyons.md
resolved_by: /events/holmes-interviews-laura-lyons.md
provenance: human
---

# The question

Barrymore reveals a crucial clue: while cleaning Sir Charles's study, Mrs.
Barrymore found the ashes of a burned letter in the grate. One slip survived:
"Please, please, as you are a gentleman, burn this letter, and be at the gate
by ten o clock." It was signed with the initials "L. L." The letter came from
Coombe Tracey, addressed in a woman's hand. Sir Charles was at the gate to meet
a woman on the night he died. Who is L. L.?

# Resolution

Dr. Mortimer identifies L. L. as Laura Lyons, Frankland's estranged daughter,
living at Coombe Tracey and running a typewriting business. Watson interviews
her and extracts a partial confession: she wrote the letter asking for
financial help toward a divorce, at Stapleton's dictation. Stapleton — posing
as her suitor — then dissuaded her from keeping the appointment. She never
went. Sir Charles waited alone. Holmes later secures her full cooperation by
revealing Stapleton is married.

# From the Source

> \"I know why he was at the gate at that hour. It was to meet a woman.\" /
> \"To meet a woman! He?\" / \"Yes, sir.\" / \"And the woman's name?\" / \"I
> can't give you the name, sir, but I can give you the initials. Her initials
> were L. L.\"
>
> — Barrymore reveals the clue to Sir Henry and Watson (ch. 10)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 10 (Barrymore's revelation), ch. 11
(Watson's interview), ch. 13 (Holmes's interview).
