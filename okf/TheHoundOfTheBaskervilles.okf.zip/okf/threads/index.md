# Threads

## Resolved

* [The Baskerville Curse](/threads/baskerville-curse.md) - The spectral hound legend — is the threat supernatural or mortal? Opened by the manuscript and Sir Charles's death, resolved by the revelation of Stapleton's scheme.
* [The Stranger on the Moor](/threads/stranger-on-the-moor.md) - Who is the unknown man hiding in the Neolithic huts, watching Baskerville Hall? Opened by Barrymore's revelation, resolved when Watson discovers Holmes.
* [Who Sent the Warning Letter?](/threads/who-sent-the-warning-letter.md) - An anonymous message warns Sir Henry to keep away from the moor — cut from a newspaper by someone who meant him good, yet dared not sign their name.
* [The Stolen Boots Mystery](/threads/stolen-boots-mystery.md) - Why would anyone steal one brown boot, then a black one, and return the brown? A seemingly purposeless theft that Holmes recognised as the key to the entire case.
* [Who Is L. L.?](/threads/who-is-l-l.md) - A burned letter in Sir Charles's study grate reveals only a postscript and the initials "L. L." — the woman who summoned him to the gate on the night of his death.
* [The Midnight Signal](/threads/midnight-signal.md) - Why does Barrymore creep through the corridors at night carrying a candle to the western window — and who answers from the moor?
* [Is She His Sister or His Wife?](/threads/sister-or-wife.md) - Stapleton introduces Beryl as his sister, but Holmes discovers they are husband and wife — a deception central to the entire murder scheme.
* [The Cry on the Moor](/threads/cry-on-the-moor.md) - A long, low moan — indescribably sad, swelling into a deep roar — haunts the moor. The peasants call it the Hound of the Baskervilles.

## Open Questions

* [Open Questions](/threads/open-questions/) - Unresolved plot threads, unwritten futures, and questions the narrative does not answer.
