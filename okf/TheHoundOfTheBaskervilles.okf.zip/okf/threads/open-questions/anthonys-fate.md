---
type: Thread
title: "Anthony's Fate"
description: "The old Spanish-American manservant at Merripit House — Stapleton's confidant and likely accomplice — vanished after the case was resolved. His whereabouts remain unknown."
tags: [open-question, anthony, accomplice, fugitive]
timestamp: 2026-08-17T00:00:00Z
canon: draft
tense: open
thread_kind: question
raised_in: /stories/the-hound-of-the-baskervilles.md
involves: [/characters/anthony.md, /characters/stapleton.md]
last_touched: /events/holmes-retrospection.md
resolved_by: null
provenance: human
---

# The question

Anthony, the wizened, rusty-coated old manservant at Merripit House, had been
with the Stapletons since their Yorkshire school-mastering days. He spoke with
a lisping Spanish-American accent (like Mrs. Stapleton), and Holmes believes he
cared for the hound during Stapleton's absences — crossing the Grimpen Mire by
the marked path. He was certainly aware that Stapleton and Beryl were husband
and wife, not brother and sister.

After the hound was killed and Stapleton perished in the mire, Anthony
disappeared. Holmes: "This man has disappeared and has escaped from the
country."

# Why this remains open

Anthony's role in the crimes is unknown. Was he a knowing accomplice to murder,
or merely a servant obeying a master he feared? Did he reach South America? Did
he take evidence with him? The novel provides no answers.

# From the Source

> There was an old manservant at Merripit House, whose name was Anthony. His
> connection with the Stapletons can be traced for several years, as far back as
> the school-mastering days, so that he must have been aware that his master and
> mistress were really husband and wife. This man has disappeared and has
> escaped from the country.
>
> — Holmes (ch. 15)

> It is suggestive that Anthony is not a common name in England, while Antonio
> is so in all Spanish or Spanish-American countries. The man, like Mrs.
> Stapleton herself, spoke good English, but with a curious lisping accent.
>
> — Holmes (ch. 15)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 7 (first appearance), ch. 14 (admits
Holmes to Merripit House), ch. 15 (Holmes on his disappearance).
