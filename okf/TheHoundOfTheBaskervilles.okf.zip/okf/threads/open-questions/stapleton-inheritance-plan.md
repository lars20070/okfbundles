---
type: Thread
title: "How Would Stapleton Have Claimed the Estate?"
description: "Holmes identifies three possible strategies Stapleton might have used to claim the Baskerville inheritance without revealing his identity as a murderer — none of which were ever tested."
tags: [open-question, inheritance, stapleton, speculation]
timestamp: 2026-08-17T00:00:00Z
canon: draft
tense: open
thread_kind: question
raised_in: /stories/the-hound-of-the-baskervilles.md
involves: [/characters/stapleton.md, /factions/baskerville-family.md]
last_touched: /events/holmes-retrospection.md
resolved_by: null
provenance: human
---

# The question

Had Stapleton succeeded in killing Sir Henry, how would he — a man living under
an assumed name, with a criminal past, a false identity, and a wife passed off
as his sister — have claimed the Baskerville estate without incriminating
himself? Watson puts the question directly to Holmes.

# Holmes's three hypotheses

Holmes acknowledges this as "a formidable difficulty" and "a hard question to
answer," noting the future lies outside his field of inquiry. But from Mrs.
Stapleton's reports of her husband's discussions, three possibilities existed:

1. **Claim from South America.** Stapleton could establish his identity before
   British authorities in South America (where he was born) and obtain the
   fortune without ever setting foot in England.
2. **Elaborate disguise.** He could adopt a deep disguise during the short time
   he needed to be in London to press the claim.
3. **An accomplice as front.** He could furnish an accomplice with the proofs
   and papers, putting that person in as heir, and retaining a claim upon a
   proportion of the income.

Holmes concludes: "We cannot doubt from what we know of him that he would have
found some way out of the difficulty."

# Why this remains open

Stapleton died in the Grimpen Mire, so none of these strategies was ever
attempted. The question is speculative, preserved here because it is the one
loose end Holmes himself acknowledged he could not answer with certainty.

# From the Source

> \"It is a formidable difficulty, and I fear that you ask too much when you
> expect me to solve it. The past and the present are within the field of my
> inquiry, but what a man may do in the future is a hard question to answer.\"
>
> — Holmes, on Stapleton's plans for claiming the estate (ch. 15)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 15 (final pages of Holmes's
retrospection).
