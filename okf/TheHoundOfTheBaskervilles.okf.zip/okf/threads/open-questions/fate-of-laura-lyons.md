---
type: Thread
title: "The Fate of Laura Lyons"
description: "After turning on Stapleton and providing Holmes with crucial testimony, Laura Lyons vanishes from the narrative — her future left unwritten."
tags: [open-question, laura-lyons, aftermath]
timestamp: 2026-08-17T00:00:00Z
canon: draft
tense: open
thread_kind: question
raised_in: /stories/the-hound-of-the-baskervilles.md
involves: [/characters/laura-lyons.md, /characters/frankland.md, /characters/stapleton.md]
last_touched: /events/holmes-interviews-laura-lyons.md
resolved_by: null
provenance: human
---

# The question

Laura Lyons was Stapleton's unwitting tool — a woman whose desperate desire for
a divorce made her vulnerable to a predator who promised marriage. After Holmes
exposed Stapleton's deception, she gave him full cooperation, providing the
testimony that completed the case against her former lover.

But what became of her afterward? Did she and her estranged father, Frankland,
ever reconcile? Did she obtain her divorce from the artist Lyons? Was she
called as a witness at any inquest or proceeding? Did she remain at Coombe
Tracey, or did the scandal drive her elsewhere?

The novel provides no answer. Her last appearance is in Holmes's interview at
her typewriting office in Coombe Tracey (ch. 13), where Holmes tells her she
has had "a fortunate escape" and that she has been "walking for some months
very near to the edge of a precipice."

# From the Source

> \"I think that on the whole you have had a fortunate escape,\" said Sherlock
> Holmes. \"You have had him in your power and he knew it, and yet you are
> alive.\"
>
> — Holmes's parting words to Laura Lyons (ch. 13)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 10, 11, 13.
