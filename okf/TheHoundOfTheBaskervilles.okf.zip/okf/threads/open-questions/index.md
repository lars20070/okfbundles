# Open Questions

These are plot threads raised by the source that remain unresolved — questions
the novel does not answer, speculation Holmes himself could not settle, and
futures the narrative leaves unwritten.

* [How Would Stapleton Have Claimed the Estate?](/threads/open-questions/stapleton-inheritance-plan.md) - Holmes identifies three possible strategies, none ever tested.
* [Stapleton's Other Crimes](/threads/open-questions/stapletons-other-crimes.md) - Four unsolved west-country burglaries and a fatal shooting may be his work.
* [Anthony's Fate](/threads/open-questions/anthonys-fate.md) - The old manservant vanished after the case; his role and whereabouts are unknown.
* [The Fate of Laura Lyons](/threads/open-questions/fate-of-laura-lyons.md) - After turning on Stapleton, she disappears from the narrative.
* [Did Beryl Stapleton Love Sir Henry?](/threads/open-questions/did-beryl-love-henry.md) - Her warnings suggest genuine feeling, but the text leaves it ambiguous.
