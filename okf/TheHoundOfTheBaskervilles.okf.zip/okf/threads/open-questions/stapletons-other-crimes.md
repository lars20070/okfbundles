---
type: Thread
title: "Stapleton's Other Crimes"
description: "Holmes suspects the Baskerville murders were not Stapleton's first crimes — four unsolved burglaries in the west country, including a fatal shooting, may be his work."
tags: [open-question, crime, stapleton, burglary]
timestamp: 2026-08-17T00:00:00Z
canon: draft
tense: open
thread_kind: question
raised_in: /stories/the-hound-of-the-baskervilles.md
involves: [/characters/stapleton.md]
last_touched: /events/holmes-retrospection.md
resolved_by: null
provenance: human
---

# The question

Holmes suggests that Stapleton's criminal career was not limited to the
Baskerville affair. During the three years before the events of the novel,
there had been four considerable burglaries in the west country — none of which
resulted in an arrest. The last, at Folkestone Court in May, was "remarkable
for the cold-blooded pistolling of the page, who surprised the masked and
solitary burglar."

Holmes's assessment: "I cannot doubt that Stapleton recruited his waning
resources in this fashion, and that for years he has been a desperate and
dangerous man."

# Why this remains open

Stapleton died in the mire before he could be questioned. The four burglaries
and the murder of the page at Folkestone Court remain officially unsolved.
Whether Holmes ever communicated his suspicions to the authorities is not
recorded.

# From the Source

> From his knowledge of our rooms and of my appearance, as well as from his
> general conduct, I am inclined to think that Stapleton's career of crime has
> been by no means limited to this single Baskerville affair. It is suggestive
> that during the last three years there have been four considerable burglaries
> in the west country, for none of which was any criminal ever arrested.
>
> — Holmes (ch. 15)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 15.
