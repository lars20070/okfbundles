---
type: Thread
title: "Did Beryl Stapleton Love Sir Henry?"
description: "Her warnings and her first question after rescue ('Is he safe?') suggest genuine feeling — but was it love, guilt, or the desperate decency of a woman trapped in her husband's scheme?"
tags: [open-question, beryl-stapleton, romance, ambiguity]
timestamp: 2026-08-17T00:00:00Z
canon: draft
tense: open
thread_kind: question
raised_in: /stories/the-hound-of-the-baskervilles.md
involves: [/characters/beryl-stapleton.md, /characters/henry-baskerville.md]
last_touched: /events/mrs-stapleton-rescued.md
resolved_by: null
provenance: human
---

# The question

Beryl risked her husband's violence — which she knew well — to warn Sir Henry
away from the moor. She cut out the warning letter in London. She intercepted
Watson on the moor path. She begged Sir Henry to leave. When she was rescued
from her bonds, her first word was not of her own safety but: "Is he safe? Sir
Henry? Is he safe?"

And yet she was also, by her own admission, still in love with her husband
until the very end: "I could endure it all, ill-usage, solitude, a life of
deception, everything, as long as I could still cling to the hope that I had
his love."

Holmes's assessment: "There can be no doubt that Stapleton exercised an
influence over her which may have been love or may have been fear, or very
possibly both, since they are by no means incompatible emotions."

Sir Henry's own feelings were clear: "His love for the lady was deep and
sincere, and to him the saddest part of all this black business was that he
should have been deceived by her." But was the deception only about her marital
status, or about her feelings as well?

# Why this remains open

The novel leaves Beryl's true feelings ambiguous. She is a woman under coercive
control, and it is impossible to disentangle what was genuine affection for Sir
Henry from what was simply the desperate humanity of someone trying to prevent
a murder. The text provides evidence for both readings and settles neither.

# From the Source

> \"Is he safe?\" she asked. \"Has he escaped?\" / \"He cannot escape us,
> madam.\" / \"No, no, I did not mean my husband. Sir Henry? Is he safe?\"
>
> — Beryl's first words upon being freed (ch. 14)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 7, 9, 14, 15.
