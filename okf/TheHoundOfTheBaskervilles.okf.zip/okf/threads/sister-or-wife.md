---
type: Thread
title: "Is She His Sister or His Wife?"
description: "Stapleton introduces Beryl as his sister, but Holmes discovers they are husband and wife — a deception central to the entire murder scheme."
tags: [deception, marriage, stapleton, identity]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
thread_kind: question
raised_in: /stories/the-hound-of-the-baskervilles.md
raised_at: /events/stapleton-interrupts-courtship.md
involves: [/characters/stapleton.md, /characters/beryl-stapleton.md, /characters/henry-baskerville.md, /characters/sherlock-holmes.md]
last_touched: /events/holmes-discovered-on-moor.md
resolved_by: /events/holmes-discovered-on-moor.md
provenance: human
---

# The question

Stapleton presents himself as a bachelor naturalist living with his sister at
Merripit House. But his behaviour is strange: when Sir Henry pays attention to
Beryl, Stapleton flies into a violent rage, and Watson catches Beryl
continually glancing at her "brother" as if seeking approval. Why would a
brother so fiercely oppose an eligible baronet's courtship of his sister? And
why did Beryl warn Sir Henry to leave, yet refuse to explain?

# Resolution

Holmes reveals to Watson at the Neolithic hut: "The lady who has passed here as
Miss Stapleton is in reality his wife." He traced the couple through scholastic
agencies to St. Oliver's private school in Yorkshire, where they taught as Mr.
and Mrs. Vandeleur. A photograph taken in York four years ago confirms it.
Beryl was forced into the deception — Stapleton "foresaw that she would be very
much more useful to him in the character of a free woman." As his sister, she
could attract Sir Henry without arousing suspicion; as his wife, she could be
controlled through fear and violence.

# From the Source

> \"The lady who has passed here as Miss Stapleton is in reality his wife.\" /
> \"Good heavens, Holmes! Are you sure of what you say? How could he have
> permitted Sir Henry to fall in love with her?\" / \"Sir Henry's falling in
> love could do no harm to anyone except Sir Henry.\"
>
> — Holmes reveals the truth to Watson at the hut (ch. 12)

> \"Because he foresaw that she would be very much more useful to him in the
> character of a free woman.\"
>
> — Holmes (ch. 12)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 7 (introduction as sister), ch. 9
(Stapleton's rage), ch. 12 (Holmes's revelation), ch. 15 (full explanation).
