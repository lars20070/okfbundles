---
type: Thread
title: "The Cry on the Moor"
description: "A long, low moan — indescribably sad, swelling into a deep roar — haunts the moor. The peasants call it the Hound of the Baskervilles. Is it supernatural, or is there a mortal explanation?"
tags: [supernatural, hound, sound, mystery]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
thread_kind: question
raised_in: /stories/the-hound-of-the-baskervilles.md
raised_at: /events/hugo-legend.md
involves: [/characters/john-watson.md, /characters/henry-baskerville.md, /characters/stapleton.md, /characters/sherlock-holmes.md]
last_touched: /events/hound-confrontation.md
resolved_by: /events/hounds-lair-explored.md
provenance: human
---

# The question

Twice Watson hears it: a long, low moan sweeping over the moor, swelling into a
deep roar, then sinking back into a melancholy murmur. Stapleton claims it is a
bittern — "a very rare bird — practically extinct — in England now" — or the
mud settling in the bog. But the peasants swear it is the Hound of the
Baskervilles calling for its prey. Sir Henry, hearing it during the pursuit of
Selden, is shaken to his core: "A hound it was... My God, can there be some
truth in all these stories?"

# Resolution

The cry is the baying of Stapleton's hound from its lair in the Grimpen Mire.
Holmes, exploring the abandoned mine: "He could hide his hound, but he could
not hush its voice, and hence came those cries which even in daylight were not
pleasant to hear." The hound was a real animal — a savage bloodhound-mastiff
cross — and its voice, carrying for miles across the empty moor, fed the
superstition that kept the locals indoors after dark.

# From the Source

> A long, low moan, indescribably sad, swept over the moor. It filled the whole
> air, and yet it was impossible to say whence it came. From a dull murmur it
> swelled into a deep roar, and then sank back into a melancholy, throbbing
> murmur once again. Stapleton looked at me with a curious expression in his
> face. \"Queer place, the moor!\" said he.
>
> — Watson first hears the cry (ch. 7)

> \"A hound it was,\" he said at last, \"but it seemed to come from miles away,
> over yonder, I think.\" / \"It was hard to say whence it came.\" / \"It rose
> and fell with the wind. Isn't that the direction of the great Grimpen Mire?\"
>
> — Sir Henry and Watson, during the Selden pursuit (ch. 9)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 7 (first hearing), ch. 9 (second
hearing), ch. 14 (lair discovery and explanation).
