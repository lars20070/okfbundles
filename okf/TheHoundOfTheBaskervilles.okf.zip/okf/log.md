# Update Log

## 2026-08-17
* **Creation**: Added 6 resolved thread pages: [Who Sent the Warning Letter?](/threads/who-sent-the-warning-letter.md), [The Stolen Boots Mystery](/threads/stolen-boots-mystery.md), [Who Is L. L.?](/threads/who-is-l-l.md), [The Midnight Signal](/threads/midnight-signal.md), [Is She His Sister or His Wife?](/threads/sister-or-wife.md), [The Cry on the Moor](/threads/cry-on-the-moor.md).
* **Creation**: Added [Open Questions](/threads/open-questions/) subfolder with 5 unresolved-thread pages: [How Would Stapleton Have Claimed the Estate?](/threads/open-questions/stapleton-inheritance-plan.md), [Stapleton's Other Crimes](/threads/open-questions/stapletons-other-crimes.md), [Anthony's Fate](/threads/open-questions/anthonys-fate.md), [The Fate of Laura Lyons](/threads/open-questions/fate-of-laura-lyons.md), [Did Beryl Stapleton Love Sir Henry?](/threads/open-questions/did-beryl-love-henry.md). Each open-question page carries `canon: draft`, `tense: open`, and `resolved_by: null`.

## 2026-08-17
* **Creation**: Added 7 new relationship pages: [Sir Henry ⇄ Beryl](/relationships/henry--beryl.md), [Stapleton ⇄ Laura Lyons](/relationships/stapleton--laura-lyons.md), [Stapleton ⇄ Sir Charles](/relationships/stapleton--charles.md), [Holmes ⇄ Stapleton](/relationships/holmes--stapleton.md), [Watson ⇄ Sir Henry](/relationships/watson--henry.md), [Barrymore ⇄ Eliza](/relationships/barrymore--eliza.md), [Sir Charles ⇄ Dr. Mortimer](/relationships/charles--mortimer.md). Each page includes verbatim source quotations, a dated state log tracking how the relationship changes across the story, and an analysis of why it generates dramatic tension.

## 2026-08-17
* **Creation**: Added 8 new event pages covering the full narrative arc: [Stapleton Interrupts the Courtship](/events/stapleton-interrupts-courtship.md), [The Barrymores' Secret Revealed](/events/barrymores-secret-revealed.md), [Watson Interviews Laura Lyons](/events/watson-interviews-laura-lyons.md), [Holmes Discovered on the Moor](/events/holmes-discovered-on-moor.md), [Stapleton Identified from the Portrait](/events/stapleton-portrait-identified.md), [Holmes Interviews Laura Lyons](/events/holmes-interviews-laura-lyons.md), [Mrs. Stapleton Rescued](/events/mrs-stapleton-rescued.md), [The Hound's Lair Explored](/events/hounds-lair-explored.md), [Holmes's Retrospection](/events/holmes-retrospection.md). Each page includes verbatim source quotations.

## 2026-08-17
* **Update**: Added verbatim quotations from the source to 22 pages, enriching character descriptions, locations, events, items, rules, and threads with vivid passages and dramatic moments from the novel. All quotations are blockquoted and cited by chapter.

## 2026-08-17
* **Creation**: Added missing character pages: [Cartwright](/characters/cartwright.md), [Perkins](/characters/perkins.md), [Anthony](/characters/anthony.md), [Rodger Baskerville](/characters/rodger-baskerville.md), [James Desmond](/characters/james-desmond.md).
* **Creation**: Added missing location pages: [Princetown](/locations/princetown.md), [Northumberland Hotel](/locations/northumberland-hotel.md), [The Neolithic Huts](/locations/neolithic-huts.md), [The Tors of Dartmoor](/locations/dartmoor-tors.md), [The Hound's Lair](/locations/hounds-lair.md).
* **Creation**: Added [Rules](/rules/) category with [The Baskerville Legend as Murder Method](/rules/baskerville-legend-exploited.md).
* **Creation**: Added event [The London Incidents](/events/london-incidents.md).
* **Creation**: Added thread [The Stranger on the Moor](/threads/stranger-on-the-moor.md).
* **Creation**: Added relationship [Stapleton ⇄ Beryl](/relationships/stapleton--beryl.md).
* **Update**: Enhanced [The Yew Alley](/locations/yew-alley.md) with exact measurements and crime-scene details.
* **Update**: Enhanced [Sir Charles Baskerville](/characters/charles-baskerville.md) with political candidacy, detailed will figures, and inheritance chain.
* **Update**: Enhanced [Stapleton](/characters/stapleton.md) with school name (St. Oliver's), tutor Fraser, and biography details.
* **Update**: Enhanced [The Legend of Hugo Baskerville](/events/hugo-legend.md) with verbatim manuscript quotations.
* **Update**: Enhanced [Dartmoor](/locations/dartmoor-moor.md) with Long Down barrow detail.

## 2026-08-17
* **Initialization**: Created the OKF wiki bundle for [The Hound of the Baskervilles](/stories/the-hound-of-the-baskervilles.md).
* **Creation**: Added [Stories](/stories/) category with the source novel concept.
* **Creation**: Added [Characters](/characters/) category with 14 character pages: [Sherlock Holmes](/characters/sherlock-holmes.md), [Dr. John Watson](/characters/john-watson.md), [Sir Henry Baskerville](/characters/henry-baskerville.md), [Dr. James Mortimer](/characters/james-mortimer.md), [Stapleton](/characters/stapleton.md), [Beryl Stapleton](/characters/beryl-stapleton.md), [Sir Charles Baskerville](/characters/charles-baskerville.md), [Hugo Baskerville](/characters/hugo-baskerville.md), [Barrymore](/characters/barrymore.md), [Eliza Barrymore](/characters/eliza-barrymore.md), [Selden](/characters/selden.md), [Laura Lyons](/characters/laura-lyons.md), [Mr. Frankland](/characters/frankland.md), [Inspector Lestrade](/characters/lestrade.md).
* **Creation**: Added [Locations](/locations/) category with 9 location pages: [221B Baker Street](/locations/baker-street.md), [Baskerville Hall](/locations/baskerville-hall.md), [The Yew Alley](/locations/yew-alley.md), [Dartmoor](/locations/dartmoor-moor.md), [Grimpen Mire](/locations/grimpen-mire.md), [Merripit House](/locations/merripit-house.md), [Lafter Hall](/locations/lafter-hall.md), [Grimpen](/locations/grimpen.md), [Coombe Tracey](/locations/coombe-tracey.md).
* **Creation**: Added [Events](/events/) category with 4 event pages: [The Legend of Hugo Baskerville](/events/hugo-legend.md), [The Death of Sir Charles Baskerville](/events/death-of-charles-baskerville.md), [The Death of Selden](/events/death-of-selden.md), [The Hound Confrontation](/events/hound-confrontation.md).
* **Creation**: Added [Items](/items/) category with 5 item pages: [Dr. Mortimer's Walking Stick](/items/walking-stick.md), [The Baskerville Manuscript (1742)](/items/baskerville-manuscript.md), [The Warning Letter](/items/warning-letter.md), [The Stolen Boots](/items/stolen-boots.md), [The Hound](/items/the-hound.md).
* **Creation**: Added [Factions](/factions/) category with [The Baskerville Family](/factions/baskerville-family.md).
* **Creation**: Added [Arcs](/arcs/) category with [Stapleton's Scheme](/arcs/stapleton-scheme.md).
* **Creation**: Added [Threads](/threads/) category with [The Baskerville Curse](/threads/baskerville-curse.md).
* **Creation**: Added [Relationships](/relationships/) category with [Sherlock Holmes ⇄ Dr. John Watson](/relationships/holmes--watson.md).
* **Creation**: Added the bundle root [index](/index.md) and [update log](/log.md).
