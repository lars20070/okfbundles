---
type: Relationship
title: "Sir Charles Baskerville ⇄ Dr. James Mortimer"
description: "Physician, friend, and trustee — Dr. Mortimer was Sir Charles's medical attendant and confidant, entrusted with the family manuscript and the responsibility of protecting the heir."
tags: [friendship, physician, trust]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
between: [/characters/charles-baskerville.md, /characters/james-mortimer.md]
charge: physician-friend
provenance: human
---

# State log
* **After death** — Mortimer withholds the giant hound footprints from the
  coroner's inquest, fearing he will be seen as endorsing superstition. He
  brings the manuscript and the newspaper report to Sherlock Holmes. As trustee
  and executor, he meets Sir Henry at Waterloo Station.
* **The evening of the death** — Perkins the groom rides to summon Mortimer.
  He reaches Baskerville Hall within an hour. He examines the body: \"Sir
  Charles lay on his face, his arms out, his fingers dug into the ground, and
  his features convulsed with some strong emotion to such an extent that I
  could hardly have sworn to his identity.\"
* **The friendship** — Sir Charles's illness brings them together; \"a
  community of interests in science\" keeps them so. They spend evenings
  discussing comparative anatomy. Sir Charles entrusts Mortimer with the 1742
  manuscript. Mortimer, observing Sir Charles's deteriorating nerves, advises
  him to go to London.

# From the Source

> \"I may say that I was his personal friend as well as his medical attendant.\"
>
> — Dr. Mortimer (ch. 2)

> \"Within the last few months it became increasingly plain to me that Sir
> Charles's nervous system was strained to the breaking point. He had taken
> this legend which I have read you exceedingly to heart.\"
>
> — Dr. Mortimer (ch. 2)

> \"It was at my advice that Sir Charles was about to go to London. His heart
> was, I knew, affected, and the constant anxiety in which he lived, however
> chimerical the cause of it might be, was evidently having a serious effect
> upon his health.\"
>
> — Dr. Mortimer (ch. 2)

# Why it generates tension
Mortimer is the bridge between the Baskerville tragedy and Holmes. His loyalty
to Sir Charles compels him to seek help, even at the risk of professional
embarrassment. He is caught between his scientific training (which rejects the
supernatural) and the evidence of his own eyes (the footprint of a gigantic
hound).

# Citations
[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 2.
