---
type: Relationship
title: "Sir Henry Baskerville ⇄ Beryl Stapleton"
description: "A doomed romance — Sir Henry falls deeply in love with the woman he believes is Miss Stapleton, while she, bound to a murderous husband, tries to warn him away."
tags: [romance, tragedy, deception]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
between: [/characters/henry-baskerville.md, /characters/beryl-stapleton.md]
charge: doomed-romance
provenance: human
---

# State log
* **Aftermath** — Sir Henry learns the truth: Beryl is Stapleton's wife, not his
  sister. The shock, combined with the hound attack, leaves him delirious with
  fever. He embarks on a round-the-world voyage with Dr. Mortimer to recover
  "not only from his shattered nerves but also from his wounded feelings. His
  love for the lady was deep and sincere, and to him the saddest part of all
  this black business was that he should have been deceived by her."
* **The proposal on the moor** — Sir Henry offers marriage. Beryl refuses,
  insisting Dartmoor is a place of danger and she will never be happy until he
  leaves. Before she can answer the proposal, Stapleton bursts upon them in a
  rage.
* **First meeting at Merripit House** — Sir Henry is instantly attracted;
  Watson observes the feeling is mutual. From that day, "hardly a day has
  passed that we have not seen something of the brother and sister."

# From the Source

> From the first moment that he saw her he appeared to be strongly attracted by
> her, and I am much mistaken if the feeling was not mutual. He referred to her
> again and again on our walk home, and since then hardly a day has passed that
> we have not seen something of the brother and sister.
>
> — Watson, in his first report to Holmes (ch. 8)

> \"There's a light in a woman's eyes that speaks louder than words.\"
>
> — Sir Henry, after the interrupted proposal (ch. 9)

> \"Is he safe?\" she asked. \"Has he escaped?\" / \"No, no, I did not mean my
> husband. Sir Henry? Is he safe?\"
>
> — Beryl's first words after being freed from her bonds (ch. 14)

# Why it generates tension
Sir Henry's love is genuine; Beryl's feelings may be too — she risks her life
to warn him — but she cannot act on them because she is a prisoner in her own
marriage. Every scene between them is shadowed by a truth the reader and
characters only gradually come to see.

# Citations
[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 7, 8, 9, 14, 15.
