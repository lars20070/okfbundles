---
type: Relationship
title: "Dr. Watson ⇄ Sir Henry Baskerville"
description: "Watson is dispatched as Sir Henry's guardian on Dartmoor — a protective ward that becomes a genuine friendship, tested by secrets and danger."
tags: [guardianship, friendship, trust]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
between: [/characters/john-watson.md, /characters/henry-baskerville.md]
charge: guardian-ward
provenance: human
---

# State log
* **The crisis** — Watson leaves Sir Henry to interview Laura Lyons at Coombe
  Tracey. During his absence, the hound kills Selden. Holmes rebukes him: \"You,
  Watson, see what comes of abandoning your charge!\" Watson is consumed with
  guilt until they discover the body is not Sir Henry.
* **The guardian's dilemma** — Sir Henry insists on walking alone on the moor
  to meet Beryl. Watson follows and watches from a distance, torn between his
  duty to protect and the impropriety of spying on a friend.
* **The commission** — Holmes assigns Watson as Sir Henry's protector and
  secret reporter. \"If my friend would undertake it there is no man who is
  better worth having at your side when you are in a tight place.\" Sir Henry
  seizes Watson's hand: \"If you will come down to Baskerville Hall and see me
  through I'll never forget it.\"

# From the Source

> \"Well, you know what my instructions are. I am sorry to intrude, but you
> heard how earnestly Holmes insisted that I should not leave you, and
> especially that you should not go alone upon the moor.\"
>
> — Watson, trying to keep Sir Henry from going alone (ch. 9)

> I was at a loss what to say or what to do, and before I had made up my mind
> he picked up his cane and was gone. But when I came to think the matter over
> my conscience reproached me bitterly for having on any pretext allowed him to
> go out of my sight.
>
> — Watson, after Sir Henry leaves (ch. 9)

> \"My dear fellow,\" said he, \"Holmes, with all his wisdom, did not foresee
> some things which have happened since I have been on the moor. You understand
> me? I am sure that you are the last man in the world who would wish to be a
> spoil-sport. I must go out alone.\"
>
> — Sir Henry, asserting his independence (ch. 9)

# Why it generates tension
Watson's duty to Holmes (constant surveillance and reporting) conflicts with his
duty to Sir Henry (trust and friendship). Sir Henry, a proud man unused to
being watched, chafes at the restriction — especially when it interferes with
his courtship of Beryl.

# Citations
[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 5, 6, 9, 12.
