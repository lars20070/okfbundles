# Relationships

* [Sherlock Holmes ⇄ Dr. John Watson](/relationships/holmes--watson.md) - Detective and chronicler; Holmes values Watson's reports and companionship but conceals his plans and his presence on the moor until the critical moment.
* [Stapleton ⇄ Beryl Stapleton](/relationships/stapleton--beryl.md) - Husband and wife passing as brother and sister; a coercive control relationship built on fear, deception, and brutal ill-treatment.
* [Sir Henry Baskerville ⇄ Beryl Stapleton](/relationships/henry--beryl.md) - A doomed romance — Sir Henry falls deeply in love with the woman he believes is Miss Stapleton, while she, bound to a murderous husband, tries to warn him away.
* [Stapleton ⇄ Laura Lyons](/relationships/stapleton--laura-lyons.md) - A predator and his unwitting tool — Stapleton posed as an unmarried suitor offering marriage, while using Laura Lyons to lure Sir Charles to his death.
* [Stapleton ⇄ Sir Charles Baskerville](/relationships/stapleton--charles.md) - A friendship feigned to enable murder — Stapleton cultivated Sir Charles as a neighbour and confidant, learning his superstitions and weak heart in order to kill him.
* [Sherlock Holmes ⇄ Stapleton](/relationships/holmes--stapleton.md) - The detective and the villain — a duel of wits fought across London and Dartmoor, each man recognising the other as a foeman worthy of his steel.
* [Dr. Watson ⇄ Sir Henry Baskerville](/relationships/watson--henry.md) - Watson is dispatched as Sir Henry's guardian on Dartmoor — a protective ward that becomes a genuine friendship, tested by secrets and danger.
* [Barrymore ⇄ Eliza Barrymore](/relationships/barrymore--eliza.md) - A devoted servant couple whose loyalty to each other — and to Eliza's fugitive brother — places them under suspicion and tests their bond to the Baskerville family.
* [Sir Charles Baskerville ⇄ Dr. James Mortimer](/relationships/charles--mortimer.md) - Physician, friend, and trustee — Dr. Mortimer was Sir Charles's medical attendant and confidant, entrusted with the family manuscript and the responsibility of protecting the heir.
