---
type: Relationship
title: "Sherlock Holmes ⇄ Dr. John Watson"
description: "Detective and chronicler; Holmes values Watson's reports and companionship but conceals his plans and his presence on the moor until the critical moment."
tags: [core-dyad, partnership]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
between: [/characters/sherlock-holmes.md, /characters/john-watson.md]
charge: trusted-partners
provenance: human
---

# State log
* **Holmes reveals himself** — after Watson finds his hut, Holmes praises
  Watson's reports and explains his deception. Watson's anger fades; partnership
  restored.
* **Watson dispatched to Dartmoor** — Holmes sends Watson as Sir Henry's
  guardian and agent while concealing his own parallel investigation.
* **Baker Street consultation** — Holmes and Watson examine Dr. Mortimer's
  stick together; Holmes uses Watson's deductions to sharpen his own.

# Why it generates tension
Holmes withholds information, keeping Watson in the dark about his presence on
the moor. Watson feels used and untrusted; Holmes's genuine praise of Watson's
work resolves the friction.

# Citations
[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 1, 5, 11.
