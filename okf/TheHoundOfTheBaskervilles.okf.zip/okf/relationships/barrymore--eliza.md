---
type: Relationship
title: "Barrymore ⇄ Eliza Barrymore"
description: "A devoted servant couple whose loyalty to each other — and to Eliza's fugitive brother — places them under suspicion and tests their bond to the Baskerville family."
tags: [marriage, loyalty, servants, secret]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
between: [/characters/barrymore.md, /characters/eliza-barrymore.md]
charge: devoted-couple
provenance: human
---

# State log
* **The confession** — Cornered, Barrymore refuses to speak. It is Eliza who
  appears, \"paler and more horror-struck than her husband,\" and confesses:
  \"It is my doing, Sir Henry — all mine. He has done nothing except for my
  sake and because I asked him.\" Sir Henry forgives them.
* **The midnight signal** — Every second night, Barrymore holds a candle to the
  western window. A tiny answering light glimmers from Cleft Tor. Barrymore
  then carries bread and meat across the moor.
* **The sobbing in the night** — Watson hears a woman weeping in Baskerville
  Hall. Mrs. Barrymore's eyes are red and swollen. Her husband lies to protect
  her.

# From the Source

> \"Oh, John, John, have I brought you to this? It is my doing, Sir Henry — all
> mine. He has done nothing except for my sake and because I asked him.\"
>
> — Eliza Barrymore, confessing (ch. 9)

> \"It is my business, and not yours. I will not tell.\" / \"Then you leave my
> employment right away.\" / \"Very good, sir. If I must I must.\"
>
> — Barrymore refusing to betray his wife, and Sir Henry's ultimatum (ch. 9)

> I have always felt that there was something singular and questionable in this
> man's character, but the adventure of last night brings all my suspicions to
> a head.
>
> — Watson, before the truth is known (ch. 8)

# Why it generates tension
The Barrymores face an impossible choice: loyalty to their employer and the
Baskerville family they have served for four generations, or loyalty to Eliza's
fugitive brother — \"the little curly-headed boy\" she nursed as a child. Their
deception makes them suspects in a murder investigation, yet their motive is
the most human one in the story.

# Citations
[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 6, 7, 8, 9.
