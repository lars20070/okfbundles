---
type: Relationship
title: "Stapleton ⇄ Beryl Stapleton"
description: "Husband and wife passing as brother and sister; a coercive control relationship built on fear, deception, and brutal ill-treatment."
tags: [toxic-dyad, deception]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
between: [/characters/stapleton.md, /characters/beryl-stapleton.md]
charge: captor-captive
provenance: human
---

# State log
* **Final crisis** — Beryl learns of the hound and confronts her husband; he
  reveals Laura Lyons as a rival in his love, then binds and gags her in the
  museum. She is found with a weal of a whiplash across her neck.
* **On the moor** — Stapleton forces Beryl to pose as his sister; she refuses
  to act as direct accomplice to Sir Charles's murder and is beaten. She
  secretly warns Sir Henry.
* **Yorkshire** — The couple run St. Oliver's private school under the name
  Vandeleur; after the epidemic and Fraser's death, they change their name and
  flee to Devonshire.
* **Costa Rica** — Rodger Baskerville Jr. marries Beryl Garcia; they
  embezzle public money and flee to England.

# Why it generates tension
Stapleton exercises absolute control — he keeps Beryl imprisoned in a London
hotel, beats her when she resists, and binds her when she threatens to expose
his scheme. Yet she remains under his influence through a mixture of love and
fear. Her ultimate betrayal is what seals his fate.

# Citations
[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 7, 14, 15.
