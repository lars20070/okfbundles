---
type: Relationship
title: "Sherlock Holmes ⇄ Stapleton"
description: "The detective and the villain — a duel of wits fought across London and Dartmoor, each man recognising the other as a foeman worthy of his steel."
tags: [adversaries, duel-of-wits, cat-and-mouse]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
between: [/characters/sherlock-holmes.md, /characters/stapleton.md]
charge: adversaries
provenance: human
---

# State log
* **The end** — Stapleton flees into the Grimpen Mire and drowns. His body is
  never recovered. Holmes: \"never yet have we helped to hunt down a more
  dangerous man than he who is lying yonder.\"
* **Checkmate in Devonshire** — Holmes reveals himself to Watson, but
  Stapleton spots him on the moor that same night at Selden's death scene.
  Holmes lies about returning to London, then sets the final trap using Sir
  Henry as bait.
* **Checkmate in London** — Stapleton shadows Sir Henry by cab, then sends the
  cabman back with the taunting message that his fare was \"Mr. Sherlock
  Holmes.\" Holmes laughs: \"A touch, Watson — an undeniable touch! I feel a
  foil as quick and supple as my own.\"

# From the Source

> \"I tell you, Watson, this time we have got a foeman who is worthy of our
> steel. I've been checkmated in London.\"
>
> — Holmes, after the cabman reveals the spy's taunt (ch. 5)

> \"What a nerve the fellow has! How he pulled himself together in the face of
> what must have been a paralyzing shock when he found that the wrong man had
> fallen a victim to his plot. I told you in London, Watson, and I tell you now
> again, that we have never had a foeman more worthy of our steel.\"
>
> — Holmes, after Stapleton's composure at Selden's death scene (ch. 12)

> \"Like most clever criminals, he may be too confident in his own cleverness
> and imagine that he has completely deceived us.\"
>
> — Holmes, on why Stapleton might not flee after seeing him (ch. 12)

# Why it generates tension
This is the axis on which the entire plot turns. Stapleton is the rare
adversary who outmanoeuvres Holmes — in London, at least — and Holmes
acknowledges him as an equal in cunning. Their duel is fought through proxies
(Watson, Sir Henry, the hound, Laura Lyons) while each man works to stay
invisible to the other.

# Citations
[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 4, 5, 12, 14, 15.
