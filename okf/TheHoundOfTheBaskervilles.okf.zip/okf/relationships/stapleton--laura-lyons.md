---
type: Relationship
title: "Stapleton ⇄ Laura Lyons"
description: "A predator and his unwitting tool — Stapleton posed as an unmarried suitor offering marriage, while using Laura Lyons to lure Sir Charles to his death."
tags: [manipulation, deception, false-romance]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
between: [/characters/stapleton.md, /characters/laura-lyons.md]
charge: predator-prey
provenance: human
---

# State log
* **The truth revealed** — Holmes shows Laura Lyons proof that Stapleton is
  married. Her fury is immediate: \"this man had offered me marriage... He has
  lied to me, the villain, in every conceivable way.\" She gives Holmes
  everything.
* **The letter** — Stapleton dictates the letter to Sir Charles, telling Laura
  she would receive money for her divorce. Then he dissuades her from keeping
  the appointment, leaving Sir Charles waiting alone at the gate.
* **The courtship** — Stapleton cultivates Laura Lyons as Sir Charles's
  almoner. Posing as a single man, he promises marriage once she obtains a
  divorce. She believes him completely.

# From the Source

> \"There can be no doubt about the matter. They meet, they write, there is a
> complete understanding between them. Now, this puts a very powerful weapon
> into our hands.\"
>
> — Holmes to Watson, after Watson's interview (ch. 12)

> \"I was never anything but a tool in his hands. Why should I preserve faith
> with him who never kept any with me? Why should I try to shield him from the
> consequences of his own wicked acts?\"
>
> — Laura Lyons, after learning the truth (ch. 13)

> \"I think that on the whole you have had a fortunate escape,\" said Sherlock
> Holmes. \"You have had him in your power and he knew it, and yet you are
> alive. You have been walking for some months very near to the edge of a
> precipice.\"
>
> — Holmes's parting words to Laura Lyons (ch. 13)

# Why it generates tension
Laura Lyons is the linchpin of Stapleton's scheme: her letter sets the trap for
Sir Charles. But she is also the scheme's weakest point — Stapleton's hold on
her depends entirely on a false promise of marriage. The moment that promise is
exposed as a lie, she becomes the prosecution's most dangerous witness.

# Citations
[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 10, 11, 13.
