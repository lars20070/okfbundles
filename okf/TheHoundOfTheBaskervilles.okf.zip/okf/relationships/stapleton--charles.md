---
type: Relationship
title: "Stapleton ⇄ Sir Charles Baskerville"
description: "A friendship feigned to enable murder — Stapleton cultivated Sir Charles as a neighbour and confidant, learning his superstitions and weak heart in order to kill him."
tags: [betrayal, murder, deception]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
between: [/characters/stapleton.md, /characters/charles-baskerville.md]
charge: betrayer-victim
provenance: human
---

# State log
* **The murder** — Stapleton dictates Laura Lyons's letter, releases the hound
  at the yew-alley gate, and Sir Charles dies of fright. The hound leaves no
  tracks on the grass; the only physical evidence is the giant footprint Dr.
  Mortimer withholds from the inquest.
* **The preparation** — Stapleton makes himself Sir Charles's almoner
  (distributor of charity). He learns from Dr. Mortimer that Sir Charles's
  heart is weak and that he is superstitious about the family legend. Sir
  Charles confides the 1742 manuscript to Dr. Mortimer's care.
* **The approach** — Stapleton establishes himself at Merripit House shortly
  after Sir Charles returns from South Africa. He cultivates the baronet's
  friendship, joining him for scientific discussions and becoming one of the
  few educated neighbours on the moor.

# From the Source

> \"His first act was to establish himself as near to his ancestral home as he
> could, and his second was to cultivate a friendship with Sir Charles
> Baskerville and with the neighbours.\"
>
> — Holmes, recounting Stapleton's method (ch. 15)

> \"The baronet himself told him about the family hound, and so prepared the way
> for his own death. Stapleton... knew that the old man's heart was weak and
> that a shock would kill him. So much he had learned from Dr. Mortimer.\"
>
> — Holmes (ch. 15)

> \"So much for the death of Sir Charles Baskerville. You perceive the devilish
> cunning of it, for really it would be almost impossible to make a case against
> the real murderer.\"
>
> — Holmes (ch. 15)

# Why it generates tension
The relationship is entirely one-sided: Sir Charles believes he has found a
congenial neighbour and fellow man of science; Stapleton sees only a target.
Every kindness Sir Charles shows — including making Stapleton his almoner —
becomes a weapon in Stapleton's hands.

# Citations
[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 2, 15.
