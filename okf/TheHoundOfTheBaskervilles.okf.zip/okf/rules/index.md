# Rules

* [The Baskerville Legend as Murder Method](/rules/baskerville-legend-exploited.md) - The family curse is not supernatural — it is a legend exploited by a murderer who used a real hound painted with phosphorus to mimic the spectral beast.
