---
type: Item
title: "The Stolen Boots"
description: "Sir Henry's new brown boot and old black boot, stolen at the Northumberland Hotel to provide the hound with his scent."
tags: [clue, scent, theft]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: damaged
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

Sir Henry Baskerville had three pairs of boots: new brown, old black, and
patent leathers. On his first night at the Northumberland Hotel, one brown boot
was stolen from outside his door. The next day, one old black boot was taken.
The brown boot was then mysteriously returned, found under a cabinet. The old
black boot was never recovered — it was later found by Holmes in the Grimpen
Mire, where Stapleton had discarded it during his flight. The boot was marked
"Meyers, Toronto" on the leather inside.

Holmes deduces that Stapleton first stole a new boot (useless, as it carried no
scent), then returned it and stole an old one. This proved to Holmes that a
real hound was being used.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 4, 5, 14, 15.

## From the Source

> "It seems a singularly useless thing to steal," said Sherlock Holmes.
>
> — Holmes, on learning the new brown boot was stolen (ch. 4)

> "The more *outré* and grotesque an incident is the more carefully it
> deserves to be examined, and the very point which appears to complicate
> a case is, when duly considered and scientifically handled, the one
> which is most likely to elucidate it."
>
> — Holmes, on the significance of the boot thefts (ch. 15)
