---
type: Item
title: "Dr. Mortimer's Walking Stick"
description: "A Penang lawyer presented to Dr. James Mortimer by the friends of the C.C.H. (Charing Cross Hospital) in 1884."
tags: [clue, mortimer]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: intact
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

A fine, thick, bulbous-headed stick of the type known as a "Penang lawyer." A
broad silver band nearly an inch across is engraved: "To James Mortimer,
M.R.C.S., from his friends of the C.C.H.," with the date "1884." The thick-iron
ferrule is worn down from extensive walking. Teeth marks in the middle indicate
it was carried by a curly-haired spaniel. Holmes's examination of this stick
opens the case and establishes Mortimer's profile before they meet.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 1.

## From the Source

> It was a fine, thick piece of wood, bulbous-headed, of the sort which is
> known as a "Penang lawyer." Just under the head was a broad silver band
> nearly an inch across. "To James Mortimer, M.R.C.S., from his friends of
> the C.C.H.," was engraved upon it, with the date "1884." It was just
> such a stick as the old-fashioned family practitioner used to carry —
> dignified, solid, and reassuring.
>
> — Watson describes the walking stick that opens the case (ch. 1)
