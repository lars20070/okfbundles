---
type: Item
title: "The Warning Letter"
description: "An anonymous message cut from a Times leader and pasted onto foolscap paper, warning Sir Henry Baskerville: 'As you value your life or your reason keep away from the moor.'"
tags: [warning, clue, anonymous]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: intact
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

A letter delivered to Sir Henry Baskerville at the Northumberland Hotel. The
words — except "moor," which is written in ink — are cut from the leading
article of the previous day's *Times* using short-bladed nail scissors and
attached with gum. The address is printed in rough characters. The envelope is
of common greyish quality, postmarked Charing Cross.

Holmes deduces the composer was an educated person posing as uneducated, writing
in a hotel with poor pen and ink, and in a state of agitation and hurry. He
detects a faint scent of white jessamine on the paper, indicating a woman's
involvement. The letter was sent by Beryl Stapleton, who cut out the words to
warn Sir Henry without her husband's knowledge.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 4, 15.

## From the Source

> Across the middle of it a single sentence had been formed by the
> expedient of pasting printed words upon it. It ran:
>
> As you value your life or your reason keep away from the moor.
>
> The word "moor" only was printed in ink.
>
> — Watson describes the warning letter (ch. 4)

> Holmes: "There are seventy-five perfumes, which it is very necessary
> that a criminal expert should be able to distinguish from each other...
> The scent suggested the presence of a lady, and already my thoughts
> began to turn towards the Stapletons."
>
> — Holmes, on detecting white jessamine on the letter (ch. 15)
