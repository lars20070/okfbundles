# Items

* [Dr. Mortimer's Walking Stick](/items/walking-stick.md) - A Penang lawyer presented to Dr. James Mortimer by the friends of the C.C.H. (Charing Cross Hospital) in 1884.
* [The Baskerville Manuscript (1742)](/items/baskerville-manuscript.md) - An 18th-century family document recounting the legend of Hugo Baskerville and the origin of the Hound of the Baskervilles.
* [The Warning Letter](/items/warning-letter.md) - An anonymous message cut from a Times leader and pasted onto foolscap paper, warning Sir Henry Baskerville: 'As you value your life or your reason keep away from the moor.'
* [The Stolen Boots](/items/stolen-boots.md) - Sir Henry's new brown boot and old black boot, stolen at the Northumberland Hotel to provide the hound with his scent.
* [The Hound](/items/the-hound.md) - A savage cross between a bloodhound and a mastiff, purchased from Ross and Mangles of Fulham Road, painted with phosphorus to appear supernatural.
