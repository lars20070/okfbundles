---
type: Item
title: "The Baskerville Manuscript (1742)"
description: "An 18th-century family document recounting the legend of Hugo Baskerville and the origin of the Hound of the Baskervilles."
tags: [baskerville-family, legend, manuscript]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: intact
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

An old manuscript on yellow paper with faded script, dated 1742, headed
"Baskerville Hall." It employs the alternative use of long and short 's'
characteristic of early 18th-century documents. The manuscript was committed to
Dr. Mortimer's care by Sir Charles Baskerville.

The text recounts the legend of Hugo Baskerville during the Great Rebellion:
his abduction of a yeoman's daughter, her escape, his oath to the Powers of
Evil, and his death at the jaws of a great black hound. It warns the family to
"forbear from crossing the moor in those dark hours when the powers of evil are
exalted" and is addressed by Hugo Baskerville to his sons Rodger and John, with
instructions not to tell their sister Elizabeth.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 2 (read aloud by Dr. Mortimer).

## From the Source

> "Of the origin of the Hound of the Baskervilles there have been many
> statements, yet as I come in a direct line from Hugo Baskerville, and as
> I had the story from my father, who also had it from his, I have set it
> down with all belief that it occurred even as is here set forth."
>
> — Opening words of the manuscript

> "...counsel you by way of caution to forbear from crossing the moor in
> those dark hours when the powers of evil are exalted."
>
> — The manuscript's closing warning

> "[This from Hugo Baskerville to his sons Rodger and John, with
> instructions that they say nothing thereof to their sister Elizabeth.]"
>
> — The manuscript's postscript
