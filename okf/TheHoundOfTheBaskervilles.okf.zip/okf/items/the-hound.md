---
type: Item
title: "The Hound"
description: "A savage cross between a bloodhound and a mastiff, purchased from Ross and Mangles of Fulham Road, painted with phosphorus to appear supernatural."
tags: [weapon, animal, phosphorus]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
status: destroyed
status_since: "1889-10"
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Description

The hound was the strongest and most savage dog in the possession of Ross and
Mangles, dealers in Fulham Road, London. Stapleton transported it by the North
Devon line and walked it across the moor to a hiding place on an island in the
Grimpen Mire — an abandoned tin mine where he kept it chained, fed on a diet
that included Dr. Mortimer's curly-haired spaniel.

The beast was a cross between a bloodhound and a mastiff, gaunt and savage, as
large as a small lioness. Stapleton daubed it with a cunning preparation of
phosphorus that gave no smell — so its mouth and eyes appeared to blaze with
hell-fire while its muzzle, hackles, and dewlap were outlined in flickering
flame. Holmes described the effect as "savage, appalling, hellish."

The hound was killed by Holmes's revolver fire during the attack on Sir Henry.
Post-mortem examination of the body confirmed the phosphorus.

# Appearances

* [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 14 (appearance and death), ch. 15
  (retrospection: purchase, transport, care).

## From the Source

> A hound it was, an enormous coal-black hound, but not such a hound as
> mortal eyes have ever seen. Fire burst from its open mouth, its eyes
> glowed with a smouldering glare, its muzzle and hackles and dewlap were
> outlined in flickering flame. Never in the delirious dream of a
> disordered brain could anything more savage, more appalling, more
> hellish be conceived than that dark form and savage face which broke
> upon us out of the wall of fog.
>
> — Watson describes the hound's appearance (ch. 14)

> In mere size and strength it was a terrible creature which was lying
> stretched before us. It was not a pure bloodhound and it was not a pure
> mastiff; but it appeared to be a combination of the two — gaunt, savage,
> and as large as a small lioness. Even now in the stillness of death, the
> huge jaws seemed to be dripping with a bluish flame and the small,
> deep-set, cruel eyes were ringed with fire. I placed my hand upon the
> glowing muzzle, and as I held them up my own fingers smouldered and
> gleamed in the darkness.
>
> "Phosphorus," I said.
>
> — Watson examines the dead hound (ch. 14)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 14 ("a hound it was, an enormous
coal-black hound"), ch. 15 ("the strongest and most savage").
