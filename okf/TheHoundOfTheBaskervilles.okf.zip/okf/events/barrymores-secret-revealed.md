---
type: Event
title: "The Barrymores' Secret Revealed"
description: "Sir Henry and Watson stake out the corridor, catch Barrymore signalling with a candle, and uncover that he and his wife are aiding her brother — the escaped convict Selden."
tags: [barrymore, selden, secret, night-watch]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
in_world_date: "1889-10"
sort_key: 1889.15
location: /locations/baskerville-hall.md
participants: [/characters/henry-baskerville.md, /characters/john-watson.md, /characters/barrymore.md, /characters/eliza-barrymore.md, /characters/selden.md]
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Summary

After Watson discovers Barrymore signalling from the western window with a
candle on two successive nights, Sir Henry and Watson stake out the corridor.
On the second night they catch Barrymore red-handed. Watson holds the candle to
the window and sees a tiny pinpoint of yellow light answering from the moor.
Cornered, Barrymore refuses to explain — until Mrs. Barrymore appears and
confesses: the light signals to her brother, Selden the Notting Hill murderer,
who is hiding on the moor. Every second night Barrymore carries bread and meat
to him.

Sir Henry forgives them. That same night, Sir Henry and Watson attempt to
capture Selden, chasing him across the moor by moonlight but failing to catch
him.

# From the Source

> \"My unhappy brother is starving on the moor. We cannot let him perish at our
> very gates. The light is a signal to him that food is ready for him, and his
> light out yonder is to show the spot to which to bring it.\"
>
> — Mrs. Barrymore confesses (ch. 9)

> \"Yes, sir, my name was Selden, and he is my younger brother... to me, sir, he
> was always the little curly-headed boy that I had nursed and played with as an
> elder sister would.\"
>
> — Mrs. Barrymore (ch. 9)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 8 (first sighting), ch. 9
(confrontation and confession).
