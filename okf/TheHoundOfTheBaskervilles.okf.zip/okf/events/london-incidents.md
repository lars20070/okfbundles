---
type: Event
title: "The London Incidents"
description: "The warning letter, boot thefts, cab pursuit, and hotel register inquiry — Stapleton's shadowing of Sir Henry in London before his departure for Devonshire."
tags: [london, warning, stalking]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
in_world_date: "1889-10"
sort_key: 1889.12
location: /locations/northumberland-hotel.md
participants: [/characters/henry-baskerville.md, /characters/stapleton.md, /characters/sherlock-holmes.md, /characters/john-watson.md, /characters/james-mortimer.md]
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Sequence

1. **Warning letter**: Sir Henry receives an anonymous message at the
   Northumberland Hotel — words cut from a *Times* leader, pasted onto
   foolscap. "As you value your life or your reason keep away from the moor."
   The word "moor" is in ink. Holmes traces it to the previous day's *Times*
   leader, deduces the sender used nail-scissors and gum in a hotel near
   Charing Cross, and detects a faint scent of white jessamine. Later
   identified as Beryl Stapleton's work.

2. **Boot thefts**: A new brown boot is stolen from outside Sir Henry's door.
   Next day, an old black boot is taken. The brown boot is mysteriously
   returned (found under a cabinet). Holmes later finds the black boot in the
   Grimpen Mire, marked "Meyers, Toronto." The thefts prove a real hound is
   involved — the old boot was needed for the beast's scent.

3. **Cab pursuit**: Holmes and Watson follow Sir Henry and Dr. Mortimer from
   Baker Street, and spot a black-bearded man in cab No. 2704 shadowing them.
   The cab flees. Cabman John Clayton (3 Turpey Street, the Borough, cab from
   Shipley's Yard) reveals his fare claimed to be "Mr. Sherlock Holmes" — a
   taunt from Stapleton.

4. **Hotel register**: Holmes examines the Northumberland Hotel register.
   Stapleton and Beryl stayed separately at the Mexborough Private Hotel in
   Craven Street, where he kept her imprisoned.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 4, 5, 15.

## From the Source

> Across the middle of it a single sentence had been formed by the
> expedient of pasting printed words upon it. It ran:
>
> As you value your life or your reason keep away from the moor.
>
> The word "moor" only was printed in ink.
>
> — The warning letter received by Sir Henry (ch. 4)

> "I seem to have walked right into the thick of a dime novel," said our
> visitor. "Why in thunder should anyone follow or watch me?"
>
> — Sir Henry, after learning of the boot thefts and the spy in the cab
> (ch. 4)
