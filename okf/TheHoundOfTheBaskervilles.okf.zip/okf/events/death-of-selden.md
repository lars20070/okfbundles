---
type: Event
title: "The Death of Selden"
description: "The escaped convict Selden was killed by the hound while wearing Sir Henry's cast-off clothing, mistaken for the baronet by the beast."
tags: [convict, mistaken-identity]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
in_world_date: "1889-10"
sort_key: 1889.17
location: /locations/dartmoor-moor.md
participants: [/characters/selden.md, /characters/stapleton.md]
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Summary

Stapleton set the hound on Sir Henry's trail using the stolen boot for scent.
However, Selden — the Notting Hill murderer who had escaped from Princetown —
was wearing Sir Henry's cast-off tweed suit, passed to him by Barrymore. The
hound tracked the scent of the clothing and ran Selden down on the moor.
Holmes and Watson heard his screams, found his body with a crushed skull at the
base of a rocky cliff, and initially believed the victim was Sir Henry. The
bearded face revealed the truth.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 12.

## From the Source

> "A beard! A beard! The man has a beard!"
>
> "It is not the baronet — it is — why, it is my neighbour, the convict!"
>
> — Holmes, discovering the body is Selden, not Sir Henry (ch. 12)
