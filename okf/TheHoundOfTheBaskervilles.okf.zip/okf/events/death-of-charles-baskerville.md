---
type: Event
title: "The Death of Sir Charles Baskerville"
description: "On the night of May 4, 1889, Sir Charles Baskerville died of fright in the yew alley after being pursued by Stapleton's phosphorescent hound."
tags: [murder, baskerville-family, crime]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
in_world_date: "1889-05-04"
sort_key: 1889.05
location: /locations/yew-alley.md
participants: [/characters/charles-baskerville.md, /characters/stapleton.md]
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Summary

Sir Charles went for his nightly walk down the yew alley. He waited at the
moor-gate for Laura Lyons, who had written (at Stapleton's dictation) asking
him to meet her there. Stapleton released the phosphorescent hound; it sprang
over the wicket-gate. Sir Charles fled down the alley, running until his
diseased heart burst. He fell dead on his face, features contorted.

Dr. Mortimer found giant hound footprints near the body — a detail he withheld
from the inquest. The coroner's verdict was death from natural causes (cardiac
exhaustion). The post-mortem showed long-standing organic disease.

# Significance

The death, appearing to fulfil the family legend, brought the case to Sherlock
Holmes.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 2 (report, Dr. Mortimer's private
account), ch. 15 (Holmes's retrospection).

## From the Source

> "Mr. Holmes, they were the footprints of a gigantic hound!"
>
> — Dr. Mortimer reveals the withheld evidence to Holmes (ch. 2)

> One fact which has not been explained is the statement of Barrymore that
> his master's footprints altered their character from the time that he
> passed the moor-gate, and that he appeared from thence onward to have
> been walking upon his toes.
>
> — The *Devon County Chronicle* report of the inquest (ch. 2)

> Sir Charles lay on his face, his arms out, his fingers dug into the
> ground, and his features convulsed with some strong emotion to such an
> extent that I could hardly have sworn to his identity.
>
> — Dr. Mortimer's private account of finding the body (ch. 2)
