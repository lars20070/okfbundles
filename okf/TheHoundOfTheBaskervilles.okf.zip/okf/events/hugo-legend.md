---
type: Event
title: "The Legend of Hugo Baskerville"
description: "On a Michaelmas night during the Great Rebellion, Hugo Baskerville abducted a yeoman's daughter and was killed by a spectral black hound on the moor."
tags: [baskerville-family, legend, supernatural]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
in_world_date: "c. 1640s"
sort_key: 1640.0
location: /locations/dartmoor-moor.md
participants: [/characters/hugo-baskerville.md]
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# The event

> "Know then that in the time of the Great Rebellion... this Manor of
> Baskerville was held by Hugo of that name, nor can it be gainsaid that he was
> a most wild, profane, and godless man."

— From the Baskerville manuscript, 1742

Hugo Baskerville, a wild and godless squire, abducted the daughter of a local
yeoman on Michaelmas. While he caroused with his companions, she escaped down
the ivy-covered south wall of the Hall and fled homeward across the moor —
three leagues distant. Hugo, discovering her gone, sprang upon the great table
in the dining-hall and swore an oath that he would "that very night render his
body and soul to the Powers of Evil if he might but overtake the wench." He
rode out with his hounds, giving them a kerchief of the maid's as scent.

The maiden was found dead of fear and fatigue in a clearing between two ancient
stones — stones "still to be seen there, which were set by certain forgotten
peoples in the days of old." Beside her lay Hugo's body, and standing over him
was "a foul thing, a great, black beast, shaped like a hound, yet larger than
any hound that ever mortal eye has rested upon." As the pursuers watched, the
thing tore Hugo's throat out and turned blazing eyes upon them. One of the
three who witnessed it died that very night; the other two "were but broken men
for the rest of their days."

The manuscript closes with a warning: "...counsel you by way of caution to
forbear from crossing the moor in those dark hours when the powers of evil are
exalted." It is addressed by Hugo Baskerville "to his sons Rodger and John,
with instructions that they say nothing thereof to their sister Elizabeth."

# Citations

[1] [/items/baskerville-manuscript.md](/items/baskerville-manuscript.md) — read by Dr. Mortimer in ch. 2.
[2] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 2.

## From the Source

> "Know then that in the time of the Great Rebellion... this Manor of
> Baskerville was held by Hugo of that name, nor can it be gainsaid that
> he was a most wild, profane, and godless man."
>
> — Opening of the Baskerville manuscript, 1742

> "...he cried aloud before all the company that he would that very night
> render his body and soul to the Powers of Evil if he might but overtake
> the wench."
>
> — Hugo's oath, from the manuscript

> "...there ran mute behind him such a hound of hell as God forbid should
> ever be at my heels."
>
> — The night shepherd's testimony, from the manuscript
