---
type: Event
title: "Holmes Interviews Laura Lyons"
description: "Holmes reveals to Laura Lyons that Stapleton is married, breaking his hold over her and securing her testimony for the case."
tags: [interview, laura-lyons, revelation, holmes]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
in_world_date: "1889-10"
sort_key: 1889.195
location: /locations/coombe-tracey.md
participants: [/characters/sherlock-holmes.md, /characters/john-watson.md, /characters/laura-lyons.md]
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Summary

After the portrait revelation, Holmes's plan becomes clear. He and Watson
pretend to leave for London but instead visit Laura Lyons at Coombe Tracey.
Holmes opens with characteristic directness: "We regard this case as one of
murder, and the evidence may implicate not only your friend Mr. Stapleton but
his wife as well."

Laura Lyons springs from her chair. "His wife! He is not a married man." Holmes
produces a photograph of "Mr. and Mrs. Vandeleur" taken in York four years ago
and three written descriptions from St. Oliver's private school. She examines
them and looks up with the face of a desperate woman.

> \"Mr. Holmes, this man had offered me marriage on condition that I could get a
> divorce from my husband. He has lied to me, the villain, in every conceivable
> way... I was never anything but a tool in his hands.\"

She confesses everything: Stapleton dictated the letter to Sir Charles; she was
to ask for money for the divorce; then he dissuaded her from keeping the
appointment, claiming it would hurt his self-respect. He made her swear
silence. Holmes calls it "a fortunate escape" — she had been walking very near
the edge of a precipice.

# From the Source

> \"Why should I preserve faith with him who never kept any with me? Why should
> I try to shield him from the consequences of his own wicked acts? Ask me what
> you like, and there is nothing which I shall hold back.\"
>
> — Laura Lyons, turning on Stapleton (ch. 13)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 13.
