---
type: Event
title: "Mrs. Stapleton Rescued"
description: "After killing the hound, Holmes, Watson, and Lestrade storm Merripit House and find Beryl Stapleton bound and gagged in the museum — beaten and betrayed by her husband."
tags: [rescue, merripit-house, beryl-stapleton, domestic-abuse]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
in_world_date: "1889-10"
sort_key: 1889.22
location: /locations/merripit-house.md
participants: [/characters/sherlock-holmes.md, /characters/john-watson.md, /characters/lestrade.md, /characters/beryl-stapleton.md]
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Summary

After killing the hound, Holmes, Watson, and Lestrade race to Merripit House.
Stapleton has fled. They search the house and find one bedroom door locked.
Holmes kicks it open. Inside, the room is a museum of butterflies and moths. In
the centre, an upright beam supports the old roof-timber. To this post a figure
is tied — swathed in sheets, a towel round the throat, another covering the
lower face. Two dark eyes, "full of grief and shame and a dreadful questioning,"
stare at them.

They tear off the gag and bonds. Mrs. Stapleton sinks to the floor. A clear red
weal of a whiplash crosses her neck; her arms are mottled with bruises. She
asks not after her husband but after Sir Henry: "Is he safe?"

Beryl reveals that Stapleton kept her bound so she could not warn Sir Henry and
that he had confessed Laura Lyons was a rival in his love. She tells them of
the old tin mine in the heart of the Grimpen Mire — Stapleton's refuge — and
the guiding wands that mark the path. "He may find his way in, but never out,"
she says with fierce satisfaction, for the fog has hidden the wands.

# From the Source

> As her beautiful head fell upon her chest I saw the clear red weal of a
> whiplash across her neck.
>
> \"The brute!\" cried Holmes.
>
> — Watson and Holmes, upon finding Beryl (ch. 14)

> \"I could endure it all, ill-usage, solitude, a life of deception,
> everything, as long as I could still cling to the hope that I had his love,
> but now I know that in this also I have been his dupe and his tool.\"
>
> — Beryl Stapleton (ch. 14)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 14.
