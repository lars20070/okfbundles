---
type: Event
title: "Stapleton Interrupts the Courtship"
description: "Stapleton bursts upon Sir Henry and Beryl on the moor path, flying into a violent rage at their intimacy, driving his sister away and leaving Sir Henry bewildered."
tags: [stapleton, courtship, confrontation, jealousy]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
in_world_date: "1889-10"
sort_key: 1889.14
location: /locations/dartmoor-moor.md
participants: [/characters/henry-baskerville.md, /characters/beryl-stapleton.md, /characters/stapleton.md, /characters/john-watson.md]
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Summary

Sir Henry slips away from Watson and meets Beryl Stapleton on the moor path.
Watson watches from a hill above the quarry. Sir Henry proposes marriage; Beryl
refuses, repeatedly warning him this is a place of danger and she will never be
happy until he leaves. Stapleton suddenly bursts upon them — "running wildly
towards them, his absurd net dangling behind him" — white with rage, abusing
Sir Henry for his attentions. He peremptorily beckons his sister away. Sir
Henry returns dejected.

That afternoon, Stapleton visits Baskerville Hall to apologise: his sister is
everything in his life, the thought of losing her was terrible, and he asks for
a three months' cooling period during which Sir Henry may cultivate friendship
without claiming love. Sir Henry agrees. The dinner at Merripit House is
arranged for the following Friday.

# From the Source

> She kept coming back to it that this was a place of danger, and that she
> would never be happy until I had left it. I told her that since I had seen
> her I was in no hurry to leave it, and that if she really wanted me to go, the
> only way to work it was for her to arrange to go with me. With that I offered
> in as many words to marry her, but before she could answer, down came this
> brother of hers, running at us with a face on him like a madman. He was just
> white with rage, and those light eyes of his were blazing with fury.
>
> — Sir Henry recounts the scene to Watson (ch. 9)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 9.
