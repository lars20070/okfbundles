---
type: Event
title: "Stapleton Identified from the Portrait"
description: "Holmes recognises Stapleton's features in the portrait of Hugo Baskerville, proving the naturalist is a Baskerville descendant with designs on the inheritance."
tags: [portrait, identification, baskerville-family, revelation]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
in_world_date: "1889-10"
sort_key: 1889.19
location: /locations/baskerville-hall.md
participants: [/characters/sherlock-holmes.md, /characters/john-watson.md, /characters/henry-baskerville.md]
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Summary

During supper at Baskerville Hall, Holmes's attention is drawn to the line of
family portraits. Sir Henry identifies Hugo's portrait — the Cavalier in black
velvet and lace, dated 1647, "the cause of all the mischief." Holmes studies it
intently all evening. Later, alone with Watson, he holds a candle to the
time-stained canvas, stands on a chair, and curves his arm over the broad hat
and long ringlets to hide the hair.

> \"Good heavens!\" I cried in amazement. The face of Stapleton had sprung out
> of the canvas.

Holmes declares it "an interesting instance of a throwback, which appears to be
both physical and spiritual." Stapleton is a Baskerville. With the motive
established — inheritance — Holmes announces the nets are closing: "A pin, a
cork, and a card, and we add him to the Baker Street collection!"

# From the Source

> \"My eyes have been trained to examine faces and not their trimmings. It is
> the first quality of a criminal investigator that he should see through a
> disguise.\"
>
> — Holmes, after revealing Stapleton in the portrait (ch. 13)

> \"The fellow is a Baskerville — that is evident.\" / \"With designs upon the
> succession.\" / \"Exactly. This chance of the picture has supplied us with one
> of our most obvious missing links.\"
>
> — Holmes and Watson (ch. 13)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 13.
