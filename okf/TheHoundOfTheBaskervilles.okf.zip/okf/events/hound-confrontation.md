---
type: Event
title: "The Hound Confrontation"
description: "Holmes, Watson, and Lestrade ambushed and killed the phosphorescent hound as it attacked Sir Henry on the moor path from Merripit House."
tags: [climax, hound, rescue]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
in_world_date: "1889-10"
sort_key: 1889.18
location: /locations/dartmoor-moor.md
participants: [/characters/sherlock-holmes.md, /characters/john-watson.md, /characters/henry-baskerville.md, /characters/lestrade.md, /characters/stapleton.md]
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Summary

Sir Henry, following Holmes's instructions, dined at Merripit House and walked
home alone across the moor path. A dense fog rolled in from the Grimpen Mire.
Holmes, Watson, and Lestrade waited in ambush behind rocks. As Sir Henry passed,
the hound burst from the fog: an enormous coal-black beast with fire blazing
from its mouth and eyes, daubed with phosphorus. Holmes and Watson fired
together, wounding it. The hound continued after Sir Henry. Holmes emptied five
barrels of his revolver into its flank, killing it.

Sir Henry was saved with no physical wound, though the shock shattered his
nerves. Stapleton fled into the Grimpen Mire and drowned. Mrs. Stapleton was
found bound and gagged in the upstairs museum of Merripit House.

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 14.

## From the Source

> With long bounds the huge black creature was leaping down the track,
> following hard upon the footsteps of our friend. So paralyzed were we by
> the apparition that we allowed him to pass before we had recovered our
> nerve. Then Holmes and I both fired together, and the creature gave a
> hideous howl, which showed that one at least had hit him. He did not
> pause, however, but bounded onward. Far away on the path we saw Sir
> Henry looking back, his face white in the moonlight, his hands raised in
> horror, glaring helplessly at the frightful thing which was hunting him
> down.
>
> — Watson describes the ambush and the hound's charge (ch. 14)

> "It's dead, whatever it is," said Holmes. "We've laid the family ghost
> once and forever."
>
> — Holmes, after killing the hound (ch. 14)
