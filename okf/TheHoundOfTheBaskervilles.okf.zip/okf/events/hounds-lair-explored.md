---
type: Event
title: "The Hound's Lair Explored"
description: "Guided by Mrs. Stapleton, the investigators cross the Grimpen Mire to the abandoned tin mine where the hound was kept, finding Sir Henry's missing boot, the spaniel's bones, and the phosphorus paste."
tags: [exploration, grimpen-mire, evidence, lair]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
in_world_date: "1889-10"
sort_key: 1889.24
location: /locations/hounds-lair.md
participants: [/characters/sherlock-holmes.md, /characters/john-watson.md, /characters/lestrade.md, /characters/beryl-stapleton.md]
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Summary

The morning after the hound's death, the fog lifts. Mrs. Stapleton guides
Holmes, Watson, and Lestrade through the Grimpen Mire, following the zigzag
path marked by small wands. "Rank reeds and lush, slimy water-plants sent an
odour of decay and a heavy miasmatic vapour"; false steps plunge them
thigh-deep into the quivering mire.

On the path Holmes spots a dark object projecting from a tuft of cotton grass.
He sinks to his waist retrieving it — Sir Henry's missing old black boot,
marked "Meyers, Toronto." Stapleton had held it during his flight and hurled it
away mid-escape.

On the bog-girt island stands the abandoned tin mine — a huge driving-wheel,
rubbish-filled shaft, and crumbling miners' cottages. In one cottage: a staple
and chain with gnawed bones where the hound was confined; a skeleton with brown
hair — Dr. Mortimer's spaniel. A tin of luminous phosphorus paste completes the
evidence.

Stapleton's footprints vanish in the rising mud. "Somewhere in the heart of the
great Grimpen Mire, down in the foul slime of the huge morass which had sucked
him in, this cold and cruel-hearted man is forever buried."

# From the Source

> \"A dog!\" said Holmes. \"By Jove, a curly-haired spaniel. Poor Mortimer will
> never see his pet again.\"
>
> — Holmes discovers the spaniel's skeleton (ch. 14)

> He could hide his hound, but he could not hush its voice, and hence came
> those cries which even in daylight were not pleasant to hear.
>
> — Holmes (ch. 14)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 14.
