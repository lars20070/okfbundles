# Events

* [The Legend of Hugo Baskerville](/events/hugo-legend.md) - On a Michaelmas night during the Great Rebellion, Hugo Baskerville abducted a yeoman's daughter and was killed by a spectral black hound on the moor.
* [The Death of Sir Charles Baskerville](/events/death-of-charles-baskerville.md) - On the night of May 4, 1889, Sir Charles Baskerville died of fright in the yew alley after being pursued by Stapleton's phosphorescent hound.
* [The London Incidents](/events/london-incidents.md) - The warning letter, boot thefts, cab pursuit, and hotel register inquiry — Stapleton's shadowing of Sir Henry in London before his departure for Devonshire.
* [Stapleton Interrupts the Courtship](/events/stapleton-interrupts-courtship.md) - Stapleton bursts upon Sir Henry and Beryl on the moor path, flying into a violent rage at their intimacy, driving his sister away and leaving Sir Henry bewildered.
* [The Barrymores' Secret Revealed](/events/barrymores-secret-revealed.md) - Sir Henry and Watson stake out the corridor, catch Barrymore signalling with a candle, and uncover that he and his wife are aiding her brother — the escaped convict Selden.
* [The Death of Selden](/events/death-of-selden.md) - The escaped convict Selden was killed by the hound while wearing Sir Henry's cast-off clothing, mistaken for the baronet by the beast.
* [Watson Interviews Laura Lyons](/events/watson-interviews-laura-lyons.md) - Watson travels to Coombe Tracey and confronts Laura Lyons about the letter that lured Sir Charles to his death, extracting a partial confession.
* [Holmes Discovered on the Moor](/events/holmes-discovered-on-moor.md) - Watson tracks the mysterious stranger on the moor to a Neolithic hut and lies in wait — only to be greeted by Sherlock Holmes himself.
* [The Hound Confrontation](/events/hound-confrontation.md) - Holmes, Watson, and Lestrade ambushed and killed the phosphorescent hound as it attacked Sir Henry on the moor path from Merripit House.
* [Stapleton Identified from the Portrait](/events/stapleton-portrait-identified.md) - Holmes recognises Stapleton's features in the portrait of Hugo Baskerville, proving the naturalist is a Baskerville descendant with designs on the inheritance.
* [Holmes Interviews Laura Lyons](/events/holmes-interviews-laura-lyons.md) - Holmes reveals to Laura Lyons that Stapleton is married, breaking his hold over her and securing her testimony for the case.
* [Mrs. Stapleton Rescued](/events/mrs-stapleton-rescued.md) - After killing the hound, Holmes, Watson, and Lestrade storm Merripit House and find Beryl Stapleton bound and gagged in the museum — beaten and betrayed by her husband.
* [The Hound's Lair Explored](/events/hounds-lair-explored.md) - Guided by Mrs. Stapleton, the investigators cross the Grimpen Mire to the abandoned tin mine where the hound was kept, finding Sir Henry's missing boot, the spaniel's bones, and the phosphorus paste.
* [Holmes's Retrospection](/events/holmes-retrospection.md) - At Baker Street in late November, Holmes lays out the entire Baskerville case from Stapleton's perspective — his lineage, his methods, and how every piece of the puzzle fit together.
