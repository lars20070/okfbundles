---
type: Event
title: "Holmes's Retrospection"
description: "At Baker Street in late November, Holmes lays out the entire Baskerville case from Stapleton's perspective — his lineage, his methods, and how every piece of the puzzle fit together."
tags: [retrospection, explanation, holmes, conclusion]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
in_world_date: "1889-11"
sort_key: 1889.30
location: /locations/baker-street.md
participants: [/characters/sherlock-holmes.md, /characters/john-watson.md]
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Summary

In late November, Sir Henry and Dr. Mortimer visit Baker Street before
embarking on a round-the-world voyage to restore Sir Henry's shattered nerves.
After they leave, Watson asks Holmes to recount the case from memory. Holmes
obliges, reconstructing the entire affair from Stapleton's point of view:

Stapleton was Rodger Baskerville Jr., son of the black-sheep brother. He
married Beryl Garcia in Costa Rica, embezzled money, fled to England as
"Vandeleur," and ran St. Oliver's school in Yorkshire with the help of a
consumptive tutor named Fraser. After Fraser died and the school collapsed, the
couple became the Stapletons and moved to Devonshire.

Learning only two lives stood between him and the Baskerville estate, Stapleton
bought the hound from Ross and Mangles of Fulham Road, concealed it in the
Grimpen Mire, and daubed it with phosphorus. He used Laura Lyons to lure Sir
Charles to the gate, released the hound, and Sir Charles died of fright. For
Sir Henry, he stole a boot in London for the hound's scent, shadowed him by
cab, and returned to Dartmoor for the final trap.

Holmes explains the significance of the boot thefts (proving a real hound), the
white jessamine scent on the warning letter (proving a woman's involvement),
and the portrait (proving Stapleton's Baskerville blood). He acknowledges the
risk he took using Sir Henry as bait and the failure to foresee the fog.

# From the Source

> \"The more *outré* and grotesque an incident is the more carefully it deserves
> to be examined, and the very point which appears to complicate a case is, when
> duly considered and scientifically handled, the one which is most likely to
> elucidate it.\"
>
> — Holmes, on the boot thefts (ch. 15)

> \"The past and the present are within the field of my inquiry, but what a man
> may do in the future is a hard question to answer.\"
>
> — Holmes, on Stapleton's inheritance plans (ch. 15)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 15.
