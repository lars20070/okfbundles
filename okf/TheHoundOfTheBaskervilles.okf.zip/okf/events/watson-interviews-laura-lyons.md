---
type: Event
title: "Watson Interviews Laura Lyons"
description: "Watson travels to Coombe Tracey and confronts Laura Lyons about the letter that lured Sir Charles to his death, extracting a partial confession."
tags: [interview, laura-lyons, investigation]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
in_world_date: "1889-10-18"
sort_key: 1889.16
location: /locations/coombe-tracey.md
participants: [/characters/john-watson.md, /characters/laura-lyons.md]
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Summary

Following Barrymore's revelation of the burned letter signed "L. L.," Watson
drives to Coombe Tracey to interview Laura Lyons. She is strikingly beautiful
but with a coarseness that mars her looks. Watson confronts her with the
postscript of her letter: "Please, please, as you are a gentleman, burn this
letter, and be at the gate by ten o'clock." She turns deathly pale, then
confesses she wrote it — asking Sir Charles to meet her so she could ask for
financial help toward a divorce. She swears she never kept the appointment;
"something intervened." She refuses to say what.

Watson leaves baffled and disheartened, convinced she is holding something
back. Later Holmes reveals Stapleton dictated the letter, then dissuaded her
from going, using her as an unwitting tool to lure Sir Charles to his death.

# From the Source

> \"Yes, I did write it,\" she cried, pouring out her soul in a torrent of
> words. \"I did write it. Why should I deny it? I have no reason to be ashamed
> of it. I wished him to help me. I believed that if I had an interview I could
> gain his help, so I asked him to meet me.\"
>
> — Laura Lyons, confessing to Watson (ch. 11)

> \"I never went.\" / \"Mrs. Lyons!\" / \"No, I swear it to you on all I hold
> sacred. I never went. Something intervened to prevent my going.\"
>
> — Laura Lyons and Watson (ch. 11)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 10 (discovery of L.L.), ch. 11
(interview).
