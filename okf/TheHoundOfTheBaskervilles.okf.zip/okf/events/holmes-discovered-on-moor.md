---
type: Event
title: "Holmes Discovered on the Moor"
description: "Watson tracks the mysterious stranger on the moor to a Neolithic hut and lies in wait — only to be greeted by Sherlock Holmes himself."
tags: [holmes, watson, reveal, neolithic-hut]
timestamp: 2026-08-17T00:00:00Z
canon: hard
tense: past
in_world_date: "1889-10-18"
sort_key: 1889.165
location: /locations/neolithic-huts.md
participants: [/characters/john-watson.md, /characters/sherlock-holmes.md]
established_in: /stories/the-hound-of-the-baskervilles.md
provenance: human
---

# Summary

Using information from Frankland's telescope (the boy carrying supplies),
Watson searches the Neolithic huts near the Black Tor. He finds one fitted as a
habitation — blankets, fire ashes, cooking utensils, tins, a pannikin and
spirits. On a flat stone table lies a cloth bundle from the boy containing
bread, tinned tongue, and preserved peaches. Beneath it, a pencilled note:
"Dr. Watson has gone to Coombe Tracey."

Watson realises he — not Sir Henry — is being watched. He waits in the dark
hut, revolver cocked, for the tenant. Footsteps approach. A shadow falls across
the doorway.

> \"It is a lovely evening, my dear Watson,\" said a well-known voice. \"I
> really think that you will be more comfortable outside than in.\"

Holmes has been on the moor all along, conducting a parallel investigation from
the hut while Cartwright ran supplies. He has received all Watson's reports
(forwarded from Baker Street to Coombe Tracey), identified Stapleton's wife
posing as his sister, and is ready to close the case.

# From the Source

> For a minute I stood there with the paper in my hands thinking out the
> meaning of this curt message. It was I, then, and not Sir Henry, who was
> being dogged by this secret man.
>
> — Watson discovers the note (ch. 11)

> \"I have been able to get about as I could not possibly have done had I been
> living in the Hall, and I remain an unknown factor in the business, ready to
> throw in all my weight at a critical moment.\"
>
> — Holmes explains his strategy (ch. 12)

# Citations

[1] [/stories/the-hound-of-the-baskervilles.md](/stories/the-hound-of-the-baskervilles.md) — ch. 11 (discovery), ch. 12 (Holmes's
explanation).
