---
type: World Rule
title: "Honour and shame govern heroic conduct"
description: "A hero's primary motivation is honour (timē); shame (aidōs) prevents retreat, and public reputation is valued above life itself."
tags: [honour, shame, heroism, motivation]
timestamp: 2026-08-16T00:00:00Z
canon: hard
invariant: true
established_in: /stories/the-iliad.md
provenance: human
---

# Description

The heroic code of the Iliad is built on *timē* (honour, public worth) and
*aidōs* (shame, the fear of disgrace). A hero fights not for abstract principle
but for personal honour — the visible tokens of respect from his community:
prizes, spoils, and public acknowledgement.

[Achilles](/characters/achilles.md)'s wrath is triggered by the loss of honour
when [Agamemnon](/characters/agamemnon.md) seizes [Briseïs](/characters/briseis.md),
his prize of war. [Hector](/characters/hector.md) refuses to retreat within the
walls of Troy in Book XXII not because he expects to win but because he cannot
bear the shame of having led his people to disaster and then hidden: "Better to
meet at once the worst that fate may send." [Ajax](/characters/ajax-the-greater.md),
when the ships are threatened in Book XV, fights not for survival but because
retreat is unthinkable for a man of honour.

This code extends to the treatment of the dead: stripping a body of its armour
brings honour to the victor, but refusing burial brings disgrace. Achilles'
dragging of Hector's body is the poem's most transgressive act precisely because
it violates the honour code's limits.

# Appearances

* [The Iliad](/stories/the-iliad.md) — throughout; the poem is built on this code.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book I: Achilles' honour wounded by Agamemnon.
[2] [The Iliad](/stories/the-iliad.md) — Book IX: Achilles' rejection of material compensation.
[3] [The Iliad](/stories/the-iliad.md) — Book XXII: Hector's choice to face Achilles.
[4] [The Iliad](/stories/the-iliad.md) — Book XXIV: the shame-limits of corpse abuse.
