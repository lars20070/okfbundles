---
type: World Rule
title: "Prophecy is always fulfilled but may be misunderstood"
description: "All prophecies in the poem come true, but mortals frequently misinterpret them or fail to act on them until too late."
tags: [prophecy, fate, interpretation]
timestamp: 2026-08-16T00:00:00Z
canon: hard
invariant: true
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Prophecy in the Iliad is universally reliable — whatever is foretold comes to
pass — but the manner of its fulfilment is often surprising, and mortals
routinely fail to understand or heed it. [Thetis](/characters/thetis.md) tells
[Achilles](/characters/achilles.md) that he has two fates: a long, obscure life
at home, or a short but glorious one at Troy. Achilles chooses the latter but
does not know the precise shape of his doom. [Hector](/characters/hector.md),
dying, prophesies that Achilles will fall to [Paris](/characters/paris.md) and
[Apollo](/characters/apollo.md) at the Scaean Gate — which Buckley's
[Concluding Note](/continuity/post-iliad-fates.md) confirms happens.

The horse [Xanthus](/items/horses-of-achilles.md), given voice by
[Juno](/characters/juno.md), prophesies Achilles' death in Book XIX. Achilles
acknowledges the prophecy but charges into battle regardless. The pattern is
consistent: prophecy reveals the shape of fate but never provides enough
specificity to change it. Characters who ignore prophecy (like
[Hector](/characters/hector.md) dismissing [Polydamas](/characters/polydamas.md)
in Book XVIII) suffer the consequences.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books I (Thetis's prophecy to Achilles), IX (the story of Meleager as warning), XVIII (Polydamas's ignored warning), XIX (Xanthus's prophecy), XXII (Hector's dying prophecy).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book I: Thetis reveals Achilles' two fates.
[2] [The Iliad](/stories/the-iliad.md) — Book XVIII: Polydamas warns Hector; Hector ignores him.
[3] [The Iliad](/stories/the-iliad.md) — Book XIX: Xanthus prophesies Achilles' death.
[4] [The Iliad](/stories/the-iliad.md) — Book XXII: Hector's dying prophecy.
