---
type: World Rule
title: "Blood-price and compensation can settle disputes"
description: "Wrongs between warriors can be resolved through material compensation (gifts, treasure); the poem explores the limits of this principle."
tags: [compensation, reconciliation, gifts]
timestamp: 2026-08-16T00:00:00Z
canon: hard
invariant: true
established_in: /stories/the-iliad.md
provenance: human
---

# Description

The heroic world has an institutional mechanism for resolving disputes: material
compensation. In Book IX, [Agamemnon](/characters/agamemnon.md) offers
[Achilles](/characters/achilles.md) an enormous list of gifts — gold, horses,
women, land, even his daughter's hand in marriage — to atone for the seizure of
[Briseïs](/characters/briseis.md). By the norms of the culture, this is a
generous offer, and [Ulysses](/characters/ulysses.md) presents it as such.

Achilles' refusal to accept compensation is the poem's central ethical
exploration. He values his wounded honour above any material recompense,
suggesting that some wrongs are beyond price. In Book XIX, when he does
reconcile, the same gifts are accepted — but only after
[Patroclus](/characters/patroclus.md)'s death has changed what matters to him.
The poem thus both affirms the compensation principle (it is offered, and
ultimately accepted) and questions its limits (Achilles' refusal shows that
honour is not reducible to goods).

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books I (the quarrel originates in a dispute over spoils), IX (the offer of compensation), XIX (the acceptance).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book IX: Agamemnon's offer of compensation to Achilles.
[2] [The Iliad](/stories/the-iliad.md) — Book XIX: the reconciliation and acceptance of gifts.
