---
type: World Rule
title: "Divine favour is earned through sacrifice"
description: "The gods respond to proper ritual — prayer, hecatombs, libations; neglecting sacrifice invites divine wrath."
tags: [sacrifice, ritual, divine-favour]
timestamp: 2026-08-16T00:00:00Z
canon: hard
invariant: true
established_in: /stories/the-iliad.md
provenance: human
---

# Description

The relationship between mortals and gods in the Iliad is transactional: favour
is secured through sacrifice and proper ritual observance. The poem's opening
crisis is a case study: [Agamemnon](/characters/agamemnon.md) dishonours
[Chryses](/characters/chryses.md), priest of [Apollo](/characters/apollo.md),
refusing his ransom. Apollo answers his priest's prayer with a plague. The
plague is only lifted when the Greeks return [Chryseïs](/characters/chryseis.md)
and offer "hecatombs" (hundred-ox sacrifices) at [Chrysa](/locations/chrysa.md).

Throughout the poem, characters pour libations, offer prayers, and make
sacrifices before critical undertakings. [Achilles](/characters/achilles.md)
pours a libation before [Patroclus](/characters/patroclus.md) goes to battle
(Book XVI). The Greek wall, built without proper sacrifice, is fated to fall
(Book XII). The pattern is consistent: neglect the gods and suffer; honour them
and receive aid — though aid is never guaranteed, as fate may override divine
willingness.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books I (Apollo's plague and its lifting), VII (the wall built without sacrifice), XII (consequences), XVI (Achilles' libation).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book I: the plague sent by Apollo and lifted by sacrifice.
[2] [The Iliad](/stories/the-iliad.md) — Book VII: the Greek wall built without sacrifice.
[3] [The Iliad](/stories/the-iliad.md) — Book XII: the wall's inevitable fall.
