---
type: World Rule
title: "The gods intervene in mortal affairs"
description: "The Olympian gods personally enter battle, speak to mortals, and alter outcomes; they can be wounded but not killed."
tags: [gods, intervention, divine-law]
timestamp: 2026-08-16T00:00:00Z
canon: hard
invariant: true
established_in: /stories/the-iliad.md
provenance: human
---

# Description

The Olympian gods are not distant observers: they appear to mortals, fight
alongside them, and directly alter the course of battle. Gods assume disguises
([Neptune](/characters/neptune.md) as [Calchas](/characters/calchas.md),
[Minerva](/characters/minerva.md) as Deiphobus,
[Mercury](/characters/mercury.md) as a Myrmidon). They can be injured —
[Diomed](/characters/diomed.md) wounds [Venus](/characters/venus.md) and
[Mars](/characters/mars.md) — but cannot die. The boundary is policed by
[Jupiter](/characters/jupiter.md), who forbids intervention in Book VIII and
then permits it in Book XX.

# Appearances

* [The Iliad](/stories/the-iliad.md) — throughout.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book V: Diomed wounds Venus and Mars.
[2] [The Iliad](/stories/the-iliad.md) — Book VIII: Jupiter forbids divine intervention.
[3] [The Iliad](/stories/the-iliad.md) — Book XX: Jupiter permits the gods to join battle.
