---
type: World Rule
title: "Mortals are subject to death and decay"
description: "All mortals, however great, are doomed to die and their bodies to decay unless the gods intervene; proper burial is essential."
tags: [mortality, burial, honour]
timestamp: 2026-08-16T00:00:00Z
canon: hard
invariant: true
established_in: /stories/the-iliad.md
provenance: human
---

# Description

The Iliad insistently reminds us that all mortals die. The opening lines
establish this as the poem's theme: Achilles' wrath sends "the souls of mighty
chiefs" to Hades and leaves "their limbs unburied on the naked shore." Proper
burial is a central concern: the battle for [Patroclus](/characters/patroclus.md)'s
body in Book XVII, the preservation of [Hector](/characters/hector.md)'s body by
divine intervention (Apollo and Venus shield it from decay), and the poem's
closure with Hector's funeral rites all attest to the religious necessity of
burial. Without it, the soul cannot find rest. Achilles' abuse of Hector's body
is therefore not merely cruel but impious, and his eventual return of the body
to [Priam](/characters/priam.md) restores the cosmic order.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books I, XVII, XVIII, XXII, XXIII, XXIV.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book I: the opening invocation.
[2] [The Iliad](/stories/the-iliad.md) — Book XXIII: Patroclus's ghost demands burial.
[3] [The Iliad](/stories/the-iliad.md) — Book XXIV: Hector's funeral rites.
