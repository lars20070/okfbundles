---
type: World Rule
title: "Guest-friendship (xenia) is sacred"
description: "The hereditary bond of hospitality between families transcends battlefield enmity, compelling even enemies to honour it."
tags: [xenia, hospitality, honour]
timestamp: 2026-08-16T00:00:00Z
canon: hard
invariant: true
established_in: /stories/the-iliad.md
provenance: human
---

# Description

The bond of *xenia* (guest-friendship) between families is inherited across
generations and carries sacred obligation. In Book VI, when
[Glaucus](/characters/glaucus.md) and [Diomed](/characters/diomed.md) meet
between the armies, they discover that Diomed's grandfather Oeneus once hosted
Glaucus's grandfather Bellerophon. This ancestral bond transforms them from
enemies into friends; they exchange armour as a sign, and Diomed gives Glaucus
bronze armour worth nine oxen for golden armour worth a hundred — a gesture that
underscores the primacy of the bond over material value.

# Appearances

### In the Iliad

* [The Iliad](/stories/the-iliad.md) — Book VI: the meeting of Glaucus and Diomed.

### In the Odyssey

* [The Odyssey](/stories/the-odyssey.md) — throughout: the poem is structured around violations (by the suitors) and exemplary demonstrations (by the Phaeacians, Eumaeus) of xenia.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book VI: the exchange of arms between Glaucus and Diomed.
[2] [The Odyssey](/stories/the-odyssey.md) — the suitors' violation of xenia and its punishment.
[3] [The Odyssey](/stories/the-odyssey.md) — the Phaeacians' exemplary hospitality.
[4] [The Odyssey](/stories/the-odyssey.md) — the Cyclops's grotesque inversion of xenia.
