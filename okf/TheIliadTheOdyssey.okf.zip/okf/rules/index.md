# Rules

* [The gods intervene in mortal affairs](/rules/gods-intervene.md) - The Olympian gods personally enter battle, speak to mortals, and alter outcomes; they can be wounded but not killed.
* [Fate is fixed and inescapable](/rules/fate-is-fixed.md) - Neither mortals nor gods can alter what fate has decreed; Jupiter cannot save Sarpedon or Hector.
* [Guest-friendship (xenia) is sacred](/rules/guest-friendship.md) - The hereditary bond of hospitality between families transcends battlefield enmity.
* [Mortals are subject to death and decay](/rules/mortals-are-subject-to-death.md) - All mortals die; proper burial is essential for the soul's rest.
* [Honour and shame govern heroic conduct](/rules/honour-and-shame.md) - A hero's primary motivation is honour (timē); shame (aidōs) prevents retreat.
* [Divine favour is earned through sacrifice](/rules/divine-favour-through-sacrifice.md) - The gods respond to prayer, hecatombs, and libations; neglect invites wrath.
* [Prophecy is always fulfilled but may be misunderstood](/rules/prophecy-always-fulfilled.md) - All prophecies come true, but mortals frequently misinterpret them.
* [Blood-price and compensation can settle disputes](/rules/blood-price-and-compensation.md) - Wrongs can be resolved through material compensation; the poem explores the limits of this principle.
