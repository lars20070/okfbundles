---
type: World Rule
title: "Fate is fixed and inescapable"
description: "Neither mortals nor gods can alter what fate has decreed; Jupiter cannot save Sarpedon or Hector from their destined deaths."
tags: [fate, destiny, divine-limitation]
timestamp: 2026-08-16T00:00:00Z
canon: hard
invariant: true
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Fate (*moira*) is a force that binds even the gods. [Jupiter](/characters/jupiter.md),
the king of the gods, twice contemplates saving a mortal he loves: his son
[Sarpedon](/characters/sarpedon.md) in Book XVI, and [Hector](/characters/hector.md)
in Book XXII. Both times [Juno](/characters/juno.md) or [Minerva](/characters/minerva.md)
reminds him that overturning fate would set a precedent no god could sustain. In
Book VIII and again in Book XXII, Jupiter weighs fates on his golden scales;
when a hero's scale sinks, his death is certain. [Achilles](/characters/achilles.md)
knows from [Thetis](/characters/thetis.md) that two fates await him: a long,
obscure life at home or a short, glorious one at Troy. He chooses the latter.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books I (Achilles' choice), VIII (scales), XVI (Sarpedon), XXII (Hector's scales, death).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book VIII: Jupiter weighs the fates.
[2] [The Iliad](/stories/the-iliad.md) — Book XVI: Jupiter grieves for Sarpedon but cannot save him.
[3] [The Iliad](/stories/the-iliad.md) — Book XXII: Jupiter weighs Hector's fate.
