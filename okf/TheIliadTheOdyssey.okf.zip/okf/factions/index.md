# Factions

* [Greeks](/factions/greeks.md) - The Achaean coalition besieging Troy: Myrmidons, Mycenaeans, Spartans, Argives, Cretans, Ithacans, Pylians, Locrians, and others.
* [Trojans](/factions/trojans.md) - The defenders of Troy: Trojans, Dardans, Lycians, Thracians, and other allies.
* [Olympian Gods](/factions/olympian-gods.md) - The divine faction, split between pro-Greek and pro-Trojan allegiances.
* [Myrmidons](/factions/myrmidons.md) - Achilles' personal forces, from Phthia.

## Odyssey factions

* [Suitors](/factions/suitors.md) - The 108 men who occupy Ulysses' palace and demand Penelope remarry.
* [Phaeacians](/factions/phaeacians.md) - Seafaring people of Scheria who convey Ulysses home.
