---
type: Faction
title: "Trojans"
description: "The defenders of Troy: Trojans, Dardans, and allies from Lycia, Thrace, and other regions."
tags: [trojan, defenders]
timestamp: 2026-08-16T00:00:00Z
canon: hard
established_in: /stories/the-iliad.md
provenance: human
---

# Description

The Trojans and their allies defend [Troy](/locations/troy.md) under the
leadership of [Hector](/characters/hector.md), son of King
[Priam](/characters/priam.md). Their forces include native Trojans and Dardans
(led by [Aeneas](/characters/aeneas.md)) as well as allied contingents: Lycians
under [Sarpedon](/characters/sarpedon.md) and [Glaucus](/characters/glaucus.md),
Thracians under [Rhesus](/characters/rhesus.md), and others catalogued in Book
II.

Their divine patrons are [Apollo](/characters/apollo.md),
[Venus](/characters/venus.md), and [Mars](/characters/mars.md).
[Jupiter](/characters/jupiter.md) favours them temporarily at
[Thetis](/characters/thetis.md)'s request.

# Appearances

* [The Iliad](/stories/the-iliad.md) — throughout; catalogue in Book II.

# Key Members

* [Hector](/characters/hector.md), [Priam](/characters/priam.md), [Paris](/characters/paris.md), [Aeneas](/characters/aeneas.md), [Sarpedon](/characters/sarpedon.md), [Glaucus](/characters/glaucus.md), [Pandarus](/characters/pandarus.md), [Polydamas](/characters/polydamas.md), [Helen](/characters/helen.md), [Andromache](/characters/andromache.md), [Hecuba](/characters/hecuba.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book II: the catalogue of Trojan forces.
