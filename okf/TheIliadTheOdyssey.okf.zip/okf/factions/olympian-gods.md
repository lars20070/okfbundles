---
type: Faction
title: "Olympian Gods"
description: "The divine faction, split into pro-Greek and pro-Trojan camps, who intervene throughout the Trojan War."
tags: [gods, olympian, divine]
timestamp: 2026-08-16T00:00:00Z
canon: hard
established_in: /stories/the-iliad.md
provenance: human
---

# Description

The Olympian gods are the immortal powers who rule from
[Olympus](/locations/olympus.md). In the Iliad they are intensely involved in
the war below, splitting into factions:

**Pro-Greek:** [Juno](/characters/juno.md), [Minerva](/characters/minerva.md),
[Neptune](/characters/neptune.md), [Vulcan](/characters/vulcan.md).

**Pro-Trojan:** [Apollo](/characters/apollo.md),
[Venus](/characters/venus.md), [Mars](/characters/mars.md).

[Jupiter](/characters/jupiter.md) occupies a middle position: he favours Troy
personally but is bound by fate and must balance divine factions.
[Thetis](/characters/thetis.md), though a sea-nymph, has access to Olympus and
petitions Jupiter directly. [Mercury](/characters/mercury.md) and
[Iris](/characters/iris.md) serve as messengers for all sides.

The gods are constrained by Jupiter's decrees — notably his prohibition of
intervention in Book VIII — but repeatedly test those boundaries. Divine
machinery (Jupiter's scales in Books VIII and XXII, the seduction on Ida in Book
XIV, the theomachy in Book XXI) drives the narrative as much as mortal combat.

# Appearances

* [The Iliad](/stories/the-iliad.md) — throughout.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book IV: the divine council decides Troy's fate.
[2] [The Iliad](/stories/the-iliad.md) — Book VIII: Jupiter forbids intervention.
[3] [The Iliad](/stories/the-iliad.md) — Book XX: the battle of the gods.
