---
type: Faction
title: "Greeks"
description: "The Achaean coalition besieging Troy: a confederation of kingdoms including Mycenae, Sparta, Ithaca, Pylos, Crete, Argos, Salamis, and Locris."
tags: [greek, achaean, besiegers]
timestamp: 2026-08-16T00:00:00Z
canon: hard
established_in: /stories/the-iliad.md
provenance: human
---

# Description

The Greek army (Achaeans, Argives, Danaans — all used interchangeably in the
poem) is a coalition of independent kingdoms united under the command of
[Agamemnon](/characters/agamemnon.md), king of Mycenae. The coalition includes:
the [Myrmidons](/factions/myrmidons.md) of [Achilles](/characters/achilles.md);
the Spartans of [Menelaus](/characters/menelaus.md); the Ithacans of
[Ulysses](/characters/ulysses.md); the Pylians of [Nestor](/characters/nestor.md);
the Cretans of [Idomeneus](/characters/idomeneus.md); the Argives of
[Diomed](/characters/diomed.md); the Salaminians of [Ajax the Greater](/characters/ajax-the-greater.md);
the Locrians of [Ajax the Lesser](/characters/ajax-the-lesser.md); and many
others catalogued in Book II.

Their divine patrons are [Juno](/characters/juno.md),
[Minerva](/characters/minerva.md), [Neptune](/characters/neptune.md), and
[Vulcan](/characters/vulcan.md).

# Appearances

* [The Iliad](/stories/the-iliad.md) — throughout; catalogue in Book II.

# Key Members

* [Achilles](/characters/achilles.md), [Agamemnon](/characters/agamemnon.md), [Menelaus](/characters/menelaus.md), [Diomed](/characters/diomed.md), [Ulysses](/characters/ulysses.md), [Nestor](/characters/nestor.md), [Ajax the Greater](/characters/ajax-the-greater.md), [Ajax the Lesser](/characters/ajax-the-lesser.md), [Idomeneus](/characters/idomeneus.md), [Patroclus](/characters/patroclus.md), [Phoenix](/characters/phoenix.md), [Calchas](/characters/calchas.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book II: the catalogue of Greek forces.
