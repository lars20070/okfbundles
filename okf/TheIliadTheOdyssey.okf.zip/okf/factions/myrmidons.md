---
type: Faction
title: "Myrmidons"
description: "Achilles' personal forces from Phthia; led into battle by Patroclus in Book XVI."
tags: [greek, achilles]
timestamp: 2026-08-16T00:00:00Z
canon: hard
established_in: /stories/the-iliad.md
provenance: human
---

# Description

The Myrmidons are the warriors of Phthia, personally commanded by
[Achilles](/characters/achilles.md). They remain in camp during Achilles' long
withdrawal, but in Book XVI, [Patroclus](/characters/patroclus.md) leads them
into battle wearing Achilles' armour. With Achilles' renewed participation from
Book XIX onward, they fight at his side through the killing of
[Hector](/characters/hector.md) and beyond. Their name and loyalty are
inseparable from their leader.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books XVI, XVIII, XIX, XX, XXI, XXII, XXIII.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XVI: Patroclus leads the Myrmidons.
