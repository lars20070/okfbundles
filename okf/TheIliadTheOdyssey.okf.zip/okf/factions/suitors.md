---
type: Faction
title: "Suitors"
description: "The 108 men from Ithaca and the surrounding islands who occupy Ulysses' palace, consume his wealth, and demand Penelope remarry."
tags: [ithaca, suitors, antagonists]
timestamp: 2026-08-16T00:00:00Z
canon: hard
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

The suitors are 108 men — sons of the leading families of Ithaca and the
neighbouring islands — who have occupied the palace of
[Ulysses](/characters/ulysses.md) in his absence, consuming his livestock and
wine, and pressing [Penelope](/characters/penelope.md) to marry one of them.
They are led by the arrogant [Antinous](/characters/antinous.md) and the
calculating [Eurymachus](/characters/eurymachus.md).

Their defining crime is the violation of [guest-friendship (xenia)](/rules/guest-friendship.md):
they are guests in another man's house who abuse their host's absence to
consume his estate. The poem treats their slaughter in Book XXII not as revenge
but as the execution of divine justice.

# Key Members

* [Antinous](/characters/antinous.md), [Eurymachus](/characters/eurymachus.md),
  Amphinomus (the most decent of them), Leiodes (the seer).

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books I–IV, XVII–XXII.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XXII: the slaughter of the suitors.
