---
type: Faction
title: "Phaeacians"
description: "A seafaring people on the island of Scheria; near-kin to the gods; they convey Ulysses home to Ithaca with gifts."
tags: [phaeacian, scheria, seafarers]
timestamp: 2026-08-16T00:00:00Z
canon: hard
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

The Phaeacians, ruled by [Alcinous](/characters/alcinous.md) and Arete on the
island of [Scheria](/locations/scheria.md), are a utopian people "near of kin to
the gods." Originally neighbours of the Cyclopes, they were led by Nausithous to
Scheria, where they built a civilisation of ships, gardens, feasts, and athletic
contests. They are the Odyssey's exemplars of proper
[guest-friendship](/rules/guest-friendship.md): they receive the shipwrecked
[Ulysses](/characters/ulysses.md) with unstinting generosity — food, games,
gifts, and the ship that carries him to [Ithaca](/locations/ithaca.md).

For this act, [Neptune](/characters/neptune.md), still persecuting Ulysses,
turns their returning ship to stone and rings Scheria with mountains. The
Phaeacians' era of conveying mortals safely home is ended.

# Key Members

* [Alcinous](/characters/alcinous.md) (king), Arete (queen),
  [Nausicaa](/characters/nausicaa.md), Demodocus (bard).

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books VI–VIII, XIII.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XIII: Neptune's punishment of the Phaeacians.
