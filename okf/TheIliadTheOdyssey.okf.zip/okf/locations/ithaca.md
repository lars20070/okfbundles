---
type: Location
title: "Ithaca"
description: "Island kingdom of Ulysses in the Ionian Sea; the destination of his ten-year journey home."
tags: [island, ithaca, home-of-ulysses]
timestamp: 2026-08-16T00:00:00Z
canon: hard
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Ithaca, the rocky island kingdom of [Ulysses](/characters/ulysses.md) in the
Ionian Sea, is the destination toward which the entire Odyssey strains. It is
described as "rough" but a "good nurse of men." When the poem opens, it has been
without its king for twenty years. The palace of Ulysses, where
[Penelope](/characters/penelope.md) and the [suitors](/factions/suitors.md)
reside, is the setting for the poem's second half (Books XIII–XXIV). Key
locations include the harbour of Phorcys (where Ulysses lands), the hut of
[Eumaeus](/characters/eumaeus.md), and the mountain Neriton. The farm of
[Laertes](/characters/laertes.md) lies outside the city.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books I–IV, XIII–XXIV.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book I: the suitors in Ithaca.
[2] [The Odyssey](/stories/the-odyssey.md) — Book XIII: Ulysses' return to Ithaca.
