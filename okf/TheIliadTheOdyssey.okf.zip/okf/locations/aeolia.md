---
type: Location
title: "Aeolia"
description: "The floating island of Aeolus, keeper of the winds, surrounded by a wall of bronze."
tags: [island, floating, winds]
timestamp: 2026-08-16T00:00:00Z
canon: hard
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Aeolia is the floating island of [Aeolus](/characters/aeolus.md), son of
Hippotas, "iron bound with a wall that girds it." Here Aeolus lives with his six
sons married to his six daughters, feasting perpetually. He gives
[Ulysses](/characters/ulysses.md) the bag of contrary winds that nearly brings
him home, but when the crew opens it, the ship is blown back. Aeolus's refusal
to help a second time marks a turning point in Ulysses' fortunes — even the
friendly powers now abandon him.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Book X.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book X: Aeolus and the bag of winds.
