---
type: Location
title: "Simois"
description: "The second river of the Trojan plain; joins the Scamander in attacking Achilles in Book XXI."
tags: [river, trojan-plain]
timestamp: 2026-08-16T00:00:00Z
canon: hard
established_in: /stories/the-iliad.md
provenance: human
---

# Description

The Simois is the smaller of the two rivers of the Trojan plain, mentioned
alongside the [Scamander](/locations/scamander.md). In Book XXI, when the
river-god Scamander attacks [Achilles](/characters/achilles.md), Simois joins
him — "Simois joins Scamander" — until both are subdued by
[Vulcan](/characters/vulcan.md)'s fire. The plain between Simois and Scamander
is the primary battlefield.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books VI, XXI.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XXI: Simois joins the river-battle.
