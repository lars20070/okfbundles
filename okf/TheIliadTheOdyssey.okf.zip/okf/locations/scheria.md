---
type: Location
title: "Scheria"
description: "Island of the Phaeacians; a utopian, seafaring kingdom where Ulysses is received with honour before being conveyed home."
tags: [island, phaeacian, utopia]
timestamp: 2026-08-16T00:00:00Z
canon: hard
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Scheria (Phaeacia) is the island of the [Phaeacians](/factions/phaeacians.md),
a seafaring people ruled by [Alcinous](/characters/alcinous.md) and Arete. It is
portrayed as a kind of earthly paradise: the palace gleams with bronze and gold,
the orchards bear fruit year-round, and the harbour is filled with ships. The
Phaeacians are "near of kin to the gods" and once lived near the Cyclopes before Nausithous led them to Scheria.

[Ulysses](/characters/ulysses.md) washes ashore in Book VI and is received with
exemplary [hospitality](/rules/guest-friendship.md): feasts, games, song, and
the gift of a ship to carry him to [Ithaca](/locations/ithaca.md). For this,
[Neptune](/characters/neptune.md) punishes the Phaeacians by turning their
returning ship to stone and ringing the island with mountains (Book XIII).

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books V–VIII, XIII.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Books VI–VIII: Ulysses among the Phaeacians.
[2] [The Odyssey](/stories/the-odyssey.md) — Book XIII: departure and Neptune's punishment.
