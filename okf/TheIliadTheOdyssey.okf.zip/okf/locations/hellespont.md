---
type: Location
title: "Hellespont"
description: "The strait separating the Troad from Thrace; the Greek ships are beached along its shore."
tags: [strait, sea, thrace]
timestamp: 2026-08-16T00:00:00Z
canon: hard
established_in: /stories/the-iliad.md
provenance: human
---

# Description

The Hellespont (modern Dardanelles) is the narrow strait that separates the
Troad from Thrace. The Greek ships are drawn up on its shore, forming the
seaward boundary of the [Grecian camp](/locations/grecian-camp.md). The Trojans'
Thracian allies, including [Rhesus](/characters/rhesus.md), cross it to join the
war.

# Appearances

* [The Iliad](/stories/the-iliad.md) — mentioned throughout; especially Books X, XVIII, XXIII.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XVIII: Achilles by the Hellespont.
