---
type: Location
title: "Olympus"
description: "The mountain home of the Olympian gods; the celestial vantage point from which they observe and intervene in the war."
tags: [mountain, gods, olympus]
timestamp: 2026-08-16T00:00:00Z
canon: hard
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Olympus is the mountain home of the twelve [Olympian Gods](/factions/olympian-gods.md).
From its "cloudy tops" and "starry hall," [Jupiter](/characters/jupiter.md)
convenes the divine council, weighs mortal fates, and issues decrees that shape
the battle below. Gods descend from Olympus to the Trojan plain and return to
it, sometimes wounded (as [Mars](/characters/mars.md) and
[Venus](/characters/venus.md) do in Book V). The poem's divine scenes — councils,
quarrels, reconciliations — all occur here. [Vulcan](/characters/vulcan.md)'s
forge is located on or within Olympus.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books I, IV, V, VIII, XIV, XV, XVIII, XX, XXI, XXIV.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book I: the quarrel of Jupiter and Juno; Vulcan's intervention.
[2] [The Iliad](/stories/the-iliad.md) — Book IV: the divine council on Olympus.
[3] [The Iliad](/stories/the-iliad.md) — Book VIII: Jupiter threatens the gods from Olympus.
