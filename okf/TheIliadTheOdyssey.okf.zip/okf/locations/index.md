# Locations

* [Troy](/locations/troy.md) - The walled city of King Priam, besieged by the Greeks for ten years.
* [Olympus](/locations/olympus.md) - The mountain home of the Olympian gods.
* [Mount Ida](/locations/mount-ida.md) - Mountain near Troy where Jupiter watches the battle.
* [Grecian Camp](/locations/grecian-camp.md) - The Greek encampment by the Hellespont, with ships drawn up on the shore.
* [Scamander](/locations/scamander.md) - River of the Trojan plain (also called Xanthus); a river-god fights Achilles in Book XXI.
* [Simois](/locations/simois.md) - The second river of the Trojan plain.
* [Chrysa](/locations/chrysa.md) - City of Chryses, priest of Apollo.
* [Hellespont](/locations/hellespont.md) - The strait separating the Troad from Thrace; the Greek ships are beached here.

## Odyssey locations

* [Ithaca](/locations/ithaca.md) - Island kingdom of Ulysses; the destination of his journey.
* [Ogygia](/locations/ogygia.md) - Remote island where Calypso detains Ulysses.
* [Aeaea](/locations/aeaea.md) - Island home of the enchantress Circe.
* [Scheria](/locations/scheria.md) - Island of the Phaeacians; a utopian seafaring kingdom.
* [Underworld](/locations/underworld.md) - The realm of the dead, visited by Ulysses in Book XI.
* [Scylla and Charybdis](/locations/scylla-and-charybdis.md) - The narrow strait of twin perils.
* [Thrinacia](/locations/thrinacia.md) - Island of the Sun-god Hyperion's sacred cattle.
* [Aeolia](/locations/aeolia.md) - Floating island of Aeolus, keeper of the winds.
* [Cyclops Island](/locations/cyclops-island.md) - Land of the one-eyed giants.
* [Sirens' Isle](/locations/sirens-isle.md) - Island of the deadly-singing Sirens.
