---
type: Location
title: "Mount Ida"
description: "Mountain near Troy; Jupiter watches the battle from its summit and is seduced there by Juno."
tags: [mountain, troy]
timestamp: 2026-08-16T00:00:00Z
canon: hard
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Mount Ida, near Troy, is where [Jupiter](/characters/jupiter.md) stations
himself to watch the battle. In Book VIII he weighs the fates of Greeks and
Trojans from its summit; in Book XIV [Juno](/characters/juno.md) seduces him
there after borrowing the [Girdle of Venus](/items/girdle-of-venus.md), putting
him to sleep so [Neptune](/characters/neptune.md) can aid the Greeks. In Book
XV, Jupiter awakens on Ida to find the battle turned.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books VIII, XIV, XV.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book VIII: Jupiter on Mount Ida.
[2] [The Iliad](/stories/the-iliad.md) — Book XIV: Juno seduces Jupiter on Mount Ida.
