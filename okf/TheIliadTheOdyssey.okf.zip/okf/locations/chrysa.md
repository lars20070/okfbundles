---
type: Location
title: "Chrysa"
description: "City sacred to Apollo; home of his priest Chryses, father of Chryseïs."
tags: [city, apollo]
timestamp: 2026-08-16T00:00:00Z
canon: hard
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Chrysa is a town sacred to [Apollo](/characters/apollo.md), home to his priest
Chryses. At the start of the poem, [Agamemnon](/characters/agamemnon.md) has
taken Chryses's daughter [Chryseïs](/characters/chryseis.md) captive. When
Chryses's ransom plea is rejected and he prays for vengeance, Apollo sends a
plague from Chrysa upon the Greek camp. [Ulysses](/characters/ulysses.md)
returns Chryseïs to Chrysa in Book I, and the Greeks offer hecatombs to appease
the god. The scene briefly shifts there in Book I.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Book I.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book I: the return of Chryseïs.
