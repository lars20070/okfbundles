---
type: Location
title: "Thrinacia"
description: "Island of the Sun-god Hyperion; his sacred cattle graze here; Ulysses' men slaughter them, dooming themselves."
tags: [island, cattle-of-the-sun, hyperion]
timestamp: 2026-08-16T00:00:00Z
canon: hard
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Thrinacia, the island of [Hyperion](/characters/hyperion.md) the Sun-god, is
home to his sacred herds — seven herds of cattle and seven flocks of sheep,
each numbering fifty, which never breed or die. [Tiresias](/characters/tiresias.md)
and [Circe](/characters/circe.md) both emphatically warn [Ulysses](/characters/ulysses.md)
not to harm them. Stranded by contrary winds and facing starvation, Ulysses'
crew slaughters the cattle while he sleeps. The hides crawl, the meat on the
spits bellows. [Hyperion](/characters/hyperion.md) demands vengeance from
[Jupiter](/characters/jupiter.md), who destroys the ship with a thunderbolt —
only Ulysses survives.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Book XII.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XII: the cattle of the Sun.
