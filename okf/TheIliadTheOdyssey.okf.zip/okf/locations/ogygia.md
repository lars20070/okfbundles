---
type: Location
title: "Ogygia"
description: "Remote island where the nymph Calypso detains Ulysses for seven years; a paradise that is also a prison."
tags: [island, calypso, ogygia]
timestamp: 2026-08-16T00:00:00Z
canon: hard
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Ogygia is a "lonely sea-girt island, far away, poor man, from all his friends"
— the domain of the nymph [Calypso](/characters/calypso.md), daughter of Atlas.
It is covered with forest, with a cave dwelling surrounded by gardens, meadows,
and four fountains. [Ulysses](/characters/ulysses.md) spends seven years here
after his shipwreck, longing daily for [Ithaca](/locations/ithaca.md). Calypso
offers him immortality and eternal youth to stay; he refuses. In Book V,
[Mercury](/characters/mercury.md) brings the command for his release, and he
builds a raft from the island's timber.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books I, V.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book V: Ulysses leaves Ogygia.
