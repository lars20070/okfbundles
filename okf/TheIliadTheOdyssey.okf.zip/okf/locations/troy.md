---
type: Location
title: "Troy"
description: "The walled city of King Priam, besieged by the Greeks for ten years; also called Ilium; defended by Hector and the Trojans."
tags: [city, troy, iliad]
timestamp: 2026-08-16T00:00:00Z
canon: hard
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Troy (Ilium), the capital of the Troad, is a walled city ruled by
[Priam](/characters/priam.md). Its key features within the poem are: the [Scaean
Gate](/locations/troy.md), before which [Hector](/characters/hector.md) dies; the
walls from which the Trojan elders and Helen watch the battle; the temple of
[Minerva](/characters/minerva.md) where [Hecuba](/characters/hecuba.md) leads
prayers; and the palace of Priam. The city is defended by the
[Trojans](/factions/trojans.md) and their allies, while the
[Greeks](/factions/greeks.md) camp on the plain below. The plain is bounded by
the rivers [Scamander](/locations/scamander.md) and
[Simois](/locations/simois.md). The war has lasted ten years when the Iliad
opens.

# Appearances

* [The Iliad](/stories/the-iliad.md) — throughout the poem; scenes within its walls in Books III, VI, XXII, XXIV.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book III: Priam and the elders on the walls.
[2] [The Iliad](/stories/the-iliad.md) — Book VI: Hector within the city.
[3] [The Iliad](/stories/the-iliad.md) — Book XXII: the death of Hector before the Scaean Gate.
[4] [The Iliad](/stories/the-iliad.md) — Book XXIV: Hector's funeral in Troy.
