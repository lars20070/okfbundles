---
type: Location
title: "Underworld"
description: "The realm of the dead (Hades), visited by Ulysses in Book XI to consult the shade of Tiresias."
tags: [underworld, hades, dead]
timestamp: 2026-08-16T00:00:00Z
canon: hard
aliases: ["Hades", "house of Hades"]
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

The Underworld (Hades), the realm of the dead, is visited by
[Ulysses](/characters/ulysses.md) in Book XI. [Circe](/characters/circe.md) has
directed him to the edge of Oceanus, where he digs a pit, pours libations, and
sacrifices sheep. The shades of the dead gather, and Ulysses speaks with:
[Tiresias](/characters/tiresias.md) (who foretells his future); his mother
Anticlea (who died of grief during his absence); and the heroes of the Trojan
War — [Agamemnon](/characters/agamemnon.md) (who tells of his murder),
[Achilles](/characters/achilles.md) (who declares he would rather be a living
slave than king of the dead), and [Ajax](/characters/ajax-the-greater.md) (who,
still angry, refuses to speak). In Book XXIV the ghosts of the slain suitors
arrive, led by [Mercury](/characters/mercury.md).

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books X (preparation), XI (the visit), XXIV (the suitors' ghosts).

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XI: Ulysses among the dead.
