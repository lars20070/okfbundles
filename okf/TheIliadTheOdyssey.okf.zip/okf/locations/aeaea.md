---
type: Location
title: "Aeaea"
description: "Island home of the enchantress Circe, where Ulysses' men are turned to swine and where Ulysses stays for a year."
tags: [island, circe, enchantment]
timestamp: 2026-08-16T00:00:00Z
canon: hard
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Aeaea is the island of [Circe](/characters/circe.md), where dawn and sunrise
occur "as in other places" — a phrase suggesting it lies at the world's eastern
edge. Circe's palace of polished stone stands in a clearing, surrounded by
tamed wolves and lions (men transformed by her drugs). Here [Ulysses](/characters/ulysses.md)
and his men stay for a year, restored from their ordeals. Circe sends Ulysses
from Aeaea to the [Underworld](/locations/underworld.md) to consult
[Tiresias](/characters/tiresias.md); on his return she provides warnings and
directions for the journey ahead.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books X, XII.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book X: arrival at Aeaea.
[2] [The Odyssey](/stories/the-odyssey.md) — Book XII: departure from Aeaea.
