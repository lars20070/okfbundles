---
type: Location
title: "Scamander"
description: "River of the Trojan plain, also called Xanthus; personified as a river-god who fights Achilles in Book XXI."
tags: [river, trojan-plain]
timestamp: 2026-08-16T00:00:00Z
canon: hard
established_in: /stories/the-iliad.md
provenance: human
---

# Description

The Scamander (also called Xanthus by the gods) is one of the two rivers of the
Trojan plain, along with the [Simois](/locations/simois.md). In Book XXI,
[Achilles](/characters/achilles.md) drives fleeing Trojans into its waters and
fills the river with corpses. The river-god Scamander, "immortal progeny of
Jove," rises against Achilles, attacking him with all his waves.
[Simois](/locations/simois.md) joins the assault.
[Neptune](/characters/neptune.md) and [Minerva](/characters/minerva.md) aid
Achilles, and finally [Vulcan](/characters/vulcan.md) dries up the river with
fire at [Juno](/characters/juno.md)'s command.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books VI, XXI.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XXI: the battle in the river Scamander.
