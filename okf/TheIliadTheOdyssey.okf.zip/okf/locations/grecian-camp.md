---
type: Location
title: "Grecian Camp"
description: "The Greek encampment on the shore of the Hellespont, with ships drawn up and a defensive wall; the base of the Greek army throughout the siege."
tags: [camp, greek, hellespont]
timestamp: 2026-08-16T00:00:00Z
canon: hard
established_in: /stories/the-iliad.md
provenance: human
---

# Description

The Grecian camp is the temporary home of the Greek army during the ten-year
siege. The ships are drawn up on the shore of the [Hellespont](/locations/hellespont.md),
and the camp includes the tents of the leaders — notably [Achilles](/characters/achilles.md)'s
pavilion — as well as a defensive wall with towers, ditch, and palisades built
on [Nestor](/characters/nestor.md)'s advice (Book VII). Much of the poem's action
takes place at or near the camp: councils, embassies, and the desperate defence
of the ships in Books XIII–XV.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books I, II, VII, IX, XI, XII, XIII, XIV, XV, XVI, XVIII, XIX, XXIII, XXIV.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book VII: building of the fortification.
[2] [The Iliad](/stories/the-iliad.md) — Book IX: the embassy in Achilles' tent.
[3] [The Iliad](/stories/the-iliad.md) — Books XIII–XV: battle at the ships.
