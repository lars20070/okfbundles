---
type: Location
title: "Scylla and Charybdis"
description: "The twin perils of a narrow strait: Scylla, a six-headed monster, and Charybdis, a whirlpool that swallows and vomits the sea."
tags: [strait, monster, whirlpool]
timestamp: 2026-08-16T00:00:00Z
canon: hard
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Scylla and Charybdis guard opposite sides of a narrow strait that
[Ulysses](/characters/ulysses.md) must pass in Book XII. Charybdis, on one side,
sucks down the sea three times a day and spews it back up — a ship caught in her
vortex is lost. Scylla, on the other, is a six-headed monster who snatches a man
from the deck with each mouth. [Circe](/characters/circe.md) advises Ulysses to
sail closer to Scylla: "Better to lose six men than all." He follows her advice
and loses six, but saves the ship.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Book XII.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XII: the passage of Scylla and Charybdis.
