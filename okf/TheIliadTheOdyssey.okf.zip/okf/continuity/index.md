# Continuity

* [Open Questions](/continuity/open-questions.md) - Unresolved matters of canon.
* [Contradictions](/continuity/contradictions.md) - Known tensions in the source material.
* [Post-Iliad Fates](/continuity/post-iliad-fates.md) - What happened to the chief actors after the poem's conclusion.
