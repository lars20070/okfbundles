---
type: Register
title: "Open Questions"
description: "Unresolved matters of canon in the Iliad world."
tags: [continuity, open-questions]
timestamp: 2026-08-16T00:00:00Z
canon: hard
provenance: human
---

# Open Questions

## Unresolved within the poem's scope

* **The death of Achilles.** Foreshadowed throughout — [Thetis](/characters/thetis.md)
  tells him two fates await (Book I), his horse [Xanthus](/items/horses-of-achilles.md)
  prophesies it (Book XIX), and the dying [Hector](/characters/hector.md)
  foretells it (Book XXII). The poem ends before it occurs. Buckley's
  [Concluding Note](/continuity/post-iliad-fates.md) records that Paris, with
  Apollo's aid, kills him with an arrow to the heel.

* **The fate of Briseïs.** Her status after the reconciliation in Book XIX is
  not addressed. She laments [Patroclus](/characters/patroclus.md) and then
  vanishes from the narrative.

* **The fall of Troy.** The most famous event of the war — the wooden horse, the
  sack — is outside the poem's scope. The Iliad ends with Hector's funeral and a
  twelve-day truce.

* **The return of the Greek heroes.** Only sketched in Buckley's Concluding
  Note: [Agamemnon](/characters/agamemnon.md) murdered,
  [Diomed](/characters/diomed.md) exiled, [Ajax](/characters/ajax-the-greater.md)
  a suicide, [Ulysses](/characters/ulysses.md) wandering,
  [Nestor](/characters/nestor.md) the sole peaceful return.

* **The fate of Aeneas after the war.** [Neptune](/characters/neptune.md) states
  Aeneas is destined to survive and rule (Book XX); Virgil's *Aeneid* develops
  this, but it is outside the Iliad.

* **The Judgment of Paris.** The root cause of [Juno](/characters/juno.md)'s and
  [Minerva](/characters/minerva.md)'s hatred of Troy is referenced obliquely
  (Book XXIV alludes to the "injury" Paris did them) but never narrated. The
  judgment predates the Iliad's timeline.

## Source-critical questions

* **The Homeric Question.** Buckley's Introduction surveys the debate over
  single vs. multiple authorship. This bundle takes Homeric authorship as given
  (per [CDR-0001](/decisions/cdr-0001.md)) but the question remains open in
  scholarship. The relationship between the Iliad and the Odyssey — whether by
  the same poet, composed at different periods, or representing different
  traditions — is a central branch of the Homeric Question.

* **The relationship of Pope's translation to the Greek.** Pope's heroic
  couplets are a creative translation, not a literal one. Where Pope embellishes
  or compresses, the Greek text stands as the ultimate authority (see
  [CDR-0001](/decisions/cdr-0001.md)), but direct comparison is beyond this
  bundle's scope.

* **The Epic Cycle.** The Iliad is one poem in a larger cycle that included the
  *Cypria* (events before the Iliad), the *Aethiopis* (Achilles' death), the
  *Little Iliad* and *Sack of Ilium* (the wooden horse and the fall of Troy),
  and the *Returns* (the homecomings of the Greek heroes). Most of these are
  lost, known only through summaries and fragments.

## Odyssey-specific questions

* **Ulysses' ultimate fate.** [Tiresias](/characters/tiresias.md) prophesies a
  "gentle death from the sea" for Ulysses (Odyssey Book XI). No surviving poem
  narrates this — it exists only as prophecy. The *Telegony* (a lost poem of the
  Epic Cycle) reportedly told of Ulysses killed unwittingly by Telegonus, his
  son by [Circe](/characters/circe.md).

* **What happened to Calypso after Book V?** Her fate after obeying the gods is
  unexplored. Her protest about the double standard applied to goddesses who
  love mortals remains one of the poem's unanswered moral questions.

* **The identity of the Phaeacians.** Their island [Scheria](/locations/scheria.md)
  has been identified (by ancient and modern scholars) with Corcyra (Corfu), but
  this is speculative. Their disappearance from history after Neptune's
  punishment leaves them in a mythological twilight.

* **The status of the Odyssey's timeline.** The Odyssey compresses Ulysses' ten
  years of wandering into a narrative that mostly occupies about forty days
  (from the council in Book I to the peace in Book XXIV), with the wanderings
  themselves narrated in flashback (Books IX–XII). The compression is even more
  extreme than the Iliad's.
