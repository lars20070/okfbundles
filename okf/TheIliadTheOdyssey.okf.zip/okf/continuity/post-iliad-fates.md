---
type: Register
title: "Post-Iliad Fates"
description: "What happened to the chief actors after the conclusion of the Iliad, as recorded in Buckley's Concluding Note and the broader Epic Cycle."
tags: [continuity, post-iliad, fates]
timestamp: 2026-08-16T00:00:00Z
canon: soft
provenance: human
---

# Post-Iliad Fates

The Iliad ends with [Hector](/characters/hector.md)'s funeral. The Concluding
Note by Theodore Alois Buckley summarises what happened afterwards, drawing from
the broader Epic Cycle and later tradition. These fates are `canon: soft` — they
are attested in the tradition but do not belong to the Iliad proper.

## Individual fates

* **[Achilles](/characters/achilles.md):** Fell before Troy, killed by an arrow
  from [Paris](/characters/paris.md) that struck his heel — the only vulnerable
  part of his body. [Hector](/characters/hector.md) had prophesied this at his
  death (Book XXII). In the [Odyssey](/stories/the-odyssey.md), his shade
  appears in the [Underworld](/locations/underworld.md) (Book XI) and declares
  he would rather be a living slave than king of the dead.

* **[Priam](/characters/priam.md):** Killed by Pyrrhus (Neoptolemus), the son
  of Achilles, during the sack of Troy.

* **[Ajax the Greater](/characters/ajax-the-greater.md):** After Achilles'
  death, he contested with [Ulysses](/characters/ulysses.md) for the right to
  inherit the armour of [Vulcan](/characters/vulcan.md). When the Greeks awarded
  it to Ulysses, Ajax killed himself in shame and rage. In the
  [Odyssey](/stories/the-odyssey.md), his shade appears in the
  [Underworld](/locations/underworld.md) (Book XI) and, still nursing his
  grievance, refuses to speak to Ulysses.

* **[Helen](/characters/helen.md):** After the death of Paris, she married his
  brother [Deiphobus](/characters/deiphobus.md). At the fall of Troy she
  betrayed Deiphobus to reconcile with [Menelaus](/characters/menelaus.md), who
  received her back into favour. In the [Odyssey](/stories/the-odyssey.md),
  [Telemachus](/characters/telemachus.md) visits her at Sparta (Book IV), where
  she is restored as queen.

* **[Agamemnon](/characters/agamemnon.md):** On his return to Mycenae, he was
  murdered by Aegysthus at the instigation of his wife Clytemnestra, who had
  taken Aegysthus as her lover during Agamemnon's absence. In the
  [Odyssey](/stories/the-odyssey.md), his shade tells the story to Ulysses in
  the [Underworld](/locations/underworld.md) (Book XI) and warns him to return
  to [Ithaca](/locations/ithaca.md) secretly.

* **[Diomed](/characters/diomed.md):** Expelled from Argos after the war and
  nearly killed by his unfaithful wife Aegiale. He fled to Apulia in Italy,
  where King Daunus received him and shared his kingdom. His manner of death is
  uncertain.

* **[Nestor](/characters/nestor.md):** Lived in peace with his children in
  Pylos, his native country, the only major Greek leader to return home without
  tragedy. In the [Odyssey](/stories/the-odyssey.md),
  [Telemachus](/characters/telemachus.md) visits him there (Book III).

* **[Ulysses](/characters/ulysses.md):** After innumerable troubles by sea and
  land — the subject of Homer's [Odyssey](/stories/the-odyssey.md) — he at last
  returned safely to [Ithaca](/locations/ithaca.md). [Tiresias](/characters/tiresias.md)
  prophesied (Odyssey Book XI) that he will eventually die "a gentle death, from
  the sea, in sleek old age."

## The fall of Troy

Troy was taken soon after Hector's death by the stratagem of the wooden horse,
described by Virgil in the second book of the Aeneid. This event, though the
most famous episode of the war, falls outside both the Iliad's and the Odyssey's
scope.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Buckley's Concluding Note.
[2] [The Odyssey](/stories/the-odyssey.md) — Book XI: Ulysses in the Underworld.
[3] Virgil, *Aeneid*, Book II — the wooden horse and the sack of Troy.
[4] Homer, *Odyssey* — the return of Ulysses.
