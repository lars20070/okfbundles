---
type: Register
title: "Contradictions"
description: "Known tensions and inconsistencies in the Iliad canon."
tags: [continuity, contradictions]
timestamp: 2026-08-16T00:00:00Z
canon: hard
provenance: human
---

# Contradictions

## Within the Iliad

* **Pylaimenes.** A Paphlagonian leader slain by [Menelaus](/characters/menelaus.md)
  in Book V, yet he appears alive in Book XIII to mourn his son Harpalion. Noted
  by ancient commentators (*scholia*) as a well-known Homeric inconsistency.

* **The Greek wall.** Built in Book VII on [Nestor](/characters/nestor.md)'s
  advice, it is presented as a massive new fortification. But the poem's
  internal timeline is in the tenth year of the siege, and earlier books show no
  awareness of its existence. The poem compresses events that would logically
  span years into a concentrated narrative.

* **The armour of Achilles.** When [Hector](/characters/hector.md) strips
  [Patroclus](/characters/patroclus.md)'s body (Book XVII), he takes the armour
  of Achilles that Patroclus was wearing. Yet in Book XVIII
  [Thetis](/characters/thetis.md) tells [Vulcan](/characters/vulcan.md) that
  Hector "has" Achilles' arms, which Vulcan replaces. The original armour's
  final disposition is never clarified — Hector presumably wears it, but this is
  not explicit after Book XVII.

* **The twelve-day hiatus.** In Book I, Thetis tells Achilles that
  [Jupiter](/characters/jupiter.md) is away feasting with the Æthiopians for
  twelve days and she cannot petition him until his return. Yet the narrative
  moves forward without marking this interval clearly; the timing is elided.

* **Cebriones.** Hector's charioteer is killed by Patroclus in Book XVI, but
  Hector is shown driving his own chariot earlier in the same book.

## Between the Iliad and the broader Epic Cycle

* **The death of Achilles.** The Iliad says he will die by "a god and fate" at
  the Scaean Gate (Hector's prophecy, Book XXII). In the lost *Aethiopis*,
  [Paris](/characters/paris.md) and [Apollo](/characters/apollo.md) kill him.
  Later tradition adds that he was invulnerable except for his heel — a detail
  absent from the Iliad.

* **The armour contest.** The Iliad does not mention the contest for Achilles'
  armour between [Ajax](/characters/ajax-the-greater.md) and
  [Ulysses](/characters/ulysses.md). Buckley's Concluding Note records it from
  the Epic Cycle.

* **Helen's subsequent marriage.** The Iliad does not mention Helen marrying
  [Deiphobus](/characters/deiphobus.md) after Paris's death. This is known from
  the Epic Cycle and later sources, recorded in Buckley's Concluding Note.

* **The Trojan Horse.** The war's most famous event is not in the Iliad. It
  belongs to the *Little Iliad* and *Sack of Ilium* (both lost), and is most
  famously narrated in Virgil's *Aeneid*, Book II.

## Translation-specific

* **Roman vs. Greek god-names.** Pope uses Roman names (Jupiter, Juno, Mars,
  Venus) throughout. This bundle follows Pope's convention for consistency
  ([CDR-0001](/decisions/cdr-0001.md)), but the names differ from the Greek
  original (Zeus, Hera, Ares, Aphrodite). Cross-references to works using Greek
  names should note this.

## Between the Iliad and the Odyssey

* **Ulysses' epithets.** In the Iliad, Ulysses is the "sacker of cities" and a
  frontline warrior. In the Odyssey, he is *polytropos* ("of many turns") and
  triumphs through cunning rather than force. The shift in character reflects
  the different genres: war epic vs. return narrative.

* **The fate of the crew.** The Odyssey's opening states Ulysses "could not
  save his men, for they perished through their own sheer folly" — yet the
  Iliad (Book X) shows Ulysses and Diomed's night raid as a joint success with
  no suggestion of his men's recklessness. The Odyssey retroactively frames the
  crew's destruction as inevitable.

* **Helen's character.** In the Iliad she is guilt-ridden and self-loathing; in
  the Odyssey (Book IV) she is poised, omniscient, and dispensing prophetic
  drugs in Sparta. The contrast may reflect different epic traditions or
  different moments in her story.

* **Neptune's role.** In the Iliad he is a steadfast Greek ally; in the Odyssey
  he is Ulysses' relentless persecutor. The shift is explained by Polyphemus's
  curse but represents a major realignment of a god's narrative function.

* **The Phaeacians' punishment.** Odyssey Book XIII: Neptune turns their ship
  to stone, ending their role as transporters of mortals. Yet in the Iliad,
  there is no hint of this limitation — the Phaeacians are not mentioned at all,
  and the Odyssey presents them as a recently isolated people.

## The Odyssey's relationship to the Epic Cycle

* **The Telemachy as a prequel.** Books I–IV of the Odyssey function as a
  self-contained coming-of-age story that also serves to connect the Odyssey to
  the Iliad's aftermath, through Telemachus's visits to
  [Nestor](/characters/nestor.md), [Menelaus](/characters/menelaus.md), and
  [Helen](/characters/helen.md).

* **The recognition scenes.** The Odyssey contains a chain of recognitions
  ([Eumaeus](/characters/eumaeus.md), [Telemachus](/characters/telemachus.md),
  the dog Argos, [Eurycleia](/characters/eurycleia.md),
  [Penelope](/characters/penelope.md), [Laertes](/characters/laertes.md)) whose
  cumulative effect is to rebuild Ulysses' identity piece by piece. This
  structure has no parallel in the Iliad, where identity is asserted and
  contested openly.
