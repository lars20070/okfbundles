# Stories

* [The Iliad](/stories/the-iliad.md) - Epic poem narrating the wrath of Achilles during the Trojan War.
* [The Odyssey](/stories/the-odyssey.md) - Epic poem narrating the return of Ulysses from Troy to Ithaca.
