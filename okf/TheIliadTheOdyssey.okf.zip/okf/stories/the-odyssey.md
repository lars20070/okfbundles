---
type: Story
title: "The Odyssey"
description: "Epic poem narrating the return of Ulysses from Troy to Ithaca and his revenge on the suitors; translated by Alexander Pope, with Flaxman's Designs."
tags: [epic-poetry, greek-mythology, odyssey, return, pope-translation]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: published
resource: https://www.gutenberg.org/ebooks/1727
pov: [/characters/ulysses.md, /characters/telemachus.md]
provenance: human
---

# Description

The Odyssey recounts the ten-year journey of [Ulysses](/characters/ulysses.md)
(Odysseus), king of [Ithaca](/locations/ithaca.md), as he struggles to return
home after the Trojan War. While [Neptune](/characters/neptune.md) persecutes
him for blinding his son [Polyphemus](/characters/polyphemus.md), Ulysses
endures the [Cyclops](/characters/polyphemus.md), the sorceress
[Circe](/characters/circe.md), the [Sirens](/characters/sirens.md),
[Scylla and Charybdis](/locations/scylla-and-charybdis.md), and the loss of
all his men. Meanwhile, in Ithaca, his wife [Penelope](/characters/penelope.md)
fends off the suitors consuming his estate, and his son
[Telemachus](/characters/telemachus.md) searches for news of him. The poem
concludes with Ulysses' return, the slaughter of the suitors, and his reunion
with Penelope.

The Odyssey is a sequel to [The Iliad](/stories/the-iliad.md), picking up after
the fall of Troy and following one of the Greek heroes on his way home.

# Structure

Twenty-four books, in Pope's heroic couplets, beginning *in medias res* with
Ulysses already detained by [Calypso](/characters/calypso.md).

## Narrative arc

1. **The Telemachy (Books I–IV):** The gods in council decree Ulysses' release.
   [Minerva](/characters/minerva.md), disguised as
   [Mentor](/characters/mentor.md), visits [Telemachus](/characters/telemachus.md)
   in [Ithaca](/locations/ithaca.md) and sends him in search of news of his
   father. He visits [Nestor](/characters/nestor.md) at
   [Pylos](/characters/nestor.md) and [Menelaus](/characters/menelaus.md) at
   Sparta, learning that Ulysses is alive on
   [Calypso](/characters/calypso.md)'s island. The
   [suitors](/factions/suitors.md) plot to ambush him on his return.

2. **Release and shipwreck (Book V):** [Mercury](/characters/mercury.md)
   commands Calypso to release Ulysses. He builds a raft, but
   [Neptune](/characters/neptune.md) wrecks it. Ulysses washes ashore on
   [Scheria](/locations/scheria.md), the land of the
   [Phaeacians](/factions/phaeacians.md).

3. **The Phaeacians (Books VI–VIII):** [Nausicaa](/characters/nausicaa.md),
   daughter of King [Alcinous](/characters/alcinous.md), finds Ulysses and
   brings him to the palace. At a banquet, the bard Demodocus sings of Troy,
   moving Ulysses to tears.

4. **The wanderings recounted (Books IX–XII):** Ulysses reveals his identity
   and narrates his adventures: the Cicones, the Lotus-eaters, the
   [Cyclops Polyphemus](/characters/polyphemus.md), [Aeolus](/characters/aeolus.md)
   and the bag of winds, the Laestrygonians, [Circe](/characters/circe.md), the
   visit to the [Underworld](/locations/underworld.md) to consult
   [Tiresias](/characters/tiresias.md), the [Sirens](/characters/sirens.md),
   [Scylla and Charybdis](/locations/scylla-and-charybdis.md), and the cattle
   of the Sun-god [Hyperion](/characters/hyperion.md) — his men's final,
   fatal transgression.

5. **Return to Ithaca (Books XIII–XVI):** The Phaeacians convey Ulysses to
   Ithaca. [Minerva](/characters/minerva.md) disguises him as a beggar. He
   shelters with the swineherd [Eumaeus](/characters/eumaeus.md), where he
   reveals himself to Telemachus, returned safely from his journey.

6. **Reconnaissance and revenge (Books XVII–XXII):** Still disguised, Ulysses
   endures abuse from the suitors and the goatherd
   [Melanthius](/characters/melanthius.md). [Penelope](/characters/penelope.md)
   sets the [contest of the bow](/events/contest-of-the-bow.md): whoever can
   string Ulysses' bow and shoot through twelve axe-heads shall marry her. Only
   Ulysses succeeds. He then slaughters the suitors with Telemachus, Eumaeus,
   and [Philoetius](/characters/philoetius.md).

7. **Recognition and peace (Books XXIII–XXIV):** Penelope tests Ulysses with
   the secret of their marriage bed; satisfied, she embraces him. The ghosts of
   the suitors arrive in Hades. Ulysses visits his aged father
   [Laertes](/characters/laertes.md). The Ithacans rise in revenge, but Minerva
   imposes peace.

# Themes

* **Nostos (homecoming).** The poem is the archetypal journey home, in which
  the hero's identity is tested, disguised, and finally recognised.
* **Xenia (guest-friendship).** The Odyssey is a sustained meditation on
  [hospitality](/rules/guest-friendship.md): the suitors violate it, the
  Phaeacians exemplify it, and the Cyclops inverts it grotesquely.
* **Cunning over strength.** Unlike Achilles, Ulysses triumphs through
  intelligence, disguise, and patience — *metis* rather than *biē*.
* **Loyalty and recognition.** The poem is structured around scenes of
  recognition: by Telemachus, by the dog Argos, by the nurse
  [Eurycleia](/characters/eurycleia.md), by Eumaeus, and finally by Penelope.

# Relationship to the Iliad

The Odyssey is a sequel to [The Iliad](/stories/the-iliad.md). It follows one
of the Greek heroes after the fall of Troy. [Nestor](/characters/nestor.md),
[Menelaus](/characters/menelaus.md), and [Helen](/characters/helen.md) appear,
already returned home. The shade of [Achilles](/characters/achilles.md) appears
in the Underworld (Book XI), and [Agamemnon](/characters/agamemnon.md)'s ghost
tells the story of his murder — already recorded in Buckley's
[Post-Iliad Fates](/continuity/post-iliad-fates.md).

# Citations

[1] [The Odyssey of Homer, translated by Alexander Pope](https://www.gutenberg.org/ebooks/1727) — Project Gutenberg eBook #1727.
