---
type: Story
title: "The Iliad"
description: "Epic poem narrating the wrath of Achilles during the Trojan War (c. 50 days in the tenth year of the siege); translated by Alexander Pope, annotated by Theodore Alois Buckley."
tags: [epic-poetry, trojan-war, homer, pope-translation]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: published
resource: https://www.gutenberg.org/ebooks/6130
pov: [/characters/achilles.md]
provenance: human
---

# Description

The Iliad recounts a fifty-day episode in the tenth year of the Trojan War: the
wrath of [Achilles](/characters/achilles.md) against
[Agamemnon](/characters/agamemnon.md), his withdrawal from battle, and his
return after the death of [Patroclus](/characters/patroclus.md), culminating in
the slaying of [Hector](/characters/hector.md) and the ransoming of his body by
[Priam](/characters/priam.md). The [Olympian gods](/factions/olympian-gods.md)
intervene throughout, taking sides and shaping events.

The poem opens *in medias res* with the quarrel over [Chryseïs](/characters/chryseis.md)
and [Briseïs](/characters/briseis.md), and closes with Hector's funeral rites at
[Troy](/locations/troy.md).

# Structure

Twenty-four books, each with a prose argument (summary) preceding Pope's heroic
couplets. Buckley supplies scholarly footnotes and a concluding note.

## Narrative arc

1. **The quarrel (Book I):** [Agamemnon](/characters/agamemnon.md) refuses
   [Chryses](/characters/chryses.md)'s ransom for [Chryseïs](/characters/chryseis.md);
   [Apollo](/characters/apollo.md) sends a plague. Agamemnon takes
   [Briseïs](/characters/briseis.md) from [Achilles](/characters/achilles.md),
   who withdraws. [Thetis](/characters/thetis.md) petitions
   [Jupiter](/characters/jupiter.md) to aid the Trojans.

2. **The war without Achilles (Books II–VIII):** The armies clash. The
   [duel](/events/duel-of-menelaus-and-paris.md) between
   [Menelaus](/characters/menelaus.md) and [Paris](/characters/paris.md) fails
   to end the war (Book III). [Diomed](/characters/diomed.md) excels, wounding
   [Venus](/characters/venus.md) and [Mars](/characters/mars.md) (Book V).
   [Hector](/characters/hector.md) bids farewell to
   [Andromache](/characters/andromache.md) (Book VI) and fights
   [Ajax](/characters/ajax-the-greater.md) to a draw (Book VII). The Trojans
   press the Greeks back to their ships (Book VIII).

3. **The embassy and its failure (Book IX):** [Ulysses](/characters/ulysses.md),
   [Ajax](/characters/ajax-the-greater.md), and [Phoenix](/characters/phoenix.md)
   [offer gifts and reconciliation](/events/embassy-to-achilles.md). Achilles
   refuses.

4. **The Greek crisis (Books X–XV):** [Diomed](/characters/diomed.md) and
   [Ulysses](/characters/ulysses.md) raid the Trojan camp at night (Book X).
   [Agamemnon](/characters/agamemnon.md) excels then is wounded (Book XI).
   [Hector](/characters/hector.md) breaches the Greek wall (Book XII).
   [Neptune](/characters/neptune.md) aids the Greeks (Book XIII).
   [Juno](/characters/juno.md) seduces [Jupiter](/characters/jupiter.md) to
   distract him (Book XIV). The Trojans reach the ships; Ajax defends almost
   alone (Book XV).

5. **Patroclus and the turning point (Book XVI–XVII):**
   [Patroclus](/characters/patroclus.md), wearing Achilles' armour, drives back
   the Trojans, kills [Sarpedon](/characters/sarpedon.md), and is
   [slain by Hector](/events/death-of-patroclus.md) (Book XVI). A fierce battle
   rages [over his body](/events/death-of-patroclus.md) (Book XVII).

6. **Achilles' return (Books XVIII–XXII):** Achilles' grief transforms to rage.
   [Thetis](/characters/thetis.md) obtains [new armour](/events/forging-of-achilles-armour.md)
   from [Vulcan](/characters/vulcan.md), including the
   [Shield](/items/shield-of-achilles.md) (Book XVIII). Achilles and Agamemnon
   [reconcile](/events/reconciliation-of-achilles-and-agamemnon.md) (Book XIX).
   The [gods join battle](/factions/olympian-gods.md) (Book XX). Achilles fights
   the [river Scamander](/locations/scamander.md) (Book XXI). He kills
   [Hector](/characters/hector.md) before the walls of Troy (Book XXII).

7. **Resolution (Books XXIII–XXIV):** Achilles holds
   [funeral games](/events/funeral-games-for-patroclus.md) for Patroclus (Book
   XXIII). [Priam](/characters/priam.md), guided by
   [Mercury](/characters/mercury.md), [ransoms Hector's body](/events/redemption-of-hectors-body.md),
   and the poem ends with Hector's funeral (Book XXIV).

# Themes

* **Wrath and its consequences.** The poem's first word (in Greek: *mēnin*,
  "wrath") announces its subject. Achilles' anger — first at Agamemnon, then at
  Hector — drives every event.
* **Honour and shame.** The heroic code is governed by [honour and
  shame](/rules/honour-and-shame.md): warriors fight for reputation, and
  disgrace is worse than death.
* **Mortality and the heroic choice.** [Achilles](/characters/achilles.md)
  chose a short, glorious life over a long, obscure one. The poem constantly
  juxtaposes mortal transience against divine immortality.
* **Fate and free will.** [Fate](/rules/fate-is-fixed.md) is fixed, but
  characters make real choices that shape how fate arrives. Hector *chooses* to
  stand; Achilles *chooses* to return.

# Fates after the poem

The Iliad ends before the fall of Troy. [Post-Iliad fates](/continuity/post-iliad-fates.md)
(soft canon) record that: Achilles fell to Paris's arrow; Priam was killed by
Pyrrhus; Ajax committed suicide; Agamemnon was murdered on his return; Diomed
was exiled; Nestor alone returned home peacefully; Ulysses wandered for ten
years before reaching Ithaca.

# Citations

[1] [The Iliad of Homer, translated by Alexander Pope](https://www.gutenberg.org/ebooks/6130) — Project Gutenberg eBook #6130.
