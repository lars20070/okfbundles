---
type: Item
title: "Shield of Achilles"
description: "The wondrous shield forged by Vulcan for Achilles, depicting the cosmos and the full cycle of human life in concentric scenes."
tags: [achilles, vulcan, shield, artefact]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: intact
established_in: /stories/the-iliad.md
provenance: human
---

# Description

The Shield of Achilles is the centrepiece of the armour forged by
[Vulcan](/characters/vulcan.md) in Book XVIII and one of the most celebrated
ekphrastic passages in Western literature. Vulcan decorates it with scenes of:

- The earth, sky, sea, sun, moon, and stars.
- Two cities: one at peace (a wedding feast, a legal dispute) and one at war (a
  siege, an ambush).
- Fields being ploughed, a king's harvest, and a vineyard heavy with grapes.
- A herd of cattle attacked by lions.
- A dancing-floor with young men and women.
- The river Ocean flowing around the rim.

The shield is a microcosm of the mortal world that Achilles will leave behind.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Book XVIII (description of the forging).

# Relationships

Part of the [Armour of Achilles](/items/armour-of-achilles.md). Forged by
[Vulcan](/characters/vulcan.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XVIII: the shield of Achilles.
