---
type: Item
title: "Girdle of Venus"
description: "The magic cestus (girdle) of Venus, containing all the powers of love and desire; borrowed by Juno to seduce Jupiter."
tags: [venus, juno, seduction, magic]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: intact
established_in: /stories/the-iliad.md
provenance: human
---

# Description

The girdle (cestus) of [Venus](/characters/venus.md) is a magical embroidered
band worn across the breast, imbued with all the powers of love, desire, and
seduction. In Book XIV, [Juno](/characters/juno.md) asks Venus for it,
pretending she needs to reconcile Oceanus and Tethys. Venus, unsuspecting,
removes it and lends it to her. Juno uses it to seduce
[Jupiter](/characters/jupiter.md) on [Mount Ida](/locations/mount-ida.md) so
that [Neptune](/characters/neptune.md) can aid the Greeks while Jupiter sleeps.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Book XIV.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XIV: Juno borrows the girdle of Venus.
