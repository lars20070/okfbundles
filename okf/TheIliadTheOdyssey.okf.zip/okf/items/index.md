# Items

* [Armour of Achilles](/items/armour-of-achilles.md) - The divine armour forged by Vulcan in Book XVIII, including the Shield of Achilles.
* [Shield of Achilles](/items/shield-of-achilles.md) - The wondrous shield depicting the cosmos, cities at peace and war, and the cycle of human life.
* [Horses of Achilles](/items/horses-of-achilles.md) - The immortal horses Xanthus and Balius; Xanthus prophesies Achilles' death in Book XIX.
* [Horses of Rhesus](/items/horses-of-rhesus.md) - The famous white horses of the Thracian king, captured by Diomed and Ulysses in Book X.
* [Girdle of Venus](/items/girdle-of-venus.md) - The magic cestus that Juno borrows to seduce Jupiter in Book XIV.
* [Aegis of Apollo](/items/aegis-of-apollo.md) - The divine shield Apollo bears when he leads the Trojans in Book XV.

## Odyssey items

* [Bow of Ulysses](/items/bow-of-ulysses.md) - The great bow that only Ulysses can string; the instrument of the suitors' destruction.
