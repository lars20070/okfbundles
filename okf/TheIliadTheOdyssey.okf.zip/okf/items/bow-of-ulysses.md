---
type: Item
title: "Bow of Ulysses"
description: "The great bow of Ulysses, stored in the palace during his absence; only he can string it; the instrument of the suitors' destruction."
tags: [ulysses, bow, contest]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: intact
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

The bow of [Ulysses](/characters/ulysses.md) is a recurve bow of immense draw
weight, stored in the treasury of the palace at [Ithaca](/locations/ithaca.md)
during the hero's absence. In Book XXI, [Penelope](/characters/penelope.md)
brings it forth for the [contest](/events/contest-of-the-bow.md): whoever can
string it and shoot through twelve axe-heads shall marry her. The suitors
attempt in vain; only Ulysses can bend it. The moment he strings the bow — as
easily "as when a bard strings a new chord upon his lyre" — signals the end of
his disguise and the beginning of the slaughter.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Book XXI.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XXI: the bow of Ulysses.
