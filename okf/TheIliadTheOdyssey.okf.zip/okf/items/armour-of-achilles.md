---
type: Item
title: "Armour of Achilles"
description: "The divine armour forged by Vulcan in Book XVIII, replacing the set lost when Hector stripped Patroclus's body."
tags: [achilles, vulcan, armour]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: intact
established_in: /stories/the-iliad.md
provenance: human
---

# Description

After [Hector](/characters/hector.md) strips the body of
[Patroclus](/characters/patroclus.md) (who was wearing Achilles' original
armour), [Thetis](/characters/thetis.md) commissions
[Vulcan](/characters/vulcan.md) to forge a new set for her son. The armour
consists of a helmet with a golden crest, a breastplate, greaves, and the
magnificent [Shield of Achilles](/items/shield-of-achilles.md). The set is
indestructible and divinely crafted, marking Achilles' return to battle in Book
XIX. Its creation is described in detail in Book XVIII.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books XVIII (forging), XIX (delivery and arming), XX–XXII (in battle).

# Relationships

Forged by [Vulcan](/characters/vulcan.md). Commissioned by
[Thetis](/characters/thetis.md). Worn by [Achilles](/characters/achilles.md).
The original set was lost when [Hector](/characters/hector.md) took it from
[Patroclus](/characters/patroclus.md)'s body (Book XVII).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XVIII: Vulcan forges the armour.
[2] [The Iliad](/stories/the-iliad.md) — Book XIX: Thetis delivers the armour; Achilles arms.
