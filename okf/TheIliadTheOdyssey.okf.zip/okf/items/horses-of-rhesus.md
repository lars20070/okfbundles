---
type: Item
title: "Horses of Rhesus"
description: "The famous white horses of the Thracian king Rhesus, captured by Diomed and Ulysses in their night raid (Book X)."
tags: [rhesus, horses, thracian, night-raid]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: intact
established_in: /stories/the-iliad.md
provenance: human
---

# Description

The horses of [Rhesus](/characters/rhesus.md), king of Thrace, are described as
the finest and largest horses in the world, whiter than snow and swift as the
wind. In Book X, [Diomed](/characters/diomed.md) and
[Ulysses](/characters/ulysses.md) infiltrate the Trojan camp at night, kill the
sleeping Rhesus, and drive the horses back to the Greek camp in triumph.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Book X.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book X: the night-adventure of Diomed and Ulysses.
