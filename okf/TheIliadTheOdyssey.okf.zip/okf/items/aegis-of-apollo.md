---
type: Item
title: "Aegis of Apollo"
description: "The divine shield borne by Apollo when he leads the Trojans in Book XV; a symbol of divine terror and protection."
tags: [apollo, shield, divine]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: intact
established_in: /stories/the-iliad.md
provenance: human
---

# Description

The aegis is a divine shield or breastplate associated primarily with
[Jupiter](/characters/jupiter.md) and [Minerva](/characters/minerva.md), but in
Book XV [Apollo](/characters/apollo.md) bears it as he marches before the
Trojans, reinspiring [Hector](/characters/hector.md) and turning the tide of
battle. Its appearance radiates terror; when Apollo shakes it, the Greeks are
thrown into confusion and the Trojan assault on the ships becomes irresistible.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Book XV.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XV: Apollo leads the Trojans with his aegis.
