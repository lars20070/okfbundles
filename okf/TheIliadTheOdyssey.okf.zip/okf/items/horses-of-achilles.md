---
type: Item
title: "Horses of Achilles"
description: "The immortal horses Xanthus and Balius; Xanthus is given voice and prophesies Achilles' death in Book XIX."
tags: [achilles, horses, prophecy]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: intact
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Achilles' chariot is drawn by two immortal horses, Xanthus and Balius, offspring
of the West Wind (Zephyrus) and the harpy Podarge. In Book XVII they weep for
[Patroclus](/characters/patroclus.md), and [Jupiter](/characters/jupiter.md)
pities them. In Book XIX, as Achilles mounts his chariot, [Juno](/characters/juno.md)
endows Xanthus with human speech: the horse prophesies that Achilles will die
soon — not through any fault of the horses, but by "a god and fate." Achilles,
undeterred, charges into battle.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books XVI, XVII, XIX.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XIX: Xanthus prophesies Achilles' death.
