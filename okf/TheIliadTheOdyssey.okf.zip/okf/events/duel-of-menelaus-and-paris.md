---
type: Event
title: "Duel of Menelaus and Paris"
description: "Paris challenges the Greeks; Menelaus defeats him but Venus rescues Paris in a cloud, preventing a settlement of the war."
tags: [menelaus, paris, duel, venus]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 3.0
location: /locations/troy.md
participants: [/characters/menelaus.md, /characters/paris.md, /characters/hector.md, /characters/helen.md, /characters/priam.md, /characters/venus.md, /characters/iris.md, /characters/agamemnon.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Book III. The armies are about to engage when [Hector](/characters/hector.md)
proposes that [Paris](/characters/paris.md) and [Menelaus](/characters/menelaus.md)
settle the war by single combat: the winner takes [Helen](/characters/helen.md).
[Iris](/characters/iris.md) summons Helen to the walls, where she joins
[Priam](/characters/priam.md) and identifies the Greek leaders — the
*teichoscopia*. The kings of both sides swear oaths, and the duel begins.
Menelaus overpowers Paris, but as he drags him by the helmet,
[Venus](/characters/venus.md) snaps the chin-strap and transports Paris to his
chamber in a cloud. She compels Helen to join him. [Agamemnon](/characters/agamemnon.md)
declares Menelaus the victor and demands Helen's return.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book III: the duel of Menelaus and Paris.
