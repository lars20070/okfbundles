---
type: Event
title: "The Visit to the Underworld"
description: "Ulysses descends to Hades, consults Tiresias, and speaks with the shades of the dead — including his mother, Agamemnon, and Achilles."
tags: [ulysses, underworld, tiresias, achilles, agamemnon]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 64.0
location: /locations/underworld.md
participants: [/characters/ulysses.md, /characters/tiresias.md, /characters/achilles.md, /characters/agamemnon.md, /characters/ajax-the-greater.md, /characters/circe.md]
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Odyssey Book XI (the *Nekyia*). Following [Circe](/characters/circe.md)'s
instructions, [Ulysses](/characters/ulysses.md) sails to the edge of the world,
to the land of the Cimmerians "wrapped in mist and cloud." He digs a pit, pours
libations of milk, honey, wine, and water, and sacrifices a black ram and ewe.
The shades of the dead flock to drink the blood and speak.

[Tiresias](/characters/tiresias.md), the blind Theban prophet, drinks first
and foretells the path home: Ulysses will reach [Ithaca](/locations/ithaca.md),
but must not harm the cattle of the [Sun](/characters/hyperion.md) on
[Thrinacia](/locations/thrinacia.md). He also prophesies Ulysses' eventual death
— "a gentle death, from the sea, in sleek old age."

Ulysses then speaks with his mother Anticlea, who died of grief during his
absence. The parade of heroines and heroes follows. Most striking are the
encounters with his fallen comrades from [Troy](/locations/troy.md):
[Agamemnon](/characters/agamemnon.md), who tells of his murder by Aegysthus
and Clytemnestra and warns Ulysses to return secretly ("never be too kind to
your wife"); [Achilles](/characters/achilles.md), who delivers the poem's
most famous statement on mortality — "I would rather be a hired servant to a
landless man, with scarcely enough to live on, than king of all the dead"; and
[Ajax](/characters/ajax-the-greater.md), who, still nursing his grievance over
the armour, refuses to speak and stalks away in silence.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XI: the visit to the dead.
