---
type: Event
title: "The Plague of Apollo"
description: "Apollo sends a nine-day plague on the Greek camp after Agamemnon refuses Chryses's ransom for Chryseïs; the crisis that opens the Iliad."
tags: [apollo, plague, chryses, agamemnon]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 0.5
location: /locations/grecian-camp.md
participants: [/characters/apollo.md, /characters/agamemnon.md, /characters/chryses.md, /characters/chryseis.md, /characters/achilles.md, /characters/calchas.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Book I. [Chryses](/characters/chryses.md), priest of
[Apollo](/characters/apollo.md), comes to the Greek camp bearing rich ransom
for his daughter [Chryseïs](/characters/chryseis.md), held captive by
[Agamemnon](/characters/agamemnon.md). Agamemnon refuses and dismisses the old
priest with threats. Chryses prays to Apollo, who "heard his prayer" and
descended from [Olympus](/locations/olympus.md) "with his bow and his covered
quiver." For nine days the god's arrows — invisible shafts of plague — struck
the Greek camp. Funeral pyres burned continuously.

On the tenth day, [Achilles](/characters/achilles.md) called a council.
[Calchas](/characters/calchas.md), the seer, revealed the cause: the plague
would not lift until Chryseïs was returned to her father without ransom and a
hecatomb offered to Apollo. Agamemnon, enraged at Calchas and at the loss of
his prize, agreed — but seized [Briseïs](/characters/briseis.md) from Achilles
in compensation, setting the poem's central conflict in motion. Chryseïs was
returned by [Ulysses](/characters/ulysses.md), the sacrifice was made, and the
plague ceased.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book I: Apollo's plague and its lifting.
