---
type: Event
title: "The Battle of the Gods"
description: "Jupiter permits the Olympians to join the battle openly; the gods clash on the Trojan plain while Achilles drives all before him."
tags: [gods, battle, achilles, divine-war]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 20.0
location: /locations/troy.md
participants: [/characters/jupiter.md, /characters/juno.md, /characters/minerva.md, /characters/apollo.md, /characters/venus.md, /characters/mars.md, /characters/neptune.md, /characters/vulcan.md, /characters/achilles.md, /characters/aeneas.md, /characters/hector.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Book XX. With [Achilles](/characters/achilles.md) returned to battle,
[Jupiter](/characters/jupiter.md) lifts his prohibition on divine intervention
and permits the gods to join whichever side they choose. The Olympians descend:
[Juno](/characters/juno.md), [Minerva](/characters/minerva.md),
[Neptune](/characters/neptune.md), [Vulcan](/characters/vulcan.md), and
[Mercury](/characters/mercury.md) for the Greeks; [Apollo](/characters/apollo.md),
[Venus](/characters/venus.md), [Mars](/characters/mars.md), and
[Diana](/characters/diana.md) for the Trojans. The clash of immortal powers is
described as shaking the foundations of the earth and the depths of Tartarus.

On the mortal plane, [Apollo](/characters/apollo.md) encourages
[Aeneas](/characters/aeneas.md) to face Achilles. After an extended exchange —
in which Aeneas recites his divine lineage and Achilles mocks him for fleeing
before — they fight, but [Neptune](/characters/neptune.md) saves Aeneas,
declaring that fate has destined him to survive the war. Achilles then pursues
the Trojans in a furious rampage, nearly catching
[Hector](/characters/hector.md) before [Apollo](/characters/apollo.md) hides him
in a cloud. The theomachy proper erupts in Book XXI, where gods fight gods.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XX: the battle of the gods.
[2] [The Iliad](/stories/the-iliad.md) — Book XXI: the theomachy (gods fighting gods).
