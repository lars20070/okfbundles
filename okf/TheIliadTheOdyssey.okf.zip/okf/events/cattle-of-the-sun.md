---
type: Event
title: "The Cattle of the Sun"
description: "Stranded on Thrinacia, Ulysses' starving men slaughter Hyperion's sacred cattle; Jupiter destroys the ship with a thunderbolt, killing all but Ulysses."
tags: [hyperion, ulysses, cattle, shipwreck, divine-vengeance]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 68.0
location: /locations/thrinacia.md
participants: [/characters/ulysses.md, /characters/hyperion.md, /characters/jupiter.md, /characters/circe.md, /characters/tiresias.md]
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Odyssey Book XII. Both [Tiresias](/characters/tiresias.md) and
[Circe](/characters/circe.md) had warned [Ulysses](/characters/ulysses.md): do
not harm the cattle of the Sun-god [Hyperion](/characters/hyperion.md) on
[Thrinacia](/locations/thrinacia.md). But after passing
[Scylla and Charybdis](/locations/scylla-and-charybdis.md), contrary winds
strand the ship on Thrinacia for a month. Their provisions exhausted, the crew
faces starvation.

While Ulysses sleeps — having gone inland to pray — Eurylochus convinces the
men: "All deaths are hateful to miserable mortals, but death by hunger is far
the worst." They slaughter the sacred cattle. The portents are immediate and
terrible: the hides crawl, and the meat on the spits bellows.

Hyperion demands vengeance from [Jupiter](/characters/jupiter.md), threatening
to shine only in Hades if it is denied. When the ship sails again, Jupiter
raises a storm and strikes it with a thunderbolt. The mast falls, the ship
shatters, and every man is drowned — all except Ulysses, who clings to wreckage
and drifts back past [Charybdis](/locations/scylla-and-charybdis.md). Nine days
later, he washes ashore on [Ogygia](/locations/ogygia.md), where
[Calypso](/characters/calypso.md) finds him. This is the final, fatal
transgression that ensures Ulysses reaches home alone, fulfilling
[Polyphemus](/characters/polyphemus.md)'s curse.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XII: the cattle of the Sun.
