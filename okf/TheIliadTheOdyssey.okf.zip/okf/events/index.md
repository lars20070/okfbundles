# Events

## Iliad events

* [The Plague of Apollo](/events/plague-of-apollo.md) - Apollo's plague forces Agamemnon to return Chryseïs (Book I).
* [Quarrel of Achilles and Agamemnon](/events/quarrel-of-achilles-and-agamemnon.md) - Agamemnon seizes Briseïs; Achilles withdraws (Book I).
* [Duel of Menelaus and Paris](/events/duel-of-menelaus-and-paris.md) - Single combat; Venus rescues Paris (Book III).
* [Embassy to Achilles](/events/embassy-to-achilles.md) - Ulysses, Ajax, and Phoenix fail to persuade Achilles (Book IX).
* [The Night Raid of Diomed and Ulysses](/events/night-raid-of-diomed-and-ulysses.md) - Spies kill Rhesus and capture his horses (Book X).
* [Juno Deceives Jupiter](/events/juno-deceives-jupiter.md) - Juno seduces Jupiter on Mount Ida (Book XIV).
* [Death of Patroclus](/events/death-of-patroclus.md) - Patroclus slain by Hector (Book XVI).
* [Forging of Achilles' Armour](/events/forging-of-achilles-armour.md) - Thetis commissions Vulcan (Book XVIII).
* [Reconciliation of Achilles and Agamemnon](/events/reconciliation-of-achilles-and-agamemnon.md) - The two leaders reconcile (Book XIX).
* [The Battle of the Gods](/events/battle-of-the-gods.md) - Jupiter permits the gods to join battle (Books XX–XXI).
* [Death of Hector](/events/death-of-hector.md) - Achilles slays Hector (Book XXII).
* [Funeral Games for Patroclus](/events/funeral-games-for-patroclus.md) - Athletic contests in Patroclus's honour (Book XXIII).
* [Redemption of Hector's Body](/events/redemption-of-hectors-body.md) - Priam ransoms his son (Book XXIV).

## Odyssey events

* [Minerva Rouses Telemachus](/events/minerva-rouses-telemachus.md) - Gods decree Ulysses' return; Telemachus begins his journey (Book I).
* [Ulysses Departs Ogygia](/events/ulysses-departs-ogygia.md) - Calypso releases Ulysses; Neptune wrecks his raft (Book V).
* [Ulysses and Nausicaa](/events/ulysses-and-nausicaa.md) - Shipwrecked Ulysses encounters the Phaeacian princess (Book VI).
* [The Cyclops Episode](/events/cyclops-episode.md) - Ulysses blinds Polyphemus, incurring Neptune's curse (Book IX).
* [Circe's Transformation](/events/circes-transformation.md) - Enchantress turns men to swine; Ulysses overcomes her (Book X).
* [The Visit to the Underworld](/events/visit-to-the-underworld.md) - Ulysses consults Tiresias and speaks with the dead (Book XI).
* [The Cattle of the Sun](/events/cattle-of-the-sun.md) - Crew slaughters sacred cattle; Jupiter destroys the ship (Book XII).
* [Ulysses Returns to Ithaca](/events/ulysses-returns-to-ithaca.md) - Phaeacians convey him home; Minerva disguises him (Book XIII).
* [Contest of the Bow](/events/contest-of-the-bow.md) - Penelope's contest; only Ulysses strings the bow (Book XXI).
* [Slaughter of the Suitors](/events/slaughter-of-the-suitors.md) - Ulysses kills all 108 suitors (Book XXII).
* [Recognition by Penelope](/events/recognition-by-penelope.md) - The test of the marriage bed (Book XXIII).
* [Peace in Ithaca](/events/peace-in-ithaca.md) - Minerva imposes peace; the poem ends (Book XXIV).
