---
type: Event
title: "Funeral Games for Patroclus"
description: "Achilles holds funeral rites for Patroclus, including the sacrifice of twelve Trojan captives, followed by athletic contests."
tags: [patroclus, achilles, funeral, games]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 23.0
location: /locations/grecian-camp.md
participants: [/characters/achilles.md, /characters/patroclus.md, /characters/antilochus.md, /characters/diomed.md, /characters/ulysses.md, /characters/ajax-the-greater.md, /characters/ajax-the-lesser.md, /characters/menelaus.md, /characters/meriones.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Book XXIII. After Hector's death, [Achilles](/characters/achilles.md) and the
[Myrmidons](/factions/myrmidons.md) honour [Patroclus](/characters/patroclus.md)'s
body. That night, Patroclus's ghost appears to the sleeping Achilles, demanding
burial. The next day, mules and wagons fetch wood for the pyre. In a grand
funeral procession, the Myrmidons cut their hair and lay it on the body.
Achilles sacrifices animals and twelve Trojan captives on the pyre, then lights
it. [Iris](/characters/iris.md) summons the winds to fan the flames. After
burning all night, the bones are gathered into a golden urn and a tomb is
raised.

Achilles then institutes funeral games: chariot race (won by
[Diomed](/characters/diomed.md) after [Minerva](/characters/minerva.md)
intervenes), boxing (won by Epeus), wrestling (draw between
[Ajax](/characters/ajax-the-greater.md) and [Ulysses](/characters/ulysses.md)),
footrace, single combat, discus, archery, and javelin. The games demonstrate
Achilles' return to the Greek community through ritual and sport.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XXIII: funeral games for Patroclus.
