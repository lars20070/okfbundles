---
type: Event
title: "Reconciliation of Achilles and Agamemnon"
description: "The two leaders publicly reconcile; Agamemnon admits fault and offers gifts; Achilles arms for battle with Vulcan's armour."
tags: [achilles, agamemnon, reconciliation]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 19.0
location: /locations/grecian-camp.md
participants: [/characters/achilles.md, /characters/agamemnon.md, /characters/thetis.md, /characters/ulysses.md, /characters/briseis.md, /characters/minerva.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Book XIX. [Thetis](/characters/thetis.md) delivers the new armour from
[Vulcan](/characters/vulcan.md) and preserves [Patroclus](/characters/patroclus.md)'s
body from corruption. [Achilles](/characters/achilles.md) assembles the army and
declares his wrath at an end. [Agamemnon](/characters/agamemnon.md) publicly
admits his fault — blaming Ate (Ruin), whom even Jupiter cannot resist — and
offers the promised gifts. [Ulysses](/characters/ulysses.md) advises that the
troops eat before battle; Achilles refuses all food. [Briseïs](/characters/briseis.md)
laments over Patroclus's body. [Minerva](/characters/minerva.md), sent by
[Jupiter](/characters/jupiter.md), descends to strengthen the fasting Achilles.
He arms, and as he mounts his chariot, his horse [Xanthus](/items/horses-of-achilles.md)
miraculously speaks, prophesying his death — but Achilles rushes to battle
regardless.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XIX: the reconciliation.
