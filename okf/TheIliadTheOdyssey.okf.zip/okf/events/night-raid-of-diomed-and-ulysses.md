---
type: Event
title: "The Night Raid of Diomed and Ulysses"
description: "Diomed and Ulysses infiltrate the Trojan camp by night, capture the spy Dolon, kill the Thracian king Rhesus, and seize his famous horses."
tags: [diomed, ulysses, night-raid, rhesus, dolon]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 10.0
location: /locations/troy.md
participants: [/characters/diomed.md, /characters/ulysses.md, /characters/dolon.md, /characters/rhesus.md, /characters/hector.md, /characters/agamemnon.md, /characters/nestor.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Book X (the *Doloneia*). After the failed [embassy to Achilles](/events/embassy-to-achilles.md),
[Agamemnon](/characters/agamemnon.md) cannot sleep. He rouses the Greek leaders
and a council decides to send spies into the Trojan camp.
[Diomed](/characters/diomed.md) volunteers and chooses
[Ulysses](/characters/ulysses.md) as his companion.

In the no-man's-land between the armies, they capture [Dolon](/characters/dolon.md),
a Trojan sent on a reciprocal spy mission by [Hector](/characters/hector.md).
Dolon, begging for his life, reveals the positions of the Trojan allies and the
recent arrival of [Rhesus](/characters/rhesus.md), the Thracian king, with his
famous [white horses](/items/horses-of-rhesus.md). Diomed kills Dolon.

The two Greeks infiltrate the sleeping Thracian camp. Diomed slaughters Rhesus
and twelve of his men; Ulysses drags the bodies aside to clear a path for the
horses. They ride the captured horses back to the Greek camp in triumph — one of
the few unambiguous Greek successes while Achilles is absent.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book X: the night-adventure of Diomed and Ulysses.
