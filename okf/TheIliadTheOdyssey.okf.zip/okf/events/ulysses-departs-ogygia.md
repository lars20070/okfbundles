---
type: Event
title: "Ulysses Departs Ogygia"
description: "Mercury commands Calypso to release Ulysses; she reluctantly helps him build a raft; Neptune wrecks it, and Ulysses swims to Scheria."
tags: [ulysses, calypso, mercury, neptune, ogygia]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 55.0
location: /locations/ogygia.md
participants: [/characters/ulysses.md, /characters/calypso.md, /characters/mercury.md, /characters/jupiter.md, /characters/neptune.md, /characters/minerva.md]
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Odyssey Book V. [Mercury](/characters/mercury.md), bound in his golden sandals
and bearing his wand, skims the waves to [Ogygia](/locations/ogygia.md), the
remote island of [Calypso](/characters/calypso.md). He finds the nymph in her
fragrant cave, singing at her loom. He delivers [Jupiter](/characters/jupiter.md)'s
command: Ulysses must be released to return home on a raft, "after a perilous
voyage of twenty days," to [Scheria](/locations/scheria.md), where the
[Phaeacians](/factions/phaeacians.md) will honour him and convey him to
[Ithaca](/locations/ithaca.md).

Calypso protests bitterly. She saved Ulysses from shipwreck, offered him
immortality, and loved him — yet the gods, who freely take mortal lovers, deny
goddesses the same right. Nevertheless, she obeys. She gives Ulysses tools, and
he builds a raft from twenty trees. She provides provisions, clothing, and a
fair wind.

For seventeen days Ulysses sails, navigating by the stars. On the eighteenth,
[Neptune](/characters/neptune.md), returning from Ethiopia, sees him and rages:
"So the gods have changed their minds about Ulysses while I was away!" He raises
a storm that shatters the raft. Ulysses clings to a single beam. The sea-nymph
Ino (Leucothea) gives him her immortal veil, which will keep him from drowning.
After two days and nights in the water, [Minerva](/characters/minerva.md) calms
the waves, and Ulysses swims ashore on [Scheria](/locations/scheria.md), naked
and exhausted.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book V: Ulysses departs Ogygia and reaches Scheria.
