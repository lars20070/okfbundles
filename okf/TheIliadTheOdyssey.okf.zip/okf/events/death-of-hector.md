---
type: Event
title: "Death of Hector"
description: "Achilles chases Hector thrice around Troy's walls; Minerva deceives Hector; Achilles kills him and drags his body behind his chariot."
tags: [hector, achilles, death, climactic-duel]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 22.0
location: /locations/troy.md
participants: [/characters/hector.md, /characters/achilles.md, /characters/minerva.md, /characters/priam.md, /characters/hecuba.md, /characters/andromache.md, /characters/apollo.md, /characters/jupiter.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Book XXII. The Trojans having retreated inside the walls, [Hector](/characters/hector.md)
alone remains outside to face [Achilles](/characters/achilles.md).
[Priam](/characters/priam.md) and [Hecuba](/characters/hecuba.md) plead from the
walls; Hector wavers, but when Achilles approaches, his courage fails and he
flees. Achilles chases him three times around the walls of Troy.
[Jupiter](/characters/jupiter.md) weighs their fates on his golden scales:
Hector's sinks. [Minerva](/characters/minerva.md) descends, takes the form of
Hector's brother Deiphobus, and convinces Hector to stand. When Hector turns to
face Achilles, Deiphobus vanishes — Hector knows he is doomed. Achilles kills
him with a spear-thrust to the throat, the only place his armour leaves exposed.
He then ties the body to his chariot and drags it before the walls as Priam,
Hecuba, and [Andromache](/characters/andromache.md) lament from the
battlements.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XXII: the death of Hector.
