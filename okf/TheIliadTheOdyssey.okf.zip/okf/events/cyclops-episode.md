---
type: Event
title: "The Cyclops Episode"
description: "Ulysses and his men are trapped by Polyphemus; Ulysses blinds the Cyclops with a sharpened stake, escapes beneath the sheep, and — fatally — reveals his name."
tags: [ulysses, polyphemus, cyclops, neptune, curse]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 60.0
location: /locations/cyclops-island.md
participants: [/characters/ulysses.md, /characters/polyphemus.md, /characters/neptune.md]
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Odyssey Book IX. On the land of the [Cyclopes](/locations/cyclops-island.md),
[Ulysses](/characters/ulysses.md) and twelve men explore a cave stocked with
cheeses, lambs, and kids. The owner, [Polyphemus](/characters/polyphemus.md)
— a one-eyed giant, son of [Neptune](/characters/neptune.md) — returns at
evening, rolls a boulder across the entrance, and eats two men.

Trapped, Ulysses devises his escape. He gets Polyphemus drunk on undiluted wine
and tells him his name is "Nobody" (*Outis*). While the giant sleeps, Ulysses
and his men heat an olive stake in the fire and drive it into Polyphemus's
single eye. The Cyclops roars in agony; when his neighbours ask who hurts him,
he cries, "Nobody is killing me!" — and they leave.

At dawn, Ulysses ties his men beneath the bellies of the rams and himself clings
to the largest. As the blinded giant feels his sheep's backs, he misses the men
beneath. Safely aboard ship, Ulysses cannot resist: he shouts his real name —
"Ulysses, son of Laertes, sacker of cities!" — to the enraged Cyclops.
Polyphemus prays to his father Neptune: let Ulysses never reach home, or reach
it "late, in misery, in another's ship, and find troubles in his house." Neptune
hears, and becomes Ulysses' relentless persecutor. This single boast drives the
entire Odyssey.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book IX: the Cyclops episode.
