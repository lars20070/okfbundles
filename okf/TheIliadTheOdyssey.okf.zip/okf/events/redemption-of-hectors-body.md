---
type: Event
title: "Redemption of Hector's Body"
description: "Priam, guided by Mercury, enters the Greek camp alone, kneels before Achilles, and ransoms his son's body for burial."
tags: [priam, achilles, hector, ransom, resolution]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 24.0
location: /locations/grecian-camp.md
participants: [/characters/priam.md, /characters/achilles.md, /characters/hector.md, /characters/mercury.md, /characters/thetis.md, /characters/jupiter.md, /characters/iris.md, /characters/hecuba.md, /characters/andromache.md, /characters/helen.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Book XXIV. The gods debate the fate of Hector's body, which
[Achilles](/characters/achilles.md) continues to abuse. [Jupiter](/characters/jupiter.md)
sends [Thetis](/characters/thetis.md) to persuade her son to accept ransom, and
[Iris](/characters/iris.md) to [Priam](/characters/priam.md) to encourage him.
Despite [Hecuba](/characters/hecuba.md)'s protests, Priam loads a wagon with
treasures and sets out. [Mercury](/characters/mercury.md), in the form of a
young Myrmidon, guides him safely through the Greek guards.

Priam enters Achilles' tent and kneels, kissing the hands that killed his son.
He asks Achilles to think of his own father, Peleus. Achilles, moved to
compassion, grants the request. He orders the body washed and wrapped, and
detains Priam for one night. In the morning, Priam returns to Troy with Hector's
body. [Andromache](/characters/andromache.md), [Hecuba](/characters/hecuba.md),
and [Helen](/characters/helen.md) each deliver a lament, and the poem ends with
Hector's funeral rites — a twelve-day truce granted by Achilles for the burial.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XXIV: the redemption of Hector's body.
