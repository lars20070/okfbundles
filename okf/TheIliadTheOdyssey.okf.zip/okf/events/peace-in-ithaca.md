---
type: Event
title: "Peace in Ithaca"
description: "Minerva imposes peace between Ulysses and the Ithacans who rise to avenge the slain suitors; the Odyssey ends with reconciliation."
tags: [ulysses, minerva, ithaca, peace, resolution]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 104.0
location: /locations/ithaca.md
participants: [/characters/ulysses.md, /characters/minerva.md, /characters/laertes.md, /characters/telemachus.md, /characters/jupiter.md]
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Odyssey Book XXIV. After the [slaughter](/events/slaughter-of-the-suitors.md),
[Mercury](/characters/mercury.md) leads the ghosts of the dead suitors to the
[Underworld](/locations/underworld.md), where they encounter the shades of
[Achilles](/characters/achilles.md) and [Agamemnon](/characters/agamemnon.md).
Agamemnon, hearing of Ulysses' triumph and [Penelope](/characters/penelope.md)'s
fidelity, contrasts his own murder by Clytemnestra: "Happy son of Laertes! You
won a wife of surpassing virtue."

Meanwhile, [Ulysses](/characters/ulysses.md) visits his aged father
[Laertes](/characters/laertes.md) on his farm. After testing him with a false
story, he reveals himself by showing the scar and naming the fruit trees Laertes
gave him as a child — thirteen pear trees, ten apples, forty figs, and fifty
rows of vines. Laertes weeps and embraces his son.

But the families of the slain suitors arm and march against Ulysses. A battle
begins; Laertes, filled with new vigour by
[Minerva](/characters/minerva.md), kills Eupeithes, father of
[Antinous](/characters/antinous.md). Before the slaughter can spread,
Minerva shouts — "Stop this war, men of Ithaca!" — and [Jupiter](/characters/jupiter.md),
with a thunderbolt, confirms her command. Ulysses obeys, and Minerva, in the
form of [Mentor](/characters/mentor.md), imposes a lasting peace between the
king and his people. The poem ends not in violence but in reconciliation.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XXIV: peace in Ithaca.
