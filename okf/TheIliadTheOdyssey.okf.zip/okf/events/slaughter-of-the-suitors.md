---
type: Event
title: "Slaughter of the Suitors"
description: "Ulysses, Telemachus, Eumaeus, and Philoetius kill all 108 suitors in the great hall; the maidservants who consorted with them are hanged."
tags: [ulysses, suitors, revenge, justice]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 101.0
location: /locations/ithaca.md
participants: [/characters/ulysses.md, /characters/telemachus.md, /characters/eumaeus.md, /characters/philoetius.md, /characters/minerva.md, /characters/antinous.md, /characters/eurymachus.md, /characters/melanthius.md]
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Book XXII. After [stringing the bow](/events/contest-of-the-bow.md),
[Ulysses](/characters/ulysses.md) tears off his beggar's rags and springs onto
the threshold. His first arrow kills [Antinous](/characters/antinous.md) through
the throat. [Eurymachus](/characters/eurymachus.md) tries to negotiate but is
killed next. With [Telemachus](/characters/telemachus.md),
[Eumaeus](/characters/eumaeus.md), and [Philoetius](/characters/philoetius.md),
Ulysses slaughters all 108 suitors. [Minerva](/characters/minerva.md), in the
form of [Mentor](/characters/mentor.md), deflects the suitors' spears. The
treacherous goatherd [Melanthius](/characters/melanthius.md) is mutilated, and
twelve maidservants who consorted with the suitors are hanged.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XXII: the killing of the suitors.
