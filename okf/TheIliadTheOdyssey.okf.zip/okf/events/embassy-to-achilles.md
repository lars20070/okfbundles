---
type: Event
title: "Embassy to Achilles"
description: "Agamemnon sends Ulysses, Ajax, and Phoenix to persuade Achilles to return; all three speeches fail."
tags: [achilles, embassy, reconciliation-failed]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 9.0
location: /locations/grecian-camp.md
participants: [/characters/achilles.md, /characters/ulysses.md, /characters/ajax-the-greater.md, /characters/phoenix.md, /characters/agamemnon.md, /characters/nestor.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Book IX. After the Greeks' defeat in Book VIII, [Agamemnon](/characters/agamemnon.md)
proposes abandoning the siege. [Diomed](/characters/diomed.md) opposes him;
[Nestor](/characters/nestor.md) advises strengthening the guard and sending an
embassy to [Achilles](/characters/achilles.md). [Ulysses](/characters/ulysses.md),
[Ajax](/characters/ajax-the-greater.md), and [Phoenix](/characters/phoenix.md)
are chosen. Ulysses delivers a polished speech enumerating Agamemnon's generous
offers; Phoenix, Achilles' old tutor, appeals to their personal bond and warns
with the story of Meleager; Ajax speaks bluntly as a soldier. Achilles rejects
all three, though he keeps Phoenix with him. The ambassadors return to camp in
failure.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book IX: the embassy to Achilles.
