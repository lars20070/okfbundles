---
type: Event
title: "Circe's Transformation"
description: "Circe turns half of Ulysses' men into swine; Ulysses, protected by the herb moly, overcomes her and wins her aid."
tags: [circe, ulysses, transformation, aeaea]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 62.0
location: /locations/aeaea.md
participants: [/characters/circe.md, /characters/ulysses.md, /characters/mercury.md]
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Odyssey Book X. After the disaster with [Aeolus](/characters/aeolus.md) and the
Laestrygonians — who destroy all ships but Ulysses' own — the survivors reach
[Aeaea](/locations/aeaea.md), the island of [Circe](/characters/circe.md).
Eurylochus leads half the crew inland to Circe's palace, where wolves and lions
fawn on them — men transformed by her drugs. Circe welcomes them, mixes a potion
into their wine, and strikes them with her wand: they become swine in body,
though their minds remain human. Eurylochus, who stayed outside, returns with
the news.

[Ulysses](/characters/ulysses.md) sets out alone. On the way,
[Mercury](/characters/mercury.md) meets him in the form of a young man and gives
him the herb *moly* — black-rooted, white-flowered, and proof against Circe's
drugs. He also instructs Ulysses: when Circe strikes with her wand, he must draw
his sword and threaten her; she will then invite him to her bed, and he must
extract an oath that she will do him no harm.

All proceeds as Mercury foretold. Circe, overcome, restores Ulysses' men — now
taller and handsomer than before. Ulysses and his crew stay a full year on
Aeaea, feasting. When they decide to leave, Circe tells Ulysses he must first
visit the [Underworld](/locations/underworld.md) to consult the prophet
[Tiresias](/characters/tiresias.md).

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book X: Circe's transformation and Ulysses' triumph.
