---
type: Event
title: "Quarrel of Achilles and Agamemnon"
description: "Agamemnon seizes Briseïs from Achilles, who withdraws from battle; Thetis petitions Jupiter to aid the Trojans."
tags: [achilles, agamemnon, central-conflict]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 1.0
location: /locations/grecian-camp.md
participants: [/characters/achilles.md, /characters/agamemnon.md, /characters/briseis.md, /characters/chryseis.md, /characters/calchas.md, /characters/nestor.md, /characters/thetis.md, /characters/jupiter.md, /characters/juno.md, /characters/vulcan.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Book I. [Chryses](/characters/chryses.md), priest of
[Apollo](/characters/apollo.md), comes to ransom his daughter
[Chryseïs](/characters/chryseis.md) from [Agamemnon](/characters/agamemnon.md).
Refused, he prays to Apollo, who sends a plague. [Achilles](/characters/achilles.md)
calls a council; the seer [Calchas](/characters/calchas.md) reveals the cause.
Agamemnon agrees to return Chryseïs but seizes [Briseïs](/characters/briseis.md)
from Achilles in compensation. [Nestor](/characters/nestor.md) tries to pacify
the quarrel, but Achilles withdraws his forces. He asks his mother
[Thetis](/characters/thetis.md) to petition [Jupiter](/characters/jupiter.md),
who grants that the Trojans shall prevail until Achilles is honoured. This
angers [Juno](/characters/juno.md), but [Vulcan](/characters/vulcan.md)
reconciles the divine couple.

The time spans twenty-two days: nine of plague, one of the quarrel, and twelve
while Jupiter is with the Æthiopians.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book I: the contention of Achilles and Agamemnon.
