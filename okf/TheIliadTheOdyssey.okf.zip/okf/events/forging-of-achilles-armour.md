---
type: Event
title: "Forging of Achilles' Armour"
description: "Thetis commissions Vulcan to make new arms for Achilles; the Shield of Achilles, depicting the cosmos, is the centrepiece."
tags: [achilles, thetis, vulcan, armour, shield]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 18.0
location: /locations/olympus.md
participants: [/characters/thetis.md, /characters/vulcan.md, /characters/achilles.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Book XVIII. [Thetis](/characters/thetis.md), hearing [Achilles](/characters/achilles.md)'s
grief over [Patroclus](/characters/patroclus.md), travels to the palace of
[Vulcan](/characters/vulcan.md) on [Olympus](/locations/olympus.md). Recalling
that Thetis once saved him when [Jupiter](/characters/jupiter.md) cast him from
heaven, Vulcan agrees to forge new armour. The centrepiece is the
[Shield of Achilles](/items/shield-of-achilles.md): a vast depiction of the
earth, sky, and sea; two cities (one at peace, one at war); fields being
ploughed and harvested; vineyards; herds; and a dancing-floor. Around the rim
flows the river Ocean. Alongside the shield, Vulcan makes a helmet with a golden
crest, a breastplate, and greaves.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XVIII: the forging of Achilles' armour.
