---
type: Event
title: "Recognition by Penelope"
description: "Penelope tests the man who claims to be Ulysses with the secret of their marriage bed; satisfied, she embraces her husband after twenty years."
tags: [penelope, ulysses, recognition, reunion]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 103.0
location: /locations/ithaca.md
participants: [/characters/penelope.md, /characters/ulysses.md, /characters/eurycleia.md, /characters/telemachus.md]
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Odyssey Book XXIII. After the [slaughter of the suitors](/events/slaughter-of-the-suitors.md),
[Eurycleia](/characters/eurycleia.md) rushes to tell
[Penelope](/characters/penelope.md) that [Ulysses](/characters/ulysses.md) has
returned and killed the suitors. Penelope refuses to believe her: the gods may
send madness even to the wise. She descends to the hall and sits opposite the
man who claims to be her husband, studying him in silence.

Telemachus rebukes her — "Mother, you are hard-hearted!" — but Ulysses
understands. He tells his son: "Leave your mother to test me." He orders a bath,
and when he emerges, [Minerva](/characters/minerva.md) has restored his full
appearance. Still Penelope hesitates — until she deploys her own cunning.

She tells Eurycleia to move the marriage bed outside the bedroom. Ulysses
explodes: the bed cannot be moved. He built it himself around the trunk of a
living olive tree, smoothing it into a bedpost. The secret of the bed — that one
post is rooted in the earth, impossible to move — is knowledge only Ulysses
could have. Penelope, her test passed, runs to him weeping: "Do not be angry
with me, Ulysses. The gods sent us sorrow." They embrace, and
[Minerva](/characters/minerva.md) holds back the dawn to give them a full night
together after twenty years apart.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XXIII: the recognition by Penelope.
