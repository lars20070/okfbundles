---
type: Event
title: "Ulysses Returns to Ithaca"
description: "The Phaeacians convey the sleeping Ulysses to Ithaca; Minerva disguises him as a beggar and reveals the suitors' depredations."
tags: [ulysses, ithaca, minerva, disguise, return]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 70.0
location: /locations/ithaca.md
participants: [/characters/ulysses.md, /characters/alcinous.md, /characters/minerva.md, /characters/neptune.md, /characters/eumaeus.md]
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Odyssey Book XIII. The [Phaeacians](/factions/phaeacians.md), having heard
[Ulysses](/characters/ulysses.md)' [story of his wanderings](/events/cyclops-episode.md),
load him with gifts — more treasure than he would have brought from Troy — and
convey him by night in one of their magical ships. Ulysses sleeps through the
entire voyage. At dawn, the crew places him, still sleeping, on the shore of
[Ithaca](/locations/ithaca.md), with his treasures beside him.

[Neptune](/characters/neptune.md), enraged that the Phaeacians have helped
Ulysses, turns their returning ship to stone in the harbour of
[Scheria](/locations/scheria.md) — the fulfilment of an ancient prophecy — and
rings the island with mountains. The Phaeacians' era of conveying mortals is
ended.

Ulysses wakes and does not recognise his homeland — [Minerva](/characters/minerva.md)
has shrouded it in mist. She appears as a young shepherd and, when Ulysses
invents a false identity, she reveals herself with amusement: "You were always a
liar, but I love you for it." She tells him the
[suitors](/factions/suitors.md) have occupied his palace for three years. Then
she touches him with her wand: his skin wrinkles, his hair falls out, and he
becomes a ragged old beggar — unrecognisable. She sends him to the hut of the
swineherd [Eumaeus](/characters/eumaeus.md) to begin his reconnaissance.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XIII: Ulysses returns to Ithaca.
