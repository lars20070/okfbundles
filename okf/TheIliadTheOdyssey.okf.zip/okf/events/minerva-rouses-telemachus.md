---
type: Event
title: "Minerva Rouses Telemachus"
description: "The gods decree Ulysses' return; Minerva, disguised as Mentor, visits Telemachus in Ithaca and sends him in search of his father."
tags: [telemachus, minerva, ithaca, telemachy]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 50.0
location: /locations/ithaca.md
participants: [/characters/minerva.md, /characters/telemachus.md, /characters/jupiter.md, /characters/penelope.md, /characters/mentor.md]
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Odyssey Book I. With [Neptune](/characters/neptune.md) absent among the
Ethiopians, the gods meet in council on [Olympus](/locations/olympus.md).
[Jupiter](/characters/jupiter.md) speaks first, reflecting on Aegisthus — who
ignored [Mercury](/characters/mercury.md)'s warning and was killed by Orestes
for murdering [Agamemnon](/characters/agamemnon.md). [Minerva](/characters/minerva.md)
turns the conversation to [Ulysses](/characters/ulysses.md), still detained by
[Calypso](/characters/calypso.md) on [Ogygia](/locations/ogygia.md). Jupiter
decrees his release, and Minerva proposes a two-part plan: send Mercury to
Calypso with the command, and dispatch Minerva herself to
[Ithaca](/locations/ithaca.md) to rouse Ulysses' son.

Binding on her golden sandals, Minerva descends to Ithaca in the form of
[Mentor](/characters/mentor.md), an old friend of Ulysses. She finds the
[suitors](/factions/suitors.md) feasting in the palace and
[Telemachus](/characters/telemachus.md) sitting among them, despondent. She
tells him his father is alive and puts "courage into his heart." He is to call
an assembly, then sail to [Pylos](/characters/nestor.md) and Sparta to seek
news. Telemachus, transformed, confronts the suitors for the first time.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book I: the gods in council; Minerva's visit to Ithaca.
