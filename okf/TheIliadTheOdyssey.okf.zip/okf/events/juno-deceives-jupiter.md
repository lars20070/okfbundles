---
type: Event
title: "Juno Deceives Jupiter"
description: "Juno borrows the Girdle of Venus, seduces Jupiter on Mount Ida, and puts him to sleep so Neptune can aid the Greeks."
tags: [juno, jupiter, seduction, venus, neptune]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 14.0
location: /locations/mount-ida.md
participants: [/characters/juno.md, /characters/jupiter.md, /characters/venus.md, /characters/neptune.md, /characters/sleep.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Book XIV (the *Dios Apatē* — "Deception of Zeus"). With the Trojans pressing
hard and [Jupiter](/characters/jupiter.md) watching from
[Mount Ida](/locations/mount-ida.md) with strict orders that no god aid the
Greeks, [Juno](/characters/juno.md) devises a stratagem. She bathes, anoints
herself with ambrosial oil, dresses in her finest robes, and visits
[Venus](/characters/venus.md), claiming she needs the
[girdle of love](/items/girdle-of-venus.md) to reconcile Oceanus and Tethys.
Venus, unsuspecting, unwinds the embroidered *cestus* from her breast and lends
it.

Armed with the girdle, Juno then persuades Sleep (Hypnos), brother of Death, to
close Jupiter's eyes — promising him one of the Graces in marriage. On Mount
Ida, Jupiter, overwhelmed by desire, takes Juno in his arms while a golden cloud
envelops them. Jupiter falls into deep slumber.

[Neptune](/characters/neptune.md), free to act, rushes to the Greek lines and
turns the battle. The deception lasts until Book XV, when Jupiter awakens in
fury.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XIV: Juno deceives Jupiter.
