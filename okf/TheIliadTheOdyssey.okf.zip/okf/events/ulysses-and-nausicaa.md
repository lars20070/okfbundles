---
type: Event
title: "Ulysses and Nausicaa"
description: "Shipwrecked and naked, Ulysses encounters Nausicaa on the shore of Scheria; her kindness and composure bring him to the Phaeacian court."
tags: [ulysses, nausicaa, scheria, phaeacians]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 56.0
location: /locations/scheria.md
participants: [/characters/ulysses.md, /characters/nausicaa.md, /characters/minerva.md, /characters/alcinous.md]
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Odyssey Book VI. After [washing ashore](/events/ulysses-departs-ogygia.md) on
[Scheria](/locations/scheria.md), [Ulysses](/characters/ulysses.md) sleeps
exhausted in a bed of leaves. [Minerva](/characters/minerva.md) appears in a
dream to [Nausicaa](/characters/nausicaa.md), daughter of King
[Alcinous](/characters/alcinous.md), urging her to wash her wedding linens at
the river — a delicate hint at her marriageable age.

At the river, Nausicaa and her handmaidens play ball after their washing. Their
cries wake Ulysses, who emerges from the bushes "like a mountain lion," naked
and crusted with brine. The handmaidens flee; only Nausicaa stands her ground —
Minerva has put courage into her heart. Ulysses, keeping his distance, delivers
a famously tactful speech: he compares her to Artemis and praises her parents'
good fortune in having such a daughter. He asks only for clothing and directions
to the city.

Impressed by his dignity, Nausicaa clothes him, anoints him with oil, and
instructs him how to approach her parents. She advises him to supplicate Queen
Arete first — a shrewd piece of political intelligence. Ulysses bathes,
[Minerva](/characters/minerva.md) makes him taller and more beautiful, and
Nausicaa watches him walk toward the city, half-hoping he might stay.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book VI: Ulysses and Nausicaa.
