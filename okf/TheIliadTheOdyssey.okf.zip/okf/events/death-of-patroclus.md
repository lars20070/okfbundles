---
type: Event
title: "Death of Patroclus"
description: "Patroclus, in Achilles' armour, drives the Trojans back to the walls, kills Sarpedon, and is slain by Hector."
tags: [patroclus, hector, pivotal-death]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 16.0
location: /locations/troy.md
participants: [/characters/patroclus.md, /characters/hector.md, /characters/sarpedon.md, /characters/apollo.md, /characters/euphorbus.md, /characters/achilles.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Book XVI. [Patroclus](/characters/patroclus.md), following
[Nestor](/characters/nestor.md)'s suggestion from Book XI, begs
[Achilles](/characters/achilles.md) to let him lead the
[Myrmidons](/factions/myrmidons.md) into battle wearing Achilles' armour.
Achilles consents but commands him only to save the ships, not to pursue.

The Trojans, mistaking Patroclus for Achilles, fall into panic. Patroclus drives
them from the ships, kills [Sarpedon](/characters/sarpedon.md) (son of
[Jupiter](/characters/jupiter.md)), and presses on to the walls of Troy. There
[Apollo](/characters/apollo.md) disarms him: the god strikes his helmet from his
head, breaks his spear, and strips his shield. [Euphorbus](/characters/euphorbus.md)
wounds him, and [Hector](/characters/hector.md) delivers the killing blow.

This event transforms the poem. Achilles' grief and rage pivot from
[Agamemnon](/characters/agamemnon.md) to Hector, driving the second half of the
Iliad.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XVI: the acts and death of Patroclus.
