---
type: Event
title: "Contest of the Bow"
description: "Penelope sets the contest: whoever can string Ulysses' bow and shoot an arrow through twelve axe-heads shall marry her; only Ulysses succeeds."
tags: [contest, bow, ulysses, suitors]
timestamp: 2026-08-16T00:00:00Z
canon: hard
sort_key: 100.0
location: /locations/ithaca.md
participants: [/characters/ulysses.md, /characters/penelope.md, /characters/telemachus.md, /characters/antinous.md, /characters/eurymachus.md, /characters/eumaeus.md, /characters/philoetius.md]
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Book XXI. [Penelope](/characters/penelope.md), prompted by
[Minerva](/characters/minerva.md), fetches the great bow of
[Ulysses](/characters/ulysses.md) — a weapon only he could string — and
announces the contest: whoever can string it and shoot through twelve iron
axe-heads shall be her husband. One by one the suitors try and fail; even the
strongest cannot bend it.

[Ulysses](/characters/ulysses.md), still disguised as a beggar, asks to try. The
suitors mock him but [Telemachus](/characters/telemachus.md) insists. Ulysses
strings the bow as easily as a bard strings a lyre, plucks the string — it sings
— and shoots through all twelve axes. He then nods to Telemachus, and the
slaughter of the suitors begins.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XXI: the trial of the bow.
