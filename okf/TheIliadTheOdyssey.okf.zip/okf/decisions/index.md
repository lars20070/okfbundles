# Decisions

* [CDR-0001](/decisions/cdr-0001.md) - Pope's translation is canonical for this bundle; the Greek text is the underlying authority.
* [CDR-0002](/decisions/cdr-0002.md) - Buckley's annotations are soft canon, not binding worldbuilding canon.
* [CDR-0003](/decisions/cdr-0003.md) - Post-Iliad fates from Buckley's Concluding Note are soft canon.
* [CDR-0004](/decisions/cdr-0004.md) - Roman god-names follow Pope's translation; Greek names are noted as aliases.
* [CDR-0005](/decisions/cdr-0005.md) - The broader Epic Cycle is referenced but not bundled.
