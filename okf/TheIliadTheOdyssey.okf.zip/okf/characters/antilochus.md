---
type: Character
title: "Antilochus"
description: "Son of Nestor; a swift runner; brings news of Patroclus's death to Achilles in Book XVIII."
tags: [greek, messenger]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/grecian-camp.md
faction: [/factions/greeks.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Antilochus, son of [Nestor](/characters/nestor.md), is a swift-footed Greek
warrior. In Book XVII, [Menelaus](/characters/menelaus.md) sends him to
[Achilles](/characters/achilles.md) with the news of
[Patroclus](/characters/patroclus.md)'s death — a message he delivers with
tears. In Book XXIII, he competes in the chariot race at the funeral games.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books XVII, XVIII, XXIII.

# Relationships

Son of [Nestor](/characters/nestor.md). Messenger to
[Achilles](/characters/achilles.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XVII: Antilochus sent to Achilles.
