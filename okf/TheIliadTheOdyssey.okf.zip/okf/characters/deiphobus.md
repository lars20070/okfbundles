---
type: Character
title: "Deiphobus"
description: "Son of Priam; brother of Hector; Minerva takes his shape to deceive Hector in Book XXII."
tags: [trojan, prince]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/troy.md
faction: [/factions/trojans.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Deiphobus, a son of [Priam](/characters/priam.md) and brother of
[Hector](/characters/hector.md) and [Paris](/characters/paris.md), appears in
the battle scenes of Book XIII. His most significant role is indirect: in Book
XXII, [Minerva](/characters/minerva.md) takes his shape to convince Hector to
stand and face [Achilles](/characters/achilles.md). When Hector turns and
Deiphobus has vanished, he knows the gods have deceived him and his death is
near.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books XIII, XXII.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XXII: Minerva in the form of Deiphobus.
