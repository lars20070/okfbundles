---
type: Character
title: "Aeneas"
description: "Son of Venus and Anchises; a Trojan hero; saved by Neptune from Achilles in Book XX; survives the war."
tags: [trojan, dardan, hero]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/troy.md
faction: [/factions/trojans.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Aeneas, son of [Venus](/characters/venus.md) and the mortal Anchises, leads the
Dardan contingent allied to Troy. In Book V, [Diomed](/characters/diomed.md)
nearly kills him, but Venus shields her son; when Venus is wounded,
[Apollo](/characters/apollo.md) spirits Aeneas to the temple of Pergamus to be
healed. In Book XX, Apollo encourages him to face
[Achilles](/characters/achilles.md). A long conversation between the two heroes
precedes their duel, but [Neptune](/characters/neptune.md) rescues Aeneas,
noting that he is fated to survive the war and rule over the remnant of the
Trojans — a prophecy that later becomes the seed of Virgil's *Aeneid*.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books V, XIII, XVII, XX.

# Relationships

Son of [Venus](/characters/venus.md). Ally of [Hector](/characters/hector.md).
Opposed to [Diomed](/characters/diomed.md) and [Achilles](/characters/achilles.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book V: Aeneas rescued from Diomed.
[2] [The Iliad](/stories/the-iliad.md) — Book XX: Aeneas faces Achilles; saved by Neptune.
