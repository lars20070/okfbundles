---
type: Character
title: "Ulysses"
description: "King of Ithaca; the most cunning of the Greeks; skilled orator and strategist."
tags: [greek, ithaca, strategist]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: ["Odysseus", "son of Laertes"]
home: /locations/grecian-camp.md
faction: [/factions/greeks.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Ulysses (Odysseus), king of Ithaca, is the most resourceful of the Greek
leaders in the Iliad and the central figure of the Odyssey.

### In the Iliad

In Book II, when the army, deluded by Agamemnon's stratagem, rushes to
embark for home, it is Ulysses who rallies them and chastises the insolent
Thersites. In Book IX, he is chosen to lead the embassy to
[Achilles](/characters/achilles.md), delivering the most polished and persuasive
of the three speeches — but even his eloquence cannot move Achilles.

In Book X, he accompanies [Diomed](/characters/diomed.md) on the night raid into
the Trojan camp, capturing the spy Dolon and killing the Thracian king
[Rhesus](/characters/rhesus.md). In Book XIX, it is Ulysses who advises Achilles
to let the troops eat before battle.

### In the Odyssey

After the fall of Troy, Ulysses spends ten years struggling to return to
[Ithaca](/locations/ithaca.md), while [Neptune](/characters/neptune.md)
persecutes him for blinding his son [Polyphemus](/characters/polyphemus.md). His
wanderings take him to the land of the Lotus-eaters, the
[Cyclops](/characters/polyphemus.md), [Aeolus](/characters/aeolus.md), the
Laestrygonians, [Circe](/characters/circe.md), the
[Underworld](/locations/underworld.md), the [Sirens](/characters/sirens.md),
[Scylla and Charybdis](/locations/scylla-and-charybdis.md), and
[Thrinacia](/locations/thrinacia.md) — where his men's slaughter of the
Sun-god's cattle brings divine destruction. Only Ulysses survives.

Detained seven years by [Calypso](/characters/calypso.md) on
[Ogygia](/locations/ogygia.md), he is finally released and conveyed by the
[Phaeacians](/factions/phaeacians.md) to Ithaca. There, disguised as a beggar by
[Minerva](/characters/minerva.md), he endures the abuse of the
[suitors](/factions/suitors.md), reveals himself to his son
[Telemachus](/characters/telemachus.md), [strings his bow](/events/contest-of-the-bow.md),
[slays the suitors](/events/slaughter-of-the-suitors.md), and is finally
recognised by [Penelope](/characters/penelope.md).

Ulysses' defining trait is *metis* (cunning, craft): he is the man "of many
turns," who triumphs not through strength but through intelligence, patience,
and disguise. His epithet is *polytropos* — "much-turned" or "of many ways."

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books II, III, IX, X, XI, XIV, XIX, XXIII.

# Relationships

Ally of [Diomed](/characters/diomed.md). Respected by
[Nestor](/characters/nestor.md) and [Agamemnon](/characters/agamemnon.md). His
post-Iliad adventures form the Odyssey (not in this bundle).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book II: Ulysses rallies the army.
[2] [The Iliad](/stories/the-iliad.md) — Book IX: the embassy to Achilles.
[3] [The Iliad](/stories/the-iliad.md) — Book X: the night raid with Diomed.

# Post-Iliad Fate

(Soft canon — see [CDR-0003](/decisions/cdr-0003.md) and
[Post-Iliad Fates](/continuity/post-iliad-fates.md).)

After the war, Ulysses wandered for ten years, enduring innumerable troubles
by sea and land — the subject of Homer's Odyssey — before at last returning
safely to Ithaca.
