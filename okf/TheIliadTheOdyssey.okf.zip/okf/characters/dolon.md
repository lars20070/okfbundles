---
type: Character
title: "Dolon"
description: "Trojan spy captured by Diomed and Ulysses in Book X; reveals the positions of the Trojan allies, including Rhesus."
tags: [trojan, spy]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: dead
home: /locations/troy.md
faction: [/factions/trojans.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Dolon, a Trojan sent by [Hector](/characters/hector.md) to spy on the Greek camp
in Book X, is captured by [Diomed](/characters/diomed.md) and
[Ulysses](/characters/ulysses.md). In exchange for his life, he reveals the
arrangement of the Trojan and allied forces, including the recent arrival of
[Rhesus](/characters/rhesus.md) and his Thracians. After extracting the
information, Diomed kills him.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Book X.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book X: the capture of Dolon.
