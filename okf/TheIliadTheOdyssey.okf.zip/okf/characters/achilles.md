---
type: Character
title: "Achilles"
description: "Greatest of the Greek warriors; son of Thetis and Peleus; leader of the Myrmidons; his wrath is the subject of the Iliad."
tags: [greek, myrmidon, hero, central-character]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: ["Pelides", "son of Peleus", "Achilles of the swift foot"]
home: /locations/grecian-camp.md
faction: [/factions/greeks.md, /factions/myrmidons.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Achilles is the son of the sea-nymph [Thetis](/characters/thetis.md) and Peleus,
king of the Myrmidons. He is the mightiest warrior on the Greek side and the
central figure of the Iliad, which opens with an invocation to the Muse to sing
of his wrath — "Achilles' wrath, to Greece the direful spring / Of woes
unnumber'd."

His quarrel with [Agamemnon](/characters/agamemnon.md) over the captive
[Briseïs](/characters/briseis.md) drives the entire narrative. When Agamemnon
seizes Briseïs as compensation for returning [Chryseïs](/characters/chryseis.md),
Achilles withdraws from battle and asks his mother Thetis to petition
[Jupiter](/characters/jupiter.md) to grant victory to the Trojans, so the Greeks
will feel their need of him.

His defining relationship is with [Patroclus](/characters/patroclus.md), his
beloved companion. When Patroclus is slain by [Hector](/characters/hector.md),
Achilles' grief transforms his wrath from Agamemnon to the Trojans. He returns
to battle in new armour forged by [Vulcan](/characters/vulcan.md), slaughters
his way through the Trojan ranks, fights the river-god
[Scamander](/locations/scamander.md), and finally kills Hector. He then drags
Hector's body behind his chariot before eventually, moved by [Priam](/characters/priam.md),
returning it for burial.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books I, IX, XI, XVI, XVIII, XIX, XX, XXI, XXII, XXIII, XXIV.

# Relationships

Son of [Thetis](/characters/thetis.md). Companion of [Patroclus](/characters/patroclus.md).
Antagonist to [Agamemnon](/characters/agamemnon.md) (reconciled in Book XIX) and
[Hector](/characters/hector.md) (slain in Book XXII). His horses
[Xanthus and Balius](/items/horses-of-achilles.md) are immortal.

# Key Passages

**The opening invocation (Book I):**

> Achilles' wrath, to Greece the direful spring
> Of woes unnumber'd, heavenly goddess, sing!
> That wrath which hurl'd to Pluto's gloomy reign
> The souls of mighty chiefs untimely slain;

**Achilles to Patroclus (Book XVI):**

> "Patroclus, say, what grief thy bosom bears,
> That flows so fast in these unmanly tears?
> No girl, no infant whom the mother keeps
> From her loved breast, with fonder passion weeps;
> Not more the mother's soul, that infant warms,
> Clung to her knees, and reaching at her arms,
> Than thou hast mine!"

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book I, opening lines: the invocation of Achilles' wrath.
[2] [The Iliad](/stories/the-iliad.md) — Book XVI, ll. 1–19: Achilles' speech to Patroclus.
[3] [The Iliad](/stories/the-iliad.md) — Book XIX: reconciliation with Agamemnon.
[4] [The Iliad](/stories/the-iliad.md) — Book XXII: death of Hector.

# Post-Iliad Fate

(Soft canon — see [CDR-0003](/decisions/cdr-0003.md) and
[Post-Iliad Fates](/continuity/post-iliad-fates.md).)

Achilles fell before Troy, struck by an arrow from
[Paris](/characters/paris.md) with [Apollo](/characters/apollo.md)'s aid. The
arrow found his heel, the only vulnerable part of his body. This fulfilled
[Hector](/characters/hector.md)'s dying prophecy (Book XXII).
