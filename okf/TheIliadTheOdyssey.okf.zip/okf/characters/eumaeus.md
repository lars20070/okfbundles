---
type: Character
title: "Eumaeus"
description: "The loyal swineherd of Ulysses; shelters the disguised king and fights alongside him against the suitors."
tags: [ithaca, loyal-servant, swineherd]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/ithaca.md
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Eumaeus, the "divine swineherd," is one of the most sympathetic figures in the
Odyssey. Originally a prince, kidnapped as a child and sold into slavery, he
now serves [Ulysses](/characters/ulysses.md)' household with unwavering loyalty.
He is the first person Ulysses encounters on returning to
[Ithaca](/locations/ithaca.md) (Book XIV). Despite his guest's beggarly
appearance, Eumaeus treats him with exemplary
[hospitality](/rules/guest-friendship.md), sharing his meagre food and shelter.

In Book XVI, Ulysses reveals himself to [Telemachus](/characters/telemachus.md)
in Eumaeus's hut. Eumaeus fights alongside Ulysses and Telemachus in the
slaughter of the suitors (Book XXII) and is rewarded with freedom, wealth, and
a wife.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books XIV–XVII, XX–XXIV.

# Relationships

Servant of [Ulysses](/characters/ulysses.md) and
[Penelope](/characters/penelope.md). Ally of
[Telemachus](/characters/telemachus.md) and
[Philoetius](/characters/philoetius.md).

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XIV: Ulysses sheltered by Eumaeus.
[2] [The Odyssey](/stories/the-odyssey.md) — Book XVI: the reunion in the hut.
