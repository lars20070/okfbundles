---
type: Character
title: "Ajax the Greater"
description: "Son of Telamon; mightiest Greek warrior in physical strength after Achilles; fights Hector to a draw and defends the ships almost alone."
tags: [greek, salamis, hero]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: ["Telamonian Ajax", "bulwark of the Achaeans"]
home: /locations/grecian-camp.md
faction: [/factions/greeks.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Ajax, son of Telamon, is the bulwark of the Greek army — a giant of a man whose
shield is "like a tower." In Book VII, the lot falls to him to answer
[Hector](/characters/hector.md)'s challenge to single combat; they fight to a
respectful draw and exchange gifts. In Book XV, when the Trojans press to fire
the ships, Ajax defends them almost alone, wielding a massive pike and leaping
from deck to deck.

He is one of the ambassadors sent to [Achilles](/characters/achilles.md) in Book
IX, where his blunt, soldierly speech contrasts with [Ulysses](/characters/ulysses.md)'s
eloquence. In Book XVII, he and [Menelaus](/characters/menelaus.md) defend the
body of [Patroclus](/characters/patroclus.md).

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books VII, IX, XI, XIII, XIV, XV, XVI, XVII, XXIII.

# Relationships

Half-brother of [Teucer](/characters/teucer.md). Respected rival of
[Hector](/characters/hector.md). Ambassador to [Achilles](/characters/achilles.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book VII: single combat with Hector.
[2] [The Iliad](/stories/the-iliad.md) — Book IX: embassy to Achilles.
[3] [The Iliad](/stories/the-iliad.md) — Book XV: Ajax defends the ships.

# Post-Iliad Fate

(Soft canon — see [CDR-0003](/decisions/cdr-0003.md) and
[Post-Iliad Fates](/continuity/post-iliad-fates.md).)

After [Achilles](/characters/achilles.md)' death, Ajax contested with
[Ulysses](/characters/ulysses.md) for the right to inherit the
[armour of Vulcan](/items/armour-of-achilles.md). When the Greeks awarded it
to Ulysses, Ajax killed himself in shame and rage.
