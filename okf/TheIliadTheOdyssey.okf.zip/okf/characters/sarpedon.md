---
type: Character
title: "Sarpedon"
description: "Son of Jupiter; king of Lycia and Trojan ally; slain by Patroclus in Book XVI; his death grieves Jupiter, who cannot defy fate."
tags: [lycian, trojan-ally, son-of-jupiter]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: dead
home: /locations/troy.md
faction: [/factions/trojans.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Sarpedon, son of [Jupiter](/characters/jupiter.md), is the king of Lycia and
one of Troy's most distinguished allies. In Book XII he makes the first breach
in the Greek wall. In Book XVI, facing [Patroclus](/characters/patroclus.md), he
is killed — but not before Jupiter, grieving, debates whether to save his son.
[Juno](/characters/juno.md) reminds him that if he spares Sarpedon, every other
god will expect the same for their mortal offspring. Jupiter yields to fate, but
sends [Apollo](/characters/apollo.md) to carry Sarpedon's body to Lycia for
proper burial.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books V, XII, XVI.

# Relationships

Son of [Jupiter](/characters/jupiter.md). Ally of [Hector](/characters/hector.md).
Killed by [Patroclus](/characters/patroclus.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XII: Sarpedon breaches the Greek wall.
[2] [The Iliad](/stories/the-iliad.md) — Book XVI: death of Sarpedon.
