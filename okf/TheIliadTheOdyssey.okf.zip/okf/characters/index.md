# Characters

## Greeks (Achaeans)

* [Achilles](/characters/achilles.md) - Greatest Greek warrior; son of Thetis and Peleus; leader of the Myrmidons.
* [Agamemnon](/characters/agamemnon.md) - King of Mycenae; commander-in-chief of the Greek forces.
* [Patroclus](/characters/patroclus.md) - Beloved companion of Achilles; his death drives Achilles back to battle.
* [Menelaus](/characters/menelaus.md) - King of Sparta; husband of Helen; brother of Agamemnon.
* [Diomed](/characters/diomed.md) - Son of Tydeus; favoured by Minerva; wounds Venus and Mars in Book V.
* [Ulysses](/characters/ulysses.md) - King of Ithaca; the cleverest of the Greeks.
* [Nestor](/characters/nestor.md) - Aged king of Pylos; the wisest counsellor.
* [Ajax the Greater](/characters/ajax-the-greater.md) - Son of Telamon; mightiest Greek after Achilles in physical strength.
* [Ajax the Lesser](/characters/ajax-the-lesser.md) - Son of Oileus; leader of the Locrians.
* [Phoenix](/characters/phoenix.md) - Aged tutor of Achilles; part of the embassy in Book IX.
* [Idomeneus](/characters/idomeneus.md) - Cretan leader; distinguished in Book XIII.
* [Calchas](/characters/calchas.md) - Greek seer; reveals the cause of Apollo's plague.
* [Teucer](/characters/teucer.md) - Greek archer; half-brother of Ajax the Greater.
* [Machaon](/characters/machaon.md) - Greek physician; wounded by Paris in Book XI.
* [Antilochus](/characters/antilochus.md) - Son of Nestor; brings news of Patroclus's death.
* [Meriones](/characters/meriones.md) - Cretan warrior; companion of Idomeneus.

## Trojans

* [Hector](/characters/hector.md) - Greatest Trojan warrior; son of Priam; slain by Achilles in Book XXII.
* [Priam](/characters/priam.md) - Aged king of Troy; ransoms Hector's body in Book XXIV.
* [Paris](/characters/paris.md) - Son of Priam; his abduction of Helen caused the war.
* [Aeneas](/characters/aeneas.md) - Son of Venus and Anchises; saved by Neptune in Book XX.
* [Sarpedon](/characters/sarpedon.md) - Son of Jupiter; king of Lycia; slain by Patroclus in Book XVI.
* [Andromache](/characters/andromache.md) - Wife of Hector; her farewell scene is in Book VI.
* [Hecuba](/characters/hecuba.md) - Queen of Troy; wife of Priam.
* [Helen](/characters/helen.md) - Wife of Menelaus; her abduction by Paris sparked the war.
* [Polydamas](/characters/polydamas.md) - Trojan counsellor; often advises caution to Hector.
* [Glaucus](/characters/glaucus.md) - Lycian ally; exchanges armour with Diomed in Book VI.
* [Pandarus](/characters/pandarus.md) - Trojan archer; breaks the truce in Book IV.
* [Deiphobus](/characters/deiphobus.md) - Son of Priam; Minerva takes his shape to deceive Hector.
* [Euphorbus](/characters/euphorbus.md) - Trojan who wounds Patroclus before Hector kills him.
* [Dolon](/characters/dolon.md) - Trojan spy captured by Diomed and Ulysses in Book X.
* [Rhesus](/characters/rhesus.md) - King of Thrace; killed by Diomed in the night raid.

## Captives

* [Briseïs](/characters/briseis.md) - Captive awarded to Achilles; seized by Agamemnon, sparking the central conflict.
* [Chryseïs](/characters/chryseis.md) - Captive awarded to Agamemnon; daughter of Chryses, priest of Apollo.
* [Chryses](/characters/chryses.md) - Priest of Apollo; his rejected plea brings the plague.

## Ithaca (Odyssey)

* [Telemachus](/characters/telemachus.md) - Son of Ulysses and Penelope; journeys in search of news of his father.
* [Penelope](/characters/penelope.md) - Faithful wife of Ulysses; holds off the suitors for twenty years.
* [Laertes](/characters/laertes.md) - Aged father of Ulysses; lives in retirement on a farm.
* [Eumaeus](/characters/eumaeus.md) - Loyal swineherd; shelters the disguised Ulysses.
* [Eurycleia](/characters/eurycleia.md) - Aged nurse; recognises Ulysses by his scar.
* [Philoetius](/characters/philoetius.md) - Loyal cowherd; fights alongside Ulysses.
* [Melanthius](/characters/melanthius.md) - Treacherous goatherd; aids the suitors.
* [Mentor](/characters/mentor.md) - Old friend of Ulysses; the form Minerva takes to guide Telemachus.
* [Antinous](/characters/antinous.md) - Arrogant lead suitor; first to die.
* [Eurymachus](/characters/eurymachus.md) - Cunning suitor; killed after Antinous.
* [Theoclymenus](/characters/theoclymenus.md) - Fugitive seer; prophesies the suitors' doom.
* [Icarius](/characters/icarius.md) - Father of Penelope.
* [Pisistratus](/characters/pisistratus.md) - Son of Nestor; companion of Telemachus.

## Wanderings (Odyssey)

* [Calypso](/characters/calypso.md) - Nymph who detains Ulysses on Ogygia for seven years.
* [Circe](/characters/circe.md) - Enchantress on Aeaea; transforms men to swine.
* [Polyphemus](/characters/polyphemus.md) - Cyclops, son of Neptune; blinded by Ulysses.
* [Nausicaa](/characters/nausicaa.md) - Phaeacian princess; finds the shipwrecked Ulysses.
* [Alcinous](/characters/alcinous.md) - King of the Phaeacians; conveys Ulysses home.
* [Aeolus](/characters/aeolus.md) - Keeper of the winds; gives Ulysses the bag of winds.
* [Tiresias](/characters/tiresias.md) - Blind Theban prophet; consulted in the Underworld.
* [Sirens](/characters/sirens.md) - Creatures whose song lures sailors to death.
* [Hyperion](/characters/hyperion.md) - Sun-god; his sacred cattle bring doom to Ulysses' crew.

## Olympian Gods

* [Jupiter](/characters/jupiter.md) - King of the gods; weighs fates on his golden scales.
* [Juno](/characters/juno.md) - Queen of the gods; fiercely pro-Greek.
* [Minerva](/characters/minerva.md) - Goddess of wisdom and war; patron of Diomed and Achilles.
* [Apollo](/characters/apollo.md) - God of archery, plague, and prophecy; chief divine protector of Troy.
* [Venus](/characters/venus.md) - Goddess of love; mother of Aeneas; wounded by Diomed in Book V.
* [Mars](/characters/mars.md) - God of war; fights for Troy; wounded by Diomed in Book V.
* [Neptune](/characters/neptune.md) - God of the sea; aids the Greeks in defiance of Jupiter.
* [Vulcan](/characters/vulcan.md) - God of the forge; makes Achilles' new armour in Book XVIII.
* [Thetis](/characters/thetis.md) - Sea-nymph; mother of Achilles; obtains armour from Vulcan.
* [Mercury](/characters/mercury.md) - Messenger god; guides Priam to Achilles' tent in Book XXIV.
* [Iris](/characters/iris.md) - Messenger goddess; delivers commands of Jupiter.
* [Diana](/characters/diana.md) - Goddess of the hunt; sister of Apollo.
* [Hebe](/characters/hebe.md) - Goddess of youth; cupbearer of the Olympians.
