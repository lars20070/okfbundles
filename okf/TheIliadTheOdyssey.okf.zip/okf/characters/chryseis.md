---
type: Character
title: "Chryseïs"
description: "Captive awarded to Agamemnon; daughter of Chryses, priest of Apollo; her father's plea for her return is refused, bringing a plague."
tags: [captive, catalyst]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/chrysa.md
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Chryseïs is the daughter of Chryses, priest of [Apollo](/characters/apollo.md)
at [Chrysa](/locations/chrysa.md). At the opening of the poem, she is a captive
of [Agamemnon](/characters/agamemnon.md). When her father comes with rich
ransom to the Greek camp, Agamemnon refuses and dismisses him insolently.
Chryses prays to Apollo, who sends a plague upon the Greeks. The seer
[Calchas](/characters/calchas.md) reveals the cause, and Agamemnon is forced to
return her — but seizes [Briseïs](/characters/briseis.md) in compensation,
setting the central conflict in motion.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Book I.

# Relationships

Daughter of Chryses. Captive of [Agamemnon](/characters/agamemnon.md). Her
return triggers the quarrel over [Briseïs](/characters/briseis.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book I: Chryses's plea and the plague.
