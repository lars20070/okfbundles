---
type: Character
title: "Melanthius"
description: "The treacherous goatherd of Ulysses; aids the suitors and is brutally executed after their defeat."
tags: [ithaca, traitor, goatherd]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: dead
home: /locations/ithaca.md
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Melanthius, son of Dolius, is the goatherd of [Ulysses](/characters/ulysses.md)
who betrays his absent master. Unlike the loyal [Eumaeus](/characters/eumaeus.md),
he sides with the suitors, insults the disguised Ulysses, and during the battle
fetches arms for the suitors from the storeroom. After the slaughter, he is
taken outside and mutilated — his nose, ears, hands, and feet are cut off — a
brutal punishment for his treachery.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books XVII, XX, XXI, XXII.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XXII: the punishment of Melanthius.
