---
type: Character
title: "Meriones"
description: "Cretan warrior; companion of Idomeneus; fights alongside him in Book XIII and at the funeral games."
tags: [greek, cretan]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/grecian-camp.md
faction: [/factions/greeks.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Meriones, a Cretan warrior and companion of [Idomeneus](/characters/idomeneus.md),
fights bravely in Book XIII when [Neptune](/characters/neptune.md) rallies the
Greeks. After losing his spear, he goes to Idomeneus's tent for a replacement,
and the two return to battle together. In Book XVII, he helps
[Menelaus](/characters/menelaus.md) and the [Ajaces](/characters/ajax-the-greater.md)
bear [Patroclus](/characters/patroclus.md)'s body from the field. In Book XXIII,
he competes in the archery contest at the funeral games.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books XIII, XVII, XXIII.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XIII: Meriones and Idomeneus.
