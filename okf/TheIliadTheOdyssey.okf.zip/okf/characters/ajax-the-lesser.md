---
type: Character
title: "Ajax the Lesser"
description: "Son of Oileus; leader of the Locrians; swift-footed and skilled with the javelin."
tags: [greek, locrian]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: ["Oilean Ajax", "swift Ajax"]
home: /locations/grecian-camp.md
faction: [/factions/greeks.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Ajax the Lesser, son of Oileus, leads the Locrian contingent. Smaller and
swifter than [Telamonian Ajax](/characters/ajax-the-greater.md), he fights with
the sling and javelin. In Book XIII his Locrian archers and slingers help turn
the tide against the Trojans. In Book XIV he distinguishes himself when Neptune
aids the Greeks, pursuing the fleeing Trojans with particular ferocity. In Book
XXIII he competes in the funeral games, losing the footrace to
[Ulysses](/characters/ulysses.md) through Minerva's intervention.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books II, XIII, XIV, XXIII.

# Relationships

Ally of [Ajax the Greater](/characters/ajax-the-greater.md). Leader of the
Locrians.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XIII: the Locrians in battle.
[2] [The Iliad](/stories/the-iliad.md) — Book XXIII: the footrace.
