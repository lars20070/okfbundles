---
type: Character
title: "Aeolus"
description: "Keeper of the winds; gives Ulysses a bag containing all adverse winds to speed his journey home."
tags: [wind-god, aeolia]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/aeolia.md
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Aeolus, son of Hippotas and "dear to the immortal gods," rules the floating
island of [Aeolia](/locations/aeolia.md) where he keeps the winds imprisoned. In
Book X, he gives [Ulysses](/characters/ulysses.md) a leather bag containing all
the adverse winds, leaving only the west wind to carry him home to Ithaca. For
nine days Ulysses sails with this fair wind; on the tenth, within sight of
Ithaca, his crew, suspecting treasure, opens the bag. The winds burst out, and
the ship is blown back to Aeolia. Aeolus, concluding that Ulysses must be cursed
by the gods, refuses further help.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Book X.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book X: the bag of winds.
