---
type: Character
title: "Tiresias"
description: "The blind Theban prophet; Ulysses consults his shade in the Underworld, and he foretells the path home and the hero's eventual death."
tags: [prophet, underworld, theban]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: dead
home: /locations/underworld.md
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Tiresias, the blind prophet of Thebes, is consulted by
[Ulysses](/characters/ulysses.md) in the [Underworld](/locations/underworld.md)
in Book XI. [Circe](/characters/circe.md) has told Ulysses that only Tiresias
can reveal the way home. The prophet's shade drinks the sacrificial blood and
speaks: he warns Ulysses not to harm the cattle of the Sun on
[Thrinacia](/locations/thrinacia.md), foretells that he will reach Ithaca alone
and in another's ship, and describes the suitors consuming his household. He
also prophesies Ulysses' eventual death — a gentle one, from the sea, in old
age.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books X (mentioned), XI.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XI: the visit to Tiresias.
