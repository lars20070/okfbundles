---
type: Character
title: "Telemachus"
description: "Son of Ulysses and Penelope; a boy at the start of the Odyssey who journeys to Pylos and Sparta in search of news of his father."
tags: [ithaca, son-of-ulysses, hero]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/ithaca.md
faction: [/factions/greeks.md]
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Telemachus, son of [Ulysses](/characters/ulysses.md) and
[Penelope](/characters/penelope.md), was an infant when his father left for
Troy. When the Odyssey opens, he is a young man of about twenty, powerless to
stop the [suitors](/factions/suitors.md) devouring his inheritance. Book I finds
him sitting among them, hopeless.

[Minerva](/characters/minerva.md), disguised as [Mentor](/characters/mentor.md),
rouses him to action. He calls an assembly of the Ithacans (Book II), then sails
to [Pylos](/characters/nestor.md) to consult [Nestor](/characters/nestor.md)
(Book III) and to Sparta to consult [Menelaus](/characters/menelaus.md) (Book
IV), learning that his father is alive. The suitors plot to ambush him on his
return, but he evades them.

Reunited with his father at [Eumaeus](/characters/eumaeus.md)'s hut (Book XVI),
Telemachus fights alongside Ulysses in the slaughter of the suitors (Book XXII).
His journey from passive boy to active participant is one of the poem's central
arcs — the "Telemachy" (Books I–IV) is a coming-of-age story embedded within the
larger epic.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books I–IV, XV–XVII, XIX–XXIV.

# Relationships

Son of [Ulysses](/characters/ulysses.md) and [Penelope](/characters/penelope.md).
Grandson of [Laertes](/characters/laertes.md). Guided by
[Minerva](/characters/minerva.md) (as [Mentor](/characters/mentor.md)). Befriends
[Pisistratus](/characters/pisistratus.md), son of
[Nestor](/characters/nestor.md).

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Books I–IV: the Telemachy.
[2] [The Odyssey](/stories/the-odyssey.md) — Book XVI: reunion with Ulysses.
[3] [The Odyssey](/stories/the-odyssey.md) — Book XXII: the slaughter of the suitors.
