---
type: Character
title: "Idomeneus"
description: "Cretan leader; performs great deeds in Book XIII when Neptune aids the Greeks."
tags: [greek, cretan]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/grecian-camp.md
faction: [/factions/greeks.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Idomeneus, king of Crete, is one of the senior Greek commanders. In Book XIII,
when [Neptune](/characters/neptune.md) rallies the Greeks, Idomeneus arms and
returns to battle alongside [Meriones](/characters/meriones.md). He distinguishes
himself above all others in that book's fighting, killing Othryoneus, Asius, and
Alcathous before [Deiphobus](/characters/deiphobus.md) and
[Aeneas](/characters/aeneas.md) force his retreat.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books XIII, XXIII.

# Relationships

Ally of [Meriones](/characters/meriones.md). Opposed to
[Aeneas](/characters/aeneas.md) and Deiphobus.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XIII: the exploits of Idomeneus.
