---
type: Character
title: "Penelope"
description: "Wife of Ulysses and mother of Telemachus; holds off the suitors for twenty years through cunning, most famously by weaving and unweaving a funeral shroud."
tags: [ithaca, wife-of-ulysses, fidelity]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/ithaca.md
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Penelope, daughter of [Icarius](/characters/icarius.md), is the faithful wife of
[Ulysses](/characters/ulysses.md). For twenty years — ten of war, ten of
wandering — she awaits his return, besieged by 108 suitors who demand she remarry
and who consume her household's wealth. Her defining trait is *metis* (cunning),
matching her husband's: she promises to choose a suitor once she finishes weaving
a funeral shroud for [Laertes](/characters/laertes.md), but each night she
unravels what she wove by day. This stratagem holds for three years until a
servant betrays her.

In Book XIX she interviews the disguised Ulysses without recognising him; in Book
XXI she sets the [contest of the bow](/events/contest-of-the-bow.md) that leads
to the suitors' destruction. In Book XXIII, even after the slaughter, she tests
Ulysses with the secret of their marriage bed — carved from a living olive tree
— before embracing him. Her final recognition of her husband is among the most
celebrated scenes in literature.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books I, IV, XVI–XXIV.

# Relationships

Wife of [Ulysses](/characters/ulysses.md). Mother of
[Telemachus](/characters/telemachus.md). Daughter of
[Icarius](/characters/icarius.md). Served by [Eurycleia](/characters/eurycleia.md).

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book II: the shroud stratagem.
[2] [The Odyssey](/stories/the-odyssey.md) — Book XIX: interview with the disguised Ulysses.
[3] [The Odyssey](/stories/the-odyssey.md) — Book XXI: the contest of the bow.
[4] [The Odyssey](/stories/the-odyssey.md) — Book XXIII: recognition of Ulysses.
