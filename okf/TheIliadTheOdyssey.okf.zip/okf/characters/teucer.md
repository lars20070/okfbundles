---
type: Character
title: "Teucer"
description: "Greek archer; half-brother of Ajax the Greater; wounds many Trojans before being wounded by Hector in Book VIII."
tags: [greek, archer]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/grecian-camp.md
faction: [/factions/greeks.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Teucer, the half-brother of [Ajax the Greater](/characters/ajax-the-greater.md),
is the foremost archer on the Greek side. In Book VIII he takes cover behind
Ajax's shield, picking off Trojan warriors one by one, until
[Hector](/characters/hector.md) wounds him with a stone and carries him from the
field.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Book VIII.

# Relationships

Half-brother of [Ajax the Greater](/characters/ajax-the-greater.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book VIII: the acts of Teucer.
