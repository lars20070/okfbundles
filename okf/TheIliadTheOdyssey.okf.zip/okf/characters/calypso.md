---
type: Character
title: "Calypso"
description: "Nymph and goddess who detains Ulysses on the island of Ogygia for seven years, offering him immortality in exchange for staying."
tags: [nymph, goddess, ogygia]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/ogygia.md
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Calypso, daughter of the magician Atlas, is a nymph who lives on the remote
island of [Ogygia](/locations/ogygia.md). She rescued [Ulysses](/characters/ulysses.md)
after his shipwreck and kept him there for seven years, offering him immortality
and eternal youth if he would stay as her husband. Ulysses refused, longing
daily for [Ithaca](/locations/ithaca.md) and
[Penelope](/characters/penelope.md).

In Book V, [Mercury](/characters/mercury.md) brings [Jupiter](/characters/jupiter.md)'s
command that she release him. Calypso protests bitterly — pointing out the
double standard by which male gods take mortal lovers freely while goddesses are
denied — but obeys. She helps Ulysses build a raft and provides provisions for
his journey.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books I (mentioned), V.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book V: Calypso releases Ulysses.
