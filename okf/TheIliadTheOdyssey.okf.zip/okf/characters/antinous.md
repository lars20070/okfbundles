---
type: Character
title: "Antinous"
description: "The most arrogant and aggressive of Penelope's suitors; the first to die when Ulysses reveals himself."
tags: [suitor, antagonist, ithaca]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: dead
home: /locations/ithaca.md
faction: [/factions/suitors.md]
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Antinous, son of Eupeithes, is the ringleader of the 108 suitors of
[Penelope](/characters/penelope.md). Arrogant, violent, and contemptuous of
[hospitality](/rules/guest-friendship.md), he embodies the suitors' worst
qualities. He plots to ambush [Telemachus](/characters/telemachus.md) on his
return from Sparta. When [Ulysses](/characters/ulysses.md), disguised as a
beggar, begs in the hall, Antinous throws a stool at him. In Book XXII he is the
first to die: Ulysses shoots him through the throat as he raises a wine-cup.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books I, II, IV, XVII, XVIII, XXI, XXII.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XXII: the death of Antinous.
