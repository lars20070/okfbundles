---
type: Character
title: "Jupiter"
description: "King of the Olympian gods; son of Saturn; weighs the fates of Greeks and Trojans on his golden scales; ultimately arbiter of destiny."
tags: [olympian, god, king-of-gods]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: ["Jove", "Saturnian Jove", "Thunderer", "son of Saturn"]
home: /locations/olympus.md
faction: [/factions/olympian-gods.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Jupiter (Jove), the son of Saturn, rules as king of the Olympian gods. In the
Iliad he is the ultimate arbiter of fate, holding the golden scales in which he
weighs the destinies of mortals. Though he favours Troy personally — and has
promised [Thetis](/characters/thetis.md) to aid the Trojans until
[Achilles](/characters/achilles.md) is honoured — he is bound by fate and cannot
save his own son [Sarpedon](/characters/sarpedon.md) from death.

He forbids the gods from interfering in Book VIII, threatening them with
Tartarus. In Book XIV, [Juno](/characters/juno.md) seduces him to distract him
from the battle. He awakens in Book XV and reasserts control.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books I, II, IV, V, VIII, XIII, XIV, XV, XVI, XX, XXII, XXIV.

# Relationships

Husband (and brother) of [Juno](/characters/juno.md). Father of
[Sarpedon](/characters/sarpedon.md), [Mars](/characters/mars.md),
[Minerva](/characters/minerva.md), [Apollo](/characters/apollo.md),
[Venus](/characters/venus.md), [Mercury](/characters/mercury.md),
[Vulcan](/characters/vulcan.md), and [Hebe](/characters/hebe.md). Brother of
[Neptune](/characters/neptune.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book I: Jupiter grants Thetis's request.
[2] [The Iliad](/stories/the-iliad.md) — Book VIII: Jupiter forbids divine intervention.
[3] [The Iliad](/stories/the-iliad.md) — Book XIV: Juno deceives Jupiter.
[4] [The Iliad](/stories/the-iliad.md) — Book XVI: Jupiter grieves for Sarpedon but cannot defy fate.
[5] [The Iliad](/stories/the-iliad.md) — Book XX: Jupiter permits the gods to join battle.
[6] [The Iliad](/stories/the-iliad.md) — Book XXII: Jupiter weighs the fates of Achilles and Hector.
