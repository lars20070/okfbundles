---
type: Character
title: "Diomed"
description: "Son of Tydeus; greatest Greek warrior after Achilles; favoured by Minerva, who enables him to wound Venus and Mars in Book V."
tags: [greek, argive, hero]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: ["Tydides", "son of Tydeus"]
home: /locations/grecian-camp.md
faction: [/factions/greeks.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Diomed (also called Tydides, after his father Tydeus) is the pre-eminent Greek
warrior in Achilles' absence. [Minerva](/characters/minerva.md) grants him
special favour: in Book V she enables him to distinguish gods from mortals and
commands him to attack none of the immortals except [Venus](/characters/venus.md).

He wounds Venus on the hand as she tries to rescue [Aeneas](/characters/aeneas.md),
and later wounds [Mars](/characters/mars.md) himself, sending the war-god
groaning back to [Olympus](/locations/olympus.md). In Book VI, he encounters
[Glaucus](/characters/glaucus.md) between the armies; discovering an ancestral
bond of hospitality, they exchange armour in friendship.

In Book X, he volunteers for the night raid on the Trojan camp with
[Ulysses](/characters/ulysses.md), killing [Rhesus](/characters/rhesus.md) and
capturing his famous horses. Throughout the poem he is courageous, pious, and
unfailingly direct in counsel — he opposes Agamemnon's suggestion of retreat in
Book IX.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books IV, V, VI, VII, VIII, IX, X, XI, XIV, XXIII.

# Relationships

Son of Tydeus (one of the Seven against Thebes). Advised by
[Nestor](/characters/nestor.md). Allies with [Ulysses](/characters/ulysses.md)
in the night raid. Exchanges arms with [Glaucus](/characters/glaucus.md).
Antagonistic to [Aeneas](/characters/aeneas.md) and [Pandarus](/characters/pandarus.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book V: the acts of Diomed; wounds Venus and Mars.
[2] [The Iliad](/stories/the-iliad.md) — Book VI: the exchange of armour with Glaucus.
[3] [The Iliad](/stories/the-iliad.md) — Book X: the night raid with Ulysses.

# Post-Iliad Fate

(Soft canon — see [CDR-0003](/decisions/cdr-0003.md) and
[Post-Iliad Fates](/continuity/post-iliad-fates.md).)

After the fall of Troy, Diomed was expelled from Argos and nearly killed by
his unfaithful wife Aegiale. He fled to Apulia in Italy, where King Daunus
received him and shared his kingdom. The manner of his death is uncertain.
