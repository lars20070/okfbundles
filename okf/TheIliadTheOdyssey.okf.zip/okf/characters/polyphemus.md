---
type: Character
title: "Polyphemus"
description: "A Cyclops, son of Neptune; blinded by Ulysses in Book IX; his father's curse of Ulysses drives the entire Odyssey."
tags: [cyclops, monster, son-of-neptune]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: ["the Cyclops"]
home: /locations/cyclops-island.md
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Polyphemus, son of [Neptune](/characters/neptune.md) by the nymph Thoosa, is a
man-eating Cyclops whom [Ulysses](/characters/ulysses.md) encounters in Book IX.
The giant traps Ulysses and twelve of his men in his cave, devouring several
before Ulysses devises his escape: he gets Polyphemus drunk, tells him his name
is "Nobody" (Outis), and drives a sharpened stake into the giant's single eye
while he sleeps. When other Cyclopes come to help, Polyphemus cries that
"Nobody" is hurting him, and they leave.

As Ulysses sails away, he cannot resist revealing his true name — a fatal act of
pride. Polyphemus prays to Neptune, asking that Ulysses either never reach home
or reach it late, alone, and in misery. Neptune hears this prayer and becomes
Ulysses' relentless persecutor, driving the entire plot of the Odyssey.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books I (mentioned), IX.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book IX: the Cyclops episode.
