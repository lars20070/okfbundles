---
type: Character
title: "Polydamas"
description: "Trojan counsellor; often advises caution to Hector, who repeatedly overrules him."
tags: [trojan, counsellor]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/troy.md
faction: [/factions/trojans.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Polydamas, a Trojan of the same age as [Hector](/characters/hector.md), serves
as a voice of restraint. In Book XII, he advises the Trojans to dismount and
attack the Greek wall on foot — a successful tactic. But later, seeing an evil
omen (an eagle dropping a serpent), he counsels retreat; Hector overrules him.
In Book XIII, after the Trojans are repulsed, he advises calling a council.
In Book XVIII, when Achilles returns to battle, he urges the Trojans to withdraw
within the walls of Troy for the night. Hector overrules him again — a decision
that seals Hector's fate.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books XII, XIII, XVIII.

# Relationships

Counsellor to [Hector](/characters/hector.md). Son of Panthus.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XII: Polydamas advises the assault on foot.
[2] [The Iliad](/stories/the-iliad.md) — Book XVIII: Polydamas counsels retreat within the walls; Hector overrules him.
