---
type: Character
title: "Theoclymenus"
description: "A fugitive seer who joins Telemachus at Pylos and returns with him to Ithaca; prophesies the suitors' doom."
tags: [seer, ithaca]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/ithaca.md
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Theoclymenus, a descendant of the seer Melampus, is a fugitive from Argos who
meets [Telemachus](/characters/telemachus.md) at [Pylos](/characters/nestor.md)
in Book XV. Telemachus takes him aboard his ship to
[Ithaca](/locations/ithaca.md). In Book XX, at the final feast before the
slaughter, Theoclymenus has a prophetic vision: he sees the hall filled with
blood, the walls running with gore, and the suitors wrapped in darkness. The
suitors mock him and he leaves the hall. His vision confirms that divine justice
is imminent.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books XV, XVII, XX.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XX: Theoclymenus's vision.
