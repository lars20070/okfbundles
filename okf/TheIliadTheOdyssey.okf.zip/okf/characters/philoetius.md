---
type: Character
title: "Philoetius"
description: "The loyal cowherd of Ulysses; fights alongside Ulysses and Telemachus against the suitors."
tags: [ithaca, loyal-servant, cowherd]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/ithaca.md
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Philoetius, the "noble cowherd," is, alongside [Eumaeus](/characters/eumaeus.md),
one of the two loyal servants who aid [Ulysses](/characters/ulysses.md) on his
return. He weeps at the sight of the suitors wasting his master's cattle and
longs for Ulysses' return. In Book XXI, Ulysses reveals himself to Eumaeus and
Philoetius before the bow contest, and Philoetius helps bar the courtyard gates
during the slaughter of the suitors (Book XXII). Like Eumaeus, he is rewarded
with freedom and status.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books XX, XXI, XXII, XXIV.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XXI: the revelation to the loyal servants.
