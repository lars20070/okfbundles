---
type: Character
title: "Laertes"
description: "Aged father of Ulysses; lives in retirement on a farm; Ulysses visits him after the slaughter of the suitors."
tags: [ithaca, father-of-ulysses]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/ithaca.md
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Laertes, son of Arcesius, is the aged father of [Ulysses](/characters/ulysses.md).
Grief-stricken by his son's absence, he has withdrawn from the palace to live
in rags on a remote farm. In Book XXIV, after the slaughter of the suitors,
Ulysses visits him and, after testing his father's grief, reveals himself. The
recognition scene — Laertes recognising his son by a scar and a detailed
recollection of the trees they planted together in his childhood — is one of the
poem's most moving moments. Laertes then joins Ulysses and
[Telemachus](/characters/telemachus.md) to face the Ithacan uprising, and
[Minerva](/characters/minerva.md) restores his strength.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books I (mentioned), XXIV.

# Relationships

Father of [Ulysses](/characters/ulysses.md). Grandfather of
[Telemachus](/characters/telemachus.md). The shroud
[Penelope](/characters/penelope.md) weaves and unweaves is for him.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XXIV: Ulysses visits Laertes.
