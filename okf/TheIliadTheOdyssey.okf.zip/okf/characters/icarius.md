---
type: Character
title: "Icarius"
description: "Father of Penelope; offered her to any suitor who could win a footrace."
tags: [sparta, father-of-penelope]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Icarius, father of [Penelope](/characters/penelope.md), is mentioned in the
Odyssey as living in Sparta. [Telemachus](/characters/telemachus.md) tells the
Ithacan assembly that the suitors are afraid to approach Icarius to ask for
Penelope's hand formally — preferring to consume Ulysses' estate instead. In
later tradition, Icarius set a footrace as the contest for Penelope's hand,
which [Ulysses](/characters/ulysses.md) won.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books I (mentioned), II, IV (mentioned).

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book II: Telemachus mentions Icarius.
