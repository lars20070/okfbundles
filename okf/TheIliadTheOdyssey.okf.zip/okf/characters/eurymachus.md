---
type: Character
title: "Eurymachus"
description: "A leading suitor of Penelope; more cunning than Antinous; attempts to negotiate after Ulysses reveals himself."
tags: [suitor, antagonist, ithaca]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: dead
home: /locations/ithaca.md
faction: [/factions/suitors.md]
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Eurymachus, son of Polybus, is second only to [Antinous](/characters/antinous.md)
among the suitors. More polished and cunning than the brutish Antinous, he
nonetheless shares the same fundamental greed and disrespect for
[hospitality](/rules/guest-friendship.md). In Book XXII, after Antinous falls,
Eurymachus tries to negotiate with [Ulysses](/characters/ulysses.md), blaming
everything on the dead Antinous and offering compensation. Ulysses refuses, and
Eurymachus is killed in the ensuing battle.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books I, II, XVI, XVIII, XXI, XXII.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XXII: the death of Eurymachus.
