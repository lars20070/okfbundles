---
type: Character
title: "Thetis"
description: "Sea-nymph; mother of Achilles; petitions Jupiter to aid the Trojans; obtains new armour from Vulcan for her son."
tags: [sea-nymph, goddess, mother-of-achilles]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: ["silver-footed Thetis"]
home: /locations/olympus.md
faction: [/factions/olympian-gods.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Thetis, a sea-nymph of the Nereids, is the divine mother of
[Achilles](/characters/achilles.md). Knowing her son is fated to die young if he
fights at Troy, she is a figure of maternal grief throughout the poem. In Book
I, at Achilles' request, she petitions [Jupiter](/characters/jupiter.md) to
grant victory to the Trojans so the Greeks will regret dishonouring her son.
Jupiter grants this, setting the divine machinery of the poem in motion.

In Book XVIII, after [Patroclus](/characters/patroclus.md)'s death, she comes
with her sea-nymphs to comfort Achilles, then travels to
[Vulcan](/characters/vulcan.md)'s palace to obtain new arms — including the
famous [Shield of Achilles](/items/shield-of-achilles.md). In Book XIX she
delivers the armour and preserves Patroclus's body from corruption. In Book XXIV
[Jupiter](/characters/jupiter.md) sends her to Achilles to persuade him to
accept Priam's ransom for Hector's body.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books I, XVIII, XIX, XXIV.

# Relationships

Mother of [Achilles](/characters/achilles.md). Wife of Peleus. Petitioner to
[Jupiter](/characters/jupiter.md) and [Vulcan](/characters/vulcan.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book I: Thetis petitions Jupiter.
[2] [The Iliad](/stories/the-iliad.md) — Book XVIII: Thetis obtains armour from Vulcan.
[3] [The Iliad](/stories/the-iliad.md) — Book XIX: Thetis delivers the armour.
[4] [The Iliad](/stories/the-iliad.md) — Book XXIV: Thetis persuades Achilles.
