---
type: Character
title: "Glaucus"
description: "Lycian ally of Troy; discovers an ancestral bond of hospitality with Diomed; they exchange armour in friendship."
tags: [lycian, trojan-ally]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/troy.md
faction: [/factions/trojans.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Glaucus, a Lycian commander allied with Troy, meets [Diomed](/characters/diomed.md)
between the armies in Book VI. Instead of fighting, they discover that their
ancestors exchanged hospitality, and the bond makes them friends. They exchange
armour — Glaucus giving his golden armour (worth a hundred oxen) for Diomed's
bronze (worth nine) — a famous example of the Homeric theme of guest-friendship
(*xenia*). In Book XVII, Glaucus rebukes [Hector](/characters/hector.md) for
leaving [Sarpedon](/characters/sarpedon.md)'s body.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books VI, XVII.

# Relationships

Companion of [Sarpedon](/characters/sarpedon.md). Friend to
[Diomed](/characters/diomed.md) through ancestral *xenia*.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book VI: the meeting of Glaucus and Diomed.
