---
type: Character
title: "Minerva"
description: "Goddess of wisdom and war; fiercely pro-Greek; patron of Diomed, Ulysses, and Achilles."
tags: [olympian, goddess, pro-greek]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: ["Pallas", "Tritonia"]
home: /locations/olympus.md
faction: [/factions/olympian-gods.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Minerva (Athena), goddess of wisdom and war, is among the most active Olympians
in both the Iliad and the Odyssey.

### In the Iliad

She is one of the three goddesses whose beauty contest with
[Paris](/characters/paris.md) (the Judgment of Paris) gave motive to her hatred
of Troy. In Book IV, sent by [Jupiter](/characters/jupiter.md) at
[Juno](/characters/juno.md)'s urging, she persuades [Pandarus](/characters/pandarus.md)
to break the truce. In Book V, she fills [Diomed](/characters/diomed.md) with
divine strength and enables him to see gods on the battlefield. In Book XXII,
she deceives [Hector](/characters/hector.md) by taking the form of his brother
Deiphobus, then abandons him, leaving him to face [Achilles](/characters/achilles.md)
alone.

### In the Odyssey

Minerva is Ulysses' divine patroness. In Book I, she persuades
[Jupiter](/characters/jupiter.md) to end Ulysses' detention on
[Ogygia](/locations/ogygia.md) and, disguised as [Mentor](/characters/mentor.md),
visits [Telemachus](/characters/telemachus.md) to rouse him to action. She
accompanies Telemachus to [Pylos](/characters/nestor.md) (Book III) and guides
him throughout. She disguises Ulysses as a beggar on his return to
[Ithaca](/locations/ithaca.md) (Book XIII) and aids him throughout the
[slaughter of the suitors](/events/slaughter-of-the-suitors.md) (Book XXII). In
Book XXIV she imposes peace between Ulysses and the Ithacan rebels.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books I, II, IV, V, VII, VIII, X, XVIII, XX, XXI, XXII.

# Relationships

Daughter of [Jupiter](/characters/jupiter.md). Ally of
[Juno](/characters/juno.md) and [Diomed](/characters/diomed.md). Opposed to
[Mars](/characters/mars.md) and [Venus](/characters/venus.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book IV: Minerva breaks the truce.
[2] [The Iliad](/stories/the-iliad.md) — Book V: Minerva aids Diomed.
[3] [The Iliad](/stories/the-iliad.md) — Book XXII: Minerva deceives Hector.
