---
type: Character
title: "Neptune"
description: "God of the sea; brother of Jupiter; aids the Greeks despite Jupiter's prohibition."
tags: [olympian, god, pro-greek]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: ["Poseidon", "earth-shaker"]
home: /locations/olympus.md
faction: [/factions/olympian-gods.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Neptune (Poseidon), god of the sea and brother of [Jupiter](/characters/jupiter.md),
aids the Greeks in the Iliad but becomes Ulysses' relentless persecutor in the
Odyssey.

### In the Iliad

In Book VII he is jealous of the Greek fortification, but Jupiter pacifies him. In Book
XIII, seeing the Trojans breach the wall, he takes the form of
[Calchas](/characters/calchas.md) to inspire the Greek heroes, then leads them
in a renewed stand. In Book XIV, while [Juno](/characters/juno.md) has put
Jupiter to sleep, he openly leads the Greeks. In Book XV, when Jupiter awakens
and sends [Iris](/characters/iris.md) to command his withdrawal, Neptune obeys
reluctantly. In Book XX, he saves [Aeneas](/characters/aeneas.md) from
[Achilles](/characters/achilles.md), citing Aeneas's destiny.

### In the Odyssey

Neptune is the principal divine antagonist. When [Ulysses](/characters/ulysses.md)
blinds his son [Polyphemus](/characters/polyphemus.md) (Book IX), the Cyclops
prays to Neptune for vengeance. The god answers: he pursues Ulysses
relentlessly, raising storms, wrecking his raft (Book V), and preventing his
return for ten years. In Book XIII, enraged that the
[Phaeacians](/factions/phaeacians.md) have conveyed Ulysses home, he turns their
ship to stone. He is absent from the divine council in Book I because he is
feasting with the Ethiopians — the same excuse used to delay
Thetis's petition in the Iliad.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books VII, XIII, XIV, XV, XX.

# Relationships

Brother of [Jupiter](/characters/jupiter.md) and [Juno](/characters/juno.md).
Ally of the Greeks. Saves [Aeneas](/characters/aeneas.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XIII: Neptune aids the Greeks.
[2] [The Iliad](/stories/the-iliad.md) — Book XV: Neptune forced to withdraw.
[3] [The Iliad](/stories/the-iliad.md) — Book XX: Neptune saves Aeneas.
