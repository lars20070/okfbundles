---
type: Character
title: "Paris"
description: "Son of Priam; his abduction of Helen caused the Trojan War; a skilled archer but a reluctant warrior."
tags: [trojan, prince, archer]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: ["Alexander"]
home: /locations/troy.md
faction: [/factions/trojans.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Paris (also called Alexander), son of [Priam](/characters/priam.md), is the
cause of the Trojan War: his abduction of [Helen](/characters/helen.md) from her
husband [Menelaus](/characters/menelaus.md) brought the Greek fleet to Troy. As
a warrior he is compared unfavourably to his brother [Hector](/characters/hector.md):
in Book III he challenges Menelaus to single combat but is defeated and rescued
by [Venus](/characters/venus.md), who transports him to his chamber in a cloud.
[Hector](/characters/hector.md) later rebukes him for his dalliance while men
die.

In Book VI, Hector finds him in his apartments polishing his armour, and shames
him into returning to battle. Despite his flaws as a spearman, Paris is a deadly
archer: he wounds [Diomed](/characters/diomed.md) and [Machaon](/characters/machaon.md)
with arrows.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books III, VI, VII, XI, XIII.

# Relationships

Son of [Priam](/characters/priam.md) and [Hecuba](/characters/hecuba.md).
Brother of [Hector](/characters/hector.md). Lover of
[Helen](/characters/helen.md). Antagonist to [Menelaus](/characters/menelaus.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book III: the duel with Menelaus.
[2] [The Iliad](/stories/the-iliad.md) — Book VI: Hector rebukes Paris.
