---
type: Character
title: "Andromache"
description: "Wife of Hector; her farewell scene with Hector and their infant son Astyanax in Book VI is among the most celebrated passages in the poem."
tags: [trojan, wife-of-hector]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: []
home: /locations/troy.md
faction: [/factions/trojans.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Andromache, wife of [Hector](/characters/hector.md), appears in one of the
Iliad's most human moments: in Book VI, as Hector returns briefly to Troy, she
meets him at the [Scaean Gate](/locations/troy.md) with their infant son
Astyanax. She begs him not to return to battle, reminding him that
[Achilles](/characters/achilles.md) killed her father and all her brothers, and
that Hector is now her only family — "Hector, thus I call / My father, mother,
brother, husband, all."

Hector's reply — that he must fight, or shame would prevent him from facing the
Trojans — and the moment when Astyanax recoils from his father's plumed helmet,
prompting Hector to laugh and pray that his son may grow greater than he, forms
the emotional heart of the poem's domestic sphere.

At the end of Book XXII, hearing the lamentation from the walls, she rushes out
to see Hector's body dragged behind Achilles' chariot and collapses. In Book
XXIV she delivers one of the three great laments over Hector's body.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books VI, XXII, XXIV.

# Relationships

Wife of [Hector](/characters/hector.md). Mother of Astyanax. Daughter-in-law of
[Priam](/characters/priam.md) and [Hecuba](/characters/hecuba.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book VI: the parting of Hector and Andromache.
[2] [The Iliad](/stories/the-iliad.md) — Book XXII: Andromache sees Hector's body.
[3] [The Iliad](/stories/the-iliad.md) — Book XXIV: lament for Hector.
