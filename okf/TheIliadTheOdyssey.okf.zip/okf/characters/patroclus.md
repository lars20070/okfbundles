---
type: Character
title: "Patroclus"
description: "Beloved companion of Achilles; his death at Hector's hands while wearing Achilles' armour drives Achilles back into battle."
tags: [greek, myrmidon, pivotal-death]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: dead
aliases: ["Menoetiades"]
home: /locations/grecian-camp.md
faction: [/factions/greeks.md, /factions/myrmidons.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Patroclus, son of Menoetius, is the dearest companion of
[Achilles](/characters/achilles.md). Though not among the foremost warriors by
rank, his role is pivotal: grieved by the Greek losses, he persuades Achilles to
let him lead the [Myrmidons](/factions/myrmidons.md) into battle wearing
Achilles' armour (Book XVI).

Succeeding beyond expectation, Patroclus drives the Trojans back to the walls of
[Troy](/locations/troy.md), slaying [Sarpedon](/characters/sarpedon.md), son of
[Jupiter](/characters/jupiter.md). But he disobeys Achilles' command to return
after saving the ships. [Apollo](/characters/apollo.md) disarms him,
[Euphorbus](/characters/euphorbus.md) wounds him, and
[Hector](/characters/hector.md) delivers the killing blow.

His death transforms the poem: Achilles' wrath pivots from
[Agamemnon](/characters/agamemnon.md) to Hector. His body becomes the object of
a fierce battle (Book XVII), his funeral pyre consumes twelve Trojan captives
(Book XXIII), and funeral games are held in his honour. His ghost appears to
Achilles, demanding proper burial rites.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books XI, XVI (death), XVII (battle for his body), XXIII (funeral and games).

# Relationships

Companion of [Achilles](/characters/achilles.md). Son of Menoetius. His death is
avenged when Achilles kills [Hector](/characters/hector.md).

# Key Passages

**Achilles' grief at Patroclus' death (Book XVIII):**

> "Is this the day, which heaven so long ago
> Ordain'd, to sink me with the weight of woe?
> (So Thetis warn'd;) when by a Trojan hand
> The bravest of the Myrmidonian band
> Should lose the light!"

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XI: Patroclus sent by Achilles to inquire about the wounded.
[2] [The Iliad](/stories/the-iliad.md) — Book XVI: Patroclus leads the Myrmidons; his death.
[3] [The Iliad](/stories/the-iliad.md) — Book XVII: the battle for his body.
[4] [The Iliad](/stories/the-iliad.md) — Book XVIII: Achilles' grief.
[5] [The Iliad](/stories/the-iliad.md) — Book XXIII: funeral games in his honour.
