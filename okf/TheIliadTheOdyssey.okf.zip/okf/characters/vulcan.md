---
type: Character
title: "Vulcan"
description: "God of fire and the forge; makes new armour and the wondrous Shield for Achilles in Book XVIII."
tags: [olympian, god, smith]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: ["Hephaestus", "the lame god"]
home: /locations/olympus.md
faction: [/factions/olympian-gods.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Vulcan (Hephaestus), the lame god of fire and the forge, appears at two critical
junctures. In Book I, he pacifies the quarrel between [Jupiter](/characters/jupiter.md)
and [Juno](/characters/juno.md) with humour, serving nectar to the laughing
gods. In Book XVIII, [Thetis](/characters/thetis.md) comes to his palace to ask
for new arms for her son [Achilles](/characters/achilles.md). Vulcan, recalling
that Thetis once saved him when [Jupiter](/characters/jupiter.md) cast him from
[Olympus](/locations/olympus.md), forges magnificent armour, most notably the
[Shield of Achilles](/items/shield-of-achilles.md), covered with scenes of the
cosmos, cities at peace and war, agriculture, and dance. In Book XXI, at
[Juno](/characters/juno.md)'s urging, he dries up the river
[Scamander](/locations/scamander.md) with fire when the river-god attacks
Achilles.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books I, XVIII, XXI.

# Relationships

Son of [Jupiter](/characters/jupiter.md) and [Juno](/characters/juno.md).
Beholden to [Thetis](/characters/thetis.md). Maker of the
[Armour of Achilles](/items/armour-of-achilles.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book I: Vulcan pacifies the gods.
[2] [The Iliad](/stories/the-iliad.md) — Book XVIII: Vulcan forges Achilles' armour.
[3] [The Iliad](/stories/the-iliad.md) — Book XXI: Vulcan fights the river Scamander.
