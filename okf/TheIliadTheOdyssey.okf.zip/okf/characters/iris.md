---
type: Character
title: "Iris"
description: "Messenger goddess; delivers the commands of Jupiter and Juno to mortals and gods alike."
tags: [olympian, goddess, messenger]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/olympus.md
faction: [/factions/olympian-gods.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Iris, the swift-footed messenger of the Olympians, appears whenever a god —
particularly [Jupiter](/characters/jupiter.md) or [Juno](/characters/juno.md) —
needs to relay a command. In Book III she summons [Helen](/characters/helen.md)
to the walls; in Book VIII she restrains [Juno](/characters/juno.md) and
[Minerva](/characters/minerva.md); in Book XI she instructs
[Hector](/characters/hector.md) to withdraw until
[Agamemnon](/characters/agamemnon.md) is wounded; in Book XV she commands
[Neptune](/characters/neptune.md) to leave the battle; in Book XVIII she
prompts [Achilles](/characters/achilles.md) to show himself at the trench; in
Book XXIII she summons the winds to kindle Patroclus's pyre; and in Book XXIV
she encourages [Priam](/characters/priam.md) to undertake his journey.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books II, III, V, VIII, XI, XV, XVIII, XXIII, XXIV.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Books VIII, XV, XVIII, XXIV: Iris delivers divine commands.
