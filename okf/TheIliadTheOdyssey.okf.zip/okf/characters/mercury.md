---
type: Character
title: "Mercury"
description: "Messenger god; guides Priam safely to Achilles' tent in Book XXIV."
tags: [olympian, god, messenger]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: ["Hermes"]
home: /locations/olympus.md
faction: [/factions/olympian-gods.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Mercury (Hermes), the messenger of the gods, appears in both poems.

### In the Iliad

In Book XXIV, [Jupiter](/characters/jupiter.md) sends him to guide
[Priam](/characters/priam.md) safely through the Greek camp to
[Achilles](/characters/achilles.md)' tent. Taking the form of a young Myrmidon,
he leads the old king past the guards, revealing his divinity only at the last
moment.

### In the Odyssey

In Book V, Jupiter sends Mercury to [Ogygia](/locations/ogygia.md) to command
[Calypso](/characters/calypso.md) to release [Ulysses](/characters/ulysses.md).
In Book XXIV, he leads the ghosts of the slain suitors to the
[Underworld](/locations/underworld.md) with his golden wand (*caduceus*).

# Appearances

* [The Iliad](/stories/the-iliad.md) — Book XXIV.

# Relationships

Son of [Jupiter](/characters/jupiter.md). Guide to [Priam](/characters/priam.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XXIV: Mercury guides Priam.
