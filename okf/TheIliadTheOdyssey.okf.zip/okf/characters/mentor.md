---
type: Character
title: "Mentor"
description: "An old friend of Ulysses; the form Minerva takes to guide and accompany Telemachus on his journey."
tags: [ithaca, disguise-of-minerva, guide]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/ithaca.md
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Mentor, son of Alcimus, is an old Ithacan friend of
[Ulysses](/characters/ulysses.md). Before leaving for Troy, Ulysses entrusted
his household to Mentor's care. In the Odyssey, [Minerva](/characters/minerva.md)
repeatedly assumes Mentor's form: she appears as Mentor to
[Telemachus](/characters/telemachus.md) in Books I–II to encourage him, and
accompanies him to [Pylos](/characters/nestor.md) in Book III. In Book XXII she
appears as Mentor during the battle with the suitors, and in Book XXIV she takes
his form to impose peace between Ulysses and the Ithacans.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books I, II, III, XXII, XXIV (as Minerva's disguise).

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Books I–III: Minerva as Mentor.
