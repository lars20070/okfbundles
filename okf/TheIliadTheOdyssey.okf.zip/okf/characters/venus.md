---
type: Character
title: "Venus"
description: "Goddess of love; mother of Aeneas; protector of Paris and the Trojans; wounded by Diomed in Book V."
tags: [olympian, goddess, pro-trojan]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: ["Cytherea", "Aphrodite"]
home: /locations/olympus.md
faction: [/factions/olympian-gods.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Venus (Aphrodite), goddess of love, is a consistent ally of the Trojans: she won
the Judgment of [Paris](/characters/paris.md) by promising him
[Helen](/characters/helen.md), and she protects Paris and her son
[Aeneas](/characters/aeneas.md) throughout the poem. In Book III she rescues
Paris from [Menelaus](/characters/menelaus.md) in a cloud and transports him to
his chamber, then compels Helen to join him. In Book V, attempting to save
Aeneas from [Diomed](/characters/diomed.md), she is wounded on the hand —
[Diomed](/characters/diomed.md) being the only mortal permitted by
[Minerva](/characters/minerva.md) to attack her. In Book XIV her magic
[girdle](/items/girdle-of-venus.md) is borrowed by [Juno](/characters/juno.md)
to seduce [Jupiter](/characters/jupiter.md).

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books III, V, XIV.

# Relationships

Mother of [Aeneas](/characters/aeneas.md). Protector of
[Paris](/characters/paris.md). Wounded by [Diomed](/characters/diomed.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book III: Venus rescues Paris.
[2] [The Iliad](/stories/the-iliad.md) — Book V: Venus wounded by Diomed.
[3] [The Iliad](/stories/the-iliad.md) — Book XIV: the girdle of Venus.
