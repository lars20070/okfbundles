---
type: Character
title: "Nausicaa"
description: "Daughter of King Alcinous and Queen Arete of the Phaeacians; discovers the shipwrecked Ulysses and brings him to her father's palace."
tags: [phaeacian, princess, scheria]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/scheria.md
faction: [/factions/phaeacians.md]
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Nausicaa, daughter of [Alcinous](/characters/alcinous.md) and Arete, is the
Phaeacian princess who discovers [Ulysses](/characters/ulysses.md) on the shore
of [Scheria](/locations/scheria.md) in Book VI. Prompted by
[Minerva](/characters/minerva.md) in a dream, she goes with her handmaidens to
wash clothes by the river. There she finds the naked, brine-crusted Ulysses and,
with remarkable composure, clothes him and directs him to her father's palace.
Her kindness and dignity epitomise the [Phaeacians](/factions/phaeacians.md)'
exemplary hospitality. Though Alcinous half-offers her to Ulysses in marriage,
no such union occurs — Ulysses is bound for
[Penelope](/characters/penelope.md).

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books VI, VIII.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book VI: Nausicaa and Ulysses on the shore.
