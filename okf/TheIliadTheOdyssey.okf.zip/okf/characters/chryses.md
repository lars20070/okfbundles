---
type: Character
title: "Chryses"
description: "Priest of Apollo at Chrysa; father of Chryseïs; his rejected plea for his daughter's return brings Apollo's plague upon the Greeks."
tags: [priest, apollo]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/chrysa.md
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Chryses, priest of [Apollo](/characters/apollo.md) at
[Chrysa](/locations/chrysa.md), comes to the Greek camp to ransom his daughter
[Chryseïs](/characters/chryseis.md) from [Agamemnon](/characters/agamemnon.md).
When Agamemnon refuses and dismisses him insolently, Chryses prays to Apollo,
who sends a nine-day plague that sets the entire plot of the Iliad in motion.
After the Greeks return Chryseïs with hecatombs, Chryses prays again and the
plague is lifted.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Book I.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book I: Chryses's plea and the plague.
