---
type: Character
title: "Helen"
description: "Wife of Menelaus; her abduction by Paris caused the Trojan War; she identifies the Greek leaders for Priam from the walls of Troy."
tags: [trojan, spartan, cause-of-war]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: ["daughter of Jove"]
home: /locations/troy.md
faction: [/factions/trojans.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Helen, the most beautiful woman in the world, is the daughter of
[Jupiter](/characters/jupiter.md) and Leda. Her abduction from Sparta by
[Paris](/characters/paris.md) is the *casus belli* of the Trojan War. In the
Iliad she is a complex figure: aware of her guilt, she describes herself as a
"wanton" and a "curse" to Troy, yet she is also treated with sympathy.

In Book III, called by [Iris](/characters/iris.md) to watch the duel between
[Menelaus](/characters/menelaus.md) and Paris, she joins [Priam](/characters/priam.md)
on the walls and identifies the Greek leaders for him — the famous *teichoscopia*
("viewing from the wall"). After Paris is rescued by [Venus](/characters/venus.md),
the goddess compels Helen to go to him, though Helen resists.

In Book VI she laments to [Hector](/characters/hector.md) that she wishes she
had died at birth. In Book XXIV she delivers the final lament over Hector's
body.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books III, VI, XXIV.
* [The Odyssey](/stories/the-odyssey.md) — Book IV: Telemachus visits Helen at Sparta.

# Relationships

Wife of [Menelaus](/characters/menelaus.md); lover of
[Paris](/characters/paris.md). Protected by [Venus](/characters/venus.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book III: Helen on the walls of Troy.
[2] [The Iliad](/stories/the-iliad.md) — Book VI: Helen's lament to Hector.
[3] [The Iliad](/stories/the-iliad.md) — Book XXIV: Helen's lament for Hector.

# Post-Iliad Fate

(Soft canon — see [CDR-0003](/decisions/cdr-0003.md) and
[Post-Iliad Fates](/continuity/post-iliad-fates.md).)

After [Paris](/characters/paris.md)'s death, Helen married his brother
[Deiphobus](/characters/deiphobus.md). At the fall of Troy, she betrayed
Deiphobus to reconcile with [Menelaus](/characters/menelaus.md), who received
her back into favour and returned with her to Sparta.
