---
type: Character
title: "Euphorbus"
description: "Son of Panthus; a Trojan warrior who wounds Patroclus before Hector kills him in Book XVI."
tags: [trojan]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/troy.md
faction: [/factions/trojans.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Euphorbus, son of Panthus, is the Trojan who first wounds
[Patroclus](/characters/patroclus.md) in Book XVI after
[Apollo](/characters/apollo.md) has disarmed him. [Hector](/characters/hector.md)
then delivers the killing blow. In Book XVII, Euphorbus attempts to claim the
body and armour but is slain by [Menelaus](/characters/menelaus.md).

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books XVI, XVII.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XVI: Euphorbus wounds Patroclus.
