---
type: Character
title: "Priam"
description: "Aged king of Troy; father of Hector, Paris, and fifty sons; ventures into the Greek camp to ransom Hector's body."
tags: [trojan, king, troy]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: []
home: /locations/troy.md
faction: [/factions/trojans.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Priam, the aged king of Troy, is the father of [Hector](/characters/hector.md),
[Paris](/characters/paris.md), and some fifty sons in all. He rules from the
walled city that has withstood a decade of siege.

In Book III, he sits with his counsellors on the wall, asking
[Helen](/characters/helen.md) to identify the Greek leaders. In Book XXII, he
and [Hecuba](/characters/hecuba.md) plead with Hector not to face
[Achilles](/characters/achilles.md) alone — in vain.

His greatest act is in Book XXIV: guided by [Mercury](/characters/mercury.md),
he enters the Greek camp alone, kneels before Achilles, and kisses the hands
that killed his son. He begs for Hector's body, and Achilles, moved to
compassion, grants the request. Priam returns to Troy with his son's body for
proper funeral rites.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books III, VII, XXII, XXIV.

# Relationships

Husband of [Hecuba](/characters/hecuba.md). Father of
[Hector](/characters/hector.md), [Paris](/characters/paris.md), Helenus,
Deiphobus, and many others. His meeting with [Achilles](/characters/achilles.md)
in Book XXIV is one of the poem's most powerful scenes.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book III: Priam on the walls of Troy.
[2] [The Iliad](/stories/the-iliad.md) — Book XXII: Priam pleads with Hector.
[3] [The Iliad](/stories/the-iliad.md) — Book XXIV: Priam ransoms Hector's body from Achilles.

# Post-Iliad Fate

(Soft canon — see [CDR-0003](/decisions/cdr-0003.md) and
[Post-Iliad Fates](/continuity/post-iliad-fates.md).)

Priam was killed by Pyrrhus (Neoptolemus), the son of
[Achilles](/characters/achilles.md), during the sack of Troy.
