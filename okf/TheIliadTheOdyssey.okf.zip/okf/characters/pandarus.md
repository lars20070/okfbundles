---
type: Character
title: "Pandarus"
description: "Trojan archer; breaks the truce in Book IV by wounding Menelaus at Minerva's instigation; killed by Diomed in Book V."
tags: [trojan, archer]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: dead
home: /locations/troy.md
faction: [/factions/trojans.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Pandarus, a Lycian fighting for Troy, is the agent of the broken truce. In Book
IV, [Minerva](/characters/minerva.md), seeking to restart the war, persuades him
to shoot an arrow at [Menelaus](/characters/menelaus.md) — a wound that is
healed by [Machaon](/characters/machaon.md) but which shatters the peace. In
Book V, he wounds [Diomed](/characters/diomed.md) with an arrow and then joins
[Aeneas](/characters/aeneas.md) in a chariot attack; Diomed, now healed and
emboldened by Minerva, kills him.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books IV, V.

# Relationships

Ally of [Aeneas](/characters/aeneas.md). Killed by
[Diomed](/characters/diomed.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book IV: Pandarus breaks the truce.
[2] [The Iliad](/stories/the-iliad.md) — Book V: death of Pandarus.
