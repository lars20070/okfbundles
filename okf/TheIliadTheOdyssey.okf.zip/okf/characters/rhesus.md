---
type: Character
title: "Rhesus"
description: "King of Thrace and Trojan ally; killed in his sleep by Diomed during the night raid in Book X."
tags: [thracian, trojan-ally]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: dead
home: /locations/troy.md
faction: [/factions/trojans.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Rhesus, king of Thrace, arrives to aid Troy with his famous white horses,
described as the largest and swiftest in the world. In Book X,
[Diomed](/characters/diomed.md) and [Ulysses](/characters/ulysses.md), having
captured the Trojan spy [Dolon](/characters/dolon.md) and learned of Rhesus's
arrival, infiltrate the Thracian camp at night. Diomed kills Rhesus and his men
in their sleep, and the two Greeks drive the [famous horses](/items/horses-of-rhesus.md)
back to their camp.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Book X.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book X: the night-adventure of Diomed and Ulysses.
