---
type: Character
title: "Nestor"
description: "Aged king of Pylos; the wisest counsellor among the Greeks; his advice shapes strategy throughout the poem."
tags: [greek, pylos, counsellor]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: ["Gerenian horseman"]
home: /locations/grecian-camp.md
faction: [/factions/greeks.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Nestor, the aged king of Pylos, has outlived two generations of men and now
serves as the Greeks' chief counsellor. Though too old for frontline combat, his
wisdom, experience, and gift for storytelling make him indispensable. He
pacifies the quarrel between [Achilles](/characters/achilles.md) and
[Agamemnon](/characters/agamemnon.md) in Book I, advises the building of the
Greek fortification in Book VII, and proposes the embassy to Achilles in Book
IX.

In Book XI, when [Patroclus](/characters/patroclus.md) visits to ask about the
wounded, Nestor delivers a long recital of his youthful exploits, subtly urging
Patroclus to persuade Achilles to return — or to enter battle himself wearing
Achilles' armour. This conversation sets in motion the events that lead to
Patroclus's death.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books I, II, IV, VII, VIII, IX, X, XI, XIV, XXIII.
* [The Odyssey](/stories/the-odyssey.md) — Book III: Telemachus visits Nestor at Pylos.

# Relationships

Father of [Antilochus](/characters/antilochus.md). Counsellor to
[Agamemnon](/characters/agamemnon.md). Respected by all.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book I: Nestor pacifies the quarrel.
[2] [The Iliad](/stories/the-iliad.md) — Book VII: Nestor advises the fortification.
[3] [The Iliad](/stories/the-iliad.md) — Book IX: Nestor proposes the embassy.
[4] [The Iliad](/stories/the-iliad.md) — Book XI: Nestor's conversation with Patroclus.

# Post-Iliad Fate

(Soft canon — see [CDR-0003](/decisions/cdr-0003.md) and
[Post-Iliad Fates](/continuity/post-iliad-fates.md).)

Nestor alone among the major Greek leaders returned home without tragedy,
living in peace with his children in Pylos, his native country.
