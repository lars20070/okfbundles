---
type: Character
title: "Hebe"
description: "Goddess of youth; cupbearer of the Olympian gods; daughter of Jupiter and Juno."
tags: [olympian, goddess]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/olympus.md
faction: [/factions/olympian-gods.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Hebe, goddess of youth and daughter of [Jupiter](/characters/jupiter.md) and
[Juno](/characters/juno.md), serves as cupbearer to the Olympian gods. In Book
IV she pours nectar at the divine council. Her role is minor but emblematic of
the Olympian order.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Book IV.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book IV: Hebe serves nectar at the divine council.
