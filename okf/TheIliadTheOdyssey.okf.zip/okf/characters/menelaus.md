---
type: Character
title: "Menelaus"
description: "King of Sparta; husband of Helen; brother of Agamemnon; his honour is the cause of the Greek expedition."
tags: [greek, sparta, commander]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: ["Atrides", "son of Atreus"]
home: /locations/grecian-camp.md
faction: [/factions/greeks.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Menelaus, king of Sparta, is the aggrieved husband of [Helen](/characters/helen.md):
her abduction by [Paris](/characters/paris.md) launched the Greek expedition
against Troy. He defeats Paris in single combat in Book III, but
[Venus](/characters/venus.md) spirits the Trojan prince away before the duel can
settle the war. In Book IV he is wounded by [Pandarus](/characters/pandarus.md)'s
arrow, breaking the truce. He is a capable and dutiful warrior, though less
imposing than his brother [Agamemnon](/characters/agamemnon.md). In Book XVII,
he defends the body of [Patroclus](/characters/patroclus.md) and sends
[Antilochus](/characters/antilochus.md) to inform [Achilles](/characters/achilles.md)
of the death.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books III, IV, V, VI, VII, X, XIII, XVII, XXIII.
* [The Odyssey](/stories/the-odyssey.md) — Book IV: Telemachus visits Menelaus at Sparta.

# Relationships

Brother of [Agamemnon](/characters/agamemnon.md). Husband of
[Helen](/characters/helen.md). Ally of [Ajax the Greater](/characters/ajax-the-greater.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book III: duel with Paris.
[2] [The Iliad](/stories/the-iliad.md) — Book IV: wounded by Pandarus.
[3] [The Iliad](/stories/the-iliad.md) — Book XVII: defence of Patroclus's body.
