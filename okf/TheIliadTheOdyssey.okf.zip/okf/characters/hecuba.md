---
type: Character
title: "Hecuba"
description: "Queen of Troy; wife of Priam; mother of Hector and Paris; laments Hector's death in Book XXII."
tags: [trojan, queen]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/troy.md
faction: [/factions/trojans.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Hecuba, queen of Troy and wife of [Priam](/characters/priam.md), appears in the
poem's most wrenching moments. In Book VI she leads the Trojan matrons in prayer
to [Minerva](/characters/minerva.md). In Book XXII, she and Priam plead from the
walls for [Hector](/characters/hector.md) not to face
[Achilles](/characters/achilles.md) — baring her breast to remind him of his
infancy. After Hector's death, she leads the lamentation. In Book XXIV,
terrified for Priam's safety, she tries to dissuade him from going alone to
Achilles' tent, but is overruled.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books VI, XXII, XXIV.

# Relationships

Wife of [Priam](/characters/priam.md). Mother of [Hector](/characters/hector.md)
and [Paris](/characters/paris.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book XXII: Hecuba's plea to Hector.
[2] [The Iliad](/stories/the-iliad.md) — Book XXIV: Hecuba tries to stop Priam.
