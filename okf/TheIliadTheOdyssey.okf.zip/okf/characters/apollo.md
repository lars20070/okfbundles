---
type: Character
title: "Apollo"
description: "God of archery, plague, music, and prophecy; the chief divine protector of Troy."
tags: [olympian, god, pro-trojan]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: ["Phoebus", "son of Latona", "the far-shooter"]
home: /locations/olympus.md
faction: [/factions/olympian-gods.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Apollo (Phoebus Apollo), son of [Jupiter](/characters/jupiter.md) and Latona, is
the foremost divine protector of Troy. In Book I, angered by
[Agamemnon](/characters/agamemnon.md)'s treatment of his priest Chryses, he
sends a plague upon the Greek camp — the opening crisis of the poem. He rescues
[Aeneas](/characters/aeneas.md) from [Diomed](/characters/diomed.md) in Book V,
and in Book VII he and [Minerva](/characters/minerva.md) agree to postpone the
general battle. In Book XV, he reinspires [Hector](/characters/hector.md) and
leads the Trojans with his [aegis](/items/aegis-of-apollo.md). In Book XVI, he
disarms [Patroclus](/characters/patroclus.md) before Hector kills him. In Book
XXII, he repeatedly shields Hector from [Achilles](/characters/achilles.md)
until the fated moment arrives.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books I, V, VII, XV, XVI, XX, XXI, XXII, XXIV.

# Relationships

Son of [Jupiter](/characters/jupiter.md). Brother of
[Diana](/characters/diana.md). Protector of [Hector](/characters/hector.md) and
[Aeneas](/characters/aeneas.md). Opposed to [Achilles](/characters/achilles.md)
and the Greeks.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book I: Apollo sends the plague.
[2] [The Iliad](/stories/the-iliad.md) — Book XV: Apollo leads the Trojans.
[3] [The Iliad](/stories/the-iliad.md) — Book XVI: Apollo disarms Patroclus.
