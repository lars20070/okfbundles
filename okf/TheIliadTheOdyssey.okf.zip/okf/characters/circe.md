---
type: Character
title: "Circe"
description: "Enchantress living on the island of Aeaea; transforms Ulysses' men into swine but is overcome by him; becomes his host and guide."
tags: [sorceress, enchantress, aeaea]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/aeaea.md
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Circe, daughter of the Sun ([Hyperion](/characters/hyperion.md)), is a "great
and cunning goddess" living on the island of [Aeaea](/locations/aeaea.md). When
[Ulysses](/characters/ulysses.md)' men explore her palace, she drugs them and
turns them into swine. Ulysses, protected by the herb *moly* given by
[Mercury](/characters/mercury.md), resists her magic and draws his sword.
Overcome, Circe becomes his lover and host. She restores his men and keeps
Ulysses for a year before sending him to the
[Underworld](/locations/underworld.md) to consult the prophet
[Tiresias](/characters/tiresias.md) (Book X). On his return, she warns him of
the [Sirens](/characters/sirens.md), [Scylla and Charybdis](/locations/scylla-and-charybdis.md),
and the cattle of the Sun (Book XII). Her advice is detailed, precise, and
essential to his survival.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books X, XII.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book X: Ulysses and Circe.
[2] [The Odyssey](/stories/the-odyssey.md) — Book XII: Circe's warnings.
