---
type: Character
title: "Diana"
description: "Goddess of the hunt; sister of Apollo; mentioned but does not appear directly in the Iliad's action."
tags: [olympian, goddess]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: ["Artemis"]
home: /locations/olympus.md
faction: [/factions/olympian-gods.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Diana (Artemis), goddess of the hunt and the moon, is the twin sister of
[Apollo](/characters/apollo.md). She is mentioned in the Iliad but does not take
part in the battle or divine councils directly — unlike most of the major
Olympians. Her absence from the divine conflict is notable; in the broader Epic
Cycle and later tradition she has a more active role.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — mentioned as Apollo's sister.
