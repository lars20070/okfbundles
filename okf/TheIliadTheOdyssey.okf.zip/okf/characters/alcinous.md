---
type: Character
title: "Alcinous"
description: "King of the Phaeacians on Scheria; hosts Ulysses, hears his story, and provides the ship that carries him home to Ithaca."
tags: [phaeacian, king, scheria]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/scheria.md
faction: [/factions/phaeacians.md]
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Alcinous, son of Nausithous, is king of the seafaring
[Phaeacians](/factions/phaeacians.md) on the island of
[Scheria](/locations/scheria.md). He and his queen Arete receive
[Ulysses](/characters/ulysses.md) with exemplary
[hospitality](/rules/guest-friendship.md), holding a banquet and games in his
honour (Book VIII). At the feast, Ulysses weeps at the bard Demodocus's song
about Troy; Alcinous notices and asks his guest to reveal his identity. This
prompts Ulysses to recount his wanderings (Books IX–XII). In Book XIII, Alcinous
provides a ship and crew to convey Ulysses to
[Ithaca](/locations/ithaca.md), loading him with gifts. For this act of
generosity, [Neptune](/characters/neptune.md) punishes the Phaeacians by
turning their returning ship to stone.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books VI, VII, VIII, XI, XIII.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Books VII–VIII: Ulysses at Alcinous's court.
[2] [The Odyssey](/stories/the-odyssey.md) — Book XIII: Ulysses conveyed to Ithaca.
