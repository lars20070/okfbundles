---
type: Character
title: "Agamemnon"
description: "King of Mycenae; commander-in-chief of the Greek forces at Troy; his seizure of Briseïs sparks Achilles' wrath."
tags: [greek, mycenae, commander]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: ["Atrides", "son of Atreus", "king of men"]
home: /locations/grecian-camp.md
faction: [/factions/greeks.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Agamemnon, son of Atreus (hence "Atrides"), is the king of Mycenae and the
supreme commander of the Greek expedition against Troy. He is a capable warrior
but a flawed leader: proud, rash, and prone to alienating his best fighters.

In Book I, his refusal to return [Chryseïs](/characters/chryseis.md) to her
father Chryses brings a plague upon the Greek camp. When forced by
[Calchas](/characters/calchas.md)'s prophecy to give her back, he seizes
[Briseïs](/characters/briseis.md) from [Achilles](/characters/achilles.md) as
compensation, triggering the central conflict of the poem.

His military prowess is displayed in Book XI, where he leads a successful
charge, but after being wounded he must withdraw. Following the death of
[Patroclus](/characters/patroclus.md), he reconciles with Achilles in Book XIX,
admitting his fault and offering rich gifts.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books I, II, III, IV, VII, IX, X, XI, XIV, XIX, XXIII.

# Relationships

Brother of [Menelaus](/characters/menelaus.md). Antagonist to [Achilles](/characters/achilles.md)
(reconciled in Book XIX). Advised by [Nestor](/characters/nestor.md).

# Key Passages

**Nestor's advice at the council (Book IX):**

Nestor prevails upon Agamemnon to send an embassy to Achilles, acknowledging:
the king's actions were wrong and reconciliation is needed.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book I: the quarrel with Achilles over Briseïs.
[2] [The Iliad](/stories/the-iliad.md) — Book II: the deceptive dream sent by Jupiter.
[3] [The Iliad](/stories/the-iliad.md) — Book IX: the embassy to Achilles.
[4] [The Iliad](/stories/the-iliad.md) — Book XI: Agamemnon's valour in battle.
[5] [The Iliad](/stories/the-iliad.md) — Book XIX: reconciliation with Achilles.

# Post-Iliad Fate

(Soft canon — see [CDR-0003](/decisions/cdr-0003.md) and
[Post-Iliad Fates](/continuity/post-iliad-fates.md).)

On his return to Mycenae, Agamemnon was murdered by Aegysthus at the
instigation of his wife Clytemnestra, who had taken Aegysthus as her lover
during the king's absence at Troy.
