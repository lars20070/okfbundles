---
type: Character
title: "Hyperion"
description: "The Sun-god; his sacred cattle on Thrinacia are killed by Ulysses' men, bringing divine vengeance and the loss of the entire crew."
tags: [sun-god, cattle, divine-vengeance]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: ["Helios", "the Sun"]
home: /locations/thrinacia.md
faction: [/factions/olympian-gods.md]
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Hyperion (Helios), the Sun-god, keeps sacred cattle on the island of
[Thrinacia](/locations/thrinacia.md). [Tiresias](/characters/tiresias.md) and
[Circe](/characters/circe.md) both warn [Ulysses](/characters/ulysses.md)
emphatically not to harm them. Stranded on Thrinacia by contrary winds and
starving, Ulysses' men slaughter the cattle while he sleeps. Hyperion demands
vengeance, and [Jupiter](/characters/jupiter.md) destroys the ship with a
thunderbolt, killing all the crew. Ulysses alone survives, clinging to wreckage.
This is the final, fatal transgression that fulfils
[Polyphemus](/characters/polyphemus.md)'s curse: Ulysses reaches home alone.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books I, XII.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XII: the cattle of the Sun.
