---
type: Character
title: "Mars"
description: "God of war; fights for Troy; wounded by Diomed with Minerva's aid in Book V."
tags: [olympian, god, pro-trojan]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: ["Ares"]
home: /locations/olympus.md
faction: [/factions/olympian-gods.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Mars (Ares), the god of war, fights on the Trojan side. In Book V, after
rallying the Trojans, he is confronted by [Diomed](/characters/diomed.md),
guided by [Minerva](/characters/minerva.md). Diomed wounds him in the belly, and
Mars flees to [Olympus](/locations/olympus.md) groaning, where
[Jupiter](/characters/jupiter.md) rebukes him as the most hateful of the gods.
In Book XV, [Juno](/characters/juno.md) incites him to avenge his son Ascalaphus,
but [Minerva](/characters/minerva.md) restrains him.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books V, XV, XX, XXI.

# Relationships

Son of [Jupiter](/characters/jupiter.md) and [Juno](/characters/juno.md). Ally
of [Hector](/characters/hector.md). Wounded by [Diomed](/characters/diomed.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book V: Mars wounded by Diomed.
