---
type: Character
title: "Pisistratus"
description: "Son of Nestor; accompanies Telemachus on his journey from Pylos to Sparta and back."
tags: [pylos, companion-of-telemachus]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /characters/nestor.md
faction: [/factions/greeks.md]
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Pisistratus, the youngest son of [Nestor](/characters/nestor.md) (excepting the
infant), is the companion of [Telemachus](/characters/telemachus.md) on the
journey from [Pylos](/characters/nestor.md) to Sparta and back. In Book III he
welcomes Telemachus and [Minerva](/characters/minerva.md) (as
[Mentor](/characters/mentor.md)) to the feast of [Neptune](/characters/neptune.md)
and offers the strangers food and drink — an early display of proper
[hospitality](/rules/guest-friendship.md). He drives Telemachus by chariot to
[Menelaus](/characters/menelaus.md)'s palace in Book IV and returns with him in
Book XV.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books III, IV, XV.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Books III–IV: the journey to Sparta.
