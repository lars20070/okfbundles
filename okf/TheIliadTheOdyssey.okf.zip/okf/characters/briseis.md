---
type: Character
title: "Briseïs"
description: "Captive awarded to Achilles; seized by Agamemnon as compensation for returning Chryseïs, sparking the central conflict of the poem."
tags: [captive, catalyst]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/grecian-camp.md
faction: [/factions/greeks.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Briseïs is a captive woman taken by [Achilles](/characters/achilles.md) during
the sack of a Trojan-allied town. When [Agamemnon](/characters/agamemnon.md) is
forced to return [Chryseïs](/characters/chryseis.md), he seizes Briseïs as
compensation, triggering Achilles' wrath and withdrawal — the subject of the
entire poem. She is a silent figure for most of the work, but in Book XIX she
appears to lament over the body of [Patroclus](/characters/patroclus.md), whom
she calls the kindest of the Greeks and the one who comforted her after
Achilles killed her family.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books I, XIX.

# Relationships

Captive of [Achilles](/characters/achilles.md). Seized by
[Agamemnon](/characters/agamemnon.md). Mourns [Patroclus](/characters/patroclus.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book I: the quarrel over Briseïs.
[2] [The Iliad](/stories/the-iliad.md) — Book XIX: Briseïs laments Patroclus.
