---
type: Character
title: "Sirens"
description: "Creatures whose enchanting song lures sailors to shipwreck; Ulysses has his crew plug their ears with wax and binds himself to the mast to hear them."
tags: [monster, enchantment, song]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/sirens-isle.md
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

The Sirens are creatures who sit in a meadow and sing with such enchantment that
any sailor who hears them is drawn to his death on the rocks. [Circe](/characters/circe.md)
warns [Ulysses](/characters/ulysses.md) in Book XII to plug his crew's ears with
wax if he wishes to hear them himself. Ulysses has himself bound to the mast and
orders his men not to release him no matter how he begs. As they pass, he hears
the Sirens' song — promising knowledge of all that happens on earth — and strains
against his bonds. His men, deaf to both the song and his pleas, row on.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Book XII.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XII: the Sirens.
