---
type: Character
title: "Phoenix"
description: "Aged tutor of Achilles; accompanies Ulysses and Ajax on the embassy in Book IX; his speech fails to move Achilles."
tags: [greek, myrmidon, counsellor]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/grecian-camp.md
faction: [/factions/greeks.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Phoenix, an aged warrior who helped raise [Achilles](/characters/achilles.md)
from childhood, is the third ambassador in Book IX alongside
[Ulysses](/characters/ulysses.md) and [Ajax](/characters/ajax-the-greater.md).
His speech to Achilles is the most personal: he recalls his own exile, his role
as Achilles' tutor, and the story of Meleager — a hero who likewise refused to
fight — as a warning. Though he moves Achilles somewhat, the hero still refuses
to return. Phoenix stays in Achilles' tent when the other ambassadors depart.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Book IX.

# Relationships

Tutor of [Achilles](/characters/achilles.md). Ambassador alongside
[Ulysses](/characters/ulysses.md) and [Ajax](/characters/ajax-the-greater.md).

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book IX: Phoenix's speech to Achilles.
