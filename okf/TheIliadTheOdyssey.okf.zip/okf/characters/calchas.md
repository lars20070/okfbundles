---
type: Character
title: "Calchas"
description: "Greek seer; reveals that Agamemnon's refusal to return Chryseïs is the cause of Apollo's plague."
tags: [greek, seer]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/grecian-camp.md
faction: [/factions/greeks.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Calchas, son of Thestor, is the Greek army's seer. In Book I,
[Achilles](/characters/achilles.md) convenes a council to discover the cause of
the plague ravaging the camp. Calchas, protected by Achilles' promise of
immunity from [Agamemnon](/characters/agamemnon.md)'s anger, reveals that Apollo
sent the plague because Agamemnon dishonoured the priest Chryses by refusing to
return [Chryseïs](/characters/chryseis.md). His revelation sets the entire plot
in motion.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Book I.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book I: Calchas reveals the cause of the plague.
