---
type: Character
title: "Juno"
description: "Queen of the Olympian gods; fiercely pro-Greek; repeatedly schemes against the Trojans and deceives Jupiter."
tags: [olympian, goddess, pro-greek]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
aliases: ["Saturnia", "Saturn's daughter"]
home: /locations/olympus.md
faction: [/factions/olympian-gods.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Juno (Hera), daughter of Saturn and sister-wife of
[Jupiter](/characters/jupiter.md), is the most ardent divine supporter of the
Greeks. Her hatred of Troy stems from the Judgment of Paris (a pre-Iliad event
in which [Paris](/characters/paris.md) chose [Venus](/characters/venus.md) over
her and [Minerva](/characters/minerva.md)).

She schemes constantly: in Book IV she sends [Minerva](/characters/minerva.md)
to break the truce; in Book VIII she attempts to rally
[Neptune](/characters/neptune.md) against Jupiter's decree; and in Book XIV she
borrows the [Girdle of Venus](/items/girdle-of-venus.md) and seduces Jupiter on
[Mount Ida](/locations/mount-ida.md) so that Neptune can aid the Greeks
unobserved.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books I, IV, V, VIII, XIV, XV, XVIII, XX, XXI.

# Relationships

Wife of [Jupiter](/characters/jupiter.md). Allies with
[Minerva](/characters/minerva.md) and [Neptune](/characters/neptune.md).
Antagonistic to [Venus](/characters/venus.md) and the Trojans.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book I: Juno quarrels with Jupiter; pacified by Vulcan.
[2] [The Iliad](/stories/the-iliad.md) — Book IV: Juno urges the breach of the truce.
[3] [The Iliad](/stories/the-iliad.md) — Book XIV: Juno deceives Jupiter with the girdle of Venus.
[4] [The Iliad](/stories/the-iliad.md) — Book XV: Juno appeases the awakened Jupiter.
