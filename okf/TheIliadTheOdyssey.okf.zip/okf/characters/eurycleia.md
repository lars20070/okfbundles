---
type: Character
title: "Eurycleia"
description: "Aged nurse of Ulysses and later Telemachus; recognises Ulysses by the scar on his leg while washing his feet."
tags: [ithaca, nurse, recognition]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/ithaca.md
established_in: /stories/the-odyssey.md
provenance: human
---

# Description

Eurycleia, daughter of Ops, has served the household of
[Ulysses](/characters/ulysses.md) for three generations — she nursed Ulysses as
an infant and later [Telemachus](/characters/telemachus.md). In Book XIX,
[Penelope](/characters/penelope.md) orders her to wash the feet of the disguised
beggar (Ulysses). Seeing the scar on his leg — from a boar's tusk in his youth
— she recognises her master instantly. Ulysses grips her throat and swears her
to silence. In Book XXII she identifies the maidservants who consorted with the
suitors, and in Book XXIII she tells Penelope of Ulysses' return.

# Appearances

* [The Odyssey](/stories/the-odyssey.md) — Books I, XIX, XXII, XXIII.

# Citations

[1] [The Odyssey](/stories/the-odyssey.md) — Book XIX: the scar-recognition scene.
