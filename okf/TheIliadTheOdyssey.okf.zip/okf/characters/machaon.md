---
type: Character
title: "Machaon"
description: "Greek physician; son of Aesculapius; wounded by an arrow from Paris in Book XI."
tags: [greek, healer]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: alive
home: /locations/grecian-camp.md
faction: [/factions/greeks.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Machaon, son of Aesculapius (the god of medicine), serves as a physician to the
Greek army. In Book IV he heals [Menelaus](/characters/menelaus.md) after
[Pandarus](/characters/pandarus.md) wounds him. In Book XI he is himself wounded
by an arrow from [Paris](/characters/paris.md) and carried from the field in
[Nestor](/characters/nestor.md)'s chariot. His wounding prompts
[Achilles](/characters/achilles.md) to send [Patroclus](/characters/patroclus.md)
to inquire, setting in motion the events of Book XVI.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books IV, XI.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book IV: Machaon heals Menelaus.
[2] [The Iliad](/stories/the-iliad.md) — Book XI: Machaon wounded by Paris.
