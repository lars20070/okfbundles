---
type: Character
title: "Hector"
description: "Greatest Trojan warrior; son of Priam and Hecuba; husband of Andromache; slain by Achilles in Book XXII."
tags: [trojan, hero, prince-of-troy]
timestamp: 2026-08-16T00:00:00Z
canon: hard
status: dead
aliases: ["tamer of horses", "guardian of Troy"]
home: /locations/troy.md
faction: [/factions/trojans.md]
established_in: /stories/the-iliad.md
provenance: human
---

# Description

Hector, son of King [Priam](/characters/priam.md) and Queen
[Hecuba](/characters/hecuba.md), is the foremost defender of Troy and the
greatest warrior on the Trojan side. Unlike many Homeric heroes, he is portrayed
not only as a fighter but as a devoted husband to [Andromache](/characters/andromache.md)
and father to the infant Astyanax.

His most human moment comes in Book VI, when he returns to Troy from the
battlefield and takes tender leave of Andromache and their son, who is
frightened by his father's plumed helmet — the famous "parting of Hector and
Andromache."

Hector leads the Trojan assault that breaches the Greek wall (Book XII), kills
[Patroclus](/characters/patroclus.md) while the latter wears Achilles' armour
(Book XVI), and finally faces [Achilles](/characters/achilles.md) in single
combat before the [Scaean Gate](/locations/troy.md). Deceived by
[Minerva](/characters/minerva.md) in the shape of his brother Deiphobus, he is
slain. His body is dragged behind Achilles' chariot, then ransomed back to Priam
in Book XXIV.

# Appearances

* [The Iliad](/stories/the-iliad.md) — Books III, V, VI, VII, VIII, XI, XII, XIII, XIV, XV, XVI, XVII, XX, XXII.

# Relationships

Son of [Priam](/characters/priam.md) and [Hecuba](/characters/hecuba.md).
Husband of [Andromache](/characters/andromache.md). Brother of
[Paris](/characters/paris.md), Helenus, Deiphobus. Antagonist to
[Achilles](/characters/achilles.md) and [Ajax the Greater](/characters/ajax-the-greater.md)
(with whom he fights a respectful draw in Book VII).

# Key Passages

**The parting from Andromache (Book VI):**

Hector reaches for his infant son, who recoils from the nodding horsehair plume
of his helmet. Hector laughs, removes the helmet, and prays that his son may
grow to be a greater man than he.

# Citations

[1] [The Iliad](/stories/the-iliad.md) — Book VI: the parting of Hector and Andromache.
[2] [The Iliad](/stories/the-iliad.md) — Book VII: single combat with Ajax.
[3] [The Iliad](/stories/the-iliad.md) — Book XII: Hector breaches the Greek wall.
[4] [The Iliad](/stories/the-iliad.md) — Book XVI: Hector kills Patroclus.
[5] [The Iliad](/stories/the-iliad.md) — Book XXII: the death of Hector.
[6] [The Iliad](/stories/the-iliad.md) — Book XXIV: Priam ransoms Hector's body.
