---
okf_version: "0.1"
---

# Homeric World Canon

## Stories

* [The Iliad](/stories/the-iliad.md) — Epic poem; the wrath of Achilles during the Trojan War. Pope's translation with Buckley's notes (1899).
* [The Odyssey](/stories/the-odyssey.md) — Epic poem; the return of Ulysses from Troy to Ithaca. Pope's translation with Flaxman's designs.

## Entities

* [Characters](/characters/) — Mortals and immortals from both poems.
* [Locations](/locations/) — From Olympus and Troy to Ithaca, Ogygia, and the Underworld.
* [Factions](/factions/) — Armies, nations, suitors, and divine alliances.
* [Items](/items/) — Significant objects, armour, weapons, and artefacts.
* [Events](/events/) — Key turning points in both narratives.
* [Rules](/rules/) — Invariants governing the Homeric world.

## Canon Machinery

* [Continuity](/continuity/) — Open questions and known tensions.
* [Decisions](/decisions/) — Canon rulings and interpretive choices.
