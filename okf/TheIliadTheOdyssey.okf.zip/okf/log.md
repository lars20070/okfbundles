# Update Log

## 2026-08-16
* **Creation**: Added 16 new event concepts: [The Plague of Apollo](/events/plague-of-apollo.md), [The Night Raid of Diomed and Ulysses](/events/night-raid-of-diomed-and-ulysses.md), [Juno Deceives Jupiter](/events/juno-deceives-jupiter.md), [The Battle of the Gods](/events/battle-of-the-gods.md) (Iliad); [Minerva Rouses Telemachus](/events/minerva-rouses-telemachus.md), [Ulysses Departs Ogygia](/events/ulysses-departs-ogygia.md), [Ulysses and Nausicaa](/events/ulysses-and-nausicaa.md), [The Cyclops Episode](/events/cyclops-episode.md), [Circe's Transformation](/events/circes-transformation.md), [The Visit to the Underworld](/events/visit-to-the-underworld.md), [The Cattle of the Sun](/events/cattle-of-the-sun.md), [Ulysses Returns to Ithaca](/events/ulysses-returns-to-ithaca.md), [Recognition by Penelope](/events/recognition-by-penelope.md), [Peace in Ithaca](/events/peace-in-ithaca.md) (Odyssey).
* **Update**: Expanded [Post-Iliad Fates](/continuity/post-iliad-fates.md) with Odyssey Underworld material (Achilles, Ajax, Agamemnon in Hades).
* **Update**: Expanded [Contradictions](/continuity/contradictions.md) with Iliad-Odyssey cross-poem tensions (Ulysses' character, Helen's role, Neptune's realignment, the Phaeacians).
* **Update**: Expanded [Open Questions](/continuity/open-questions.md) with Odyssey-specific questions (Ulysses' ultimate fate, Calypso, the Phaeacians, timeline compression).
* **Creation**: Added [The Odyssey](/stories/the-odyssey.md) story concept — the sequel to [The Iliad](/stories/the-iliad.md).
* **Creation**: Added 17 new character concepts: [Telemachus](/characters/telemachus.md), [Penelope](/characters/penelope.md), [Laertes](/characters/laertes.md), [Eumaeus](/characters/eumaeus.md), [Eurycleia](/characters/eurycleia.md), [Philoetius](/characters/philoetius.md), [Melanthius](/characters/melanthius.md), [Mentor](/characters/mentor.md), [Antinous](/characters/antinous.md), [Eurymachus](/characters/eurymachus.md), [Theoclymenus](/characters/theoclymenus.md), [Icarius](/characters/icarius.md), [Calypso](/characters/calypso.md), [Circe](/characters/circe.md), [Polyphemus](/characters/polyphemus.md), [Nausicaa](/characters/nausicaa.md), [Alcinous](/characters/alcinous.md), [Aeolus](/characters/aeolus.md), [Tiresias](/characters/tiresias.md), [Sirens](/characters/sirens.md), [Hyperion](/characters/hyperion.md), [Pisistratus](/characters/pisistratus.md).
* **Creation**: Added 10 new location concepts: [Ithaca](/locations/ithaca.md), [Ogygia](/locations/ogygia.md), [Aeaea](/locations/aeaea.md), [Scheria](/locations/scheria.md), [Underworld](/locations/underworld.md), [Scylla and Charybdis](/locations/scylla-and-charybdis.md), [Thrinacia](/locations/thrinacia.md), [Aeolia](/locations/aeolia.md), [Cyclops Island](/locations/cyclops-island.md), [Sirens' Isle](/locations/sirens-isle.md).
* **Creation**: Added 2 new faction concepts: [Suitors](/factions/suitors.md), [Phaeacians](/factions/phaeacians.md).
* **Creation**: Added 2 new event concepts: [Contest of the Bow](/events/contest-of-the-bow.md), [Slaughter of the Suitors](/events/slaughter-of-the-suitors.md).
* **Creation**: Added item: [Bow of Ulysses](/items/bow-of-ulysses.md).
* **Update**: Expanded [Ulysses](/characters/ulysses.md), [Minerva](/characters/minerva.md), [Neptune](/characters/neptune.md), [Mercury](/characters/mercury.md), [Nestor](/characters/nestor.md), [Menelaus](/characters/menelaus.md), and [Helen](/characters/helen.md) with Odyssey roles and appearances.
* **Update**: Expanded [guest-friendship](/rules/guest-friendship.md) rule with Odyssey material (suitors' violation, Phaeacian exemplar).
* **Update**: Renamed bundle root index to "Homeric World Canon".
* **Creation**: Established worldbuilding bundle root and category indexes.
* **Creation**: Added [The Iliad](/stories/the-iliad.md) story concept.
* **Creation**: Added character concepts for the major figures of the poem.
* **Creation**: Added location, faction, event, item, and world-rule concepts.
* **Creation**: Added continuity tracking for open questions and canon decisions.
* **Creation**: Added world rules for [honour and shame](/rules/honour-and-shame.md), [divine favour through sacrifice](/rules/divine-favour-through-sacrifice.md), [prophecy](/rules/prophecy-always-fulfilled.md), and [blood-price](/rules/blood-price-and-compensation.md).
* **Creation**: Added [Post-Iliad Fates](/continuity/post-iliad-fates.md) from Buckley's Concluding Note.
* **Creation**: Added canon decisions [CDR-0003](/decisions/cdr-0003.md), [CDR-0004](/decisions/cdr-0004.md), and [CDR-0005](/decisions/cdr-0005.md) for post-Iliad fates, Roman naming, and Epic Cycle scope.
* **Update**: Expanded [The Iliad](/stories/the-iliad.md) with full narrative arc, themes, and post-poem fates.
* **Update**: Expanded [Open Questions](/continuity/open-questions.md) and [Contradictions](/continuity/contradictions.md).
* **Update**: Added post-Iliad fate sections to [Achilles](/characters/achilles.md), [Agamemnon](/characters/agamemnon.md), [Ajax the Greater](/characters/ajax-the-greater.md), [Helen](/characters/helen.md), [Diomed](/characters/diomed.md), [Nestor](/characters/nestor.md), [Priam](/characters/priam.md), and [Ulysses](/characters/ulysses.md).
