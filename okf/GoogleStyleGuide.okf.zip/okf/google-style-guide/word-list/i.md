---
type: Section
title: "Word list — I"
description: "Word list entries for terms beginning with I."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — I

## I

**IaaS**
    Write out on first mention: *infrastructure as a service (IaaS)*.

**IAM**
    When referring to the Google Cloud product, spell it out on first use:
    *Identity and Access Management (IAM)*.
    When referring to UI text, write this term the way it's written in the UI.
    When referring to the general practice of identity and access management,
    spell it out in lowercase on first use and include a parenthetical
    comment:
    Recommended: Identity and access
    management (generally referred to as *IAM*) is the practice of
    granting the right individuals access to the right resources for the
    right reasons.

**ID**
    Not *Id* or *id,* except in string literals or enums.
    In some contexts, it's best to spell out as *identifier* or
    *identification*.

**Don't use: i.e.**
    Don't use. Instead, use phrases like *that is*. Many people confuse
    *e.g.* and *i.e.*

**if**
    Wondering whether to use *if* or *whether*? See
    [whether](https://developers.google.com/style/word-list#whether).
    Although it is common in casual usage to omit the word *then* in *if...then*
    statements, you should include helper words like *then* in technical documentation. For
    more information, see
    [Use clear, precise, and unambiguous language](https://developers.google.com/style/translation#clear-language).

**image**
    *Image* by itself doesn't localize well because of its many meanings. Consider adding
    context—for example, *disk image* or *container image*.

**Avoid: impact**
    Use only as a noun. Instead of writing that something *has an
    impact*, use the word *affect*.
    Recommended: This issue affects
    user experience.
    Acceptable: This issue has an impact
    on user experience.
    Not recommended: This issue impacts
    user experience.

**index**
    Use the plural *indexes* unless there is a domain-specific reason
    (for example, a mathematical or financial context) to use *indices*.

**ingest**
    Use *import*, *load*, or *copy* when referring to simple movement of data. Use
    *ingest* only when referring to such operations that also involve significant processing
    of the data.

**ingress**
    When referring to the networking term, use lowercase. When referring
    to the GKE term or API, capitalize *Ingress*.

**Avoid: in order to**
    Avoid *in order to*; instead, use *to*.
    Use *in order to* when needed to clarify meaning or to make
    something easier to read.
    Recommended: You can use
    monitoring to help identify issues.
    Not recommended: You can use
    monitoring in order to help identify issues.
    Recommended: The infrastructure is
    required in order to support search.
    Not recommended: The infrastructure
    is required to support search.

**inline**
    One word as an adjective, *inline*, not *in line* or
    *in-line*.

**instance group**
    Don't abbreviate to *IG*. See also
    [managed instance group](https://developers.google.com/style/word-list#mig).

**intercluster**
    Use unhyphenated *intercluster*, not *inter-cluster*.

**interconnectAttachment**
    Use when referring to the API. Otherwise, use
    [VLAN attachment](https://developers.google.com/style/word-list#vlan).

**Interconnect connection**
    Only use *Interconnect connection* relative to a product as follows:

    - CDN Interconnect connection
    - Cloud Interconnect connection
    - Dedicated Interconnect connection
    - Partner Interconnect connection

    OK to use *connection* on subsequent mentions.
    When you're referring to a Google Cloud product, always specify the
    product name. Don't use *Interconnect* or *interconnect* as
    standalone terms, and don't use generic terms like *cloud interconnect
    connection* or *cross-connect*.

**Interconnect connection location**
    Only refer to an *Interconnect connection location* in context of a
    specific product, for example *CDN Interconnect*.
    OK to also use *colocation facility*.

**Don't use: interconnect type**
    Don't use. Instead, use *connection type*. Examples of connection
    types are a *dedicated connection* or a *connection provided by a
    service provider*.

**interface**
    OK to use as a noun.
    Don't use as a verb. Instead, use *interact*, *talk*,
    *speak*, *communicate*, or other similar terms.

**internal DNS**
    Write *internal* all lowercase except at the beginning of a
    sentence, heading, or list item.

**Internationalized Domain Name (IDN)**
    Write out and capitalize each word on first use. OK to abbreviate as
    *IDN* after first use.

**internet**
    Lowercase except at the beginning of a sentence,
    heading, or list item.

**Internet Key Exchange (IKE)**
    Write out and capitalize each word on first use. OK to abbreviate
    *IKE* after first use.

**I/O (see also [Google I/O](https://developers.google.com/style/word-list#google-io))**
    Not *I-O* or *IO*.

**IoT**
    OK to use as an abbreviation for *Internet of Things*. Note
    the lowercase *o*.

**IPsec**
    Not *IPSec* or *IPSECShort*.
    Short for *Internet Protocol Security*. No need to spell out on
    first mention.
