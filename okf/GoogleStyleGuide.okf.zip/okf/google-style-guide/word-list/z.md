---
type: Section
title: "Word list — Z"
description: "Word list entries for terms beginning with Z."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — Z

## Z

**Avoid: zippy**
    Don't use to refer to
    [expander arrows](https://developers.google.com/style/word-list#expander-arrow),
    unless you're specifically referring to the [Zippy widget](https://google.github.io/closure-library/api/goog.ui.Zippy.html)
    in Closure.
