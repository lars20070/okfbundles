---
type: Section
title: "Word list — O"
description: "Word list entries for terms beginning with O."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — O

## O

**OAuth 2.0**
    Not *OAuth 2*, *OAuth2*, or *Oauth*.

**Don't use: off-the-shelf, commercial off-the-shelf (COTS)**
    Use more widely understood terms like *ready-made*, *prebuilt*,
    *standard*, or *default*.

**Avoid: old, older**
    Don't use to refer to a previous version of a product. Instead, use
    [*earlier*](https://developers.google.com/style/word-list#earlier).
    Make sure that you provide a version number by which to understand
    *earlier*.
    In Android documentation, use
    [*lower*](https://developers.google.com/style/word-list#lower) instead of *earlier*.
    Recommended: This functionality
    doesn't work in versions earlier than 1.17.0.
    Not recommended: This functionality
    doesn't work in older versions.
    For more information, see
    [Timeless documentation](https://developers.google.com/style/timeless-documentation).

**Don't use: omnibox**
    Don't use. Instead, use *address bar*.

**once**
    If you mean *after*, then use *after* instead of *once*.

**on-premises**
    Not *on prem*, *on premise*, or *on-premise*. Hyphenate
    when used as any part of speech.
    Use to refer to a customer's resources that they manage in their own
    facilities. Don't use *peer*.
    It can be acceptable to use *on-premises* as a noun when it would be
    awkward to repeatedly write out a full phrase like *an on-premises
    environment*. However, it's preferable to use the more complete phrase
    whenever possible.
    Recommended: An on-premises database.
    Recommended: The database runs
    on-premises.
    OK: Moving data from on-premises to
    Google Cloud.

**OS**
    OK to use as a shortening of "operating system."

**Don't use: outpost**
    Don't use. Instead, use *channel*.
    Recommended: social media channels

**Avoid: outside the box, out of the box, out-of-the-box**
    Avoid using in a figurative way. OK to use literally.

**Don't use: (Android) overview screen**
    In Android documentation, don't use. Instead, use *recents screen*.
