---
type: Section
title: "Word list — L"
description: "Word list entries for terms beginning with L."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — L

## L

**Don't use: lame**
    Don't use. Instead, use precise, non-figurative language to refer to a
    deficiency in a component.

**later**
    Use for a range of version numbers, not *higher*.
    Recommended: Use version 2.2 or
    later.
    Not recommended: Use version 2.2 or
    higher.
    Not recommended: Use version 2.2+.
    A release with the highest version number might not be the latest version.
    For example, if version 2.0 of an operating system receives a bug-fix
    update after version 3.0 has been released, then version 2.0.1 might be
    the latest version, even though its version number is lower than 3.0.
    In Android documentation, don't use
    *later* for a range of version numbers. Instead, use *higher*.
    When referring to a position in a document, use *later* or
    *following*, not *below*.

**Avoid: latest**
    Avoid in timeless documentation because this word can become outdated.
    If you must use *latest*, give the reader a reference
    point—for example, a version number or release date.
    Recommended: To help keep your
    system secure, install the latest version of the tools.
    Recommended: The June 2021 release
    includes the latest tools that help secure your system.
    Not recommended: The product includes
    the latest tools that help secure your system.
    For more information, see
    [Timeless documentation](https://developers.google.com/style/timeless-documentation).

**Don't use: learnings**
    Don't use. Instead, refer to *knowledge* or *things that you
    learned*.

**Don't use: left-nav, right-nav**
    Don't use directional language. For more information, see
    Writing accessible documentation.
    If referring to applications, use
    [navigation menu](https://developers.google.com/style/ui-elements#navigation-menu).
    If referring to navigational elements for documentation, use *content
    navigation menu*.

**legacy**
    If possible, use a more precise term. If you do use *legacy*,
    include or point to a definition to clarify what you mean in the current
    context. Don't use *legacy* with any sort of pejorative
    connotation.

**Don't use: let's (as a contraction of *let us*)**
    Don't use if at all possible.
    Not recommended: Let's click the
    **OK** button now.

**Letter of Authorization and Connecting Facility Assignment (LOA-CFA)**
    Write out and capitalize each word on first use. OK to abbreviate as
    *LOA-CFA* after first use.

**Avoid: leverage**
    Avoid using if you mean *use*. If possible, use a more precise term.
    For example, *use*, *build on*, or *take advantage of*.

**lifecycle**
    Not *life cycle* or *life-cycle*.

**lift and shift**
    See
    [rehost](https://developers.google.com/style/word-list#rehost).

**like**
    It's OK to use *like* for either drawing comparisons (in the sense of *similar to*)
    or introducing examples (in the sense of *such as*).
    Recommended: Common I/O operations, like reading files or
    making network requests, can be asynchronous.
    Recommended: The new compression algorithm works like a
    dictionary encoder, replacing repeated strings with shorter codes.
    See also
    [such as](https://developers.google.com/style/word-list#such-as). For more information, see
    [Format examples](https://developers.google.com/style/examples).

**limits**
    In an API context, *limit* often refers to usage limits (number of
    queries allowed per second or per day). Where possible, specify the kind
    of limit that you mean, such as *usage limit* or *service
    limit*; the word *limit* can refer to many different kinds of
    limits, including rules about acceptable use. See also
    [quota](https://developers.google.com/style/word-list#quota).

**lint**
    Write both command-line tool name and command in lowercase. Use code font
    except where inappropriate.

**little-endian**
    Hyphenate. Lowercase except at the beginning of a sentence,
    heading, or list item.
    Recommended: The codebase assumes
    little-endian byte ordering.
    Not recommended: The codebase assumes
    Little Endian byte ordering.
    Not recommended: The codebase assumes
    Little-endian byte ordering.
    Not recommended: The codebase assumes
    little endian byte ordering.

**livestream**
    Not *live stream*.

**load balancing (noun), load-balancing (adjective)**
    Spell as *load balancing* when used as a noun and as *load-balancing* when
    used as an adjective. See also
    [high availability (noun), high-availability (adjective)](https://developers.google.com/style/word-list#high-availability).

**(Android) lock screen**
    Two words in Android contexts; not *lockscreen* or
    *lock-screen*.

**login (noun or adjective), log in (verb)**
    For the verb form, *sign in* is generally better.
    If you're documenting a tool that uses the term *log in*, then use
    that term.

**Don't use: (Android) long press**
    In Android documentation, don't use. Instead, use *touch & hold*.
    (Not *touch and hold*.)

**long-running operation**
    Not *long running operation*.
    OK to abbreviate as *LRO* after the first use.

**lower**
    Don't use for a range of version numbers. Instead, use
    [*earlier*](https://developers.google.com/style/word-list#earlier).
    Don't use to refer to a position in a document. Instead, use *later*
    or *following*.
    Don't use to refer to a position in the UI. Instead, write instructions
    that avoid directional language. For more information, see
    Writing accessible documentation.
    In Android documentation, use
    *lower* for a range of version numbers, not *earlier*.
