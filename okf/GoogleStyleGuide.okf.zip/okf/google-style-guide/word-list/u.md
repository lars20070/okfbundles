---
type: Section
title: "Word list — U"
description: "Word list entries for terms beginning with U."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — U

## U

**UI**
    Don't use generically to refer to a page or dashboard. Use a more specific
    term like
    [page](https://developers.google.com/style/word-list#page) or
    [console](https://developers.google.com/style/word-list#console). If a specific term is unavailable,
    use *web interface*.
    Recommended: In the Google Cloud
    console
    Recommended: On the **Cloud Tasks**
    page
    Recommended: In the Secure Source
    Manager web interface
    Not recommended: In the **Cloud
    Tasks** UI

**Don't use: unarchive**
    Don't use. Instead, use *extract*.

**Don't use: uncheck**
    Don't use to refer to clearing a check mark from a checkbox. Instead, use
    *clear*.
    Recommended: Clear **Automatically
    check for updates**.
    Not recommended: Uncheck
    **Automatically check for updates**.
    Not recommended: Deselect
    **Automatically check for updates**.

**Don't use: uncompress**
    Don't use. Instead, use *extract*.

**Don't use: under**
    Don't use for a range of version numbers. Instead,
    use [*earlier*](https://developers.google.com/style/word-list#earlier).
    Don't use to refer to a position in the UI.
    Recommended: In the **Service account
    ID** field, enter a name.
    Recommended: For **Service account
    ID**, enter a name.
    Not recommended: Under **Service
    account ID**, enter a name.

**Unicode**
    Not *UNICODE*.

**Unix-like**
    Not *Unixlike* or *Unix like*.

**Unix epoch time**
    Use instead of *Unix time* or *epoch time* to refer to a
    point in time represented as a number of seconds since the Unix epoch
    (00:00:00 UTC on January 1, 1970), ignoring leap seconds.

**Don't use: unselect**
    Don't use. Instead, use *clear* for checkboxes, and *deselect*
    for other UI elements.

**Don't use: unsighted**
    Don't use. See
    [blind](https://developers.google.com/style/word-list#blind).

**Don't use: untar**
    Don't use. Instead, use *extract*.

**Don't use: unzip**
    Don't use. Instead, use *extract*.

**US**
    OK to use as an abbreviation for *United States*. Don't use
    *U.S.* or *U.S.A.* For more information, see
    [Periods with abbreviations](https://developers.google.com/style/abbreviations#periods).

**user**
    Use the word *user* only to refer to the user of the software that
    your reader is developing. Otherwise, address the reader as *you*
    and assume that they will complete the tasks that you're documenting. For
    more information, see
    [Second person and first person](https://developers.google.com/style/second-person).

**user base**
    Not *userbase*.

**using**
    Where *using* might have more than one interpretation, use *by
    using* to help clarify the logic of the sentence.
    Recommended: You can filter for data
    with specific attributes by using custom filters.
    Not recommended: You can filter for
    data with specific attributes using custom filters.

**UTF**
    Include the hyphen in the names of Unicode encodings, such as
    *UTF-8*, *UTF-16*, and *UTF-32*.

**utilize, utilization**
    Use with caution. Don't use *utilize* when you mean *use*. It's
    OK to use *utilize* or *utilization* when referring to the
    quantity of a resource being used.
    Recommended: When CPU utilization
    exceeds 75%, the autoscaler adds more CPU resources.
    Recommended: To distribute network
    traffic, use a load balancer.
    Not recommended: To distribute network
    traffic, utilize a load balancer.
