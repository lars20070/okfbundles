---
type: Section
title: "Word list — J"
description: "Word list entries for terms beginning with J."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — J

## J

**Avoid: jank, janky**
    Use only to refer to a glitch or problem with graphics that is caused by a loss of data or
    inadequate refresh rate. Don't use otherwise. Use a less figurative term to refer to something
    of poor or unreliable quality.

**Avoid: just**
    Avoid. Usually, *just* is a filler word that you can delete without
    affecting your meaning.
    Recommended: BigQuery skips the row.
    Not recommended: BigQuery just skips
    the row.
    If your meaning is unclear without *just*, then use a more specific
    term such as *only*, *instead*, or *previously*, or revise
    your language to be more specific. (Even if one of these replacement
    terms fits, you often don't need it.)
    Recommended: You can run DML
    statements in the same way that you'd run a `SELECT`
    statement.
    Not recommended: You can run DML
    statements just as you'd run a `SELECT` statement.
    Recommended: Let a user query only
    the table without full dataset access.
    Recommended: Let a user query the
    table without full dataset access.
    Not recommended: Let a user query
    just the table without full dataset access.
    Sometimes, *just* is useful for conveying that one approach is
    simpler than another. In those cases, use *just* instead of
    [simply](https://developers.google.com/style/word-list#simple).
    Recommended: Use the namespace ID
    `namespace:example-kind` or just `example-kind`.
