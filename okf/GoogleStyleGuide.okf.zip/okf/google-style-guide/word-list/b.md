---
type: Section
title: "Word list — B"
description: "Word list entries for terms beginning with B."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — B

## B

**backend**
    Not *back-end* or *back end*.

**Avoid: bar**
    Avoid when possible. For more information, see
    [foo](https://developers.google.com/style/word-list#foo).

**bare metal**
    Lowercase except at the beginning of a sentence,
    heading, or list item.
    Hyphenate when used as a compound modifier, such as *bare-metal
    server*.

**base64**
    Lowercase except at the beginning of a sentence,
    heading, or list item. Otherwise, capitalize *Base64* only if it's part of a
    formal name.
    Write *base64* in code font *only* if it's a string literal or
    otherwise quoted from code.

**Avoid: baz**
    Avoid when possible. For more information, see
    [foo](https://developers.google.com/style/word-list#foo).

**Avoid: below**
    Don't use for a range of version numbers. Instead, use
    [*earlier*](https://developers.google.com/style/word-list#earlier).
    Don't use to refer to a position in a document. Instead, use *later*
    or *following*.
    Don't use to refer to a position in the UI. Instead, write instructions
    that avoid directional language. For more information, see
    Writing accessible documentation.
    It's OK to use *below* in set phrases such as *below (the)
    average*, *below the mean*, *below zero*.
    It's OK to use *below* in a non-directional way, such as when describing a hierarchy.

**Avoid: best effort**
    Avoid where possible. Instead, use more specific wording. After providing
    a description, you can add a phrase like "sometimes referred to as *best
    effort*."

**beta**
    Lowercase except when part of a product name.
    Recommended: PRODUCT_NAME
    Beta
    Recommended: PRODUCT_NAME
    is currently in beta.

**between versus among**
    It's fine to use *between* when talking about more than two things;
    however, *between* isn't interchangeable with *among*.
    Use *between* when you're talking about two or more distinct
    things:
    Recommended: JavaScript introduces
    dependencies between the DOM, the CSSOM, and JavaScript execution.
    Use *among* when you're talking about things that are part of a group
    or things that aren't distinct:
    Recommended: ... a conventional SQL
    database that can be shared among multiple apps.
    More examples:
    Recommended: Because screen
    dimensions vary widely among devices (for example, between phones and
    tablets, and even among different phones), you should configure the
    viewport so that your pages render correctly on many different devices.
    Not recommended: Because screen
    dimensions vary widely between devices (for example, between phones and
    tablets, and even between different phones), you should configure the
    viewport so that your pages render correctly on many different devices.
    Recommended: You can share services
    among multiple clients.
    Not recommended: You can share
    services between multiple clients.
    See also [Grammar Girl's
    discussion of *between* and *among*](http://www.quickanddirtytips.com/education/grammar/between-versus-among).

**big-endian**
    Hyphenate. Lowercase except at the beginning of a sentence,
    heading, or list item.
    Recommended: The codebase assumes
    big-endian byte ordering.
    Not recommended: The codebase assumes
    Big Endian byte ordering.
    Not recommended: The codebase assumes
    Big-endian byte ordering.
    Not recommended: The codebase assumes big
    endian byte ordering.

**Avoid: billing charges**
    Don't use *billing charges* to mean charges that appear on a bill.
    Instead, use *billed charges*.
    Use *billing charges* to describe the cost of creating the bill.

**Avoid: black-box**
    Avoid using *black-box*, *blackbox*, or *black box* to
    describe monitoring and testing. Consider using a more precise term for
    clarity.

    - For monitoring, use *synthetic monitoring*.
    - For testing, use *opaque-box testing*.

**Avoid: Black Friday**
    Avoid unless explicitly referring to an event in the US. Instead use
    *peak scale event*.

**Don't use: blackhat, black hat, black-hat**
    Don't use. Instead, use precise terms for the kind of violation or
    practice, such as *illegal*, *unethical*, or *in violation of
    rules*.

**Don't use: blackhole (verb), blackholed (adjective)**
    Don't use. Instead, use a more descriptive term or phrase, such as
    *dropped without notification*.

**Don't use: blacklist, black list, black-list**
    Don't use *blacklist*, *whitelist*, and *graylist*.
    Instead, use more precise terms that are appropriate for your domain.
    - For the noun *blacklist*, consider using a replacement such as
      *denylist*, *excludelist*, or *blocklist*.
    - For the noun *whitelist*, consider using a replacement such as
      *allowlist*, *trustlist*, or *safelist*.
    - For the noun *graylist* (*greylist*), consider using a
      replacement such as *provisional list*.
    In all of these cases, consider that there might not actually be a list
    involved. When replacing problematic terms, be sure to be technically
    accurate for the specific context.
    For the verb forms of these words, a simple word-for-word replacement
    typically isn't the best solution. Instead, replace verbs such as
    *blacklisted* with phrases that accurately convey the relevant
    action. For example:
    Recommended: To deny requests from
    an IP address, add it to the `dos.yaml` file.
    Not recommended: To denylist an IP
    address, add it to the `dos.yaml` file.
    Don't use: To blacklist an IP
    address, add it to the `dos.yaml` file.
    If the command or code that you're documenting uses one of these words,
    then use the words only in direct reference to the code items
    (formatted as code), and make it clear
    what you're referring to.
    Recommended: Add a user to the
    allowlist (`whitelist`) by entering the following:
    `whitelist adduser EMAIL_ADDRESS`.
    Not recommended: Add a user to the
    whitelist by entering the following: `whitelist adduser
    EMAIL_ADDRESS`.
    For more information, see the
    [inclusive documentation](https://developers.google.com/style/inclusive-documentation) page.

**Don't use: blacklisted, black listed, black-listed**
    Don't use. See [blacklist](#blacklist).

**Don't use: blacklisting, black listing, black-listing**
    Don't use. See [blacklist](#blacklist).

**Don't use: blast radius**
    Don't use. Instead, use a more precise term like *affected area* or
    *spatial impact*.

**Avoid: blind**
    Avoid using *blind to* or *blind eye to*. Instead, use more
    precise terms like *ignore*, *unaware of*, *disregard*,
    *avoid*, or *reject*.
    Avoid using *blind writes*. Instead, use a more precise phrase, such
    as *a write operation without a read operation*.
    Avoid using *blind change* or *change blindly*. Instead, use a
    more precise phrase such as *change without first confirming the
    value*.
    When referring to people, use terms like *person who is blind*,
    *screen reader user* (if applicable), *person who is visually
    impaired*, *person who is low-vision*, *magnification user*
    (if applicable).

**blue-green**
    Not *blue/green* or *blue green*.

**boolean**
    In most contexts, *boolean* refers to a specific data type in a
    specific programming language. In such cases, use code font and the exact
    spelling and capitalization of the programming keyword.
    When referring to the abstract data type, use lowercase.
    If you refer to *Boolean mathematics* or *Boolean logic*, use
    uppercase.

**branding information**
    In the Google Cloud console, the phrase *branding information* refers
    to the information that Google shows to users when the client asks them to
    authorize access: specifically, the project's name and logo, and the
    developer's Google Account. This information is set in the **Consent
    screen** page.

**Don't use: break-glass**
    Don't use. Instead, use a more precise term depending on context:

    - To describe a general emergency or procedure that grants emergency
      access, use *emergency access*.
    - To describe a fallback procedure, use *manual fallback* or
      *preplanned procedure*.

**Don't use: brown bag, brown-bag**
    Don't use. Instead, use a more precise term like *learning session*,
    *lunch and learn*, *lunchtime learning session*,
    *casual training*, or *informal training*.

**Don't use: build cop, build sheriff**
    Don't use. Instead, use a more precise term like *build monitor*.

**button**
    In a UI, a link isn't the same as a button; don't use the term
    *button* to refer to a link.
    Use *button* to refer to mechanical buttons (like the volume control
    buttons on the side of a phone) and capacitive touch buttons on a phone
    (like the Home button). You *press* mechanical buttons, and
    *tap* capacitive and on-screen buttons.
