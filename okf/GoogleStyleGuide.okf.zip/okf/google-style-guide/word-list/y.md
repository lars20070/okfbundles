---
type: Section
title: "Word list — Y"
description: "Word list entries for terms beginning with Y."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — Y

## Y

**Don't use: ymmv**
    Don't use. Instead, use something like *Your results might vary*.

**you**
    Use *you* instead of
    [user](https://developers.google.com/style/word-list#user) to address the
    reader of your document. For more information, see
    [Second person and first person](https://developers.google.com/style/second-person).
