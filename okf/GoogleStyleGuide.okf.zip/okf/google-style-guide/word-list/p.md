---
type: Section
title: "Word list — P"
description: "Word list entries for terms beginning with P."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — P

## P

**PaaS**
    Write out on first mention: *platform as a service (PaaS)*.

**page**
    Use *page* to refer to the following:

    - A whole web page, which can include text, images, links, banners, navigational panes,
      and other features.
    - A sub-page of a [console](https://developers.google.com/style/word-list#console) in particular.

    See also
    [documentation or document or documents](https://developers.google.com/style/word-list#documentation).
    Recommended: To refresh the page, press `F5`.

**parameter**
    In our API documentation, *parameter* is usually short for *query
    parameter*; it's a `NAME=VALUE` pair
    that's appended to a URL in an HTTP `GET` request. In some
    contexts, however, the term can have other meanings.

**parent-child or parent/child**
    Not *parent – child* or *parent—child*.

**path**
    Avoid using *filepath*, *file path*, *pathname*, or *path
    name* if possible.

**peer gateway**
    Don't use *on-premises gateway* when you mean a *peer gateway*.
    A peer gateway can be an on-premises device or service or another cloud
    gateway.

**peer network**
    Don't use *on-premises network* when you mean a *peer network*.
    A peer network can be an on-premises network or another cloud network.

**peering zone**
    Not *peer zone*.

**per**
    To express a rate, use *per* instead of the division slash (/),
    unless space constraints require the use of the slash. For more
    information, see
    [Units of measurement](https://developers.google.com/style/units-of-measurement#rates).
    Avoid *per* in contexts other than rate units.
    Recommended: requests per day
    Recommended: create a policy for each
    Pod
    Recommended: according to the style
    guide
    Recommended: in response to your
    request
    Not recommended: requests/day
    Not recommended: create a policy per
    Pod
    Not recommended: per the style guide
    Not recommended: as per your request

**Avoid: performant**
    Avoid where possible. Instead, use a more precise term.
    Recommended: an accurate machine
    learning model
    Not recommended: a performant machine
    learning model

**persist**
    Don't use as a transitive verb. It's best to avoid using as a verb at all,
    especially in
    [passive voice](https://developers.google.com/style/active-voice).
    Recommended: To make the token
    persistent ...
    OK: To make the token persist ...
    Not recommended: The token is persisted
    ...
    Not recommended: To persist the token
    ...

**persistent disk**
    Not *PD*.
    Lowercase except at the start of a sentence.

**personally identifiable information (PII)**
    Some government agencies use the less common term *personally
    identifying information*; use this alternate term only in contexts
    where you're referring to a document that uses this term.

**Don't use: pets versus cattle, pets vs. cattle, pets v. cattle**
    Don't use. Instead, use more precise terms like *persistent versus
    dynamic* or *manually configured versus automated*. For more
    information, see
    [Avoid
    figurative language](https://developers.google.com/style/inclusive-documentation#figurative-language).

**plain text**
    In most contexts, use *plain text*, but use *plaintext* in a
    cryptography context.

**Avoid: please**
    Don't use *please* in the normal course of explaining how to use a
    product, even if you're explaining a difficult task.
    Don't use the phrase *please note*.
    Use *please* only when you're asking for permission or
    forgiveness—for example, when what you're asking for benefits you,
    inconveniences a reader, or suggests a potential issue with a product.
    Recommended: If the issue persists,
    please contact your account representative.
    For more information, see
    [voice and tone](https://developers.google.com/style/voice-and-tone#politeness).

**plugin (noun), plug-in (adjective), plug in (verb)**
    Use the noun form *plugin* when referring to the software component. Use the adjective
    form *plug-in* when referring to the action of installing a software component. Use the
    verb form *plug in* when you're describing the process of installing a software
    component.

**PM**
    See
    [AM, PM](https://developers.google.com/style/word-list#am-pm).

**point to**
    Use to refer to the action of pointing the mouse pointer (focus). This
    action doesn't imply a length of time waiting for the UI to react to user
    action.
    This is similar to the action [hold the
    pointer over (hover)](https://developers.google.com/style/word-list#hold-the-pointer-over). In most cases, it's better to use the verb
    phrase *hold the pointer over* if you want the user to wait for the
    UI to react.

**POJO**
    If you're not actually writing about a Plain Old Java Object for a Java
    audience, use *simple object*. You can write *a simple object,
    similar to a POJO in Java* if that helps your audience.

**PoP**
    Acronym for *point of presence*.
    Recommended: point of presence (PoP)
    Not recommended: point of presence
    (POP)

**pop-up, popup**
    Don't use.
    To describe a window that appears and asks for, or presents, additional
    information, use
    [dialog](https://developers.google.com/style/word-list#dialog).
    To describe a menu that rises from an interface (such as a right-click
    context menu), use *menu*.

**populate**
    OK to use if you're writing about a process populating a table or other
    entity. If you're writing about a person, use *fill in*.
    Recommended: The SQL command
    populates the table with sample data.
    Recommended: When you have finished
    filling in the form ...
    Not recommended: When you have
    finished populating the form ...

**port**
    Use *listen on* (not *to*).

**Avoid: portal**
    Don't use to refer to the Google Cloud console. For more information, see
    [console](https://developers.google.com/style/word-list#console).

**Don't use: possible**
    Don't use *possible* or *impossible* to mean *you can* or
    *you can't*.

**PostgreSQL**
    If the UI uses the name *Postgres*, it's OK to match the UI. Don't
    use *PostgreSQL*.

**Avoid: postmortem**
    Avoid in general usage. Instead, use *retrospective*.
    In disaster recovery (DR) and DevOps contexts, use *blameless
    postmortem*.

**practitioner**
    Avoid using without any supporting information to define the roles that
    you're referring to.
    Recommended: The framework describes
    best practices for architects, developers, administrators, and other cloud
    practitioners.
    Not recommended: The framework
    describes best practices for cloud practitioners.

**pre***
    See
    [guidance about hyphens with prefixes](https://developers.google.com/style/hyphens#prefixes).

**prebuilt**
    Not *pre-built*.

**precapture**
    Not *pre-capture*.

**preemptible**
    Not *pre-emptible* or *pre-emptive*.

**pre-existing**
    Not *preexisting*.

**Don't use: preferred pronouns**
    Don't use. Instead, use *pronouns*.

**prerecorded**
    Not *pre-recorded*.

**pre-shared key**
    Not *preshared key*.

**Avoid: presently, at present**
    Avoid because this word or phrase is implied. The word or phrase can also
    prematurely disclose product or feature strategy or inappropriately imply
    that a product or feature might change.
    See also
    [as of this writing](https://developers.google.com/style/word-list#as-of-this-writing) and
    [currently](https://developers.google.com/style/word-list#currently).
    Recommended: This setting is required.
    Not recommended: At present, this
    setting is required.
    For more information, see
    [Timeless documentation](https://developers.google.com/style/timeless-documentation).

**press**
    Use when referring to pressing a key or a key combination to cause an
    action to occur. Also use for mechanical buttons.
    For on-screen and soft (capacitive) buttons, use *tap*.
    Recommended: Press
    `Control+C` (or `Command+C` on macOS).

**presubmit**
    Not *pre-submit*.

**Avoid: primitive**
    Use with caution. Don't use *primitive* in a disparaging sense.

**(Cloud) project**
    In Google Cloud documentation, use *Google Cloud project* on first
    mention and in any context in which there might be ambiguity about what
    kind of project you're referring to.

**Don't use: pros**
    Don't use. Instead, use a more precise term, such as *advantages*.
