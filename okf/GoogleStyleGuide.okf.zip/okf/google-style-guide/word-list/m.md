---
type: Section
title: "Word list — M"
description: "Word list entries for terms beginning with M."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — M

## M

**Don't use: male adapter**
    Don't use. Instead, use a genderless word like *plug*.

**Don't use: man hours, manhours, man-hours**
    Avoid using gendered terms. Instead use terms like *person hours*.

**Don't use: man-in-the-middle (MITM)**
    Avoid using gendered terms. Instead use terms like *on-path
    attacker* or *person-in-the-middle (PITM)*.

**managed instance group (MIG)**
    OK to abbreviate to *MIG* on subsequent mention. See also
    [instance group](https://developers.google.com/style/word-list#instance-group).

**Don't use: manmade, man made**
    Avoid using gendered terms. Instead use a word like *artificial*,
    *manufactured*, or *synthetic*.

**Don't use: manned**
    Avoid using gendered terms. Instead use terms like *staffed* or
    *crewed*.

**Don't use: manpower, man power, man-power**
    Avoid using gendered terms. Instead use terms like *staff* or
    *workforce*.

**Markdown**
    Always capitalized, even when you're referring to a nonstandard version.

**Don't use: master**
    Use with caution. Never use in conjunction with *slave*. Where
    possible, replace *master* with a specific term that is accurate for
    the context, such as *primary*, *main*, *original*,
    *parent*, *initiator*, *driver*, *controller*,
    *manager*, *mixer*, *aggregator*, *publisher*,
    *leader*, or *active*.

    Guidance | Recommended | Not recommended || Don't use *master* in conjunction with *slave* in any context. | Cloud SQL primary/replica | Cloud SQL master/slave |
    | Avoid using *master* where possible. | - GKE control plane - Jenkins controller - root key (in security) - primary key (in databases) | - GKE master plane - Jenkins master - master key (in security) - master key (in databases) |
    If the command or code that you're documenting uses the literal word
    *master*, then use this word only in direct reference to the code
    item (formatted as code), make it clear
    what you're referring to, and use the new term thereafter.
    See also
    [slave](https://developers.google.com/style/word-list#slave).

**Material Design**
    Capitalize each word in *Material Design*.

**matrix**
    Use the plural *matrixes* unless there is a domain-specific reason
    (for example, a mathematical context) to use *matrices*.

**may**
    In general, reserve for official policy or legal considerations.
    To convey *possibility*, use *can* or *might*
    instead.
    To convey *permission*, use *can* instead.
    See also
    [can](https://developers.google.com/style/word-list#can),
    [could](https://developers.google.com/style/word-list#could),
    [may](https://developers.google.com/style/word-list#may),
    [might](https://developers.google.com/style/word-list#might),
    [must](https://developers.google.com/style/word-list#must),
    [should](https://developers.google.com/style/word-list#should), and
    [would](https://developers.google.com/style/word-list#would).
    For information about clarifying who's performing an action, see
    Active voice.

**MBps**
    Short for *megabytes per second*. By convention, we don't use
    *MB/s*. For more information, see
    [Units of measurement](https://developers.google.com/style/units-of-measurement).

**Mbps**
    Short for *megabits per second*. By convention, we don't use
    *Mb/s*. For more information, see
    [Units of measurement](https://developers.google.com/style/units-of-measurement).

**media type**
    In general, use the term [media type](https://www.iana.org/assignments/media-types/media-types.xhtml).
    In contexts where you need to refer to a *content type*—For example, if you mention
    the `Content-Type` HTTP header—it's okay to use *content type* instead, to avoid
    confusion. Don't use *MIME type*.

**meta***
    See
    [guidance about hyphens with prefixes](https://developers.google.com/style/hyphens#prefixes).

**metafeed**
    Not *meta-feed*.

**metageneration**
    Not *meta-generation*.

**method**
    In programming contexts where *method* refers to a member of a class
    (as in Java), avoid also using the word generically to mean "approach" or
    "manner."

**metropolitan area (metro)**
    In networking, a *metro* is a city where a colocation facility is
    located.

**microservices**
    Not *Microservices* or *micro-services*.

**might**
    Use to convey possibility or an uncertain outcome (for example, "You
    might be prompted to enter your credentials").
    See also
    [can](https://developers.google.com/style/word-list#can),
    [could](https://developers.google.com/style/word-list#could),
    [may](https://developers.google.com/style/word-list#may),
    [must](https://developers.google.com/style/word-list#must),
    [should](https://developers.google.com/style/word-list#should), and
    [would](https://developers.google.com/style/word-list#would).
    For information about clarifying who's performing an action, see
    Active voice.

**Avoid: MIME type**
    *MIME* stands for "Multipurpose Internet Mail Extensions," and was originally used to
    refer to email standards.
    Don't use *MIME* when you mean [media type](https://www.iana.org/assignments/media-types/media-types.xhtml).
    If you feel that might be ambiguous to an audience familiar with the term *MIME*,
    then you can write *media (MIME) type* for clarity.

**Don't use: mobile**
    Don't use *mobile* as a standalone noun. Instead, specify
    *mobile phone*, or if you're talking about more than phones, then use
    *mobile device*.

**mobile data**
    Use instead of *cellular data*.

**mobile device**
    Use *mobile device* when you're referring to more than phones (for
    example, tablets and phones). It's OK to use *phone* (without
    *mobile*) when the context is clear.

**mobile network**
    Use instead of *cellular network*.

**mobile phone**
    If you're talking about more than phones, then use *mobile device*.
    It's OK to use *phone* (without *mobile*) when the context is
    clear.

**Don't use: mom test**
    Don't use *mom test*, *grandmother test*, *grandma test*,
    or *girlfriend test*. Instead, use terms like *beginner user
    test* or *novice user test*.

**Don't use: monkey, monkey test**
    Don't use *monkey* to refer to people. When referring to tests, refer
    to the specific function. For example: *automated, random tests*.

**multi***
    See
    [guidance about hyphens with prefixes](https://developers.google.com/style/hyphens#prefixes).

**multi-cluster**
    Hyphenate. We generally prefer to close prefixed words, but this is an
    exception because it's an established term.

**multi-region, multi-regional**
    Hyphenate when referring to a Google Cloud location that consists of more
    than one region.
    You can use *multi-regional* as an adjective in the context of
    multi-regions, but consider *multi-region* as
    an attributive noun instead, such as in "The dataset is in the EU
    multi-region location." Use *multiregional* in other contexts.

**multi-service**
    Hyphenate. We generally prefer to close prefixed words, but this is
    an exception because it's an established term.

**multi-tenancy**
    Hyphenate. We generally prefer to close prefixed words, but this is
    an exception because it's an established term.

**must**
    Use to describe a required action or state (for example, "You must have
    the Editor role"). You can also write *you need* in order to convey a
    requirement.
    See also
    [can](https://developers.google.com/style/word-list#can),
    [could](https://developers.google.com/style/word-list#could),
    [may](https://developers.google.com/style/word-list#may),
    [might](https://developers.google.com/style/word-list#might),
    [should](https://developers.google.com/style/word-list#should), and
    [would](https://developers.google.com/style/word-list#would).
    For information about clarifying who's performing an action, see
    Active voice.
