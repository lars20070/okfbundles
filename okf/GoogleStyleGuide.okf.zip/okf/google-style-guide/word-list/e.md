---
type: Section
title: "Word list — E"
description: "Word list entries for terms beginning with E."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — E

## E

**each**
    *Each* refers to every individual item taken individually, not to a
    group of items taken collectively. In other words, *each* isn't a
    synonym for *all*. For example, *a list of each item* is
    ambiguous; *a list of all the items* or *a list of the items* is
    generally clearer.

**earlier**
    Use for a range of version numbers, not *lower*.
    Recommended: Use version 2.2 or
    earlier.
    Not recommended: Use version 2.2 or
    lower.
    In Android documentation, don't use
    *earlier* for a range of version numbers. Instead, use *lower*.
    When referring to a position in a document, use *earlier* or
    *preceding*, not *higher*.

**Avoid: easy, easily**
    What might be easy for you might not be easy for others. Try eliminating
    this word from the sentence because usually the same meaning can be conveyed
    without it.

**ecommerce**
    Not *e-commerce*.

**edge availability domain**
    Don't use *edge availability zone*, *metro availability domain*,
    or *metro availability zone*. Don't shorten to *EAD*.

**Don't use: e.g.**
    Don't use. Instead, use phrases like *for example* or *such as*.
    Many people confuse *e.g.* and *i.e.*

**egress**
    When referring to the networking term, use lowercase.

**either**
    When using *either*, use parallel syntax.
    Recommended: Do either option 1 or
    option 2.
    Recommended: Either do option 1 or
    do option 2.
    Not recommended: Either do option 1
    or option 2.
    In general, use *either* only for a choice between two things, not
    for a choice among multiple things. Writing *either A or B or C* will
    distract some readers, but if it's the best phrasing for your situation,
    then use it.

**element**
    In HTML and XML, a tag is a component of an element that indicates
    the start or end of the element. (For example, the
    `<i>` start tag indicates the beginning of the
    `<i>example</i>` element.) In general, don't use
    the term *tag* to refer to an entire element.

**email**
    Not *e-mail*, *Email*, or *E-mail*.
    Don't use as a verb.
    Use a specific verb in front of the word. For example, *send email*.
    This construction is better for translation and a
    [global audience](https://developers.google.com/style/translation).

**emoji**
    Use *emoji* for both singular and plural forms. See [Don't
    know the difference between emoji and emoticons? Let me explain](https://www.theguardian.com/technology/2015/feb/06/difference-between-emoji-and-emoticons-explained) and [What's the Plural of Emoji?](http://www.theatlantic.com/technology/archive/2016/01/whats-the-plural-of-emoji-emojis/422763/)

**enable**
    In procedures, use the appropriate label and action for the
    UI element that the user interacts with. When describing a
    user action or the state of a UI element, use a more precise term where possible. It's OK to
    use *enable* when not referring to a person.
    For turning on or activating an option or feature, use *enable* or
    [turn on](https://developers.google.com/style/word-list#turn-on) consistently:

    - Use the same term in introductory text as described in the
      procedure.
    - Use the same term throughout the document unless there's a
      difference in the UI elements for different procedures.
    Recommended: To enable the API,
    click the toggle.
    Recommended: Enable the API for your
    project.
    For making it feasible to do something, use *lets you*.
    Recommended: The API lets you detect
    features in images.
    Not recommended: The API enables you
    to detect features in images.
    Not recommended: The API allows you
    to detect features in images.
    In Google Workspace documentation, if possible, use
    *turn on* or *on* instead. If referring to the state of a UI element, use
    *available*.

**endpoint**
    Not *end point*.

**enter**
    Use *enter* to refer to the user entering text. If it's important to
    not press `Enter`, explicitly say so. See also
    [type](https://developers.google.com/style/word-list#type).
    Recommended: In the **Owner** box,
    enter your name.
    Recommended: In the **Size** box,
    type a font size.

**ephemeral external IP address**
    Don't use *ephemeral IP address* or *external IP address* to
    refer to ephemeral external IP addresses.

**error-prone (adjective)**
    Hyphenate. Lowercase except at the beginning of a sentence,
    heading, or list item.

**Avoid: etc.**
    Avoid using *etc.*, *and so forth*, and *and so on*
    wherever possible. If you really need to use one, use *etc.*
    Always include the period, even if a comma follows immediately after.
    Recommended: Your app might experience
    problems such as instability or high latency.
    Recommended: Your app might experience
    problems, including instability or high latency.
    Not recommended: Your app might
    experience instability, high latency, and so on.
    Not recommended: Your app might
    experience instability, high latency, etc.
    Not recommended: If your app
    experiences instability, high latency, etc., follow these steps:

**Avoid: eventually**
    Avoid in timeless documentation because this word can become outdated. The
    word can also prematurely disclose product or feature strategy or
    inappropriately imply that a product or feature might change.
    See also
    [future](https://developers.google.com/style/word-list#future) and
    [soon](https://developers.google.com/style/word-list#soon).
    Recommended: This version of the SDK
    is deprecated.
    Not recommended: This version of the
    SDK is deprecated and eventually will be no longer supported.
    For more information, see
    [Timeless documentation](https://developers.google.com/style/timeless-documentation).

**execute**
    Verb commonly used to refer to function calls, SQL queries, and other processes. When the meaning
    is the same, use the simpler word *run* instead. If you need to use a more precise term
    for your context, use that term.

**expander arrow**
    The UI element used to expand or collapse a section of navigation or
    content. If you describe this element, use the terms *expander arrow*
    and *expandable section*
    Don't use terms like *expando* or *zippy*.

**exploit**
    Don't use *exploit* to mean "use."
    Only use *exploit* in the negative sense, such as to describe
    *exploiting a security vulnerability*.

**external VPN gateway**
    Write *external* and *gateway* all lowercase except at the
    beginning of a sentence, heading or list item.

**extract**
    Use instead of *unarchive*, *uncompress*, *untar*, or *unzip*.
