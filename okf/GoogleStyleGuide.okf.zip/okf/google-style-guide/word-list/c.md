---
type: Section
title: "Word list — C"
description: "Word list entries for terms beginning with C."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — C

## C

**can**
    Use *can* in the following ways:

    - To convey permission or ability (for example, "You can access the
      server").
    - To refer to an optional action (for example, "You can also view
      logs with the Log Viewer").
    - To describe a possible outcome (for example, "The process can
      take 30 minutes").
    See also
    [could](https://developers.google.com/style/word-list#could),
    [may](https://developers.google.com/style/word-list#may),
    [might](https://developers.google.com/style/word-list#might),
    [must](https://developers.google.com/style/word-list#must),
    [should](https://developers.google.com/style/word-list#should), and
    [would](https://developers.google.com/style/word-list#would).
    For information about clarifying who's performing an action, see
    Active voice.

**Avoid: canary**
    Don't use *canary* as a verb, and don't use *canarying*.
    When possible, avoid jargon like *canary* and
    *canary testing*. If you use one of these phrases, define it on first
    use or provide a link to the definition, and use it consistently
    throughout the document.

**Don't use: cell phone, cellphone**
    Don't use. Instead, use *mobile phone*, or if you're talking about
    more than phones, then use *mobile device*.
    It's OK to use *phone* (without *mobile*) when the context is
    clear.

**Don't use: cellular data**
    Don't use. Instead, use *mobile data*.

**Don't use: cellular network**
    Don't use. Instead, use *mobile network*.

**chapter**
    When referring to documentation that isn't in the form of a book, don't
    use the term *chapter*. Instead, refer to documents, pages, or
    sections.

**Avoid: check**
    Don't use to refer to marking a checkbox. Instead, use *select*.
    Recommended: Select **Automatically
    check for updates**.
    Not recommended: Check **Automatically
    check for updates**.

**checkbox**
    Not *check box*.

**choose**
    *Choose* is fine to use for generic contexts. For UI elements, use
    [select](https://developers.google.com/style/word-list#select).

**Don't use: chubby**
    Don't use. Instead, use a word that clearly explains what you mean, such
    as *unused* or *overextended*.

**clear**
    Use (as a verb) to refer to clearing a check mark from a checkbox.
    Recommended: Clear **Automatically
    check for updates**.
    Not recommended: Uncheck
    **Automatically check for updates**.
    Not recommended: Deselect
    **Automatically check for updates**.

**Avoid: CLI**
    Don't use *CLI* generically to refer to a command-line interface.
    Instead, refer to the specific command-line interface, such as the
    [Google Cloud CLI](https://developers.google.com/style/word-list#gcloud).

**click**
    When the environment is a desktop with a mouse, use *click* for most
    targets, such as buttons, links, list items, and radio buttons. Don't use
    *click on*.
    Recommended: Click **OK**.
    Not recommended: Click on **OK**.
    Hyphenate *right-click*, *left-click*, and *double-click*.
    When a click or tap action reveals a collapsed list, you can write
    *click to expand* or simply *expand*.
    It's OK to write *click in* when referring to a region that needs
    focus (for example: *click in the window*), but not when referring to
    a control or a link.
    For Android apps, don't use
    *click*. Instead, use
    [tap](https://developers.google.com/style/word-list#tap).

**Don't use: click here**
    Don't use. For information and alternatives, see
    [Avoid vague link text](https://developers.google.com/style/cross-references#vague-link-text).

**clickthrough (noun), click through (verb)**

**client**
    In REST and RPC API documentation, *client* is short for *client
    app*—that is, the app that the developer is writing.
    Don't use *client* as an abbreviation for *client library*;
    instead, use *library*.

**client ID**
    Lowercase except at the beginning of a sentence,
    heading, or list item.

**client secret**
    Lowercase except at the beginning of a sentence,
    heading, or list item.

**Avoid: (Cloud) Cloud**
    Don't use as short for *Google Cloud*.
    For generic references such as *the cloud* or *hybrid cloud*,
    use lowercase.

**Don't use: (Cloud) Cloud console**
    Don't use. Instead, refer to the full name *Google Cloud console*.
    If you aren't discussing any other console (such as the Google Admin
    console), you can abbreviate to *the console* after first mention.
    Use *the* before the tool name. For more information, see
    [console](https://developers.google.com/style/word-list#console).

**Cloud SDK**
    Not *Google Cloud SDK*.

**co***
    See
    [guidance about hyphens with prefixes](https://developers.google.com/style/hyphens#prefixes).

**codebase**
    Not *code base*.

**codelab**
    Not *code lab* or *code-lab*. For more information, see
    [documentation](https://developers.google.com/style/word-list#documentation).

**cold**
    When possible, avoid jargon like *cold
    failover*, *cold standby*, and *cold spare*. If you use one
    of these phrases, define it on first use and use it consistently
    throughout the document.

**colocate**
    Not *co-locate* or *colo*.

**Avoid: compliant, compliance**
    Use with caution. A claim that a product or its output is *compliant*
    with a standard is a strong statement.

**Don't use: comprise**
    Don't use. Instead, use *consist of*, *contain*, or
    *include*.

**Avoid: config**
    Avoid when possible. Instead, spell out the full word when it's used in a
    non-code sense: *configuration* or *configuring*. Use the
    verbatim code item name when referring to, for example, a data structure
    or a file with that name.

**confidential**
    *Confidential* data is data that is protected to prevent unauthorized access. See
    [sensitive](https://developers.google.com/style/word-list#sensitive).

**Don't use: cons**
    Don't use. Instead, use a more precise term, such as *disadvantages*.

**Avoid: console**
    Don't use in isolation. Instead, use the name of the specific console,
    such as the [Google Cloud
    console](https://console.cloud.google.com/) or the Google Admin console.
    Use *the* before the name of a console.
    After giving the full name of a console, you can use a shortened version
    of the name, such as the *Admin console*.
    If you're only discussing the Google Cloud console, after giving the full
    name you can refer to *the console*.
    To refer to a sub-page of a console, use the term *page*.
    If a specific term for a browser-based interface is unavailable, use
    *web interface*.

**Avoid: content type**
    Be as specific as possible when writing about a content type, and use the term only when applicable.
    For example, you can use this term if you're referring to the value of the `Content-Type` HTTP header.
    Also see [media type](https://developers.google.com/style/word-list#media-type).

**Control+S, Command+S, and other keyboard commands**
    To refer to a `Control` character, use
    `Control`+CHARACTER.
    Don't use *Ctl-S*, *Cmd-S*, or *Cloverleaf-S*.
    In most cases, use an uppercase letter for CHARACTER.
    In macOS, many keyboard commands use the `Command` key instead of
    the `Control` key, and there's an `Option` key instead
    of an `Alt` key. If your audience includes macOS users and
    Windows or Linux users, then mention both keyboard commands.
    Recommended: `Control+S`
    (`Command+S` on macOS)

**Avoid: Copy and paste**
    Avoid using. Instead, explain what to enter into a field and not how.
    Recommended: In the
    **Query** field, enter the output from the previous step.
    Not recommended: Copy the output from
    the previous step and paste into the **Query** field.

**Avoid: could**
    Avoid using. Instead, use *can* where possible.
    See also
    [can](https://developers.google.com/style/word-list#can),
    [may](https://developers.google.com/style/word-list#may),
    [might](https://developers.google.com/style/word-list#might),
    [must](https://developers.google.com/style/word-list#must),
    [should](https://developers.google.com/style/word-list#should) and
    [would](https://developers.google.com/style/word-list#would).
    For information about clarifying who's performing an action, see
    Active voice.
    For information about tenses, see
    [Present tense](https://developers.google.com/style/tense).

**CPU**
    All caps. No need to expand the abbreviation on first mention.

**Don't use: crazy, bonkers, mad, lunatic, insane, loony**
    Don't use. Instead, use *complicated*, *complex*,
    *baffling*, *strange*, or *unexpected*, and only for
    inanimate objects.

**Avoid: Create a new ...**
    Avoid using unless you need to distinguish the item from another recently
    created item. Instead, use *Create a ...*
    Recommended: Create a project.
    Not recommended: Create a new project.

**Don't use: cripple**
    Don't use. Instead, use more precise language. For example, instead of
    *it crippled the server*, write *it slowed the server down*.
    When referring to people, use terms that specifically describe a physical
    impairment, such as *person with a motor disability*; *person with
    a mobility impairment* (refers to walking or moving about); *person
    with dexterity impairment* (refers to using a standard mouse or
    keyboard); *person who uses a wheelchair, walker, or cane*;
    *wheelchair user*; *person with restricted or limited mobility*.

**cross-site request forgery**
    Lowercase except at the beginning of a sentence,
    heading, or list item.

**Don't use: curated roles**
    Don't use. Instead, use *predefined roles*.

**Avoid: currently**
    Avoid because this word is implied. The word can also prematurely disclose
    product or feature strategy or inappropriately imply that a product or
    feature might change.
    See also
    [as of this writing](https://developers.google.com/style/word-list#as-of-this-writing) and
    [presently](https://developers.google.com/style/word-list#presently).
    Recommended: Windows isn't supported.
    Not recommended: Windows isn't
    currently supported.
    For more information, see
    [Timeless documentation](https://developers.google.com/style/timeless-documentation).

**custom mode VPC network**
    Not *custom mode network*.

**curl**
    Not *cURL*.
    For information about when to use code format, see
    [Items that are sometimes in code font](https://developers.google.com/style/code-in-text#items-that-are-sometimes-in-code-font).

**Cyber Monday**
    Avoid unless explicitly referring to an event in the US. Instead use
    *peak scale event*.
