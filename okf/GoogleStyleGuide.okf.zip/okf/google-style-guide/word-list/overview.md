---
type: Section
title: "Word list"
description: "Style and usage guidelines for developer documentation terms, including guidance on entry types and numbers/symbols."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list

*Source: <https://developers.google.com/style/word-list>*

> [!NOTE]
> **Note**: This document includes references to potentially disrespectful
> or offensive terms. These terms are listed here to provide usage
> guidance and alternative terms.

## Overview

This word list covers style and usage guidelines that are specific to developer documentation.

If the term that you're looking for isn't on this list, check our other
editorial resources, including our preferred
dictionary,
[Merriam-Webster](https://www.merriam-webster.com/). If there are multiple spellings in
the Merriam-Webster word entry, use the first form listed, which is the most common spelling. For
example, in the
[entry for *cancel*](https://www.merriam-webster.com/dictionary/canceled),
the first form listed for the past tense is *canceled*, indicating that it's more common than
*cancelled*.

If you're looking for a technical definition, then it's often a good idea to check the
authoritative documentation on the topic.

Terminology decisions, including how and when to define or contextualize
terms, often require judgments based on factors like your product area,
your audience, and prevailing convention. Here are some other pages of this
guide that can help you make those types of judgments:

- Jargon
- Inclusive language
- Write for a global audience
- Hyphens
- Capitalization

As always, it's fine to deviate from our guidance if that serves your readers
better. For more information, see [Break the rules](/google-style-guide/introduction.md).

## Word list entry types

All word list entries have a link
icon next to them. To link directly to an entry, you can right-click and
copy the link address, or click and copy the URL from your address bar.

Some word list entries include guidance to *avoid* or *don't use* a
term. Apply this guidance as follows:

- **Use with caution**. A recommendation to avoid using the term *when
  possible*, or to use the term with caution. The term might be ambiguous
  or obscure, so we provide alternative term suggestions or suggest that you
  use a more specific term. However, you can use the term if needed. Where
  appropriate, define the term or use it only once, as explained on the
  Jargon page.
- **Don't use**. In all cases, we prefer to *not use the term*. The
  term might be particularly ambiguous or it might have an offensive or
  non-inclusive association. If such a term appears in code, we recommend that
  you
  replace or write around the term.
- **Android**. Applies only to Android documentation.
- **Google Cloud**. Applies only to Google Cloud documentation.
- **Google Workspace**. Applies only to Google Workspace documentation.

## Numbers and symbols

**+**
    OK to use *+* with numbers in text, such as *customer records with
    300+ demographic attributes*, except in formal contexts.

**Avoid: & (ampersand)**
    Don't use *&* instead of *and* in headings, text, navigation, or
    tables of contents.
    It's OK to use *&* when referencing UI elements that use *&*, or
    in table headings and diagram labels where space constraints require
    abbreviation.
    It's OK to use `&` for technical purposes in code.

**2-Step Verification**
    When referring to Google's
    [2-Step Verification](https://www.google.com/landing/2step/),
    use initial caps.
    When referring to
    [generic 2-step verification](http://searchsecurity.techtarget.com/definition/two-step-verification),
    use lowercase.
