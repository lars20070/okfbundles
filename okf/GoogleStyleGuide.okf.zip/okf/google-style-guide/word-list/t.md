---
type: Section
title: "Word list — T"
description: "Word list entries for terms beginning with T."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — T

## T

**tab**
    When referring to the sub-pages of a [console](https://developers.google.com/style/word-list#console), use
    *page* instead of *tab*.

**table name**
    Two words. Set specific table names in code font.

**tablet**
    *Tablet* is OK. If you don't know whether it's a tablet or a phone,
    use *device*.

**tag**
    See
    [element](https://developers.google.com/style/word-list#element).

**(Android) tap**
    In Android documentation, use for on-screen and soft (capacitive)
    buttons.
    Use instead of *click* when the environment is definitely a
    touch device.
    Use instead of *touch*. However, *touch & hold* (not *touch
    and hold*) is OK to use.
    For mechanical buttons, use
    [press](https://developers.google.com/style/word-list#press).

**Don't use: (Android) tap & hold, tap and hold**
    In Android documentation, don't use. Instead, use *touch & hold*.
    (Not *touch and hold*.)

**Don't use: tarball**
    Don't use. Instead, use *tar file*.

**target**
    Avoid using as a verb when possible, especially in reference to people.
    For some readers, *target* has aggressive connotations. Instead of
    "targeting" audiences, we try to attract them or appeal to them or make
    their lives easier.
    It's OK to use *target* as an adjective, as in *target
    audience*, but consider rephrasing for clarity. Alternatives
    include phrases such as *intended for*, *looking for*,
    *focused on*, and *interacting with*.

**Avoid: terminate**
    Avoid using as a synonym for *stop*. Instead, use words like
    *stop*, *exit*, *cancel*, or *end*.
    For a specific context where you can use *terminate* as a synonym for
    *stop*, see
    [Documenting
    command-line syntax](https://developers.google.com/style/code-syntax#linux-signals).
    In some contexts, such as telephony and networking, *terminate* has
    specific technical meanings that aren't synonyms for *stop*; in those
    contexts, you can use *terminate*.

**Don't use: text box, textbox**
    Don't use. Instead, use *box*. For more information, see
    [Text box](https://developers.google.com/style/ui-elements#textbox).
    In Google Cloud documentation, use
    *field* instead of *box*. For example, "In the **Instance**
    field, specify a value less than 64 characters long."
    In Google Workspace documentation, use
    *field* instead of *box*. For example, "In the **Instance**
    field, specify a value less than 64 characters long."

**their (singular)**
    See
    [they](https://developers.google.com/style/word-list#they).

**then**
    Although it is common in casual usage to omit the word *then* in *if...then*
    statements, you should include helper words like *then* in technical documentation. For
    more information, see
    [Use clear, precise, and unambiguous language](https://developers.google.com/style/translation#clear-language).

**they (singular)**
    This is our preferred gender-neutral pronoun. Whether used as singular
    or plural, it always takes the plural verb. For example, "A user
    authenticates their identity by entering their password." See also
    [gender-neutral he](https://developers.google.com/style/word-list#gender).

**third party (noun), third-party (adjective)**
    Spell as *third party* when used as a noun and as *third-party* when used as an
    adjective.
    Avoid abbreviating to *3rd party* or *3rd-party*. For more information, see
    [Ordinal numbers](https://developers.google.com/style/numbers#ordinal-numbers).

**this, that**
    Where possible, put a noun after *this* or *that* for clarity.
    If doing so results in clunky prose, then don't do it; but even then, try
    thinking about what the noun would be. If you aren't sure what noun
    *this* or *that* refers to, then consider rephrasing—otherwise, your reader
    probably won't know what noun you're referring to, either.

**timeframe**
    Not *time frame*. Avoid where possible, or use an alternative such as
    *period*, *schedule*, *deadline*, or *when*. But if
    you do use it, then write it as one word.

**timeout (noun), time out (verb)**

**timestamp**
    Not *time stamp*.

**time to live**
    Not *time-to-live*. Abbreviate as *TTL* after first use.

**time zone (noun), time-zone (adjective)**
    Spell as *time zone* when used as a noun and as *time-zone* when used as an
    adjective. See also
    [wake lock (noun), wake-lock (adjective)](https://developers.google.com/style/word-list#wake-lock).

**Don't use: tl;dr**
    Don't use. Instead, use something like *To summarize*, or revise the
    sentence.

**toolkit**
    Not *tool-kit* or *tool kit*.

**Don't use: (Android) touch**
    In Android documentation, don't use. Instead, use *tap*. However,
    *touch & hold* is OK to use.

**(Android) "touch & hold"**
    Not *touch and hold*.

**touchscreen**
    Not *touch screen*

**Avoid: traditional**
    If possible, use a more precise term.
    Recommended: Conventionally, Python
    function names are lowercase, with words separated by underscores.
    Not recommended: Traditionally, Python
    function names are lowercase, with words separated by underscores.
    Recommended: This tutorial explains
    how to migrate from an on-premises data warehouse to BigQuery.
    Not recommended: This tutorial
    explains how to migrate from a traditional data warehouse to BigQuery.

**transpile**
    Not *transcompile*.

**Don't use: tribal knowledge, tribal wisdom**
    Don't use. Instead, use a less figurative term to indicate knowledge held
    by a group of people.

**trojan**
    Lowercase when referring to malware.

**Avoid: turn on**
    In procedures, use the appropriate label and action for the
    UI element that the user interacts with.
    For turning on or activating an option or feature, use *turn on* or
    [enable](https://developers.google.com/style/word-list#enable) consistently. Use the same term consistently throughout your
    document.
    Recommended: To turn on Magic Mode,
    follow these steps.
    Recommended: In **Settings**, click
    the **Magic mode** toggle to the on position.

**tutorial**
    OK to use. See
    [documentation](https://developers.google.com/style/word-list#documentation).

**Avoid: type**
    In general, use
    [enter](https://developers.google.com/style/word-list#enter) instead of *type* because
    there is typically more than one way to enter text than typing (such as
    pasting text or speaking).

**typically**
    Use to describe what is usual or expected under normal circumstances.
    Don't use as the first word in a sentence, as doing so can leave the
    meaning open to misinterpretation.
