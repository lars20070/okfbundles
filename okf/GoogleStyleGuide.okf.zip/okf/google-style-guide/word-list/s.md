---
type: Section
title: "Word list — S"
description: "Word list entries for terms beginning with S."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — S

## S

**SaaS**
    Write out on first mention: *software as a service (SaaS)*.

**Don't use: sane**
    Don't use. Instead use a word like *valid* or *sensible*.

**Don't use: sanity check**
    Don't use. Instead, use a term like *quick check*, *confidence
    check*, *preliminary check* or *coherence check*.

**SAP**
    Pronounced as the individual letters *S*, *A*, *P*, so
    write *an SAP system*, not *a SAP system*. For more information, see
    [Indefinite articles before abbreviations](https://developers.google.com/style/abbreviations#articles).

**scale**
    Don't use *scale* alone to say that something is large or increasing.
    Include supporting words to indicate magnitude or direction of change in
    magnitude, whether scaling up or down, such as when you change a machine
    type to add or remove CPUs or RAM, or scaling out or in, such as adding or
    removing instances from a group.
    Recommended: The system performs
    better at a larger scale.
    Not recommended: The system performs
    better at scale.
    Recommended: The system scales up
    quickly, but it scales down more slowly.
    Not recommended: The system scales
    quickly.

**screenshot (noun)**
    Not *screen shot* or *screensnap*.
    Don't use as a verb; instead, use *take a screenshot*.

**scroll**
    OK to use *scroll* as a verb, but if possible, instead use a term
    that isn't specific to implementation. For example, write *go to the
    section*, instead of *scroll to the section*.
    If you use *scroll*, don't use directional language
    like *scroll up*. For more information, see
    [Accessibility](https://developers.google.com/style/accessibility#document-rendering).

**Search (as part of product name)**
    Capitalize *Search* when referring to a product like Google Search.

**Search Console**
    Capitalize each word in *Search Console*.

**see**
    OK as a general term and when referring to links and cross-references. Our
    research indicates that language relating to sight is OK for a wide range
    of readers. For more information, see
    [Cross-references and linking](https://developers.google.com/style/cross-references).

**select**
    Use to describe choosing an item from among multiple options, selecting
    text, or marking a checkbox.
    Recommended: Select **Automatically
    check for updates**.
    Not recommended: Check
    **Automatically check for updates**.

**sensitive**
    *Sensitive* data is data for which the release might be harmful. See
    [confidential](https://developers.google.com/style/word-list#confidential).

**service**
    It's OK to refer to Google products, such as Google Kubernetes Engine or
    Compute Engine, as *services*. However, if the term *services*
    leads to ambiguity, then use the product names.

**service level agreement**
    Lowercase when referring to service level agreements in general.
    It's OK to use title case (*Service Level Agreement*) when referring
    to a specific document.
    OK to abbreviate as *SLA* after first use.

**service level indicator**
    Lowercase except at the beginning of a sentence,
    heading, or list item.
    OK to abbreviate as *SLI* after first use.

**service level objective**
    Lowercase except at the beginning of a sentence,
    heading, or list item.
    OK to abbreviate as *SLO* after first use.

**setup (noun or adjective), set up (verb)**

**Don't use: sexy**
    Don't use. Instead, use precise, positive words, such as *fast*,
    *powerful*, or *elegant*.

**SHA-1**
    Not *SHA1*, except in string literals/enums and in hyphenated phrases
    such as *HSA-SHA1*.

**Avoid: shall**
    Avoid *shall* except under advice from a lawyer. For more
    information, see
    [should](https://developers.google.com/style/word-list#should).

**Avoid: she, her, hers**
    Don't use a gendered pronoun except for a specific individual of known
    gender. Use *they* and *their* for the general singular pronoun.

**Don't use: sherpa**
    If possible, use a more precise term. For example, if you mean
    *guide*, use that term.

**Avoid: shift left**
    In general, avoid using this term to mean moving something earlier in
    time. Instead, use a less figurative phrase, such as *shift earlier*
    or *move to an earlier phase*. This figurative term relies on the
    non-universal assumption that the natural flow is from left to right.
    It's OK to use *shift left* and *shift right* in the context of
    binary multiplication and division.

**Avoid: should, should be**
    Generally avoid.
    Because *should* is ambiguous by definition, it can be problematic. For more information
    and alternatives, see
    [Word choice for recommendations and requirements](https://developers.google.com/style/prescriptive-documentation#word-choice).
    See also
    [can](https://developers.google.com/style/word-list#can),
    [could](https://developers.google.com/style/word-list#could),
    [may](https://developers.google.com/style/word-list#may),
    [might](https://developers.google.com/style/word-list#might),
    [must](https://developers.google.com/style/word-list#must), and
    [would](https://developers.google.com/style/word-list#would).

**sign-in (noun or adjective), sign in (verb)**
    Not *log in* or *signin*.

**Don't use: sign into**
    Don't use. Instead, use *sign in to*.

**Don't use: sign-on, sign on**
    Don't use either form on its own. Use the hyphenated version as part of
    *single sign-on*.

**sign-out (noun or adjective), sign out (verb)**
    Not *log out* or *signout*.

**Avoid: simple, simply**
    What might be simple for you might not be simple for others. Try
    eliminating this word from the sentence because usually the same meaning
    can be conveyed without it.

**since**
    If you mean *because*, then use *because* instead of
    *since*. *Since* is ambiguous; it can refer to the passage of
    time. *Because* refers to causation or the reason for something.

**single most**
    Not *singlemost*.

**single pane of glass**
    Avoid. This term is used to favorably compare a centralized control and
    monitoring interface against the alternative of several disparate
    interfaces. It can almost always be replaced by *single interface* or
    *unified interface*.

**single sign-on (noun or adjective)**

**Don't use: slave**
    Don't use. Instead, use alternative terms appropriate to your domain, such
    as *worker* or *replica*.
    If you're replacing the terms *master* and *slave* together,
    then consider such combinations as *primary*/*secondary*,
    *primary*/*replica*, *original*/*replica*,
    *controller*/*worker*, *initiator*/*responder*,
    *mixer*/*leaf*, *aggregator*/*collector*,
    *publisher*/*subscriber*, *leader*/*follower*, and
    *active*/*standby*.
    If the command or code that you're documenting uses the literal word
    *slave*, then use this word only in direct reference to the code item
    (formatted as code), make it clear what
    you're referring to, and use the new term thereafter. For example, "Invoke
    the secondary (`slave`) process directly when debugging issues
    between the primary and secondary processes."
    See also
    [master](https://developers.google.com/style/word-list#master).

**Don't use: slice and dice**
    Don't use the phrase *slice and dice*. Instead, use specific terms
    appropriate to the task that you're describing. Some possible options
    include: *segment data for analysis* or *break information into
    smaller parts*.

**Don't use: smartphone, smart phone**
    Don't use. Instead, use
    [*mobile phone*](https://developers.google.com/style/word-list#mobile) or
    *phone*. If you're talking about more than phones, then use *mobile
    device*. It's OK to use *phone* (without *mobile*) when the
    context is clear.

**Avoid: soon**
    Avoid in timeless documentation because this word can become outdated. The
    word can also prematurely disclose product or feature strategy or
    inappropriately imply that a product or feature might change.
    See also
    [eventually](https://developers.google.com/style/word-list#eventually) and
    [future](https://developers.google.com/style/word-list#future).
    Recommended: This setting is
    optional.
    Not recommended: This setting is
    optional for existing applications but will soon be required for all
    applications.
    For more information, see
    [Timeless documentation](https://developers.google.com/style/timeless-documentation).

**Avoid: spin up**
    As in *spin up an instance*. Avoid using *spin up* unless you're
    referring to a hard disk; instead, use a less colloquial term like
    *create* or *start*.

**SQL**
    Refer to *a SQL* (pronounced "a sequel"), not *an SQL*. For more
    information, see
    [Indefinite articles before abbreviations](https://developers.google.com/style/abbreviations#articles).

**ssh and SSH**
    Don't use `ssh` or SSH as a verb. SSH is a secure
    communications protocol; `ssh` is a utility.
    Recommended: To establish an SSH
    connection, use the `ssh` command.
    Recommended: Connect to the instance
    by using SSH.
    Not recommended: `ssh` into
    your remote shell.

**Don't use: ssh'ing**
    Don't use. See also
    [ssh and SSH](https://developers.google.com/style/word-list#ssh).
    Recommended: When you use
    `ssh` to log in ...

**startup (noun or adjective), start up (verb)**

**static external IP address**
    Don't use *static IP address* or *external IP address* to refer
    to static external IP addresses.

**status bar**
    Not *statusbar* or *status-bar*.
    Lowercase except at the beginning of a sentence,
    heading, or list item.

**Avoid: STONITH, STOMITH**
    Avoid using
    [graphic or
    metaphorical language](https://developers.google.com/style/inclusive-documentation#graphic-language). Instead, explain the relevant feature, such as
    *fence failed nodes*.

**style sheet**
    *Style sheet* and *stylesheet* are both acceptable spellings. However, be consistent
    with your choice throughout a given document.

**sub-command**
    Not *subcommand*.

**subnet**
    OK to use as a shortening of *subnetwork*. Use the same term consistently throughout your
    document. For more
    information, see [Subnets vs. subnetworks](https://cloud.google.com/compute/docs/vpc/#subnets_vs_subnetworks).

**subtree**
    Not *sub-tree*.

**subzone**
    Not *sub-zone* or *sub zone*.

**such as**
    Use *such as* to introduce examples or draw comparisons. Note that *such as*,
    *like*, and *include* introduce non-exhaustive lists, so it's redundant to combine
    them with *etc.*, *so forth*, or *and more*. See also
    [etc.](https://developers.google.com/style/word-list#etc),
    [like](https://developers.google.com/style/word-list#like). For more information, see
    [Format examples](https://developers.google.com/style/examples).

**surface**
    Avoid as a transitive verb; instead, use a more specific term, such as
    *make people aware of* or *expose*.
    Recommended: To make the audit logs
    available, you must configure the monitoring system.
    Not recommended: To surface audit
    logs, you must configure the monitoring system.
