---
type: Section
title: "Word list — N"
description: "Word list entries for terms beginning with N."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — N

## N

**N/A**
    Not *NA*. Spell out as *not available* or *not applicable*
    on first reference.

**name server**
    Not *nameserver*.

**namespace**
    Not *name space*.

**Avoid: native**
    Avoid using *native* to refer to people.
    When referring to software products, try to use a more precise
    term—for example, use *built-in* to describe a feature that's
    part of a product.
    The term *native* isn't necessarily clear—for example,
    *cloud-native* could mean that something was written for the cloud,
    or that it's built in to a cloud platform, or that it currently exists in
    a cloud platform.
    Alternatives to a term like *cloud-native* could include:
    *modern cloud*, *born in the cloud*, *cloud first*, and
    *cloud-born*.

**navigation bar**
    Don't use to refer to a *navigation menu*. For more information, see
    [Navigation menu](https://developers.google.com/style/ui-elements#navigation-menu).

**neither**
    Write *neither A nor B*, not *neither A or B*.

**Don't use: network IP address**
    Don't use. Instead, use *internal IP address*.

**Avoid: new, newer**
    Avoid in timeless documentation because this word can become outdated.
    *New* also implies that the reader knows the older product and that
    labeling something as *new* is therefore meaningful.
    If you must use *new*, give the reader a reference point—for
    example, a version number or release date.
    Don't use *newer* to refer to a specific version of a product.
    Instead, use
    [*later*](https://developers.google.com/style/word-list#later). Make sure that you provide
    a version number or release date by which to understand *later*.

    In Android documentation, use
    [*higher*](https://developers.google.com/style/word-list#higher) instead of *later*.
    Recommended: The service's network
    analysis feature reports on network health.
    Not recommended: Network analysis, a
    new feature in the service, reports on network health.
    For more information, see
    [Timeless documentation](https://developers.google.com/style/timeless-documentation).

**Don't use: ninja**
    Don't use to refer to a person. Instead, use a term such as *expert*.
    OK to use in reference to companies, tools, software packages, and other
    entities that use the term in their names.

**non***
    See
    [guidance about hyphens with prefixes](https://developers.google.com/style/hyphens#prefixes).

**Avoid: nonce**
    Use with caution: this term has a secondary slang meaning that can cause
    confusion for global readers. Always define the term on first use, and
    only use it in specific technical contexts such as authentication and
    blockchain.
    In end-user documentation and other contexts, use a more descriptive
    phrase, such as *a number that will be used only once*.

**non-key**
    An exception to our usual preference for closed forms.

**Don't use: NoOps**
    Don't use. Instead, use *fully managed*. If you must include the
    term, define it at first use with language such as *fully managed* or
    *no operations*, but not *non-operational*. Don't use
    *noops*.
    For an instruction that does nothing, use
    [no-op](https://wikipedia.org/wiki/NOP_(code)) or the
    specific instruction name for your context.

**NoSQL**
    Not *No-SQL* or *No SQL*.

**(Android) notification drawer**
    In Android contexts, don't hyphenate. Lowercase except at the beginning of a sentence,
    heading, or list item.

**Avoid: now**
    Avoid when describing features of products or services because this word
    is implied.
    If the intent of the text is a comparison between past and present, you
    can use *now*—for example, "In versions of the tool earlier
    than 1.10, you could use only the default value, but now you can assign a
    custom value."
    Recommended: This feature lets you use
    combinations of user properties.
    Not recommended: This feature now lets
    you use combinations of user properties.
    For more information, see
    [Timeless documentation](https://developers.google.com/style/timeless-documentation).

**Don't use: nuke**
    Don't use. Instead use *remove* or *attack*. For example, a
    *denial-of-service attack*.
