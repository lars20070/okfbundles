---
type: Section
title: "Word list — K"
description: "Word list entries for terms beginning with K."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — K

## K

**Don't use: k8s**
    Don't use. Instead, use *Kubernetes*.

**KBps**
    Short for *kilobytes per second*. By convention, we don't use
    *KB/s*. For more information, see
    [Units of measurement](https://developers.google.com/style/units-of-measurement).

**Kbps**
    Short for *kilobits per second*. By convention, we don't use
    *Kb/s*. For more information, see
    [Units of measurement](https://developers.google.com/style/units-of-measurement).

**Don't use: kebab, kabob, kebab menu, kabob menu**
    Don't use. Instead use the `aria-label` for that particular
    icon. For example,
    **More**. For more information, see
    [Buttons and icons](https://developers.google.com/style/ui-elements#buttons).

**Don't use: kebab case, kabob case, kebab-case, kabob-case**
    Don't use. Instead, use *dash-case*.

**key**
    Don't use as an adjective in the sense of *crucial* or
    *important*.
    If you use *key* as a noun, specify which kind of key you're
    referring to on first mention, because there are many kinds of
    keys in technical contexts.

**key pair**
    A pair of keys, such as a public key and a private key. Contrast with
    *key-value pair*, which refers to a pairing that specifies a value
    for a variable (as in configuration files).

**key ring**
    Use instead of *keyring* (without the space) when referring to a
    grouping of Cloud KMS keys.

**key-value pair**
    Use instead of *key/value pair* or *key value pair*.

**Avoid: kill**
    Avoid when possible. Instead, use words like *stop*, *exit*,
    *cancel*, or *end*. For exceptions to this rule, see
    [Documenting command-line
    syntax](https://developers.google.com/style/code-syntax#linux-signals).
