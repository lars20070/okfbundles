---
type: Section
title: "Word list — D"
description: "Word list entries for terms beginning with D."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — D

## D

**dash**
    A dash (`—`) isn't the same character as a hyphen
    (`-`). The characters are used for different purposes.
    Therefore, don't use the word *dash* to refer to a hyphen.

**Avoid: dashboard**
    Don't use to refer to the Google Cloud console. For more information, see
    [console](https://developers.google.com/style/word-list#console).
    Use *dashboard* not *Dashboard* unless it's officially part of a
    product name.

**data**
    Use *data* as singular, not plural; *the data is*, not
    *the data are*.
    Use data as a mass noun, not a count noun; *less data*, not
    *fewer data*.

**data center**
    Not *datacenter*.

**data center campus**
    Use when referring to an entire physical location, which can encompass one
    or more data centers.

**data cleaning**
    Not *data cleansing*.

**data flow (noun); dataflow (noun)**
    If it's possible to replace with the phrase *flow of data*, then use
    two words: *data flow*.
    If that replacement doesn't work, such as when referring to something like
    stream processing or reactive programming, then use one word:
    *dataflow*.

**data source**
    Not *datasource*.

**datastore**
    Not *data store*.

**data type**
    Not *datatype*.

**dead-letter queue, dead letter**
    Define on first use, for example *dead-letter queue (unprocessed
    messages queue)*.

**deep linking**
    Not *deep-linking*. However, if you can replace with
    *linking*, then do so.

**Avoid: deficient**
    Don't use to refer to a person.
    OK to use to refer to a condition of a computer system.

**Avoid: deformed**
    Don't use to refer to a person.
    OK to use to refer to a condition of a computer system or
    inanimate object.

**Don't use: demilitarized zone (DMZ)**
    Don't use. Instead, use a more precise term like *perimeter network*.

**Don't use: denigrate**
    Don't use. Instead, use *disparage*.

**Don't use: denylist (verb), denylisted, denylisting**
    Don't use as a verb. Instead, rewrite to improve clarity.
    OK to use *denylist* as a noun.
    For more information, see
    [blacklist](https://developers.google.com/style/word-list#blacklist).

**deprecate**
    To *deprecate* an item is to recommend against the item's use,
    typically as a warning that the item will soon be unavailable or
    unsupported. Don't use *deprecated* to mean *removed*,
    *deleted*, *shut down*, or *turned down*.

**Don't use: deselect**
    Don't use to refer to clearing a check mark from a checkbox. Instead, use
    *clear*.
    Recommended: Clear **Automatically
    check for updates**.
    Not recommended: Deselect
    **Automatically check for updates**.
    Not recommended: Uncheck
    **Automatically check for updates**.

**Don't use: desire, desired**
    Don't use. Instead, use a word like *want* or *need*.
    Recommended: Set the value to the
    size that you want.
    Not recommended: Set the value to
    the size that you desire.
    Not recommended: Set the value to
    the desired size.

**Don't use: Developers Console**
    Don't use. For more information, see
    [console](https://developers.google.com/style/word-list#console).

**DevOps**
    Short for *development operations*. No need to spell out on first
    mention unless the audience requires it. For more information, see [DevOps](https://wikipedia.org/wiki/DevOps).

**dialog**
    Use *dialog* for the UI element sometimes called a [dialog box](http://wikipedia.org/wiki/Dialog_box).
    Use *dialogue* only for verbal interaction between people.

**directory, folder**
    If the context that you're documenting (such as an IDE's GUI) uses one
    term or the other, use that term. If not, then use *directory* in a
    command-line context, and *folder* in a GUI context. When in doubt,
    default to *directory*.

**Avoid: disable**
    Don't use *disable* or *disabled* to describe something that's
    broken.
    When describing a user action or the state of a UI element, use a more
    precise term where possible. You can use *inactive*,
    *unavailable*, *deactivate*, *turn off*, or
    *deselect*, depending on the context. Use the same term consistently throughout your
    document.
    See also
    [enable](https://developers.google.com/style/word-list#enable).

**Don't use: disclosure triangle, disclosure widget**
    Don't use. Instead, use *expander arrow*.

**display (verb)**
    Don't use as an intransitive verb. *Display* is a transitive verb;
    therefore, it requires an object. It is often misused in technical
    documentation, as demonstrated by the following example:
    Recommended: The Output Directories
    area appears.
    Recommended: The Output Directories
    area is displayed.
    Not recommended: The Output
    Directories area displays.
    The following example demonstrates correct usage of the verb
    *display* but means something quite different from the preceding
    examples.
    Recommended: The Output Directories
    area displays the vector image.

**distributed denial-of-service (DDoS)**
    Hyphenate as shown. On subsequent mention, use *DDoS*.

**DNS server policy**
    Lowercase *server policy*.

**DNSKEY**
    One word, all capital letters.

**documentation or document or documents**
    To refer specifically to the text on a page that explains a product, feature, or service,
    use *this document*, and not *this article*, *this topic*, *this doc*, or
    *this page*. It's OK to use *this tutorial*, *this quickstart*, or *this
    codelab* for those specific documentation types.

    Always spell out *documentation* except in cases where space is limited, such as in
    tabs and URLs.

    See also
    [page](https://developers.google.com/style/word-list#page).
    Recommended: You can find many
    examples in this document.
    Not recommended: You can find many
    examples in this article.
    Recommended: This document provides
    guidance about creating tables.
    Not recommended: This page provides
    guidance about creating tables.

**documentation set**
    Not *doc set* or *docset*.

**Avoid: does not yet**
    Avoid in timeless documentation because this phrase can become outdated.
    The phrase can also prematurely disclose product or feature strategy or
    inappropriately imply that a product or feature might change.
    Recommended: The Google Cloud console
    doesn't support this IAM role.
    Not recommended: The Google Cloud
    console does not yet support this IAM role.
    For more information, see
    [Timeless documentation](https://developers.google.com/style/timeless-documentation).

**Don't use: dojo**
    Don't use. Instead, use a precise term that is accurate for the context,
    such as *training* or *workshop*.

**domain name registrar**
    Lowercase except at the beginning of a sentence,
    heading, or list item.

**Domain Name System Security Extensions (DNSSEC)**
    Write out and capitalize each word on first use. OK to abbreviate as
    *DNSSEC* after first use.

**(Android) double-tap**
    Hyphenate. Lowercase except at the beginning of a sentence,
    heading, or list item.

**Avoid: downscope**
    Consider using a more descriptive term like *constrain scope* or
    *reduce scope*. Because *downscope* might not be broadly
    understood, if you use the term, make sure to define it on first use.
    Don't use *down scope* or *down-scope*
    Recommended: Reducing the scope of a
    token helps you follow the principle of least privilege.
    Recommended (first use): The IAM
    recommender helps you *downscope* (reduce) the permissions that are
    available to your users.

**drag**
    Use *drag*, not *click and drag* and not *drag and drop*.
    OK to use *drag-and-drop* as an adjective.
    Recommended: Drag the USER
    to the **Authorized** box.

**Avoid: drop-down**
    In most cases, you can omit *drop-down* from phrases like *drop-down list* or
    *drop-down menu*, and just use *list* or *menu*. Include *drop-down* as a
    modifier only if the omission would cause ambiguity. Don't use *drop-down* as a
    standalone noun.

**Don't use: dumb down**
    Don't use. Instead, use a word or phrase what's happening, such as
    *simplify* or *remove technical jargon*.

**Don't use: dummy variable**
    Don't use to refer to placeholders. Instead, use *placeholder*.
    Also don't use if referring to the concept in statistics known as a
    [dummy variable](https://en.wikipedia.org/wiki/Dummy_variable_(statistics)).
    Instead, use alternate terms such as
    *indicator variable*, *design variable*, *one-hot
    encoding*, *Boolean indicator*, *binary variable*, or
    *qualitative variable*.
