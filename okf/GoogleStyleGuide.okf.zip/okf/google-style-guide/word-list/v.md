---
type: Section
title: "Word list — V"
description: "Word list entries for terms beginning with V."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — V

## V

**v (abbreviating *version*)**
    Use lowercase.

**Don't use: via**
    Don't use.

**Don't use: vice versa**
    Don't use. Instead, use a phrase like *the other way around*,
    *conversely*, or *otherwise*. In some contexts, vice versa is
    unclear or imprecise because in a complex sentence it's hard to know which
    two things are swapped with each other. In such cases, make it explicitly
    clear what two things are swapped.

**virtual machine (VM) instance**
    Use when first introducing virtual machines on a given page. For
    subsequent mentions, you can use *VM instance* or *VM*.
    For Google Cloud: on first mention of a Compute Engine VM,
    use *Compute Engine instance* and then use *compute instance*
    throughout the rest of the document. If you need to indicate other types of
    VMs, use *VM*, *VM instance*, or *bare metal instance*.
    See also
    [GKE node](https://developers.google.com/style/word-list#gke-node).

**Don't use: visually challenged**
    See
    [blind](https://developers.google.com/style/word-list#blind).

**VLAN attachment**
    Don't use the following: *interconnect attachment (VLAN)*,
    *Interconnect attachment*, *Cloud Interconnect attachment*, or
    any variation thereof. See also
    [interconnectAttachment](https://developers.google.com/style/word-list#interconnectattachment).

**Don't use: voila**
    Don't use.

**Don't use: voodoo**
    Don't use. Instead, use a term like *mysterious*, *complicated*,
    or *nondeterministic*.

**Don't use: vs.**
    Don't use *vs.* as an abbreviation for *versus*; instead, use
    the unabbreviated *versus*.
