---
type: Section
title: "Word list — A"
description: "Word list entries for terms beginning with A."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — A

## A

**a and an**
    Use *a* when the next word starts with a consonant *sound*,
    regardless of what letter it starts with. For more information, see
    Articles (a, an, the).

**A/B testing**
    Capitalize and use slash notation for *A/B*.

**Avoid: abnormal**
    Don't use to refer to a person.
    OK to use to refer to a condition of a computer system.

**Avoid: abort**
    Avoid in general usage. Instead, use words like *stop*, *exit*,
    *cancel*, or *end*. In Linux, *abort* refers to a type of
    signal that terminates an abnormal process.

**about versus on**
    When a cross-reference includes information that describes what the
    cross-reference links to, use *about* instead of *on*.
    Recommended: For more information
    about indexes, see [Managing indexes](https://cloud.google.com/firestore/docs/query-data/indexing).
    Not recommended: For more information
    on indexes, see [Managing
    indexes](https://cloud.google.com/firestore/docs/query-data/indexing).

**Avoid: above**
    Don't use for a range of version numbers. Instead, use
    [*later*](https://developers.google.com/style/word-list#later).
    Don't use to refer to a position in a document. Instead, use
    *earlier* or *preceding*.
    Don't use to refer to a position in the UI. Instead, write instructions
    that avoid directional language. For more information,
    see Writing accessible documentation.
    It's OK to use *above* in a non-directional way, such as when describing a hierarchy.

**Avoid: access (verb)**
    Avoid when you can. Instead, use friendlier words like *see*,
    *edit*, *find*, *use*, or *view*.

**access token**
    Lowercase except at the beginning of a sentence,
    heading, or list item.

**Don't use: account name**
    Don't use. Instead, use [*username*](https://developers.google.com/style/word-list#username).

**Avoid: actionable**
    Avoid unless it's the clearest and simplest phrasing for your audience.
    Instead, leave it out or replace it with a phrase like *that you can act
    on* or *useful*.
    Don't use *actionable* in the legal sense without consulting a
    lawyer.

**Don't use: (Android) action bar**
    In Android documentation, don't use. Instead, use
    [*app bar*](https://developers.google.com/style/word-list#app-bar).

**ad tech**
    Write out on first mention: *advertising technology (ad tech)*.
    Don't use *adtech* or *ad-tech*.

**address bar**
    Use to refer to the URL bar or the combined URL bar and search box in a
    browser.
    Don't use *omnibox*.

**ad hoc**
    OK to use in database and analytics contexts to mean "free-form" or
    "user-written" (for example, *ad hoc queries* or *an ad hoc
    chart*). For other contexts, try to find a more specific English
    equivalent.
    Don't hyphenate or italicize the term.

**Don't use: admin**
    Write out *administrator* unless it's the name of a UI label or other
    element.
    It's OK to use *admin* in Android
    documentation.

**Don't use: (Android) administrator**
    In Android documentation, don't use. Instead, use *admin*.

**advertised route priority**
    OK to also use *base advertised route priority* when discussing
    region-to-region costs.
    Don't shorten or use variations of these terms.

**Don't use: agnostic**
    Don't use. Instead, use a more precise term like
    *platform-independent*.

**AI**
    In general, you can use *AI* without spelling out *artificial intelligence*.
    Most readers are familiar with the abbreviation *AI*. If you think your audience isn't
    familiar with the term, spell it out on first use.

**Don't use: aka**
    Don't use. Instead, write out *also known as*, or present an
    alternative term using parentheses or the word *or*. You can also
    write out a definition.
    Recommended:
    Geographic data, also known as geospatial data, is ...
    Recommended: Geographic data
    (geospatial data) is ...
    Recommended: Geographic data, or
    geospatial data, is ...

**(Android) all apps screen**
    In Android documentation: Lowercase except at the beginning of a sentence,
    heading, or list item.

**Don't use: allowlist (verb), allowlisted, allowlisting**
    Don't use as a verb. Instead, rewrite to improve clarity.
    OK to use *allowlist* as a noun.
    For more information, see
    [blacklist](https://developers.google.com/style/word-list#blacklist).

**Don't use: allows you to**
    Don't use. Instead, use *lets you*. For more information, see
    [enable](https://developers.google.com/style/word-list#enable).

**alpha**
    Lowercase except when part of a product name.
    Recommended: PRODUCT_NAME
    Alpha
    Recommended: PRODUCT_NAME
    is in alpha.

**Avoid: America, American**
    Use only to refer to the *Americas* or the *American continent*.
    Don't use to refer to the United States. Instead, use a more precise term
    like *the US* or *the United States*, and *people in the
    US*. For more information, see
    [US](https://developers.google.com/style/word-list#us).

**among**
    See
    [between versus among](https://developers.google.com/style/word-list#between).

**AM, PM**
    To be consistent with [Material Design](https://material.io/design/communication/data-formats.html#date-and-time),
    use all caps, no periods, and a space before.
    Recommended: 9:00 AM
    Recommended: 10:30 PM

**Avoid: and/or**
    Don't use unless space is limited, such as in a table. For more
    information, see
    [Slashes](https://developers.google.com/style/slashes#and-or).

**(Android) Android**
    When referring to the operating system, capitalize *Android*.

**(Android) Android-powered device**
    Not *Android device*.

**Avoid: and so on**
    Avoid using *and so on* whenever possible. For more information,
    see
    [etc.](https://developers.google.com/style/word-list#etc).

**anti***
    See
    [guidance about hyphens with prefixes](https://developers.google.com/style/hyphens#prefixes).

**Avoid: anti-pattern**
    Avoid using *anti-pattern*, particularly as a standalone heading.
    Instead, consider using a more specific and broadly understood term.
    Recommended: Avoid these five SQL
    errors.
    Recommended: Avoid these five
    programming practices that make SQL queries inefficient.
    Not recommended: Avoid these five SQL
    anti-patterns.

**API**
    Use *API* to refer to either a web API or a language-specific API.
    Don't use *API* when referring to a method or a class. For example,
    don't write *This resource has one API* to mean "This resource has
    one method."

**Don't use: API Console, APIs console, developer console, dev console, or Google API Console**
    Don't use. Instead, refer to the *Google APIs Explorer* or to the
    *Google Cloud console*. For more information, see
    [console](https://developers.google.com/style/word-list#console).

**API Console key**
    In most contexts, use *API key* instead of *API Console key*.
    In Apps admin APIs, it's OK to use *API Console key* to distinguish
    from other API keys.

**API key**
    Not *developer key* or *dev key*.

**APIs Explorer**
    Not *API explorer* or other variants.

**app**
    In general, use *app* instead of *application* when referring to
    programs for end users, especially in the context of mobile or web
    software.
    In some contexts, such as enterprise software, it's OK to use
    *application* to convey a sense of greater complexity.
    Use *application* in standard phrases such as *application
    programming interface*.

**(Android) app bar**
    In Android contexts, formerly *action bar*.

**appendix**
    Use the plural *appendixes*, not *appendices*.

**application**
    See
    [app](https://developers.google.com/style/word-list#app).

**as**
    If you mean *because*, then use *because* instead of
    *as*. *As* is ambiguous; it can refer to the passage of time.
    *Because* refers to causation or the reason for something.

**Avoid: as of this writing**
    Avoid because this phrase is implied. The phrase can also prematurely
    disclose product or feature strategy or inappropriately imply that a
    product or feature might change.
    See also
    [currently](https://developers.google.com/style/word-list#currently) and
    [presently](https://developers.google.com/style/word-list#presently).
    Recommended: BigQuery doesn't support
    that function.
    Not recommended: As of this writing,
    BigQuery doesn't support that function.
    For more information, see
    [Timeless
    documentation](https://developers.google.com/style/timeless-documentation).

**authentication and authorization**
    In general, use the word *authenticated* only to refer to users,
    and use *authorized* only to refer to requests that are sent by a
    client app on behalf of an authenticated user.

    A user *authenticates* their identity by entering their password
    (or giving some other proof of identity). The *authenticated
    user* then *authorizes* the client app to send an
    *authorized request* to the server on the user's behalf.
    When you want to use a preposition with *authenticate*, use
    *against*.

**Don't use: authN, authZ**
    Don't use. Instead, use *authentication* or *authorization*.

**auto***
    See
    [guidance about hyphens with prefixes](https://developers.google.com/style/hyphens#prefixes).

**autohealing**
    Not *auto-healing*.

**auto mode VPC network**
    Not *auto mode network*.

**autopopulate**
    Not *auto populate* or *auto-populate*.

**autoscaling**
    Not *auto-scaling*.

**autotagging**
    Not *auto-tagging*.

**Don't use: autoupdate**
    Don't use. Instead, use *automatically update*.

**Avoid: -aware**
    Avoid using as a compound modifier, as in *healthcare-aware*.
    OK to use when it's part of a product name, such as *Identity-Aware
    Proxy*.
