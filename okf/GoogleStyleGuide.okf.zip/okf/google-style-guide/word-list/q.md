---
type: Section
title: "Word list — Q"
description: "Word list entries for terms beginning with Q."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — Q

## Q

**Avoid: quick, quickly**
    What might be quick for you might not be quick for others. Try
    eliminating this word from the sentence because usually the same meaning
    can be conveyed without it.

**quota**
    In API contexts, often refers to API usage limits. Where possible, it's
    best to use a more specific term, such as *usage limit*; the word
    *quota* means many different things to many different people.
    In some contexts, such as Google Cloud documentation, the standard term is
    *quota*, so use that term.
