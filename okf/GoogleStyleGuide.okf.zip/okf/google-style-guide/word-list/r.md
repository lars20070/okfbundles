---
type: Section
title: "Word list — R"
description: "Word list entries for terms beginning with R."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — R

## R

**RDP**
    Don't use as a verb. Instead, use *connect using RDP*. If it's
    clear from context that they're using RDP, it's OK to use *connect*.

**re***
    See
    [guidance about hyphens with prefixes](https://developers.google.com/style/hyphens#prefixes).

**read-only**
    Not *read only*. Always hyphenate *read-only*.

**(Android) recents screen**
    In Android contexts, use instead of *overview screen*.

**Don't use: redline**
    Don't use as a verb. Instead, use precise terms appropriate to the
    context.
    In the context of editing or providing a review, refer to those actions or
    to *tracking changes*.
    In the context of setting priorities and planning work, refer to those
    actions or to *priority lining*.

**Don't use: regex**
    Don't use. Instead, use *regular expression*.

**rehost**
    Use to describe the migration of an app or workload with no changes or
    minimal changes to that app or workload. Also known as *lift and shift*. For more
    information, see [Rehost: lift and shift](https://cloud.google.com/architecture/migration-to-gcp-getting-started#rehost_lift_and_shift) in the Cloud Architecture Center.
    On first mention, associate rehost with lift and shift. Okay to use *rehosting* as needed
    after first mention.
    Recommended: You can use this reference architecture to
    efficiently rehost (lift and shift) on-premises applications to the cloud.
    Recommended: The first step to modernization is to rehost
    your application in the cloud (also known as lift and shift).
    Don't use *the forklift approach*.

**Don't use: repo**
    Don't use. Instead, use *repository*.

**Don't use: Representational State Transfer**
    Don't use. To people unfamiliar with REST, this acronym expansion is
    meaningless; it's better to refer to it as REST and not explain what it
    stands for.

**Don't use: reservation, off the**
    Don't use.

**resource record set**
    Not *resource recordset*.

**Don't use: retarded**
    Don't use. If you are referring to a system or component being slowed,
    use the word *slowed*.

**Don't use: retriable, triable**
    Don't use *retriable* or *triable*, unless a code item uses that
    spelling. Outside of code font, write around the term.

**Avoid: retryable, tryable**
    Where possible, write around *retryable* and *tryable*. For
    example, write out *you can try it again* or *can be tried
    again*.

**review**
    If you mean "read, potentially for the first time," then use *read*
    instead of *review*.
    If you mean "read critically, commenting on problems" (as in *code
    review*), then *review* is fine.
    Avoid using phrasing like "If you've never heard of OAuth, then review the
    OAuth documentation."

**RFC**
    When referencing an RFC specification, use a space between *RFC* and
    the number (for example, *RFC 2318*).

**Avoid: roll out**
    Don't use to mean a sudden or instantaneous launch. If you use *roll
    out*, define what you mean. When possible, use a more precise,
    non-figurative term like *gradual*, *in stages*, *phases*,
    or *progressive*.

**Don't use: RTFM**
    Don't use. Instead, use a more precise phrase like "For more information,
    see ...."

**runbook**
    Not *run book*.

**runtime, run time**
    Use the noun *runtime* when referring to the environment in which
    software runs, such as a Ruby or Java runtime.
    Use the noun phrase *run time* when referring to the time during
    program execution when something occurs, as contrasted with *compile
    time*, for example.
    Recommended: The profiler collects
    data at run time, and the scheduler uses this data at compile time to
    improve performance for subsequent runs.
    Recommended: The App Engine standard
    environment has two generations of runtime environments. The
    second-generation runtimes significantly improve the capabilities of App
    Engine.
