---
type: Section
title: "Word list — G"
description: "Word list entries for terms beginning with G."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — G

## G

**GBps**
    Short for *gigabytes per second*. By convention, we don't use
    *GB/s*. For more information, see
    [Units of measurement](https://developers.google.com/style/units-of-measurement).

**Gbps**
    Short for *gigabits per second*. By convention, we don't use
    *Gb/s*. For more information, see
    [Units of measurement](https://developers.google.com/style/units-of-measurement).

**(Cloud) `gcloud` CLI**
    Use the full name *Google Cloud CLI* the first time that you mention
    the product on a page.

**Don't use: gender-neutral he, him, or his (or she or her)**
    Don't use. Instead, use the singular *they* (see [Jane Austen and other famous authors violate what everyone learned in
    their English class](http://www.pemberley.com/janeinfo/austheir.html)). Don't use *he/she* or *(s)he* or other
    such punctuational approaches. For more information, see
    [Pronouns](https://developers.google.com/style/pronouns).

**generative AI**
    Spell out *generative*. Use sentence case.
    Don't use *gen AI* or *Gen AI*.
    Don't hyphenate *generative AI* as an adjective unless you must do
    so for clarity. See also
    [AI](https://developers.google.com/style/word-list#ai).

**Don't use: ghetto**
    Don't use. Instead use more precise terms like *clumsy*,
    *workaround*, or *inelegant* to refer to code that isn't in a
    production-ready state.

**Don't use: gimp, gimpy**
    Don't use. Instead, use precise, non-figurative language to refer to a
    deficiency in a component.
    OK to use in reference to companies, tools, software packages, and other
    entities that use the term in their names.

**GKE node**
    Use when first introducing GKE nodes on a given page. For subsequent
    mentions, you can use *node*. A GKE node is a worker machine that
    runs containerized applications and other workloads. The machine is a
    Compute Engine VM that GKE creates during cluster creation. See also
    [virtual machine (VM) instance](https://developers.google.com/style/word-list#virtual-machine-instance).

**Avoid: Google, Googling**
    Don't use as a verb or gerund. Instead, use *search with Google*.

**Google Account, Google Accounts**
    Capitalize *Account*.

**Google API Client Library for LANGUAGE (Java, .NET, etc.)**
    On second and subsequent use, you can abbreviate to
    *LANGUAGE client library*.

**Don't use: Google API Console, Google APIs Console**
    Don't use. For more information, see
    [console](https://developers.google.com/style/word-list#console).

**Google Cloud**
    Not *GCP*, *Cloud Platform*, or *Cloud*.

**Google Cloud console**
    If you're only discussing the Google Cloud console, it's OK to shorten to
    *the console* after first use on a given page.
    Use *the* before the console name. For more information, see
    [console](https://developers.google.com/style/word-list#console).

**Google Cloud project ID**
    Not *Cloud project ID* or *GCP project ID*. You can also
    shorten to *project ID*, but be aware that that term is ambiguous in
    some contexts.

**Don't use: Google Developers Console**
    Don't use. For more information, see
    [console](https://developers.google.com/style/word-list#console).

**Google I/O**
    Not *I-O* or *IO*.

**Google Play services**
    Write *services* in lowercase.

**Google Play services SDK**
    Write *services* in lowercase.

**Don't use: grandfather clause, grand-father clause, grand father clause**
    Don't use. See
    [grandfathered](https://developers.google.com/style/word-list#grandfathered).

**Don't use: grandfathered**
    Don't use to refer to something that is allowed to violate a rule because
    it predates the rule. Instead, use an adjective like *legacy* or
    *exempt* or a verb like *made an exception*.
    Recommended: The app is exempt because
    it was released before the new requirements were announced.
    Not recommended: The app is
    grandfathered in because it was released before the new requirements were
    announced.

**Avoid: gray-box, grey-box**
    Avoid using *gray-box*, *graybox*, or *gray box* to
    describe testing.
    To refer to testing that's a combination of clear and opaque testing
    methods, describe exactly what it's doing.
    If you need to refer to this type of testing after you describe it,
    consider using a more precise term for clarity, such as *translucent-box
    testing*.

**Don't use: grayed-out, greyed-out, gray out, grey out**
    Don't use. Instead, use *unavailable*.

**Don't use: grayhat, greyhat, gray hat, grey hat**
    Don't use. Follow the guidance for
    [black hat](https://developers.google.com/style/word-list#blackhat) when
    referring to someone violating rules or laws.

**Don't use: graylist, greylist, gray list, grey list, gray-list, grey-list**
    Don't use. See
    [blacklist](https://developers.google.com/style/word-list#blacklist).

**Don't use: graylisted, greylisted, gray listed, grey listed, gray-listed, grey-listed**
    Don't use. See
    [blacklist](https://developers.google.com/style/word-list#blacklist).

**Don't use: graylisting, greylisting, gray listing, grey listing, gray-listing, grey-listing**
    Don't use. See
    [blacklist](https://developers.google.com/style/word-list#blacklist).

**(Cloud) `gsutil`**
    In the Google Cloud context, use code font for both the name of the
    command-line utility and the command.

**Don't use: guru**
    If possible, use a more precise term. For example, if you mean
    *expert* or *teacher*, use those terms.

**Don't use: guys, you guys**
    When referring to a group of people use non-gendered language, such as
    *everyone* or *folks*.

**Don't use: gypsy**
    Don't use. To refer to the people, use *Romani*, *Roma*, or
    *Traveller*, as appropriate for the specific group you're referring
    to. In place of metaphorical uses of the term, use more precise phrases.
