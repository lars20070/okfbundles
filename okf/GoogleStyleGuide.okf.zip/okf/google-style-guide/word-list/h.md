---
type: Section
title: "Word list — H"
description: "Word list entries for terms beginning with H."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — H

## H

**Don't use: hamburger, hamburger menu**
    Don't use. Instead use the `aria-label` for that particular
    icon. For example, **Menu**.
    For more information, see
    [Buttons and icons](https://developers.google.com/style/ui-elements#buttons).

**Don't use: hands off, hands-off**
    Use a less figurative phrase, such as *automated*. If you're
    referring to a group that doesn't do anything during a process, write a
    description.

**Don't use: hands on, hands-on**
    Use a less figurative phrase, such as *customizable*, or write a
    description of the activity.

**Don't use: hang, hung**
    Don't use to refer to a computer or system that is not responding.
    Instead, use *stop responding* or *not responding*. For more
    information, see
    [Avoid figurative language](https://developers.google.com/style/inclusive-documentation#figurative-language).

**happiness and satisfaction**
    Use *happiness* when referring to a customer's perception of a
    site's reliability. Use *satisfaction* when referring to whether the
    site meets the customer's needs.
    Site reliability engineering (SRE) content generally refers to
    measuring *customer happiness* instead of *customer
    satisfaction*. The two phrases are not equivalent.
    The distinction the SRE documentation makes is between satisfying a need
    (a dispassionate act) and establishing an emotional response (creating
    happiness). Although it is difficult to measure happiness precisely, SRE
    uses [service level indicators
    (SLIs)](https://developers.google.com/style/word-list#service-level-indicator) to quantify user perception. For example, a customer might feel
    a "need" to watch a show on TV. If the show is available, the customer's
    need is satisfied. But if playback is slow or choppy, the customer might
    not be happy.
    For more information about SRE and measuring reliability, see [The Happiness Test](https://www.coursera.org/lecture/site-reliability-engineering-slos/the-happiness-test-ELmSr).

**hardcode (verb), hardcoded (adjective)**
    Don't hyphenate.

**Avoid: he, him, his**
    Don't use a gendered pronoun except for a specific individual of known
    gender. Use *they* and *their* for the general singular pronoun.

**healthcare**
    Not *health care* or *health-care*.

**Avoid: health check**
    Use with caution. When describing an action taken for a computer system,
    only use the term *health check* if this is the term that appears in
    the interface. Be certain to remove any ambiguity regarding whether the
    term refers to health in the medical sense.
    Use detailed, non-figurative language as much as possible, such as
    referring to a node *being responsive* instead of referring to a node
    being healthy.

**Avoid: healthy**
    Don't use. See
    [health check](https://developers.google.com/style/word-list#health-check).

**high availability (noun), high-availability (adjective)**
    Spell as *high availability* when used as a noun and as *high-availability* when
    used as an adjective. See also
    [load balancing (noun), load-balancing (adjective)](https://developers.google.com/style/word-list#load-balancing).
    Lowercase except when part of a product name, but OK to abbreviate as
    *HA* after first use.

**higher**
    Don't use for a range of version numbers. Instead, use
    [*later*](https://developers.google.com/style/word-list#later).
    Don't use to refer to a position in a document. Use *earlier* or
    *preceding*.
    Don't use to refer to a position in the UI. Instead, write instructions
    that avoid directional language. For more information, see
    Writing accessible documentation.
    In Android documentation, use
    *higher* for a range of version numbers, not *later*.
    A release with the highest version number might not be the latest version.
    For example, if version 2.0 of an operating system receives a bug-fix
    update after version 3.0 has been released, then version 2.0.1 might be
    the latest version, even though its version number is lower than 3.0.

**high performance computing (HPC)**
    Don't hyphenate. Lowercase except at the beginning of a sentence,
    heading, or list item.

**Don't use: hit**
    Don't use as a synonym for *click*, *press*, or *type*.

**hold the pointer over**
    Only use this verb phrase in the following cases:

    - When the user needs to hold their mouse over a UI element, but not
      click the UI element. This action involves waiting for the UI to
      react—for example, waiting for a tooltip to open or waiting for a
      submenu to open.
    - When the duration of time is important.

    The phrase *point to* is more common.
    See also
    [point to](https://developers.google.com/style/word-list#point-to).
    Recommended: In the **Admin**
    menu, hold the pointer over **File**, and then click **New**.
    Not recommended: In the **Admin**
    menu, hover over **File**, and then click **New**.

**Avoid: holiday, the holidays**
    Don't use to refer to the end of the year. Instead, refer to specific
    quarters or months.

**(Android) home screen**
    Two words in Android contexts; not *homescreen* or
    *home-screen*.

**hostname**
    Not *host name*.

**hot**
    When possible, avoid jargon like *hot failover*,
    *hot standby*, and *hot spare*. If you use one of these phrases,
    define it on first use and use it consistently throughout the document. However, see
    [hotspot](https://developers.google.com/style/word-list#hotspot).

**hotspot**
    In databases, *hotspots* occur when a small number of nearby rows are
    accessed frequently in a short period of time, causing CPU spikes and
    affecting performance. Use *hotspot* and *hotspots* as nouns.
    Don't use verb and gerund forms such as *hotspotting*, because they
    translate less consistently.
    When you use *hotspot*, define it the first time that you use it on
    a page as you normally do with jargon.
    Recommended: Hotspots in one table
    can affect the performance of other tables.
    Not recommended: Hotspotting in one
    table can affect the performance of other tables.

**Don't use: housekeeping, house keeping, house-keeping**
    Don't use. Instead, use less figurative and more precise terms, such as
    *maintenance* and *cleanup*.

**Don't use: hover**
    Don't use. Instead use [*hold the
    pointer over*](https://developers.google.com/style/word-list#hold-the-pointer-over).

**HTTPS**
    Not *HTTPs*.
