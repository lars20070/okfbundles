---
type: Section
title: "Word list — F"
description: "Word list entries for terms beginning with F."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — F

## F

**fail over (verb), failover (noun, adjective)**

**Don't use: fat**
    Don't use. Instead, use a precise modifier that conveys the appropriate
    meaning. For example, use *high-capacity network connection* instead
    of *fat connection* or *full-featured client* instead of *fat
    client*.
    Instead of using fat in a negative sense, such as *trim the fat*,
    refer in a more concrete manner to the *removal of unused items*.
    OK to use as an acronym when referring to file allocation table (FAT).

**Don't use: female adapter**
    Don't use. Instead, use a genderless word like *socket*.

**Fast Healthcare Interoperability Resources (FHIR)**
    Refer to *a FHIR* (pronounced "a fire," as in "a FHIR store"), not *an FHIR*.
    For more information, see
    [Indefinite articles before abbreviations](https://developers.google.com/style/abbreviations#articles).

**filename**
    Not *file name*

**file system**
    Not *filesystem*.

**fill in; fill out**
    Use *fill in* when referring to entering information in individual
    fields.
    Use *fill out* when referring to completing an entire form.
    Recommended: Fill out the
        questionnaire. Be sure to fill in the required fields.

**Don't use: final solution**
    Don't use. Instead, use *solution* as a standalone term or, depending
    on the context, *definitive*, *optimal*, *best*, or *last
    solution*.

**fintech**
    Write out on first mention: *financial technology (fintech)*. Don't
    use *FinTech* or *fin-tech*.

**firewalls**
    Don't use in Compute Engine or networking documentation. Instead, use
    *firewall rules*.
    Exception: If you're explaining how firewall rules work, you can explain
    that every network has an implied virtual distributed firewall.
    Outside of Compute Engine or networking documentation, the term
    *firewalls* is acceptable.

**Don't use: first class, first-class, first-class citizen**
    Don't use *first class* or *first-class citizen*. Instead, use
    another term that's appropriate for the context, such as *higher-order*,
    *anonymous*, or *nested*, or loosely describe the specific
    characteristics or features of the entity, resource, language, or framework.
    Recommended: These widgets have full access to the event system and lifecycle hooks.
    Not recommended: The widgets are first-class components in the UI framework.
    Recommended: Virtual machines are higher-order resources that can participate in resource groups and are integrated in a variety of identity, networking, and storage services.
    Not recommended: Virtual machines are treated as first-class resources across the identity, networking, and storage services.
    For more information, see
    [Write inclusive documentation](https://developers.google.com/style/inclusive-documentation).

**following**
    It's not necessary to use a noun after *following* unless it helps
    provide clarity and enables accessibility. See
    [Tables](https://developers.google.com/style/tables#table-placement).
    Recommended: ... in the following
    code sample ...
    Recommended: ... in the following
    table ...
    Recommended: ... do the following:
    ...

**Avoid: foo**
    Avoid when possible even though it's a common term in the developer
    community. Instead, use a clearer and more meaningful placeholder name.

**for example**
    When you introduce an example using the phrase *for example*, follow the phrase by a comma. For clarity, when
    introducing an example, separate the example using dashes, commas, or parentheses from the
    rest of the sentence as appropriate, or introduce the example in a separate sentence.
    Recommended: Enter a name for the instance—for example, `my-instance-99`.
    Recommended: Enter a six-digit hex number (for example, `228B22`), and then click **OK**.
    Recommended: Enter a six-digit hex number, and then click **OK**. For example, if you want the color forest
    green, enter `228B22`.
    For more information, see
    [Format examples](https://developers.google.com/style/examples).

**Avoid: for instance**
    Don't use the phrase *for instance* to introduce examples to avoid confusion with the
    noun *instance*. Instead, use *for example*, *like*, or *such as*. For
    more information, see
    [for example](https://developers.google.com/style/word-list#for-example).

**frontend**
    Not *front-end* or *front end*.

**Avoid: functionality**
    Use with caution. With respect to hardware or software,
    *functionality* refers to a set of associated functions or
    capabilities and how they work. However, the word is sometimes overused,
    especially when the intended meaning is *capabilities* or
    *features*.

**Avoid: future, in the future**
    Avoid in timeless documentation because this word or phrase can become
    outdated.
    See also
    [eventually](https://developers.google.com/style/word-list#eventually) and
    [soon](https://developers.google.com/style/word-list#soon). For more
    information, see
    [Timeless documentation](https://developers.google.com/style/timeless-documentation).
