---
type: Section
title: "Word list — W"
description: "Word list entries for terms beginning with W."
tags:
  - guide
  - Google
  - word-list
timestamp: 2026-06-12T00:00:00Z
---

# Word list — W

## W

**wake lock (noun), wake-lock (adjective)**
    Spell as *wake lock* when used as a noun and as *wake-lock* when used as an
    adjective. See also
    [time zone (noun), time-zone (adjective)](https://developers.google.com/style/word-list#time-zone).

**walkthrough**
    Not *walk-through*.

**Don't use: war room, warroom, war-room**
    Don't use. Instead, use a more precise term to describe the activity or
    team. Depending on context, possible alternatives include *rapid
    response team*, *situation response team*, *situation room*,
    *incident-management team*, or *media monitoring room*.

**warm**
    When possible, avoid jargon like *warm
    failover*, *warm standby*, and *warm spare*. If you use one
    of these phrases, define it on first use and use it consistently
    throughout the document.

**we**
    Don't use *we* (or other first-person plural pronouns such as
    *our* or *us*) to address the reader who is performing the
    tasks that you're documenting. Instead, use *you*.
    It's OK to use *we* to refer to the organization that's represented
    as the author of the document as long as the antecedent is clear. For more
    information, see
    [Second person and first person](https://developers.google.com/style/second-person).

**web (lowercase)**

**WebAssembly, Wasm**
    Use the capitalization established in the
    [WebAssembly specification](https://webassembly.github.io/spec/core/intro/introduction.html#introduction).

**web application firewall (lowercase)**

**Don't use: webmaster, web master**
    Don't use. Instead, use a more precise term to describe the specific role,
    such as *website owner*, *website administrator*, *web content
    manager*, *owner of a site*.

**web server**
    Not *webserver*.

**whether**
    - To decide whether it's more appropriate to use *if* or
      *whether*, see [Grammar Girl's
      discussion of *if* and *whether*](http://www.quickanddirtytips.com/education/grammar/if-versus-whether).
    - To decide whether you need to add *or not* when using
      *whether*, see [the New York
      Times's blog post about whether (or not)](http://afterdeadline.blogs.nytimes.com/2010/03/01/whether-or-not/).

**while**
    Don't use to indicate a contrast. Instead, use a more precise term, such
    as *although*.
    OK to use to refer to a period of time.

**Avoid: white-box**
    Avoid using *white-box*, *whitebox*, or *white box* to
    describe monitoring and testing. Consider using a more precise term for
    clarity.

    - For monitoring, use *introspective monitoring*.
    - For testing, use *clear-box testing*.

**Avoid: white glove, white-glove, whiteglove**
    Avoid using. Instead use terms like *high-touch*, *premium*, or
    *platinum-level*.

**Don't use: whitehat, white hat, white-hat**
    Don't use. Instead, use precise terms for the kind of compliance, such as
    *legal*, *ethical*, or *following the rules*.

**Avoid: white label, whitelabel, white-label**
    Don't use. Instead, use a more precise term for your context, such as
    *unbranded*, *unlabeled*, or *blank label*.

**Don't use: whitelist, white list, white-list**
    Don't use. See
    [blacklist](https://developers.google.com/style/word-list#blacklist).

**Don't use: whitelisted, white listed, white-listed**
    Don't use. See
    [blacklist](https://developers.google.com/style/word-list#blacklist).

**Don't use: whitelisting, white listing, white-listing**
    Don't use. See
    [blacklist](https://developers.google.com/style/word-list#blacklist).

**whitepaper**
    Not *white paper*.
    When possible, use a more precise term. The term *whitepaper* has a variety of
    meanings in various contexts. If you must use the term *whitepaper*, also use descriptive
    terms to provide context.

**whitespace**
    Not *white space*.

**wildcard**
    Not *wild card*.

**will**
    Avoid. Applies equally to its past tense, *would*. See also
    [Present tense](https://developers.google.com/style/tense) and
    [Documenting future features](https://developers.google.com/style/future-features).

**Don't use: wish**
    Don't use. Instead, use a word like *want* or *need*.

**with**
    Don't use *with* when expressing ownership:
    Recommended: A handset that has 2 GB
    of RAM.
    Not recommended: A handset with 2 GB
    of RAM.
    Don't use *with* when expressing use:
    Recommended: Use the debugging tool
    to debug.
    Not recommended: Debug this tool with
    the debugging tool.

**workload**
    The term *workload* might refer to software, like an app or
    a service; to app resources, like data and infrastructure; or to physical
    components that work together.
    Where possible, use a more precise term to describe what you mean. If you
    use the term *workload*, define your meaning on first use as you
    normally would with jargon and other ambiguous terms.

**Don't use: World Wide Web**
    Don't use. Instead, use *web*.

**Avoid: would**
    Avoid using. Instead, use *can* where possible.
    See also
    [can](https://developers.google.com/style/word-list#can),
    [could](https://developers.google.com/style/word-list#could),
    [may](https://developers.google.com/style/word-list#may),
    [might](https://developers.google.com/style/word-list#might),
    [must](https://developers.google.com/style/word-list#must), and
    [should](https://developers.google.com/style/word-list#should).
    For information about clarifying who's performing an action, see
    Active voice.
    For information about tenses, see
    [Present tense](https://developers.google.com/style/tense).
