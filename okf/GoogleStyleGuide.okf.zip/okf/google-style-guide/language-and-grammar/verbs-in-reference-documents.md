---
type: Section
title: "Verbs in reference documents"
description: "Guidance for verb forms in API reference documentation."
tags:
  - guide
  - Google
  - grammar
timestamp: 2026-08-03T15:30:00Z
---

# Verbs in reference documents

*Source: <https://developers.google.com/style/reference-verbs>*

When you're writing reference documentation for a method, phrase the main
method description in terms of what the method does (*gets*, *lists*, *creates*,
*searches*), rather than what the developer would use it to do (*get*, *list*,
*create*, *search*).

It's a subtle distinction that manifests mostly in whether the initial verb
in the description has an *-s* at the end or not.

Recommended: tasks.insert: Creates a new
task on the specified task list.

Not recommended: tasks.insert: Create a
new task on the specified task list.

For more information and examples, see the
[Google Cloud API design guide](https://cloud.google.com/apis/design/documentation#method_description).

## Citations

[1] [Google Developer Documentation Style Guide — Verbs in reference documents](https://developers.google.com/style/reference-verbs)
