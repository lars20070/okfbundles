---
type: Section
title: "Articles (a, an, the)"
description: "Guidance for using definite and indefinite articles in documentation."
tags:
  - guide
  - Google
  - grammar
timestamp: 2026-08-03T15:30:00Z
---

# Articles (a, an, the)

*Source: <https://developers.google.com/style/articles>*

For ease of comprehension and translation, include definite and indefinite
articles (*a*, *an*, and *the*) in your writing. Don't skip
articles for brevity, including in headings and titles.

Recommended: Create a VM instance

Not recommended: Create VM instance

For more information about using standard English word order and about writing
for a global audience in general, see
[Write for a global audience](/google-style-guide/general-principles/global-audience.md).

For more information about writing clear headings and titles, see
[Headings and titles](/google-style-guide/formatting-and-organization/headings-and-titles.md).

For information about using articles before product names, see
[Articles before product names](/google-style-guide/product-names.md).

For information about using *a* or *an* before an abbreviation when the pronunciation
of the abbreviation can vary, see
[Indefinite articles before abbreviations](/google-style-guide/language-and-grammar/abbreviations.md).

## Citations

[1] [Google Developer Documentation Style Guide — Articles](https://developers.google.com/style/articles)
