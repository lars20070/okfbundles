# Language and grammar

* [Abbreviations](/google-style-guide/language-and-grammar/abbreviations.md) — Guidelines for using acronyms, initialisms, and shortened words in documentation.
* [Active voice](/google-style-guide/language-and-grammar/active-voice.md) — Guidance for using active voice instead of passive voice in documentation.
* [Anthropomorphism](/google-style-guide/language-and-grammar/anthropomorphism.md) — Guidance for avoiding attributing human qualities to software or hardware.
* [Articles (a, an, the)](/google-style-guide/language-and-grammar/articles.md) — Guidance for using definite and indefinite articles in documentation.
* [Capitalization](/google-style-guide/language-and-grammar/capitalization.md) — Guidelines for capitalization in documentation, including product names and headings.
* [Contractions](/google-style-guide/language-and-grammar/contractions.md) — Guidance for using contractions in documentation.
* [Pluralization](/google-style-guide/language-and-grammar/pluralization.md) — Guidelines for forming plural nouns, abbreviations, and product names.
* [Possessives](/google-style-guide/language-and-grammar/possessives.md) — Guidelines for forming possessives for nouns, product names, and code items.
* [Prepositions](/google-style-guide/language-and-grammar/prepositions.md) — Guidance for placing prepositions in sentences.
* [Present tense](/google-style-guide/language-and-grammar/present-tense.md) — Guidance for using present tense in documentation.
* [Pronouns](/google-style-guide/language-and-grammar/pronouns.md) — Guidelines for pronoun usage, including gender-neutral and ambiguous references.
* [Second person and first person](/google-style-guide/language-and-grammar/second-person.md) — Guidance for addressing the reader as *you* and using first-person pronouns carefully.
* [Sentence structure](/google-style-guide/language-and-grammar/sentence-structure.md) — Guidance for ordering information in sentences, with circumstances before instructions.
* [Verbs in reference documents](/google-style-guide/language-and-grammar/verbs-in-reference-documents.md) — Guidance for verb forms in API reference documentation.
