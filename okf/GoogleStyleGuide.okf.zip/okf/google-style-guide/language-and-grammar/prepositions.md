---
type: Section
title: Prepositions
description: "Guidance for placing prepositions in sentences."
tags:
  - guide
  - Google
  - grammar
timestamp: 2026-08-03T15:30:00Z
---

# Prepositions

*Source: <https://developers.google.com/style/prepositions>*

There's no rule against placing a preposition at the end of a sentence.
Place the preposition where it makes the most sense and makes the sentence easiest
to read. Use prepositions as needed, even at the ends of sentences.

Recommended: For details, see the client
library documentation for the language you're interacting with.

Not recommended: For details, see the
client library documentation for the language with which you're interacting.

Include prepositions that increase clarity, omit unnecessary prepositions,
and don't clutter the sentence with too many prepositions.

Recommended: The icon for the connector
manager turns green within a few minutes, and the connector instance is
displayed shortly after.

For information about which preposition to use when referring to UI elements, see
[UI elements and interaction](/google-style-guide/computer-interfaces/ui-elements-and-interaction.md).

## Citations

[1] [Google Developer Documentation Style Guide — Prepositions](https://developers.google.com/style/prepositions)
