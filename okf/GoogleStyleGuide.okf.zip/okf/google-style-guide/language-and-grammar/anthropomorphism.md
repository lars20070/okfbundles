---
type: Section
title: Anthropomorphism
description: "Guidance for avoiding attributing human qualities to software or hardware."
tags:
  - guide
  - Google
timestamp: 2026-08-03T15:30:00Z
---

# Anthropomorphism

*Source: <https://developers.google.com/style/anthropomorphism>*

Don't attribute human qualities to software or hardware.

Anthropomorphism is a category of figurative language, which is less precise and is often harder
to understand and translate than direct language. For more information, see
[Write for a global audience](/google-style-guide/general-principles/global-audience.md).

Recommended: A Delimiter object specifies
where to split a string.

Not recommended: A Delimiter object tells
the splitter where a string should be broken.

Recommended: The PC detects a new
device.

Not recommended: The PC sees a new
device.

## Citations

[1] [Google Developer Documentation Style Guide — Anthropomorphism](https://developers.google.com/style/anthropomorphism)
