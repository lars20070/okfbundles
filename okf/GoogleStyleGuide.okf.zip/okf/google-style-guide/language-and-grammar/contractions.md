---
type: Section
title: Contractions
description: "Guidance for using contractions in documentation."
tags:
  - guide
  - Google
  - grammar
timestamp: 2026-08-03T15:30:00Z
---

# Contractions

*Source: <https://developers.google.com/style/contractions>*

In general, we write our documentation in an [informal tone](/google-style-guide/general-principles/voice-and-tone.md), so we
recommend using common two-word contractions such as *you're*, *don't*, and
*there's*.

## Negation contractions

In particular, we recommend using negation contractions such as *isn't*, *don't*, and
*can't*. It's easy for a reader to miss the word *not* when they're scanning, whereas
it's harder to misread *don't* as *do*.

If you need to emphasize the negative, you can use text formatting such as `is
<em>not</em>`, which renders as "is *not*." But in most cases, you don't
need emphasis to make your point clear.

## Contractions to avoid

Don't make up nonstandard contractions such as *guides're* or *browser's* (where
*'s* means *is*).

Don't use three-word contractions such as *mightn't've*.

## Citations

[1] [Google Developer Documentation Style Guide — Contractions](https://developers.google.com/style/contractions)
