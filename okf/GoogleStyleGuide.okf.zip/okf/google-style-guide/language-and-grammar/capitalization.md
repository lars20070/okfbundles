---
type: Section
title: Capitalization
description: "Guidelines for capitalization in documentation, including product names and headings."
tags:
  - guide
  - Google
  - capitalization
timestamp: 2026-08-03T15:30:00Z
---

# Capitalization

*Source: <https://developers.google.com/style/capitalization>*

Follow the standard [capitalization rules](https://owl.purdue.edu/owl/general_writing/mechanics/help_with_capitals.html) for American English. Additionally,
do the following:

- Don't use unnecessary capitalization; before you capitalize a word, think
  about why (and whether) it should be capitalized.
- Don't rely on a difference in capitalization to convey meaning. For example,
  although people who are familiar with Kubernetes probably understand that a
  capitalized *Pod* is a Kubernetes unit, and a lowercase *pod* is
  any other kind of pod, that distinction is likely lost on many casual
  readers or those who are new to the domain.
- Don't use all-uppercase, except in the following contexts: in official
  names, in [abbreviations](/google-style-guide/language-and-grammar/abbreviations.md) that are always
  written in all-caps, or when referring to code that uses all-caps.
- Don't use
  [camel
  case](https://en.wikipedia.org/wiki/Camel_case), except in official names or when referring to code that uses camel
  case.

For information about how to capitalize specific words, see the
[word list](/google-style-guide/word-list/).

## Capitalize product names

For information about how to capitalize product names, see
[Product names](/google-style-guide/product-names.md).

## Capitalization in titles and headings

In [document titles and headings](/google-style-guide/formatting-and-organization/headings-and-titles.md), use sentence case. That is,
capitalize only the first word in the title, the first word in a subheading after a colon, and any
proper nouns or other terms that are always capitalized a certain way.

Even though you're using sentence case, don't put a period at the end of a title or
heading.

### Capitalization in references to titles and headings

In references to any title or heading from a document that follows this guide, use sentence case
even if the title or heading itself uses title case. That way, when the title or heading is
eventually updated to sentence case, the reference will match.

When you reference the title of any work or source that doesn't follow this guide, retain the
original capitalization.

For more information about internal and external references, see
[Cross-references and linking](/google-style-guide/linking/cross-references-and-linking.md).

## Capitalization and colons

Use a lowercase letter to begin the first word of the text immediately
following a colon, unless the text is one of the following:

- A proper noun (*Open source software: Hadoop*)
- A heading; see also [Capitalization in titles
  and headings](#capitalization-in-titles-and-headings)
- A quotation (*Arthurian wit: "Bring me yon sworde"*)
- Text that follows a label such as *Caution* or *Note*

## Capitalization and figures

Use sentence case for captions. Use sentence case for labels, callouts, and
other text in images and diagrams.

## Capitalization in glossaries and indexes

Use lowercase for glossary and index terms unless the term is a proper noun
or has another reason to require capitalization.

Use sentence case for glossary definitions.

## Capitalization and hyphenated words

When a hyphenated word is the first word in a sentence or in a heading,
capitalize only the first element in the word, unless a subsequent element is a
proper noun or proper adjective.

## Capitalization in lists

Use sentence case for items in all types of lists. For more information, see
[Capitalization and end punctuation](/google-style-guide/formatting-and-organization/lists.md).

## Capitalization for tables in text

Use sentence case for all the elements in a table: contents, headings,
labels, and captions.

## Special capitalization style names

Don't use a casing style name, such as *camel case* or *snake case*, to describe a
casing style. These names don't localize well and they aren't standardized. Instead, explain what
the requirements are and provide an example.

Recommended: Enter the value for the
`attribute` field in the format where there are no spaces between words and the
first letter of each word is capitalized—for example, `AssertionAccount`.

## Citations

[1] [Google Developer Documentation Style Guide — Capitalization](https://developers.google.com/style/capitalization)
