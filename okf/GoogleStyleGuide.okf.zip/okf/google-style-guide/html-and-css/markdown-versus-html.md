---
type: Section
title: "Markdown versus HTML"
description: Guidance on choosing between Markdown and HTML for documentation authoring.
tags:
  - html-and-css
  - markdown
  - html
timestamp: 2026-08-01T06:28:39Z
---

# Markdown versus HTML

*Source: <https://developers.google.com/style/markdown>*

Use either HTML or Markdown. Some of this style guide assumes that you're using HTML. If you're
using Markdown, details like what HTML elements to use in various contexts might be
irrelevant to you.

Markdown is easier to write than HTML, and it's easier for most humans to
read Markdown source than HTML source. However, HTML is more expressive
(particularly regarding [semantic tagging](/google-style-guide/html-and-css/html-and-semantic-tagging.md))
and can achieve some specific effects that might be difficult or impossible in
Markdown. For example, you might have to switch to using the HTML `code` element
for special characters in code such as nonbreaking spaces.

In the end, which one to use is primarily a matter of personal preference;
however, if your team or your document template already uses one or the other,
it may be best to use whatever they use.
