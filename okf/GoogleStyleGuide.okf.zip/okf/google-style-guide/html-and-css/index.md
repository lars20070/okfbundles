# HTML and CSS

* [HTML and semantic tagging](/google-style-guide/html-and-css/html-and-semantic-tagging.md) — Guidance on using HTML elements for their intended semantic purposes and avoiding semantic misuse for visual formatting.
* [HTML formatting](/google-style-guide/html-and-css/html-formatting.md) — Guidance on HTML formatting conventions including indentation, case, and line length.
* [Markdown versus HTML](/google-style-guide/html-and-css/markdown-versus-html.md) — Guidance on choosing between Markdown and HTML for documentation authoring.
