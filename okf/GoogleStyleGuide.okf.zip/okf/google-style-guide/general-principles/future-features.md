---
type: Section
title: Future features
description: "Guidance for avoiding documentation of future or unapproved features."
tags:
  - guide
  - Google
timestamp: 2026-08-03T15:30:00Z
---

# Future features

*Source: <https://developers.google.com/style/future>*

Avoid documenting future features or products, even in innocuous
ways. Don't pre-announce anything in documentation unless it has been approved by your legal counsel.

See also [Present tense](/google-style-guide/language-and-grammar/present-tense.md) and
[Timeless documentation](/google-style-guide/general-principles/timeless-documentation.md).

## Citations

[1] [Google Developer Documentation Style Guide — Future features](https://developers.google.com/style/future)
