# General principles

* [Accessibility](/google-style-guide/general-principles/accessibility.md) — General guidelines for writing developer documentation with accessibility in mind.
* [Excessive claims](/google-style-guide/general-principles/excessive-claims.md) — Guidelines for avoiding excessive, unverifiable, or subjective claims in documentation.
* [Future features](/google-style-guide/general-principles/future-features.md) — Guidance for avoiding documentation of future or unapproved features.
* [Write for a global audience](/google-style-guide/general-principles/global-audience.md) — Guidelines for writing documentation that's clear, concise, and translatable for a global audience.
* [Write inclusive documentation](/google-style-guide/general-principles/inclusive-language.md) — Guidelines for writing developer documentation with inclusivity and diversity in mind.
* [Jargon](/google-style-guide/general-principles/jargon.md) — Guidance for avoiding jargon and using specialized terminology appropriately.
* [Prescriptive documentation](/google-style-guide/general-principles/prescriptive-documentation.md) — Guidance for writing prescriptive (opinionated) documentation that recommends specific approaches.
* [Third-party content](/google-style-guide/general-principles/third-party-content.md) — Guidelines for avoiding copying third-party content and using paraphrasing instead.
* [Timeless documentation](/google-style-guide/general-principles/timeless-documentation.md) — Guidelines for writing documentation that doesn't become outdated over time.
* [Voice and tone](/google-style-guide/general-principles/voice-and-tone.md) — Guidance for writing with a conversational, friendly, and respectful tone.
