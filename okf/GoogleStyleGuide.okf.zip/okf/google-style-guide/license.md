---
type: Reference
resource: https://creativecommons.org/licenses/by/4.0/
title: "License"
description: "Licensing and attribution for the Google developer documentation style guide content reproduced in this bundle."
tags:
  - license
  - legal
  - Google
timestamp: 2026-08-05T12:00:00Z
sources:
  - id: google-style-guide
    resource: https://developers.google.com/style
    title: Google developer documentation style guide
  - id: cc-by-4-0
    resource: https://creativecommons.org/licenses/by/4.0/
    title: Creative Commons Attribution 4.0 International
---

# License

## Attribution

This bundle reproduces the
[Google developer documentation style guide](https://developers.google.com/style),
created by Google LLC.

Prose content is licensed under
[Creative Commons Attribution 4.0 International (CC BY 4.0)](https://creativecommons.org/licenses/by/4.0/).
Code samples are licensed under the
[Apache License 2.0](https://www.apache.org/licenses/LICENSE-2.0).

## Changes made

This is a modified version of the original work. Pages were retrieved from
<https://developers.google.com/style>, converted from HTML to Markdown,
reorganized into an Open Knowledge Format bundle hierarchy, and given YAML
frontmatter (`type`, `title`, `description`, `tags`, `timestamp`). Some
cross-references were rewritten as bundle-relative links and others were
flattened to plain text during conversion.

## Notices

Google LLC does not endorse this bundle or its maintainers. "Google" is a
trademark of Google LLC; any use here is nominative and does not imply
affiliation or sponsorship.

The content is provided as-is, without warranties or conditions of any kind,
either express or implied, to the extent permitted by applicable law.
