# Linking

* [Cross-references and linking](/google-style-guide/linking/cross-references-and-linking.md) — Guidance on choosing links selectively, writing descriptive link text, and writing effective cross-references.
* [Headings as link targets](/google-style-guide/linking/headings-as-link-targets.md) — Guidance on creating custom anchor links for headings in developer documentation.
