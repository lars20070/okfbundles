---
type: Section
title: Commas
description: "Guidelines for using commas in documentation."
tags:
  - guide
  - Google
  - punctuation
timestamp: 2026-08-03T15:30:00Z
---

# Commas

*Source: <https://developers.google.com/style/commas>*

Use commas to separate items in a series, and use commas to separate certain kinds of
clauses.

## Serial commas

In a series of three or more items, use a comma before the final *and* or
*or* to avoid potentially changing the meaning of the sentence. This comma is called a serial
comma or an Oxford comma.

Recommended: Locations are divided into
zones, regions, and multi-regions.

Not recommended: Locations are divided into
zones, regions and multi-regions.

## Commas after introductory words and phrases

In general, place a comma after an introductory word or phrase.

Recommended: Finally, only groups that
contain parameters appear in this list.

Recommended: Based on the requirements of
your game, you can implement this method to update game information.

## Commas separating two independent clauses

When a coordinating conjunction (*and*, *but*, *or*,
*nor*, *for*, *so*, or *yet*) separates two independent
clauses, insert a comma after the first clause (before the conjunction) unless
both clauses are very short.

Recommended: The libraries make
feed creation easier, and they ensure that only valid feeds are produced.

Not recommended: The libraries make
feed creation easier and they ensure that only valid feeds are produced.

Recommended: Type your ID and click **OK**.

Not recommended: Type your ID, and click
**OK**.

## Commas separating independent from dependent clauses

When an independent clause and a dependent clause are separated by a
coordinating conjunction, insert a comma *only if* the sentence could
be misunderstood without one.

Recommended: Direct-access flags are
plain variables and can be read directly.

Not recommended: Direct-access flags are
plain variables, and can be read directly.

Recommended: The manager acknowledged the
last team member who entered the room, and started the meeting.

Not recommended: The manager acknowledged
the last team member who entered the room and started the meeting.

## Set off other kinds of clauses

It's often a good idea to set off certain kinds of clauses with a comma or
other punctuation for clarity.

A couple of specific places where commas are a good idea:

- In general, put a comma before the word *which* at the start of a
  nonrestrictive clause. For more information about this topic, see this guide's section on [relative pronouns](/google-style-guide/language-and-grammar/pronouns.md) and Grammar
  Girl's page on
  [*which* versus *that*](https://www.quickanddirtytips.com/articles/which-versus-that/).
- In general, put a semicolon or a period or a dash before a conjunctive
  adver: keep-alive}