# Punctuation

* [Colons](/google-style-guide/punctuation/colons.md) — Guidance on using colons in developer documentation.
* [Commas](/google-style-guide/punctuation/commas.md) — Rules for comma usage in technical writing.
* [Dashes](/google-style-guide/punctuation/dashes.md) — Guidance on em dashes, en dashes, and hyphens.
* [Ellipses](/google-style-guide/punctuation/ellipses.md) — How to use ellipses in documentation.
* [Hyphens](/google-style-guide/punctuation/hyphens.md) — Guidance on when to use hyphens and closed compounds.
* [Parentheses](/google-style-guide/punctuation/parentheses.md) — Guidance on when and how to use parentheses in developer documentation.
* [Periods and end punctuation](/google-style-guide/punctuation/periods-and-end-punctuation.md) — Guidance on periods, exclamation marks, and end punctuation.
* [Quotation marks](/google-style-guide/punctuation/quotation-marks.md) — Guidance on straight and curly quotation marks.
* [Semicolons](/google-style-guide/punctuation/semicolons.md) — Guidance on the use of semicolons in developer documentation.
* [Slashes](/google-style-guide/punctuation/slashes.md) — Guidance on when and how to use slashes in developer documentation.
