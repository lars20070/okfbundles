---
type: Section
title: "Periods and end punctuation"
description: "Guidance for using periods, exclamation points, and other end punctuation."
tags:
  - guide
  - Google
  - punctuation
timestamp: 2026-08-03T15:30:00Z
---

# Periods and end punctuation

*Source: <https://developers.google.com/style/periods>*

End a complete sentence with a period, unless it's a question. There are
exceptions for working in lists.

## Periods with lists

Whether to end a list item with a period depends on several factors, including
the kind of list that the item appears in.

For details about how to use periods in lists, see the
[Capitalization and end punctuation](/google-style-guide/formatting-and-organization/lists.md)
section of the "Lists" page.

## Periods with URLs

When a period immediately follows a URL or a file path, it can be hard to
tell whether the period is part of the URL.

To indicate that the punctuating period isn't part of the URL, try one of the
following techniques:

- Whenever possible, avoid putting [URLs in text](/google-style-guide/linking/cross-references-and-linking.md).
- Rewrite the sentence so that the URL isn't at the end of the sentence.
- Put the URL on a separate line from the text, omitting the final period.

If the URL is a link, it generally looks different from the surrounding text. For
example, in most browsers, link text is blue by default. This formatting helps
distinguish the URL from the period.

Recommended:

We use your feedback to improve the Animals API, in accordance with Example
Pet Store's Privacy Policy:

<http://www.examplepetstore.com/privacy/>

Not recommended:

We use your feedback to improve the Animals API, in accordance with Example
Pet Store's Privacy Policy at <http://www.examplepetstore.com/privacy/>.

When you do put a period after a URL, don't leave any space between the last character of
the URL and the period.

## Periods with quotation marks

When a sentence ends with material inside quotation marks, place the period
inside the quotation marks even if the period isn't part of the material inside
the quotation marks. An exception to this guideline applies if you're using quotation marks around
a keyword or other literal string. For more information, see
[Commas and periods with quotation marks](/google-style-guide/punctuation/quotation-marks.md).

Recommended: ... you might say "Fixed typo."

If the material inside the quotation marks ends with a question mark or an
exclamation point, don't use a period.

Recommended: Children always ask "Why?"

## Periods with parentheses

If the last part of a sentence is contained inside parentheses, put the
period after the closing parenthesis.

If the parentheses contain a complete sentence, put the period inside
the parentheses.

Recommended: Your application could show
a notification when a relevant file or folder has changed (even if that change
occurs while your application isn't running).

Recommended: App Engine applications are
easy to create, easy to maintain, and easy to scale. (With App Engine, there are
no servers for you to maintain.)

For more information, see [Parentheses](/google-style-guide/punctuation/parentheses.md).

## Periods with headings

Don't end headings with periods.

For more information, see [Headings](/google-style-guide/formatting-and-organization/headings-and-titles.md).

## Periods with numbers

Use a period to represent a decimal point. (Using a comma to separate the decimal part
of a number is the editorial custom in some countries, but not in the US.)

For more information, see [Numbers](/google-style-guide/formatting-and-organization/numbers.md).

## Periods with captions

See [Figure captions](/google-style-guide/formatting-and-organization/figures-and-other-images.md).

## Periods with alt text

See [Alt text](/google-style-guide/formatting-and-organization/figures-and-other-images.md).

## Periods with abbreviations

Put a period after a shortened word.

Don't put periods after the letters of an acronym or initialism.

For more information, see [Abbreviations](/google-style-guide/language-and-grammar/abbreviations.md).

## Spaces between sentences

Leave only one space between sentences.

## Exclamation points

In general, avoid exclamation points. They can appear unprofessional, alarming, or translate poorly into other languages. If you need to use an exclamation point, see the following guidance by content type:

- **Concept and reference docs.** Never use exclamation points. These sections should maintain a neutral, objective tone.
- **Procedural topics.** Avoid exclamation points. Use periods for completion steps—for example, "The VM is created."
- **Blog posts.** Exclamation points are acceptable to convey enthusiasm but shouldn't be used in every paragraph.

When exclamation points are acceptable:

- **Code examples.** Use when required by syntax—for example, the `!=` operator.
- **System literals.** Use when an exclamation point is part of a specific error code or log message that must be matched exactly.
- **Tutorials and learning modules.** Use sparingly to mark major milestones or achievements—for example, "Congratulations! You've completed the setup."

> [!NOTE]
> **Note:** For translation impact, be conservative with exclamation points in global documentation. In some languages, such as Japanese or Korean, exclamation marks can come across as overly emphatic or even shouting, which can alienate the reader.

## Citations

[1] [Google Developer Documentation Style Guide — Periods](https://developers.google.com/style/periods)
