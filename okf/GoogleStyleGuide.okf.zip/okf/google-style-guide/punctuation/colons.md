---
type: Section
title: Colons
description: "Guidance for using colons in documentation."
tags:
  - guide
  - Google
  - punctuation
timestamp: 2026-08-03T15:30:00Z
---

# Colons

*Source: <https://developers.google.com/style/colons>*

A colon indicates that closely-related information follows.

For information about using colons with run-in headings, see
[Description lists that use
run-in headings](/google-style-guide/formatting-and-organization/lists.md).

## Introductory phrase preceding colon

When a colon introduces a list, the text that precedes the colon must be able
to stand alone as a complete sentence.

Recommended: The fields are defined as
follows:

Not recommended: The fields are:

## Colons within sentences

In general, the first word in the text that follows a colon should be in
lowercase. For exceptions, see
[Capitalization and colons](/google-style-guide/language-and-grammar/capitalization.md).

Recommended: Tone: concise,
conversational, friendly, respectful

Recommended: When you add or update
content to an existing project, remember to take these steps: review the style
guide, use checklists, enlist a fellow writer or an editor to copyedit your
work, and request a developmental edit if you feel that it's warranted.

## See also

For more information about how to punctuate introductory material, see the
sections on [list introductions](/google-style-guide/formatting-and-organization/lists.md) and [code-sample introductions](/google-style-guide/computer-interfaces/code-samples.md).

For information about when it's better to use colons than dashes, see [Dashes](/google-style-guide/punctuation/dashes.md).

## Citations

[1] [Google Developer Documentation Style Guide — Colons](https://developers.google.com/style/colons)
