---
type: Section
title: "Highlights"
description: "Key guidelines for tone, language, formatting, and images in Google developer documentation."
tags:
  - guide
  - highlights
  - Google
timestamp: 2026-08-03T14:00:00Z
---

# Highlights

*Source: <https://developers.google.com/style/highlights>*

## Tone and content

- Be conversational and friendly without being frivolous.
- Don't pre-announce anything in documentation.
- Use descriptive link text.
- Write accessibly.
- Write for a global audience.

## Language and grammar

- Use second person: "you" rather than "we."
- Use active voice: make clear who's performing the action.
- Use standard American spelling ([see spelling](https://developers.google.com/style/spelling)) and punctuation.
- Put conditions before instructions, not after.
- For usage and spelling of specific words, see the [word list](https://developers.google.com/style/wordlist).

## Formatting, punctuation, and organization

- Use sentence case for document titles and section headings.
- Use numbered lists for sequences.
- Use bulleted lists for most other lists.
- Use description lists for pairs of related pieces of data.
- Use serial commas ([see serial commas](https://developers.google.com/style/commas-serial)).
- Put code-related text in code font.
- Put UI elements in bold.
- Use unambiguous date formatting.

## Images

- Provide alt text.
- Provide high-resolution or vector images when practical.

# Citations

[1] [Google Developer Documentation Style Guide](https://developers.google.com/style)
