# Computer interfaces

* [API reference code comments](/google-style-guide/computer-interfaces/api-reference-code-comments.md) — Guidance on writing API reference documentation and code comments for public classes, methods, and parameters.
* [Code in text](/google-style-guide/computer-interfaces/code-in-text.md) — Guidance on when and how to format code elements in ordinary text, including items that should or should not be in code font.
* [Code samples](/google-style-guide/computer-interfaces/code-samples.md) — Guidance on formatting code samples including indentation, wrapping, and code style guides.
* [Command-line syntax](/google-style-guide/computer-interfaces/command-line-syntax.md) — Guidance on documenting command-line commands, arguments, flags, and output in developer documentation.
* [Placeholder formatting](/google-style-guide/computer-interfaces/placeholder-formatting.md) — Guidance on formatting and explaining placeholders in commands, code samples, and text strings.
* [UI elements and interaction](/google-style-guide/computer-interfaces/ui-elements-and-interaction.md) — Guidance on referring to and formatting UI elements, and documenting user interactions.
