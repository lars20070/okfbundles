# Formatting and organization

* [Dates and times](/google-style-guide/formatting-and-organization/dates-and-times.md) — Guidance on expressing dates and times clearly and unambiguously in developer documentation.
* [Examples](/google-style-guide/formatting-and-organization/examples.md) — Guidance on how to introduce and format examples in developer documentation.
* [Figures and other images](/google-style-guide/formatting-and-organization/figures-and-other-images.md) — Guidance on creating, saving, and formatting images, screenshots, and diagrams in developer documentation.
* [Footnotes](/google-style-guide/formatting-and-organization/footnotes.md) — Guidance on using footnotes sparingly in developer documentation.
* [Headings and titles](/google-style-guide/formatting-and-organization/headings-and-titles.md) — Guidance on writing descriptive headings and titles using sentence case for developer documentation.
* [Italics with terms](/google-style-guide/formatting-and-organization/italics-with-terms.md) — Guidance on using italics for introducing new terms and for words-as-words in developer documentation.
* [Lists](/google-style-guide/formatting-and-organization/lists.md) — Guidance on choosing between lists and tables, types of lists, and formatting guidelines.
* [Mathematical notation](/google-style-guide/formatting-and-organization/mathematical-notation.md) — Guidance on formatting common mathematical notation including exponents, expressions, equations, and operators.
* [Notes and other notices](/google-style-guide/formatting-and-organization/notes-and-other-notices.md) — Guidance on using notices (note, caution, warning, success) to offset important information.
* [Numbers](/google-style-guide/formatting-and-organization/numbers.md) — Guidance on when to spell out numbers as words or use numerals in developer documentation.
* [Paragraphs](/google-style-guide/formatting-and-organization/paragraphs.md) — Guidance on paragraph length, structure, and scannability in developer documentation.
* [Phone numbers](/google-style-guide/formatting-and-organization/phone-numbers.md) — Guidance on formatting and using example phone numbers in developer documentation.
* [Procedures](/google-style-guide/formatting-and-organization/procedures.md) — Guidance on writing numbered procedural steps in developer documentation.
* [Tables](/google-style-guide/formatting-and-organization/tables.md) — Guidance on when and how to use tables in developer documentation.
* [Units of measurement](/google-style-guide/formatting-and-organization/units-of-measurement.md) — Guidance on formatting units of measurement, including spacing, ranges, and currency.
