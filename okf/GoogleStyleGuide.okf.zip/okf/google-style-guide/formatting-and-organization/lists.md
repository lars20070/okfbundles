---
type: Section
title: "Lists"
description: Guidance on choosing between lists and tables, types of lists, and formatting guidelines.
tags:
  - formatting
  - lists
timestamp: 2026-08-01T06:28:39Z
---

# Lists

*Source: <https://developers.google.com/style/lists>*

## List or table?

Tables and lists are both ways to present a set of similarly structured
items. Sometimes it's not obvious when to choose one presentation over the
other. To decide which presentation to use, see
[List or table?](/google-style-guide/formatting-and-organization/tables.md#tables--list-or-table)

**Note**: Don't use a list to show only one item; a single
item isn't really a list. If you want to set a single item off from surrounding
text, then use some other formatting.

## Types of lists

Choose one of the following list styles. The following table includes common ways to present
lists in our documentation:

| List type | Used for | HTML elements |
| --- | --- | --- |
| Numbered list | A set of items where the sequence is significant, such as ordered steps, phases, or priorities. The following is an example of a numbered list:  Here's a sequence of steps to follow:   1. Open the box. 2. Remove the bobcat from the box. 3. Feed the bobcat.  Nested sequential lists are labeled with lowercase letters or lowercase Roman numerals. The following is an example of a nested sequential list:  Here's a list of things to do after breakfast, in order:   1. Go shopping.    1. Buy groceries:       - Flour       - Eggs       - Sugar       - Butter    2. Go to mall:       1. Buy dress.       2. Buy shoes. 2. Make cake. 3. Build birthday present out of spare parts. 4. Clean house.  See also [Sub-steps in numbered procedures](/google-style-guide/formatting-and-organization/procedures.md#procedures--sublists). | `ol`, `li` |
| Bulleted list | A set of items that's not a sequence, such as a set of nonsequential options or examples. Make sure it's clear whether or not every item is required. The following is an example of a bulleted list:  Here's a list of things that can go wrong, in no particular order:   - Your bicycle might explode. - The sun might go out. - An ant might break its leg and require a tiny splint. | `ul`, `li` |
| Description list | A set of terms, each with a description, definition, or explanation. Use this type of list if you want to draw attention to two or more terms (such as a glossary). The following is an example of a description list:  Here are some descriptions of types of birds:  Emu  The best kind of bird.  Crow  The other best kind of bird.  Peacock  Also the best kind of bird.  Phoenix  An even better kind of bird. | `dl`, `dt`, `dd` |
| Description list that uses bulleted run-in headings | A set of introductory terms or phrases, each followed by a description, definition, or explanation. Use this type of list if you want to highlight and explain several concepts or save space. For information about how to format and punctuate run-in headings and their descriptions, see [Description lists that use run-in headings](#lists--description-lists-that-use-run-in-headings) in this document.  The following is an example of a description list that uses bulleted run-in headings:  Here are some descriptions of types of birds:   - **Emu**: the best kind of bird - **Crow**: the other best kind of bird - **Peacock**: also the best kind of bird - **Phoenix**: an even better kind of bird | `ul`, `li` |

## Multiple paragraph list items

Any list item can contain more than one paragraph.

To create multiple paragraphs, use the `p` element rather
than using the `br` element. (The HTML specification describes which uses of the
[`br`
element](https://html.spec.whatwg.org/multipage/semantics.html#the-br-element) are legitimate and which aren't.)

Example of a list item that contains more than one paragraph:

- This list item is a single paragraph.
- This list item contains multiple paragraphs.

  As you can see!
- This is another list item that's only one paragraph long.

## Introductory sentences for lists

Introduce a list with the appropriate context. In most cases, precede a list
with an introductory sentence. The sentence can end with a colon or a period; usually a colon if it
immediately precedes the list, usually a period if there's more material (such as a note
paragraph) between the introduction and the list.

If the list doesn't need any additional context other than the heading that immediately precedes
the list, it's OK to not introduce a list with an introductory sentence.

Introduce a list with a complete sentence, not a partial one that's
completed by the list items. You can also use *the following* as a noun phrase (see
[following](/google-style-guide/word-list/f.md#word-list--following) in the word list).

| Recommended | Not recommended |
| --- | --- |
| Use the **Submit** button for any of the following purposes:   - To submit the form. - To indicate that you're done. - To allow the next person to enter their data. | Use the **Submit** button to:   - Submit the form. - Indicate that you're done. - Allow the next person to enter their data. |
| To get the USB driver, follow these steps:   1. Click **Tools >    Android > SDK Manager**. 2. Select **Google USB Driver**, and then click **OK**. | To get the USB driver:   1. Click    **Tools > Android >    SDK Manager**. 2. Select **Google USB Driver**, and then click **OK**. |
| If you need to add an instance manually, do the following:   1. Click **Create instance**. 2. For **Name**, enter a name. | If you need to add an instance manually:   1. Click **Create instance**. 2. For **Name**, enter a name. |
| Objectives  - Create an instance - Snapshot an instance - Delete an instance | Objectives In the following tutorial, you will complete the following tasks:   - Create an instance - Snapshot an instance - Delete an instance |

For information about introducing sub-steps, see [Sub-steps in numbered procedures](/google-style-guide/formatting-and-organization/procedures.md#procedures--sublists).
