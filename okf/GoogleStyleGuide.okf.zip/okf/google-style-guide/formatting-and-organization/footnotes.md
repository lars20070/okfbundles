---
type: Section
title: "Footnotes"
description: Guidance on using footnotes sparingly in developer documentation.
tags:
  - formatting
  - footnotes
timestamp: 2026-08-01T06:28:39Z
---

# Footnotes

*Source: <https://developers.google.com/style/footnotes>*

A footnote is an annotation with additional information usually provided at the end of a page,
chapter, or book. We recommend avoiding footnotes because they aren't accessible and can present
challenges for localization efforts.

Instead of a footnote, consider using the following formats to convey information:

- [Add a cross-reference](/google-style-guide/linking/cross-references-and-linking.md).
- [Use a note](/google-style-guide/formatting-and-organization/notes-and-other-notices.md).
- [Put it in a parenthetical](/google-style-guide/punctuation/parentheses.md).

If the only way to convey this information is to use a footnote, then use a superscript
number—for example, `<sup>1</sup>`.

Recommended: You want to add a footnote to this sentence.1

1 Put this footnote at the bottom of the page.
