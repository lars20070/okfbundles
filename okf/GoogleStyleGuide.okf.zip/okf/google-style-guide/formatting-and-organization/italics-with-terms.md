---
type: Section
title: "Italics with terms"
description: Guidance on using italics for introducing new terms and for words-as-words in developer documentation.
tags:
  - formatting
  - italics
timestamp: 2026-08-01T06:28:39Z
---

# Italics with terms

*Source: <https://developers.google.com/style/italics-terms>*

This page describes two circumstances when we italicize terms that we're
introducing or discussing.

For more information about italics and other formatting, including HTML and
Markdown formatting for italics, see
[Text-formatting summary](/google-style-guide/text-formatting-summary.md).

## New terms

When you introduce a new term that you're defining immediately, use italics on
the first mention of the term. Don't use bold or quotation marks.

Recommended: A
*Clos network* is a kind of multistage circuit switching network.

## Words as words

When you refer to a word, phrase, or letter in reference to the word, phrase,
or letter itself (sometimes called *words as words*) use italics. Don't use bold
or quotation marks.

Recommended: Don't use
*&* (ampersand) as a conjunction. Use the word *and* instead.

Recommended: To form a
possessive of a singular noun, add *'s* to the end of the word.
