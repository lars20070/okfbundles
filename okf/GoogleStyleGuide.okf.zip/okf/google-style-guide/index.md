# Google Developer Documentation Style Guide

* [Introduction](/google-style-guide/introduction.md) — Overview of the Google Developer Documentation Style Guide, including editorial resources and annotation guidelines.
* [Highlights](/google-style-guide/highlights.md) — Key guidelines for tone, language, formatting, and images in Google developer documentation.
* [What's new](/google-style-guide/whats-new.md) — Summary of significant changes to the Google Developer Documentation Style Guide.
* [Philosophy of this guide](/google-style-guide/philosophy.md) — Principles and philosophy behind the Google Developer Documentation Style Guide.
* [Word list](/google-style-guide/word-list/) — Style and usage guidelines for developer documentation terms, organized by letter.
* [Product names](/google-style-guide/product-names.md) — Guidelines for capitalizing, shortening, and using product names in Google documentation.
* [Text-formatting summary](/google-style-guide/text-formatting-summary.md) — Quick reference for text-formatting conventions including bold, italic, code font, capitalization, and quotation marks.
* [General principles](/google-style-guide/general-principles/) — Foundational guidelines for accessibility, inclusivity, tone, and other core principles.
* [Language and grammar](/google-style-guide/language-and-grammar/) — Rules for abbreviations, voice, capitalization, pronouns, and other grammar topics.
* [Punctuation](/google-style-guide/punctuation/) — Guidance on colons, commas, dashes, hyphens, periods, and other punctuation.
* [Formatting and organization](/google-style-guide/formatting-and-organization/) — Standards for lists, tables, headings, dates, numbers, and other formatting.
* [Linking](/google-style-guide/linking/) — Cross-references, descriptive link text, and link targets.
* [Computer interfaces](/google-style-guide/computer-interfaces/) — Code in text, code samples, command-line syntax, and UI elements.
* [HTML and CSS](/google-style-guide/html-and-css/) — HTML semantic tagging, formatting, and Markdown versus HTML.
* [Names and naming](/google-style-guide/names-and-naming/) — Example domains, names, filenames, and trademarks.
* [License](/google-style-guide/license.md) — Licensing and attribution for the Google developer documentation style guide content reproduced in this bundle.
