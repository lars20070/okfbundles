# Names and naming

* [Example domains and names](/google-style-guide/names-and-naming/example-domains-and-names.md) — Guidance on using fictional example domains, names, email addresses, and other identifiers in developer documentation.
* [Filenames](/google-style-guide/names-and-naming/filenames.md) — Guidance on naming, formatting, and referring to files and directories in developer documentation.
* [Trademarks](/google-style-guide/names-and-naming/trademarks.md) — Guidance on using trademarked terms as modifiers and following trademark owner usage guidelines.
