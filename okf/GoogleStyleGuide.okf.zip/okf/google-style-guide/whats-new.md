---
type: Section
title: "What's new"
description: "Summary of significant changes to the Google Developer Documentation Style Guide."
tags:
  - guide
  - changelog
  - Google
timestamp: 2026-08-03T14:00:00Z
---

# What's new

*Source: <https://developers.google.com/style/whats-new>*

This page provides a summary of significant changes to the style guide.

## July 7, 2026

| New guidance or change | Page |
| --- | --- |
| Softened a statement regarding the effect of inconsistent terminology on translation costs. | Write for a global audience |
| Added cross-references between guidance about optional procedure steps and guidance about optional headings. | Headings and titles, Procedures |
| Clarified that much of our guidance about writing inclusive documentation relates to the broader principle of avoiding figurative language, which can be ableist or unnecessarily graphic. Instead, we use literal, precise terms in their primary sense. | Write inclusive documentation, Voice and tone, Word list |
| Updated guidance about creating custom heading targets, making anchor (`<a>`) elements equally as acceptable as section (`<section>`) elements. | Make headings into link targets |
| Added guidance about ensuring that you contextualize UI elements when you document them outside of a numbered procedure. | UI elements and interaction |
| Added word list entry: *managed instance group (MIG)* | Word list |

## April 7, 2026

| New guidance or change | Page |
| --- | --- |
| Added guidance about avoiding inconsistent end punctuation in list items. | Lists |
| Added *do the following* as a recommended phrase for introducing lists in procedures. | Procedures |
| Clarified that ordered lists are appropriate for any list where sequence is significant. Added guidance about ensuring that it's clear whether the items in an unordered list are required or optional. | Lists |
| Added guidance that if you must refer to a step number, use the numeral. | Numbers |
| Added guidance to use italics sparingly, and consolidated italics guidance into a new page. | Use italics to discuss terms, Text-formatting summary |
| Added guidance recommending the terms *selected* and *not selected* to refer to the state of a checkbox. | UI elements and interaction |
| Changed guidance to recommend using code font for IP addresses and port numbers. Added package names to the list of items to place in code font. | Code in text |
| Updated UI elements guidance with expanded definitions for *pane*, *panel*, and *section*. Added guidance about how to identify difficult-to-find UI elements without using directional language. | UI elements and interaction |
| Added `.wasm` (Wasm file) to the table of file extensions and corresponding file type names. | Filenames and file types |
| Reorganized and extended guidance about formatting abbreviation introductions. | Abbreviations, Text-formatting summary |
| Consolidated pluralization guidance into a new page, including guidance about abbreviations, product names, and code elements. | Pluralization |
| Restructured guidance about writing for a global audience to make it easier to navigate. | Write for a global audience |
| Expanded guidance about exclamation marks to clarify that we avoid them except in rare cases. | Periods and other end punctuation, Voice and tone |
| Created a page about how to format common mathematical notation. | Mathematical notation, Numbers, Text-formatting summary, Units of measurement |
| Changed guidance for temperatures to recommend a nonbreaking space between a numeral and the degree symbol instead of between the degree symbol and the temperature scale. | Units of measurement |
| Added guidance about marking headings as optional. Restructured headings guidance to make it easier to navigate. | Headings and titles |
| Added an entry for *AI*, specifying that it rarely needs to be spelled out. | Word list, Abbreviations |
| Clarified that the word *can* can be used to convey both permission and ability. | Word list |
| Clarified that when we mark a term "Use with caution" in the word list, we recommend following our standard jargon guidance. | Word list |
| Clarified how we prefer to distinguish between a *page* (the whole web page) and a *document* (the text on a page that explains a product, feature, or service). | Word list |
| Revised the entry for *style sheet* to also allow for *stylesheet*, prioritizing consistency in a document. | Word list |
| Added explanations to several existing word list items regarding compound word usage: *clickthrough*, *hardcode*, *high availability*, *load balancing*, *plugin*, *third-party*, *time zone*, and *wake lock*. | Word list |
| Expanded the entry for *first class*, *first-class*, *first-class citizen*, providing new recommended alternatives with examples. | Word list, Write inclusive documentation |
| Expanded or added entries for *like*, *such as*, *for example*, and *for instance*. Made corresponding updates to the page about writing examples. | Word list, Format examples |
| Added guidance to the *virtual machine (VM) instance* entry regarding Compute Engine instances. | Word list |

## May 8, 2025

| New guidance or change | Page |
| --- | --- |
| Removed outdated language that indicated that a list of options is treated differently than other unordered lists. | Lists |
| Added a page about writing prescriptive documentation. | Prescriptive documentation, Word list |
| Removed guidance that said to include empty parentheses after method names. | Code in text |
| Changed footnotes guidance to recommend using numbers instead of symbols. | Footnotes |
| Simplified contractions guidance, removing excess explanations and examples. | Contractions |
| Added examples to guidance about introducing sections of a document. | Headings and titles |
| Added an example service account ID. | Example domains and names |
| Simplified and clarified guidance about articles, including using articles before abbreviations and product names. | Abbreviations, Articles (a, an, the), Product names, Word list |
| Included a general explanation of why we don't document future features. | Document future features |
| Revised guidance to recommend using an abbreviation in a title or heading only if the abbreviation is the more commonly known version of the word. | Headings and titles |
| Added a suggestion that when you use an imperative in running text, consider whether to write a procedure instead. | Second person and first person |
| Generalized existing guidance on what to do when jargon is part of a command or code sample. | Jargon |
| Consolidated guidance about cross-references and linking into one page. | Cross-references and linking |
| Added some specific reasons why we avoid directional language when orienting the reader to information on a page. | Write accessible documentation |
| Clarified that spacing around icons is a judgment call based on readability. | UI elements and interaction |
| Removed an example phone number. | Example domains and names |
| Removed the word list entry for *property* because its usage heavily depends on the technical context. | Word list |

## January 17, 2025

| New guidance or change | Page |
| --- | --- |
| Consolidated spelling guidance into the introduction to the word list. Extended guidance about how to use the preferred dictionary to determine which spelling to use for a word with multiple spellings. | Word list |
| Generalized guidance about when to use spaces or tabs for indentation in code samples. | Code samples |
| Changed guidance for formatting telephone numbers to recommend using dashes instead of parentheses to set the area code off from the rest of the number. | Format phone numbers |
| Extended and clarified recommendation to avoid the abbreviations *i.e.*, *e.g.*, and *etc.* in most cases. | Abbreviations, Comma-separated lists |

## October 29, 2024

| New guidance or change | Page |
| --- | --- |
| Consolidated and expanded guidance about hyphens and closed compounds. | Hyphens |
| Added *hotspot* to the word list. | Word list |

## August 15, 2024

| New guidance or change | Page |
| --- | --- |
| Added guidance for distinguishing between binary and decimal units, such as gibibytes (GiB) and gigabytes (GB). Also corrected abbreviation of *kilobyte* to *kB*. | Decimal and binary units |
| Expanded guidance for referring to figures and other images in text. Clarified that figure numbers are not required. | Figure captions |
| Added word list entries: *curl*, *whitepaper*, *long-running operation* | Word list |
| Updated word list entries: *ingest*, *execute*, *content type*, *media type*, *MIME* | Word list |

## May 16, 2024

| New guidance or change | Page |
| --- | --- |
| Added the term *generative AI*. | Word list |
| Added the term *rehost*. Redirected the definition for *lift and shift* to *rehost*. | Word list |
| Clarified that the style guide shows examples of how placeholders render but doesn't explain how to implement this visual styling. | Format placeholders |
| Added an example to the guidance showing how to use site-root-relative URLs to link to another page on the same server. | Cross-references |
| Clarified guidance about how to format anchor text. | Make headings into link targets |

## March 21, 2024

| New guidance or change | Page |
| --- | --- |
| Expanded guidance about avoidance of the term *drop-down*. | Word list |
| Added examples to guidance about writing documentation that focuses on the present state of the software. | Timeless documentation |
| Added recommendation to use a more precise term than *workload* when possible, or to define what the term means in the specific context. Added related guidance about avoiding ambiguous or overloaded words like *workload*, *solution*, and *support*, or defining them in each context. | Word list, Jargon |
| Aligned guidance with XML and HTML specifications to recommend against the use of angle brackets as part of an element name, but instead to only use angle brackets as part of a tag. | Code in text |

## January 22, 2024

| New guidance or change | Page |
| --- | --- |
| Cleaned up word list by removing entries that only provided hyphenation, spelling, or abbreviation guidance that followed directly from our general guidance. | Word list |
| Consolidated and clarified guidance regarding alt text, figure captions, and figure descriptions. | Diagrams, figures, and other images, Write accessible documentation |
| Added recommendation to avoid linking to other document sets from navigation controls such as a table of contents. | Links to other sites |
| Clarified guidance about avoiding words such as *above* and *below* in references to documentation and user interfaces for accessibility reasons, and provided example of appropriate non-directional usage. | Word list |
| Removed prohibition against hyphenation of the phrase *open source*, so this term now follows our general guidance for hyphenation, which allows for hyphenation of an adjectival phrase to add clarity and remove ambiguity. | Word list |
| Changed guidance for indicating the omission of code from an instructional code snippet to recommend the use of an explanatory comment instead of a mere ellipsis. | Code samples |

## November 8, 2023

| New guidance or change | Page |
| --- | --- |
| Changed guidance regarding run-in headings in description lists to recommend that the punctuation (such as a colon) is not formatted as bold. Making the punctuation bold caused the punctuation to seem to be part of the heading string, which caused confusion in cases such as UI labels. | Lists |
| Removed the recommendation to use a special *external* icon (indicated by `class="external"`) for links. Readers and writers have expressed confusion about the meaning and usage of this icon. We strengthened guidance about using other, explicit means to inform the reader about the destination and behavior of a link. | Link text |

## October 24, 2023

| New guidance or change | Page |
| --- | --- |
| Removed page about custom font styling, which only said to use styles defined in the style sheet for the website. Redirected link to page about HTML formatting and semantic tagging. | HTML and semantic tagging |
| Added word-list entry for *then* and expanded entry for *if* to recommend the use of the optional helper word *then* in many cases in which it might be omitted in casual usage. | Word list |
| Simplified and unified guidance for *jank* and *janky* to recommend that these terms only be used for specific graphics issues. | Word list |
| Strengthened guidance against the use of *and/or* except in cases where space is limited. | Slashes |

## September 29, 2023

| New guidance or change | Page |
| --- | --- |
| Added several examples of when and how to use quotation marks. | Quotation marks |
| Added explanation of guidance against anthropomorphism. | Anthropomorphism |
| Added guidance about using a hyphen with the prefix *non* before hyphenated compounds. | Hyphens |

## August 24, 2023

| New guidance or change | Page |
| --- | --- |
| Added link buttons to each entry in the word list to make deep-linking to individual entries easier. | Word list |
| Extended guidance about example names to recommend using an initial to represent a person's surname. | Example person surnames |
| Clarified guidance about when to use present tense and when to use future tense. | Present tense |
| Extended link text guidance to include an example for `mailto` links. | Link text |

## July 26, 2023

| New guidance or change | Page |
| --- | --- |
| Added link to [Google API guidelines](https://google.aip.dev/192) for information about code comments. | API reference code comments |
| Revised guidance for the word *toggle* to recommend against use as a verb. | UI elements and interaction |
| Extended and clarified guidance for names for directories and files. | Filenames and file types |
| Added explanation for why to use code format for code items. | Code in text |

## June 15, 2023

| New guidance or change | Page |
| --- | --- |
| Consolidated guidance about periods and end punctuation. Also removed standalone pages about exclamation points and about spacing after periods. | Periods and other end punctuation |
| Revised guidance about hyphens to suggest a lookup strategy, categorize uses, and note exceptions. | Hyphens |
| Created firmer guidance about punctuation in lists for run-in headings and at the end of list items. | Lists |
| Strengthened capitalization guidance: when *not* to use capitalization, and how to use capitalization with product names. | Capitalization, Product names |
| Added guidance about using end punctuation when documenting a command-line option or argument. | Document command-line syntax |
| Improved description and examples for using first-person pronouns (*we*, *our*). | Second person and first person |
| Updated word list entries: *etc.*, *OK*, *user*, *we*, *you* | Word list |

## May 9, 2023

| New guidance or change | Page |
| --- | --- |
| Softened guidance regarding the choice between the pronouns *who* and *that*. | Pronouns |
| Added *web interface* as an alternative to *console* and *UI* in general references to a browser-based interface. | Word list |
| Clarified the purpose of the page about phone number formats. | Format phone numbers in text |

## March 31, 2023

| New guidance or change | Page |
| --- | --- |
| Expanded and clarified guidance about using trademarks only as modifiers. This guidance emphasizes that you should never modify a trademark, such as by creating a possessive or plural form. | Use trademarks only as modifiers |
| Strengthened guidance against shortening product names to anything other than an approved alternative name. | Google product names |
| Expanded guidance about using ARIA labels in text that describes icons in graphical user interfaces. This improves accessibility and increases consistency in terminology used to refer to visual elements in text. | Buttons and icons, Accessibility |
| New word list entry: *toolkit* | Word list |

## February 13, 2023

| New guidance or change | Page |
| --- | --- |
| Added a page about paragraph structure, which provides guidance about recommended paragraph length and order of information. | Paragraph structure |
| Expanded accessibility guidance to say that a document should convey its information when you use it without images or animation. | Write accessible documentation |
| Clarified that letter keys should be represented with uppercase letters. | Press and type keyboard keys |
| Added *existing* to list of examples of potentially problematic words in timeless documentation. | Timeless documentation |
| Recommended using an empty `alt` attribute for icons that include a text label. | Buttons and icons |
| Strengthened and clarified guidance about avoiding culturally specific references and about using simple and consistent language. | Voice and tone |
| Created section about items that are sometimes—but not always—formatted in code font, such as email addresses. | Items that are sometimes in code font |
| Added information about example internationalized domain names. | Example domain names |
| Expanded guidance about choosing example email addresses. | Example email addresses |
| Expanded guidance about using second-person *you* to refer to the reader of a document and, generally, using third-person *user* to refer to the intended user of the software that the reader is developing. | Second person |

## December 12, 2022

| New guidance or change | Page |
| --- | --- |
| New word list entry: *anti-pattern* | Word list |

## November 7, 2022

| New guidance or change | Page |
| --- | --- |
| To emphasize a negative, use `<em>`not`</em>`. | Contractions |

## October 31, 2022

| New guidance or change | Page |
| --- | --- |
| New word list entry: *standalone* | Word list |

## October 10, 2022

| New guidance or change | Page |
| --- | --- |
| Added guidance about how to document optional arguments for commands. Special characters that indicate optional and mutually exclusive arguments in commands—such as brackets, braces, and pipes—break commands if the user doesn't edit them first. The new guidance offers several approaches for avoiding these problems. | Code in text, Code samples, Document command-line syntax |
| Clarified that contractions are recommended in general, but not required in all cases. | Contractions |

## September 26, 2022

| New guidance or change | Page |
| --- | --- |
| In figure captions, always use end punctuation, and use complete sentences when possible. | Figures and other images |
| Added separators between word list terms, to improve readability. | Word list |

## September 19, 2022

| New guidance or change | Page |
| --- | --- |
| Added guidance to multiple pages about ways to make documentation more inclusive for readers who have a variety of cognitive patterns. | Write accessible documentation, Cross-references, Numbers, Procedures |

## September 12, 2022

| New guidance or change | Page |
| --- | --- |
| Don't present new information in tables through images or symbols alone. | Tables |
| Clarified guidance about using footnotes in tables. | Tables |
| Added instructions for how to look up a UI element's `aria-label` attribute. | UI elements and interaction |

## September 5, 2022

| New guidance or change | Page |
| --- | --- |
| Strengthened recommendation to avoid using semicolons where possible, and removed basic information about semicolons. Our accessibility guidance recommends against using semicolons where possible, because screen readers may not clearly indicate them. So we changed our semicolon guidance to be more in line with our accessibility guidance. | Semicolons |
| Expanded and clarified guidance about what to put in code font. | Code in text |

## August 29, 2022

| New guidance or change | Page |
| --- | --- |
| Changed and clarified recommended phrasing for describing boolean parameters in reference docs. | API reference code comments |
| Expanded and clarified explanation of why we use straight quotation marks and apostrophes. | Quotation marks |
| Added suggested alternative terms for *cloud-native*. | Word list |
| New word list entries: *prebuilt*, *scroll* | Word list |

## August 22, 2022

| New guidance or change | Page |
| --- | --- |
| Clarified that *and then* is generally better than just *then*. | Write for a global audience |
| New word list entries: *canary*, *multi-service*, *precapture*, *pre-existing*, *presubmit*, *rebranding*, *roll out* | Word list |

## August 15, 2022

| New guidance or change | Page |
| --- | --- |
| Expanded table-formatting guidance, to improve accessibility. | Tables |
| Improved guidance about figure captions, descriptions, and alt text. | Figures and other images |

## August 8, 2022

| New guidance or change | Page |
| --- | --- |
| Write *a SQL* rather than *an SQL*. Both are in use, but *a SQL* is significantly more common. | Articles (a, an, the) |
| Added information about our distinction between *don't use* and *avoid*. | Word list |
| New word list entries: *nonce*, *SQL* | Word list |

## August 1, 2022

| New guidance or change | Page |
| --- | --- |
| Expanded guidance about *mobile* and related terms. | Word list |
| It's OK to use *below* in set phrases such as *below (the) average*. | Word list |
| Expanded our information about serial commas. | Commas |
| To refer to a file with the `.tiff` extension, use the phrase *TIFF file*. | Filenames and file types |
| New word list entries: *admin*; *blue-green*; *cold*, *hot*, and *warm* (in the context of a failover, spare, or standby); *inline*; *mobile phone*; *online* | Word list |

## July 25, 2022

| New guidance or change | Page |
| --- | --- |
| Updated guidance about the term *Cloud console*. | Word list |
| Clarified guidance about the term *see*. | Word list |

## July 18, 2022

| New guidance or change | Page |
| --- | --- |
| Revised guidance about using the term *element* in HTML and XML contexts. | Word list |
| Revised and expanded guidance about how to form possessives. | Possessives |
| New word list entry: *tag* | Word list |

## June 20, 2022

| New guidance or change | Page |
| --- | --- |
| New word list entry: *brown bag* | Word list |

## June 13, 2022

| New guidance or change | Page |
| --- | --- |
| Clarified guidance about placement of *only*. | Write for a global audience |
| New word list entry: *using* | Word list |

## June 6, 2022

| New guidance or change | Page |
| --- | --- |
| Clarified guidance about *Interconnect connection*. | Word list |

## May 16, 2022

| New guidance or change | Page |
| --- | --- |
| Offset footnote symbols using superscript. | Footnotes |
| New word list entries: *could*, *would* | Word list |

## May 9, 2022

| New guidance or change | Page |
| --- | --- |
| Strengthened guidance recommending avoiding humor in documentation. Most humor is difficult to translate, and much humor is culturally specific. | Write for a global audience |
| Changed the link to a resource about identity-first language. The site that we had previously linked to has disappeared. | Write inclusive documentation |

## April 25, 2022

| New guidance or change | Page |
| --- | --- |
| Added a new page about jargon. | Jargon |
| Expanded guidance about when to use the various notice types. | Notes, cautions, warnings, and other notices |
| Clarified and expanded guidance about when to remove locales from URLs. | Link to other sites |
| New word list entries: *final solution*, `gsutil` | Word list |

## April 18, 2022

| New guidance or change | Page |
| --- | --- |
| Introduce an interactive element (such as a button that expands and collapses) in the text preceding the element, to improve accessibility. | Write accessible documentation |

## April 11, 2022

| New guidance or change | Page |
| --- | --- |
| Changed guidance about taking screenshots. | Figures and other images |
| In code samples, indicate omitted code using three dots and no spaces (`...`) | Code samples |
| New word list entries: *+* (appended to numbers in text) | Word list |

## April 4, 2022

| New guidance or change | Page |
| --- | --- |
| Removed guidance about using lettered lists for mutually exclusive options. The semantic distinction that we were making isn't in wide use, and lettered lists aren't supported in standard Markdown, so we no longer recommend using lettered lists. | Lists |
| Clarified recommendation about how to italicize in Markdown. | Text-formatting summary |
| Changed guidance about *dead-letter queue* and *hold the pointer over*. | Word list |
| New word list entry: *break-glass* | Word list |

## March 28, 2022

| New guidance or change | Page |
| --- | --- |
| Clarified guidance about using an introductory phrase before the output of a command. | Document command-line syntax |
| New word list entry: *Unicode* | Word list |

## February 21, 2022

| New guidance or change | Page |
| --- | --- |
| Use `gcloud` *CLI* instead of `gcloud` *command-line tool*. | Word list |
| New word list entry: *shift left* | Word list |

## February 7, 2022

| New guidance or change | Page |
| --- | --- |
| In general, don't use a single *x* or a series of *x*'s as placeholders; instead, use a more informative placeholder. | Formatting placeholders |
| New word list entry: *GBps* | Word list |

## January 31, 2022

| New guidance or change | Page |
| --- | --- |
| Avoid repeating the exact page title as a heading on the page. | Headings and titles |
| Expanded guidance about *runtime* and *run time*. | Word list |
| Added *.adoc* and *.md* to the list of examples of filename extensions. | Filenames and file types |

## January 24, 2022

| New guidance or change | Page |
| --- | --- |
| Clarified guidance about video formats. The main reason to avoid using animated GIF is that it's resource-inefficient. | Figures and other images |
| Clarified guidance about changing an existing custom anchor for a heading. | Making headings into link targets |

## January 18, 2022

| New guidance or change | Page |
| --- | --- |
| For animations and videos, use a compressed format (such as MP4), not animated GIF. | Figures and other images |
| Don't use *email* as a verb. | Word list |
| New word list entry: *healthcare* | Word list |

## December 31, 2021

| New guidance or change | Page |
| --- | --- |
| Added headings to make guidance about using simple and unambiguous language easier to find. | Writing for a global audience |
| Expanded guidance about demonstrative pronouns. | Ambiguous pronoun references |
| Clarified guidance about when to use code format for URLs. | Code in text |
| Refreshed guidance about optimizing for search (SEO). | Text for images, Link text, Filenames, Headings |

## November 30, 2021

| New guidance or change | Page |
| --- | --- |
| Added examples and clarified guidance recommending use of optional pronouns and other helper words. | Optional pronouns, Writing for a global audience |
| Added guidance for linking to a section of another page. | Links to sections on another page |
| New word list entries: *portal*, *copy and paste*, *performant* | Word list |

## November 1, 2021

| New guidance or change | Page |
| --- | --- |
| Added guidance about expanding shortened words and symbols. | Abbreviations |
| Expanded guidance about the order of information in complex procedures, including the recommended order for goals, results, and justifications for steps. | Procedures |
| Added guidance about including a description of default behaviors in API reference documents. | API reference code comments |
| Reinforced guidance about including words like *file* after items in code font, such as filenames. | Filenames |
| Added guidance about using alternatives to directional terms such as *above* and *below* when referring to location in a document. | Writing accessible documentation |
| New word list entries: *practitioner*, *left-nav, right-nav*, *create new* | Word list |

## October 11, 2021

| New guidance or change | Page |
| --- | --- |
| Simplified placeholder examples and clarified when to repeat an explanation for a placeholder. | Formatting placeholders |
| Added guidance on using brackets and dots (`[...]`) to indicate omitted output in an example. | Output from commands |

## October 4, 2021

| New guidance or change | Page |
| --- | --- |
| Added page about philosophy and principles of the style guide. | Philosophy of this style guide |
| Clarified recommendation to include a noun after a code element and to avoid inflecting code elements. | Code in text |
| Added guidance to not use numbers in headings to indicate a sequence of sections. | Headings and titles |
| Updated examples for verb forms in headings and titles, including special cases such as *Pricing* and *Billing*. | Headings and titles |

## September 13, 2021

| New guidance or change | Page |
| --- | --- |
| Clarified guidance about specifying the context for a task. | Procedures |
| Avoid using *run the following command* to introduce code. Instead, focus on what the command does. | Procedures |
| Expanded the guidance for *CLI*. | Word list |
| New word list entries: *ransomware* | Word list |

## September 6, 2021

| New guidance or change | Page |
| --- | --- |
| Avoid words and phrases that anchor the documentation to a point in time or assume knowledge of prior or future products and features. | Timeless documentation |
| Added *navigation menu* to the list of UI terms. | UI elements and interaction |
| Marked *slice and dice* as *don't use*. | Word list |
| New word list entries: *web application firewall*, *while* | Word list |

## August 30, 2021

| New guidance or change | Page |
| --- | --- |
| Introduce a list of placeholders with the phrase *This output includes the following values:* The old guidance for what introductory phrase to use wasn't a complete sentence. | Formatting placeholders |

## August 16, 2021

| New guidance or change | Page |
| --- | --- |
| Added guidance for heading and title phrasing. Many writers ask what verb forms to use in headings and titles. The new guidance helps writers make that decision more easily, and it improves consistency for translators and readers. | Headings and titles |

## August 2, 2021

| New guidance or change | Page |
| --- | --- |
| When you need an example project name, create a name that's meaningful or descriptive. | Example domains and names |
| New word list entry: *pop-up* | Word list |

## July 26, 2021

| New guidance or change | Page |
| --- | --- |
| New word list entry: *intercluster* | Word list |

## July 19, 2021

| New guidance or change | Page |
| --- | --- |
| Added guidance about whether to include an abbreviation if it is used only once in the document. | Abbreviations |
| Clarified and added guidance about the terms *above*, *below*, *earlier*, *higher*, *later*, *lower*, and *under* | Word list |

## July 12, 2021

| New guidance or change | Page |
| --- | --- |
| Don't refer to casing styles by names like *camel case* or *snake case*. | Capitalization |

## July 5, 2021

| New guidance or change | Page |
| --- | --- |
| In the first sentence of each procedural step, include an imperative verb. | Procedures |

## June 28, 2021

| New guidance or change | Page |
| --- | --- |
| New word list entries: *can*, *might*, *must* A writer asked us to clarify our guidance for these terms. | Word list |

## June 21, 2021

| New guidance or change | Page |
| --- | --- |
| Updated guidance on fictitious person names, and added a list of specific given names to use in examples. Many writers have asked for a list of recommended names to use. | Example domains and names |

## June 7, 2021

| New guidance or change | Page |
| --- | --- |
| Don't use UI element labels as if they were English verbs or nouns. | UI elements and interaction |

## May 24, 2021

| New guidance or change | Page |
| --- | --- |
| Clarified phrasing of guidance about avoiding using the same link text for different target pages. | Link text |
| Added guidance about what to do when link text includes a command or other code-font element. | Link text |
| Try to keep the main subject and verb as close to the beginning of a sentence as possible. | Writing for a global audience |
| Updated guidance about using a hyphen to indicate a range of numbers. For example, we now recommend using an ordinary hyphen rather than a nonbreaking hyphen, for ease of authoring. | Hyphens |
| Removed the word list entry for *AJAX*. The entry was outdated, and Wikipedia covers the term better. | Word list |
| New word list entries: *webmaster*, *white label* Use more specific terms. | Word list |

## May 3, 2021

| New guidance or change | Page |
| --- | --- |
| Don't put a link in a heading. A link in a heading is easy for a reader to miss. | Headings and titles |
| Clarified and reorganized the material about which preposition to use with each UI element. | UI elements and interaction |

## April 26, 2021

| New guidance or change | Page |
| --- | --- |
| Clarified guidance about when to create a custom anchor for a heading. | Making headings into link targets |

## April 19, 2021

| New guidance or change | Page |
| --- | --- |
| Write one-step procedures with a bullet. | Procedures |
| In headings, use punctuation sparingly. | Headings and titles |
| Added a link to another resource about active and passive voice. | Active voice |
| Clarified guidance about the word *native*. | Word list |
| New entry: *sherpa* | Word list |

## April 12, 2021

| New guidance or change | Page |
| --- | --- |
| Clarified that guidance that applies to text generally also applies to headings. | Headings and titles |
| Strengthened recommendation to use contractions. | Contractions |
| New entry: *downscope* | Word list |

## April 5, 2021

| New guidance or change | Page |
| --- | --- |
| Expanded guidance about using simple words and phrases. | Writing for a global audience |
| New entry: *instance group* | Word list |

## March 29, 2021

| New guidance or change | Page |
| --- | --- |
| To form the plural of an abbreviation, treat the abbreviation like an English word, and follow standard English pluralizing patterns. | Abbreviations |

## March 15, 2021

| New guidance or change | Page |
| --- | --- |
| New entries: more than 60 terms to not use or to use with caution, for inclusive-language reasons (too many to list here) | Word list |

## March 8, 2021

| New guidance or change | Page |
| --- | --- |
| Expanded and clarified guidance about placeholders. | Formatting placeholders |
| New entries: *outside the box* (and related terms), and more than 40 networking terms (too many to list here) | Word list |

## March 1, 2021

| New guidance or change | Page |
| --- | --- |
| Clarified guidance about spelling out an abbreviation. | Abbreviations |
| Use *documentation set* instead of *docset*. | Word list |

## February 15, 2021

| New guidance or change | Page |
| --- | --- |
| New entry: *lock-in* | Word list |

## February 1, 2021

| New guidance or change | Page |
| --- | --- |
| Revised and clarified guidance about using *should*. | Word list |
| In some contexts, you can use *active*/*standby* as a replacement for *master*/*slave*. | Word list |
| Updated guidance about using *firewalls*. | Word list |
| New entries: *black-box*, *external IP address*, *gray-box*, *IPsec*, *N/A*, *war room*, *white-box* | Word list |

## January 25, 2021

| New guidance or change | Page |
| --- | --- |
| Updated guidance about link text to remove reliance on external sources. | Link text |
| Don't use abbreviations or product names as verbs. | Abbreviations, Product names |

## January 11, 2021

| New guidance or change | Page |
| --- | --- |
| Clarified guidance about indentation in code samples. | Code samples |
| Added links to more coding-style guides. | Code in text |
| Clarified that you can use *please* under certain specific circumstances. | Word list |
| Clarified guidance about *terminate*. | Word list |
| New entries: *hang*, *MTU*, *utilize* | Word list |

## January 4, 2021

| New guidance or change | Page |
| --- | --- |
| Merged landing page with "Other editorial resources" to help new readers learn how to use this guide. | About this guide |
| New entry: *deprecate* | Word list |

## December 28, 2020

| New guidance or change | Page |
| --- | --- |
| Added an explanation of what placeholders are. | Formatting placeholders |

## December 14, 2020

| New guidance or change | Page |
| --- | --- |
| Distinguished between the Google Cloud product called Identity and Access Management (IAM) and the general practice of identity and access management. | Word list |
| Clarified that the word *terminate* has a specific meaning in telephony. | Word list |

## December 7, 2020

| New guidance or change | Page |
| --- | --- |
| When you describe navigating through menus using angle brackets, add an `aria-label` attribute to each angle bracket, for use by screen readers: `<span aria-label="and then">></span>`. | UI elements and interaction |
| New entry: *metageneration* | Word list |

## November 30, 2020

| New guidance or change | Page |
| --- | --- |
| Updated content-navigation titles for some style guide pages. | Content navigation |
| Clarified guidance for *just*. | Word list |
| New entry: *time to live* | Word list |

## November 23, 2020

| New guidance or change | Page |
| --- | --- |
| Changed guidance about fictitious email addresses. | Example domains and names |
| New entry: *holiday, the holidays* | Word list |

## November 16, 2020

| New guidance or change | Page |
| --- | --- |
| In examples, use fictional street addresses. | Example domains and names |
| Clarified guidance for *functionality*. | Word list |

## November 9, 2020

| New guidance or change | Page |
| --- | --- |
| Format folder and directory names in code font. | Code in text |

## November 2, 2020

| New guidance or change | Page |
| --- | --- |
| Avoid double negatives. | Writing accessible documentation |
| Expanded guidance about how to write around unavoidable references to non-inclusive words. | Writing inclusive documentation |

## October 19, 2020

We're changing the format of the updates to this page, to focus on what each change is rather than where it is.

| New guidance or change | Page |
| --- | --- |
| You can use an asterisk to indicate emphasis in Markdown. Don't use a double underscore to indicate bold in Markdown. | Text-formatting summary |

## October 12, 2020

| New guidance or change | Page |
| --- | --- |
| Use *enable* or *turn on* consistently. | Word list |
| All pages about linking are now grouped together under a new **Linking** heading. | Content navigation |
| Don't link to the same document multiple times in close succession. | Cross-references |
| For subsections, use the phrase *in the following sections*. | Headings and titles |
| Don't create your own abbreviations. | Abbreviations |
| Don't reveal personally identifiable information. | Example domains and names |
| For exponents, use standard mathematical notation. | Numbers |
| Expanded guidance about expressing times of day. | Dates and times |
| New entries: *aka*, *America*, *-aware*, *Black Friday*, *Cyber Monday*, *leverage*, *possible*, *postmortem* | Word list |

## October 5, 2020

- In the [word list](#word-list), updated guidance about the term *disable*.

## September 28, 2020

- On the [Capitalization](#capitalization) page, expanded guidance about using consistent capitalization.
- On the [Procedures](#procedures) page, added guidance about including keyboard shortcuts in procedures.

## September 21, 2020

- On the [Figures and other images](#images) page, added guidance about using image maps.
- On the [Text-formatting summary](#text-formatting) page, added guidance about using a variable to indicate a range of version numbers, and clarified guidance about using `<em>`.
- Added entries to the [word list](#word-list): *distributed denial-of-service (DDoS)*, *UTF*.

## September 14, 2020

- On the [Figures and other images](#images) page and the [Tables](#tables) page, added guidance about introductory sentences.
- In the [word list](#word-list), clarified the distinction between terms to never use and terms to avoid when possible. Also added icons for both kinds of terms.

## September 7, 2020

- On the [Writing for a global audience](#translation) page, clarified guidance about using simple verbs.
- Added entries to the [word list](#word-list): *single pane of glass*, *will*.

## August 31, 2020

- On the [Figures and other images](#images) page, clarified guidance about using SVG.

## August 24, 2020

- Added an entry to the [word list](#word-list): *see*.

## August 10, 2020

- On the [UI elements and interaction](#ui-elements) page, added guidance about when to use *in* and when to use *on*.
- On the [Making headings into link targets](#headings-targets) page, added guidance about changing anchors, and reorganized the page.

## August 3, 2020

- On the [Dates and times](#dates-times) page, added guidance about avoiding referring to seasons of the year.
- In the [word list](#word-list), added more suggested alternatives for *master* and *slave*.

## July 27, 2020

- Added entries to the [word list](#word-list): *grandfathered*, *graylist*, *greylist*, *multi-regional*, *Unix epoch time*. Expanded and clarified guidance for the *blacklist*, *master*, and *multi-region* entries.

## July 20, 2020

- Reorganized and updated the [Other editorial resources](https://developers.google.com/style/resources) page, and moved that page to near the top of the left nav.
- On the [Figures and other images](#images) page, added links to Web Content Accessibility Guidelines (WCAG) resources.
- On the [Procedures](#procedures) page, added guidance about introducing a procedure with an imperative.
- Added entries to the [word list](#word-list): *bar*, *baz*, *canceled*, *foo*, *like*, *such as*.
- As of this week, we've stopped including small-detail changes in this page. For example, when we corrected a typo in the style guide in the past, we used to mention that correction on this page, but we're no longer mentioning minor changes that have no effect on guidance.

## July 13, 2020

- Renamed this summary-of-recent-changes page from "Release notes" to "What's new," and moved it to near the top of the left nav.
- In the [Pronouns](#pronouns) page, slightly updated the guidance about using gender-neutral *they*.

## June 29, 2020

- On several pages, reorganized guidance about formatting code and command lines. In particular:
  - Moved the guidance that was in a page about command-line terminology to the [Documenting command-line syntax](#code-syntax) page, and deleted the separate command-line terminology page.
  - Moved the guidance about placeholders to a new [Formatting placeholders](#placeholders) page.
  - Added cross-references among various code-related pages.
- In the [word list](#word-list), corrected a typo.

## June 22, 2020

- In the [word list](#word-list), changed guidance about using *earlier* and *later* for a range of version numbers.

## June 15, 2020

- On the [Capitalization](#capitalization) page and other pages, made guidance consistent about capitalizing references to document titles.
- On the [Cross-references](#cross-references) page and other pages, added guidance about not forcing a link to open in a new tab.
- On the [Code in text](#code-in-text) page, added guidance about when to put UI elements in code font.
- Added an entry to the [word list](#word-list): *best effort*.

## June 8, 2020

- On the [Writing inclusive documentation](#inclusive-documentation) page, added guidance about avoiding figurative language that relates to the slaughter of animals.

## June 1, 2020

- On the [Figures and other images](#images) page, updated guidance about alt text, figure descriptions, and figure captions.
- Reorganized the [HTML and semantic tagging](#semantic-tagging) page, and added guidance about not using the [`br` element](https://html.spec.whatwg.org/multipage/text-level-semantics.html#the-br-element) to change visual presentation. Also replaced a broken link to a third-party site.
- On the [Numbers](#numbers) page, added guidance about avoiding using Roman numerals.
- Added entries to the [word list](#word-list): *currently*, *dash*, *NoOps*.

## May 25, 2020

- On the [Numbers](#numbers) page, corrected two examples to match our guidance.
- On the [Abbreviations](#abbreviations) page, added guidance about use of the term *acronym*.
- Added entries to the [word list](#word-list): *happiness*, *scale*, *service level agreement*, *service level indicator*, *service level objective*. Also clarified guidance for *app*.

## May 18, 2020

- On the [Filenames and file types](#filenames) page, added guidance about how to refer to a filename.
- On the [Headings and titles](#headings) page, updated the guidance about using code font in headings.
- On the [UI elements and interaction](#ui-elements) page and elsewhere, replaced the term *arrow notation* with *angle bracket*.
- On the [Procedures](#procedures) page, clarified the guidance about stating the location of an action before stating the action.
- Added entries to the [word list](#word-list): *config*, *extract*, *unarchive*, *uncompress*, *untar*. Also changed the guidance about *ssh* and related terms. Also corrected a typo.

## May 11, 2020

- Major change: On the [Code in text](#code-in-text) page, changed guidance for placeholder styling. The new preferred style is all-uppercase with underscore delimiters.
- Also on the [Code in text](#code-in-text) page, corrected guidance about how to mark up placeholders with Markdown.
- On the [Figures and other images](#images) page, corrected a typo.

## May 4, 2020

- On the [Second person and first person](#person) page, clarified guidance about when to use implicit *you*.
- On the [UI elements and interaction](#ui-elements) page, added guidance about *toggle*.
- Added entries to the [word list](#word-list): *dashboard*, *master*. Unrelatedly, fixed a longstanding word list typo.

## April 27, 2020

- On the [Documenting command-line syntax](#code-syntax) page, added guidance about showing the output of commands.
- On the [Example domains and names](#examples) page, added example IPv6 addresses.
- On the [Words as words](https://developers.google.com/style/words-as-words) page, clarified guidance.
- In the [word list](#word-list), clarified guidance for the word *following*. Also clarified guidance for the various *console* terms.
- Added an entry to the [word list](#word-list): *native*.

## April 20, 2020

- On the [Units of measurement](#units-of-measure) page, added guidance about using *per* when referring to rates.
- On the [UI elements and interaction](#ui-elements) page, clarified the distinction between text input and keyboard shortcuts, and added guidance about when to use the `code` and `kbd` elements. On the [Code in text](#code-in-text) page, added text input to the list of items to put in code font.
- On the [Accessible content](#accessibility) page, added a recommendation to use a screen reader to test your documentation. Also added guidance about introducing tables.
- On the [Example domains and names](#examples) page, changed the recommended example company names to avoid camel case.
- On the [Code in text](#code-in-text) page and the [Colons](#colons) page, clarified and expanded guidance about how to format a colon after text that's bold or in code font.
- Added entries to the [word list](#word-list): *key*, *key ring*, *per*, *vice versa*.

## April 13, 2020

- On the [Lists](#lists) page, expanded the guidance about when not to use sentence-ending punctuation.
- Added cross-references between the [Abbreviations](#abbreviations) page and the [Headings and titles](#headings) page.
- On the [Numbers](#numbers) page, clarified the guidance about hyphens and en dashes in ranges of numbers.
- On the [Units of measure](#units-of-measure) page, clarified guidance about what counts as a unit.
- In the [word list](#word-list), clarified guidance about using *blacklist* and *whitelist*.
- Added entries to the [word list](#word-list): *ad tech*, *easily*, *fintech*, *NLU*, *quick*, *quickly*.

## April 6, 2020

- On the [Abbreviations](#abbreviations) page, clarified guidance about using abbreviations in headings and titles.
- On the [Text-formatting summary](#text-formatting) page, added guidance on formatting mathematical variables.
- On the [Link text](https://developers.google.com/style/link-text) page, added guidance about abbreviations in link text.
- On the [Dates and times](#dates-times) page, added guidance about how to express time zones.
- In the [word list](#word-list), clarified guidance about *key-value pair*.
- Added an entry to the [word list](#word-list): *personally identifiable information (PII)*.

## March 30, 2020

- On the [Hyphens](#hyphens) page, clarified guidance about ranges of numbers.
- In the [UI elements and interaction](#ui-elements) page, changed guidance for formatting input for text boxes to recommend using the HTML `code` element instead of the `kbd` element.

## March 23, 2020

- On the [Capitalization](#capitalization) page, made the following changes:
  - Removed outdated guidance about capitalization after a run-in heading. For the current guidance, see "Description lists that use run-in headings" on the [Lists](#lists) page.
  - Clarified guidance about avoiding all-uppercase and camel case.
  - Clarified guidance about avoiding lowercase at the start of a sentence.
  - Clarified guidance about capitalization when referring to documents by title in various contexts.
- Expanded and reorganized the [Code in text](#code-in-text) page. In particular:
  - Expanded the guidance about documenting placeholders.
  - Expanded the list of items to put in code font.
- On the [Commas](#commas) page, added guidance about using a comma with *because*.
- On the [Dashes](#dashes) page, added guidance about not using en dashes.
- Added entries to the [word list](#word-list): *datastore*, *tutorial*. Also added guidance (in the entry for *documentation*) about phrases like *in this document*.

## March 2, 2020

- On the [Capitalization](#capitalization) page, added guidance about using sentence case for labels and callouts.
- On the [Cross-references](#cross-references) page, added guidance about how to format the titles of web series.
- Added an entry to the [word list](#word-list): *web server*.

## February 24, 2020

- On the [Resources](https://developers.google.com/style/resources) page, added links to the Kubernetes glossary and the Kubernetes style guide.
- On the [Lists](#lists) page, added guidance about how and when to use a bulleted list with run-in headings.
- Updated the [word list](#word-list) to refer to *Google Cloud* instead of *GCP*, in accord with a recent name change. In particular, changed entries for *GCP*, *GCP Console*, and *GCP project ID* to *Google Cloud*, *Google Cloud Console*, and *Google Cloud project ID*, respectively.
- Added an entry to the [word list](#word-list): *GKE node*. Also updated guidance for *GKE*.
- In the left nav, moved the word list and the product-names page to near the top.
- On the [Plurals in parentheses](https://developers.google.com/style/plurals-parentheses) page, added guidance about using the phrase *one or more*.

## January 13, 2020

- In the [Writing for a global audience](#translation) page, fixed a broken link.
- In the [Code in text](#code-in-text) page, added *environment variable names* to the list of items to put in code font.
- Added entries to the [word list](#word-list): *A/B testing*, *BGP*.

## January 6, 2020

- Added entries to the [word list](#word-list): *DevOps*, *ECMP*, *GFE*, *NoSQL*, *PostgreSQL*. Also updated guidance on *virtual machine (VM) instance*.

## December 23, 2019

- Expanded and clarified the [Writing for a global audience](#translation) page.
- Renamed the "Typographical conventions" page to "[Text-formatting summary](#text-formatting)."
- On the [Tables](#tables) page, clarified guidance about punctuation in table column heads.
- On the [Filenames and file types](#filenames) page, added *.jar* to the list of filename extensions.
- On the [UI elements](#ui-elements) page and the word list, clarified guidance about when to use *box* and *field* to refer to text boxes.

## December 16, 2019

- On the [Abbreviations](#abbreviations) page, expanded guidance about when to spell out abbreviations.
- On the [conventions page](https://developers.google.com/style/typographical-conventions), fixed two broken links.
- Added entries to the [word list](#word-list): *as*, *big-endian*, *google.dev*, *little-endian*.

## December 9, 2019

- On the [Tables](#tables) page, added guidance about sorting tables, and clarified guidance about when to use tables.
- Reverted last week's changes about using *earlier* and *later* instead of *lower* and *higher*; those changes need further refining.

## December 2, 2019

- On the [Cross-references](#cross-references) page, added guidance about using the word *about* in cross-references, rather than *on*.
- Added entries to the [word list](#word-list): *about versus on*, *for instance*, *SLA*. Also changed guidance about using *earlier* and *later* for a range of version numbers.

## November 25, 2019

- On the [UI elements and interaction](#ui-elements) page, added guidance about focusing on the task rather than on UI elements as such.
- On various pages, added cross-references linking to other pages.

## November 18, 2019

- Added a new [Typographic conventions](https://developers.google.com/style/typographical-conventions) page.
- Reorganized the [Units of measurement](#units-of-measure) page. Also added guidance about Kelvin temperatures.
- On the [Cross-references](#cross-references) page, clarified guidance about cross-references that aren't links.
- On the [UI elements and interaction](#ui-elements) page, added information about expander arrows.
- Added a term to the [word list](#word-list): *slice and dice*.

## November 11, 2019

- On the [Figures and other images](#images) page, clarified guidance about figure descriptions.
- On the [Units of measurement](#units-of-measure) page, added guidance about ranges of numbers.
- On the [Product names](#product-names) page, clarified guidance about using full trademarked product names.
- Added terms to the [word list](#word-list): *billing charges*, *port*, *repo*, *UI*.

## October 28, 2019

- Added guidance about what to do if there's [more than one way to complete a task](#procedures--same-task).
- Added terms to the [word list](#word-list): *just*, *multi-tenancy*.

## October 21, 2019

- Added a page about [formatting words as words](https://developers.google.com/style/formatting-words-as-words).
- Added a page about [formatting key terms](https://developers.google.com/style/formatting-key-terms).
- Changed the guidance about how to capitalize a [UI element](#ui-elements) name when the label is all-uppercase in the UI.
- Added guidance about [explaining placeholders](https://developers.google.com/style/code-in-text#explain-placeholders).
- Updated the list of [items to put in code font](#code-in-text--some-specific-items-to-put-in-code-font).
- Clarified the guidance about using official [capitalization](#capitalization) for names of products.
- Changed the title of the [style guide landing page](#style).
- Deleted the page about URLs in links, and moved the material that was on that page to the [cross-references](#cross-references) page. Also added some examples to that page.
- Removed unnecessary explanations of the icons that indicate that a guideline applies only in Android documentation or only in Google Cloud Platform documentation.
- Added examples to the [footnotes](#footnotes) page.
- Improved a link on the [Accessible content](#accessibility) page.
- Added terms to the [word list](#word-list): *BMaaS*, *US*.

## October 8, 2019

- Reorganized the page about [notices](#notices), and added examples.
- Cleaned up some minor formatting and phrasing issues in the [word list](#word-list).
- Corrected a typo on the [Accessible content](#accessibility) page.
- Changed the title of the style guide to use sentence case.

## September 30, 2019

- Added a term to the [word list](#word-list): *PoP*.

## September 23, 2019

- Added a page about [footnotes](#footnotes).
- Reorganized the [Other editorial resources](https://developers.google.com/style/resources) page.

## September 16, 2019

- Added a page about [using material from other sources](#other-sources).
- Added guidance about [using *a* and *an* with product names](#product-names--shortening).
- Removed contradictory guidance about quotation marks with [link text](https://developers.google.com/style/link-text).
- Clarified guidance about [periods with abbreviations](#abbreviations--periods).
- Clarified guidance about [capitalization following a colon](#capitalization).
- Moved the list of UI-related verbs from the UI elements page to the [word list](#word-list).
- Also added other terms to the [word list](#word-list): *cons*, *Gbps*, *Kbps*, *Mbps*, *pros*. Also updated the entry for *service*.

## June 24, 2019

- Added guidance about US currency to the [Numbers](#numbers) page.

## June 17, 2019

- Added further guidance about accessibility to the [Accessible content](#accessibility) page and other related pages.
- Added guidance about graphically violent terms to the [Writing inclusive documentation](#inclusive-documentation) page.
- Added guidance about the term *wheelchair-bound* to the [Writing inclusive documentation](#inclusive-documentation) page.
- Added guidance about currency to the [Units of measure](#units-of-measure) page.
- Added an example showing how to [use Markdown to mark up images](#images).
- Added terms to the [word list](#word-list): *disclosure triangle*, *hamburger menu*, *kebab menu*, *outpost*, *STONITH*. Also expanded guidance about *should*.

## May 20, 2019

- Added a new page about [avoiding excessive claims](#excessive-claims).
- Added material about file types to the [Filenames and file types](#filenames) page.
- Added terms to the [word list](#word-list): *CSV*, *traditional*, *YAML*.

## April 29, 2019

- Replaced the guidelines on the [Accessible content](#accessibility) page with a new set of more relevant guidelines.
- Added a term to the [word list](#word-list): *execute*.
- Added material about Linux signals on the [Command-line terminology](https://developers.google.com/style/command-line-terminology) page, and updated related entries in the word list.

## April 22, 2019

- Added a term to the [word list](#word-list): *method*. Also added to the guidance for *Cloud*.

## April 15, 2019

- Added more guidance about digit-group separators on the [Numbers](#numbers) page.
- Fixed a broken link on the [Numbers](#numbers) page, and another on the [Writing for a global audience](#translation) page.
- Updated guidance about example names on the [Example domains and names](#examples) page.
- Added guidance about removing personally identifying information from screenshots on the [Figures and other images](#images) page.
- Added guidance about using code font for names of command-line utilities on the [Code in text](#code-in-text) page.
- Added guidance about short and long versions of words like *app* and *demo* on the [Abbreviations](#abbreviations) page.

## March 4, 2019

- Clarified guidance about person-first and identity-first language on the [Writing inclusive documentation](#inclusive-documentation) page.
- Added guidance about passive voice on the [Active voice](#voice) page.
- Added more guidance about links on the [Linking to other sites](https://developers.google.com/style/links-external) page.
- Added terms to the [word list](#word-list): *guru*, *spin up*. Also revised the guidance for *Container Engine*.

## February 25, 2019

- Added extensive new material to the [inclusive documentation](#inclusive-documentation) page.
- Updated the [word list](#word-list):
  - Clarified guidance for *argument* and *flag*.
  - Added terms: *allows you to*, *desire*, *drop-down*, *wish*.
  - Removed the recommendations against using *enable* and *disable*, and clarified guidance for those terms.

## February 4, 2019

- Added terms to the [word list](#word-list): *add-in*, *add-on*.
- Added guidelines about avoiding [repetitive procedures](#procedures--repetitive-procedures).

## January 28, 2019

- Updated the [word list](#word-list):
  - Changed guidance for *above* and *below*.
  - Added terms: *gcloud*, *ML*.
  - Updated guidance for *&*.
  - Improved alphabetization.
- Fixed a broken link in the [Lists](#lists) page.

## January 14, 2019

- Added terms to the [word list](#word-list): *comprise*, *console*, *fail over*, *GCP Console*, *Google Cloud Platform Console*, *populate*, *surface*.
- Reorganized the [UI elements](#ui-elements) page, and added guidance and examples.
- Added Markdown information to the [URLs for images](https://developers.google.com/style/img-elements) page.
- Clarified guidance about end punctuation for lists on the [Periods](#periods) page.
- Clarified guidance about nonbreaking spaces in the [Units of measurement](#units-of-measure) page.

## December 3, 2018

- Added a term to the [word list](#word-list): *lifetime*.
- Elaborated on our guidance in the [Closed compounds and prefixes](https://developers.google.com/style/word-list#compounds) section of the word list.
- Added a new page about [command-line terminology](https://developers.google.com/style/command-line-terminology) for gcloud and Linux.
- Added a section on [straight and curly quotation marks](#quotation-marks--straight-and-curly-quotation-marks) to the Quotation marks page.
- Added guidance about avoiding overuse of bolding to the [Procedures](#procedures) page.
- Added guidance about the phrases *hold the pointer over* and *point to* to the [UI elements and interaction](#ui-elements) page.

## October 29, 2018

- Added terms to the [word list](#word-list): *blacklist*, *whitelist*.
- Reorganized the [dates and times](#dates-times) page, and added guidance about times and about ISO 8601.

## October 8, 2018

- Added recommendations for [example company names](#examples--example-company-names).
- Added guidance about using monospace formatting to the [UI elements and interaction](#ui-elements) page.
- Added guidance about giving the location of an action in a procedure to the [Procedures](#procedures) page.

## September 18, 2018

- Added terms to the [word list](#word-list): *GKE*, *POJO*.

## September 4, 2018

- Added guidance about cases where [filenames aren't under your control](#filenames--other-exceptions).
- Added a term to the [word list](#word-list): *big data*.

## August 13, 2018

- Added guidance about [avoiding internet slang](#abbreviations--dont-use).
- Added terms to the [word list](#word-list): *multi-cloud*, *RTFM*, *tl;dr*, *ymmv*.

## July 30, 2018

- Added terms to the [word list](#word-list): *disaster recovery*, *file system*, *high availability*, *high performance computing*, *OS*, *tarball*, *tar file*.
- Updated guidance in the word list for *on-premises*.
- Rephrased a paragraph of the [landing page](#style).

## June 25, 2018

- Added terms to the [word list](#word-list): *IP*, *SAP*.

## June 19, 2018

- Added a term to the [word list](#word-list): *trojan*.
- Improved the organization, formatting, and phrasing of the [filenames page](https://developers.google.com/style/file-names).

## June 12, 2018

- Added terms to the [word list](#word-list): *appendix*, *index*, *matrix*.

## May 21, 2018

- Changed the guidance about [how to link to Android reference documentation](#code-in-text--linking-api-terms-in-android).
- Added information about [using *the* with product names](https://developers.google.com/style/product-names#using-the-with-product-names).
- Added a note about indefinite and casual numbers to the [Numbers](#numbers) page.
- Fixed a broken link on the [authorial tone](#tone) page.

## May 14, 2018

- Added terms to the [word list](#word-list): *multi-cluster*, *via*. Clarified guidance on *firewalls*.

## April 2, 2018

- Added a page about [writing inclusive documentation](#inclusive-documentation).
- Added terms to the [word list](#word-list): *at scale*, *IAM*, *RFC*.

## March 26, 2018

- Added information about [`alt` text for decorative images](#images--text-associated-with-images) to the images page.
- Added terms to the [word list](#word-list): *fill in*, *fill out*, *microservices*.

## February 26, 2018

- Added a term to the [word list](#word-list): *ad hoc*.

## February 12, 2018

- Added terms to the [word list](#word-list): *Cloud*, *Container Engine*, *ephemeral external IP address*, *firewalls*, *GCP*, *GCP project ID*, *internal IP address*, *NAT*, *network IP address*, *non-key*, *on-premises*, *persistent disk*, *project*, *RDP*, *static external IP address*, *subnet*, *table name*, *textbox*, *turn on*.
- Added information about closed compounds and prefixes to the [word list](https://developers.google.com/style/word-list#compounds).

## January 29, 2018

- Added terms to the [word list](#word-list): *alpha*, *autohealing*, *autoscaling*, *autotagging*, *bare metal*, *beta*, *CLI*, *Cloud SDK*, *colocate*, *CPU*, *curated roles*, *data center campus*, *data cleaning*, *data source*, *ETL*, *IaaS*, *impact*, *ingest*, *k8s*, *key pair*, *PaaS*, *preemptible*, *regex*, *SaaS*, *screenshot*, *sign-in*, *sign into*, *sign-out*, *sub-command*, *v*, *virtual machine instance*.
- Added a section on placeholder variables to the [code in text](https://developers.google.com/style/code-in-text#placeholder-variables) page.

## January 8, 2018

- Added terms to the [word list](#word-list): *argument*, *backup*, *dataflow*, *flag*, *higher*, *later*, *long press*, *multi-region*, *option*, *slave*, *touch & hold*, *transpile*, *wildcard*.
- Added an item (DNS record types) to the list of [items to put in code font](#code-in-text--some-specific-items-to-put-in-code-font).

## December 11, 2017

- Added material on [numerical dimensions](#numbers--dimensions).
- Added material about [possessives of company and product names](https://developers.google.com/style/possessives#company--and-product-name-possessives).
- Added terms to the [word list](#word-list): *docset*, *documentation*, *startup*, *sync*.

## November 13, 2017

- Changed guidelines on [end punctuation for list items](#lists--capitalization-and-end-punctuation).
- Added alphabetical headings to the [word list](#word-list), so you can now jump to a specific letter using the in-page TOC.
- Updated [word list](#word-list) entries for *error-prone*, *real time*, and *Search*.
- Added terms to the [word list](#word-list): *dataset*, *legacy*, *nonfatal*.

## October 23, 2017

- Added a new page about [plurals in parentheses](https://developers.google.com/style/plurals-parentheses).
- Added a link to the C++ coding style guide, in the [Code style guides](#code-samples--coding) section.

## September 4, 2017

- Added several more terms to the [word list](#word-list): *check*, *checkbox*, *clear*, *deselect*, *open source*, *select*, *target*, *uncheck*, *Unix-like*, *unselect*.
- Added material to the [Trademarks](#trademarks) page about using trademarks as adjectives. Also added links to a couple of other trademark-related pages from Google.
- Removed Android-specific material from the [Headings](#headings) page, to bring Android doc guidelines more into line with non-Android guidelines. Also, added notes about things not to include in headings.
- Removed Android label from material on the [Tables](#tables) page, to make that material also apply to non-Android docs.
- Added mention of degrees and percents to the [Units of measurement](#units-of-measure) page.

## August 28, 2017

- Added 160+ terms to the [word list](#word-list). (Too many to list here.)
- Added recommendations for image size and placement to the [Images](#images) page.
- Moved material about Javadoc links to the [Code in text](#code-in-text) page.

## August 21, 2017

- Added new [File names](https://developers.google.com/style/file-names) page.

## August 15, 2017

- Added new [Units of measurement](#units-of-measure) page.
- Changed "[internet](#word-list--internet)" to lowercase.
- Added material about line lengths and Javadoc-style links to the [HTML formatting](#html-formatting) page.

## July 31, 2017

- Added new [Headings and titles](#headings) page, mostly focused on Android documentation.
- Added information about [tables in Android docs](https://developers.google.com/style/tables#a-few-more-notes-about-tables) to the Tables page.

## July 10, 2017

- Added words to the [word list](#word-list): *deep linking*, *jank*, *wake lock*.

## June 8, 2017

- Public release.

# Citations

[1] [Google Developer Documentation Style Guide](https://developers.google.com/style)
