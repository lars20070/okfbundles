# Update Log

## 2026-08-03
* **Creation**: Added [Introduction](/google-style-guide/introduction.md) — Overview of the Google Developer Documentation Style Guide, including editorial resources and annotation guidelines.
* **Creation**: Added [Highlights](/google-style-guide/highlights.md) — Key guidelines for tone, language, formatting, and images in Google developer documentation.
* **Creation**: Added [What's new](/google-style-guide/whats-new.md) — Summary of significant changes to the Google Developer Documentation Style Guide.
* **Creation**: Added [Word list](/google-style-guide/word-list/) — Style and usage guidelines for developer documentation terms, organized by letter.
* **Creation**: Added [word-list/overview.md](/google-style-guide/word-list/overview.md) — Entry types and numbers/symbols guidance.
* **Creation**: Added [word-list/a.md](/google-style-guide/word-list/a.md) — Word list entries for terms beginning with A.
* **Creation**: Added [word-list/b.md](/google-style-guide/word-list/b.md) — Word list entries for terms beginning with B.
* **Creation**: Added [word-list/c.md](/google-style-guide/word-list/c.md) — Word list entries for terms beginning with C.
* **Creation**: Added [word-list/d.md](/google-style-guide/word-list/d.md) — Word list entries for terms beginning with D.
* **Creation**: Added [word-list/e.md](/google-style-guide/word-list/e.md) — Word list entries for terms beginning with E.
* **Creation**: Added [word-list/f.md](/google-style-guide/word-list/f.md) — Word list entries for terms beginning with F.
* **Creation**: Added [word-list/g.md](/google-style-guide/word-list/g.md) — Word list entries for terms beginning with G.
* **Creation**: Added [word-list/h.md](/google-style-guide/word-list/h.md) — Word list entries for terms beginning with H.
* **Creation**: Added [word-list/i.md](/google-style-guide/word-list/i.md) — Word list entries for terms beginning with I.
* **Creation**: Added [word-list/j.md](/google-style-guide/word-list/j.md) — Word list entries for terms beginning with J.
* **Creation**: Added [word-list/k.md](/google-style-guide/word-list/k.md) — Word list entries for terms beginning with K.
* **Creation**: Added [word-list/l.md](/google-style-guide/word-list/l.md) — Word list entries for terms beginning with L.
* **Creation**: Added [word-list/m.md](/google-style-guide/word-list/m.md) — Word list entries for terms beginning with M.
* **Creation**: Added [word-list/n.md](/google-style-guide/word-list/n.md) — Word list entries for terms beginning with N.
* **Creation**: Added [word-list/o.md](/google-style-guide/word-list/o.md) — Word list entries for terms beginning with O.
* **Creation**: Added [word-list/p.md](/google-style-guide/word-list/p.md) — Word list entries for terms beginning with P.
* **Creation**: Added [word-list/q.md](/google-style-guide/word-list/q.md) — Word list entries for terms beginning with Q.
* **Creation**: Added [word-list/r.md](/google-style-guide/word-list/r.md) — Word list entries for terms beginning with R.
* **Creation**: Added [word-list/s.md](/google-style-guide/word-list/s.md) — Word list entries for terms beginning with S.
* **Creation**: Added [word-list/t.md](/google-style-guide/word-list/t.md) — Word list entries for terms beginning with T.
* **Creation**: Added [word-list/u.md](/google-style-guide/word-list/u.md) — Word list entries for terms beginning with U.
* **Creation**: Added [word-list/v.md](/google-style-guide/word-list/v.md) — Word list entries for terms beginning with V.
* **Creation**: Added [word-list/w.md](/google-style-guide/word-list/w.md) — Word list entries for terms beginning with W.
* **Creation**: Added [word-list/y.md](/google-style-guide/word-list/y.md) — Word list entries for terms beginning with Y.
* **Creation**: Added [word-list/z.md](/google-style-guide/word-list/z.md) — Word list entries for terms beginning with Z.
* **Creation**: Added [Product names](/google-style-guide/product-names.md) — Guidelines for capitalizing, shortening, and using product names in Google documentation.
* **Creation**: Added [Text-formatting summary](/google-style-guide/text-formatting-summary.md) — Quick reference for text-formatting conventions including bold, italic, code font, capitalization, and quotation marks.

* **Creation**: Added [Philosophy of this guide](/google-style-guide/philosophy.md) — Principles and philosophy behind the Google Developer Documentation Style Guide.
* **Creation**: Added [General principles/](/google-style-guide/general-principles/) — Foundational guidelines for accessibility, inclusivity, tone, and other core principles (10 pages).
* **Creation**: Added [Language and grammar/](/google-style-guide/language-and-grammar/) — Rules for abbreviations, voice, capitalization, pronouns, and other grammar topics (14 pages).
* **Creation**: Added [Punctuation/](/google-style-guide/punctuation/) — Guidance on colons, commas, dashes, hyphens, periods, and other punctuation (10 pages).
* **Creation**: Added [formatting-and-organization/](/google-style-guide/formatting-and-organization/) — Standards for lists, tables, headings, dates, numbers, and other formatting (15 pages).
* **Creation**: Added [Linking/](/google-style-guide/linking/) — Cross-references, descriptive link text, and link targets (2 pages).
* **Creation**: Added [Computer interfaces/](/google-style-guide/computer-interfaces/) — Code in text, code samples, command-line syntax, and UI elements (6 pages).
* **Creation**: Added [HTML and CSS/](/google-style-guide/html-and-css/) — HTML semantic tagging, formatting, and Markdown versus HTML (3 pages).
* **Creation**: Added [Names and naming/](/google-style-guide/names-and-naming/) — Example domains, names, filenames, and trademarks (3 pages).
